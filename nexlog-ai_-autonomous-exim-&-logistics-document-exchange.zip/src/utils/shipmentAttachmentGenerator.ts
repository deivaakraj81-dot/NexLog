import { ShipmentNotification } from "../types/notifications";

/**
 * Generates an official, printable Maritime Arrival Notice & Customs Clearance Dossier (.html/.pdf)
 * and triggers immediate local file download.
 */
export function downloadArrivalNoticeAttachment(notification: ShipmentNotification): void {
  const {
    containerNo,
    blNumber,
    vesselName,
    voyage,
    port,
    terminal,
    milestone,
    timestamp,
    details,
    recipientEmail,
    recipientPhone,
  } = notification;

  const htmlContent = `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Arrival Notice & Clearance Dossier - ${containerNo}</title>
  <style>
    @page { size: A4; margin: 15mm; }
    body {
      font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif;
      color: #0f172a;
      background: #f8fafc;
      padding: 24px;
      margin: 0;
    }
    .container {
      max-width: 800px;
      margin: 0 auto;
      background: #ffffff;
      padding: 32px;
      border: 1px solid #cbd5e1;
      border-radius: 12px;
      box-shadow: 0 4px 14px rgba(0,0,0,0.06);
    }
    .header-bar {
      display: flex;
      justify-content: space-between;
      align-items: flex-start;
      border-bottom: 2px solid #0098db;
      padding-bottom: 18px;
      margin-bottom: 24px;
    }
    .brand-title {
      color: #0098db;
      font-size: 24px;
      font-weight: 800;
      letter-spacing: -0.5px;
      margin: 0;
    }
    .subhead {
      color: #64748b;
      font-size: 12px;
      margin-top: 4px;
    }
    .badge {
      display: inline-block;
      padding: 6px 14px;
      background: #ecfdf5;
      color: #059669;
      border: 1px solid #a7f3d0;
      border-radius: 999px;
      font-size: 11px;
      font-weight: bold;
      text-transform: uppercase;
    }
    .section-title {
      font-size: 12px;
      font-weight: 800;
      text-transform: uppercase;
      letter-spacing: 0.8px;
      color: #475569;
      border-bottom: 1px solid #e2e8f0;
      padding-bottom: 6px;
      margin: 20px 0 12px 0;
    }
    .grid {
      display: grid;
      grid-template-columns: repeat(2, 1fr);
      gap: 12px;
      font-size: 13px;
    }
    .grid-cell {
      background: #f8fafc;
      padding: 10px 14px;
      border-radius: 8px;
      border: 1px solid #e2e8f0;
    }
    .label {
      color: #64748b;
      font-size: 10px;
      text-transform: uppercase;
      font-weight: 700;
      margin-bottom: 2px;
    }
    .val {
      font-weight: 700;
      color: #0f172a;
    }
    .highlight-cell {
      background: #f0fdf4;
      border-color: #86efac;
    }
    .barcode-box {
      text-align: center;
      background: #f8fafc;
      border: 2px dashed #94a3b8;
      border-radius: 8px;
      padding: 16px;
      margin: 24px 0 16px 0;
    }
    .barcode {
      font-family: 'Courier New', monospace;
      font-size: 28px;
      letter-spacing: 5px;
      font-weight: 900;
      color: #0f172a;
      margin: 6px 0;
    }
    .footer-note {
      font-size: 11px;
      color: #64748b;
      text-align: center;
      border-top: 1px solid #e2e8f0;
      padding-top: 14px;
      margin-top: 24px;
    }
    .btn-print {
      background: #0098db;
      color: white;
      border: none;
      padding: 8px 16px;
      border-radius: 6px;
      font-weight: bold;
      cursor: pointer;
      font-size: 12px;
      margin-bottom: 16px;
    }
    @media print {
      body { background: white; padding: 0; }
      .container { border: none; box-shadow: none; padding: 0; }
      .btn-print { display: none !important; }
    }
  </style>
</head>
<body>
  <div class="container">
    <div style="text-align: right;">
      <button class="btn-print" onclick="window.print()">Print / Save as PDF</button>
    </div>

    <div class="header-bar">
      <div>
        <h1 class="brand-title">Sudarsen Cargo Pvt Ltd</h1>
        <div class="subhead">Autonomous Port Community Exchange (PCS 1x) • Official Cargo Arrival Notice</div>
        <div class="subhead">Consignee Representative: <strong>John Lanny</strong> (PRN 100653)</div>
      </div>
      <div style="text-align: right;">
        <span class="badge">● SHIPMENT ARRIVED & CLEARED</span>
        <div class="subhead" style="margin-top: 6px;">Notice Ref: <strong>AN-${containerNo}-${Date.now().toString().slice(-6)}</strong></div>
        <div class="subhead">Dispatched: <strong>${timestamp}</strong></div>
      </div>
    </div>

    <div class="section-title">Maritime Shipment & Container Telematics</div>
    <div class="grid">
      <div class="grid-cell highlight-cell">
        <div class="label">Container Number</div>
        <div class="val" style="font-size: 16px; font-family: monospace; color: #0284c7;">${containerNo}</div>
      </div>
      <div class="grid-cell">
        <div class="label">Ocean Bill of Lading (Master BL)</div>
        <div class="val" style="font-family: monospace;">${blNumber}</div>
      </div>
      <div class="grid-cell">
        <div class="label">Carrying Vessel & Voyage</div>
        <div class="val">${vesselName} (Voy ${voyage})</div>
      </div>
      <div class="grid-cell">
        <div class="label">Shipping Liner / Ocean Carrier</div>
        <div class="val">${details.carrier}</div>
      </div>
      <div class="grid-cell">
        <div class="label">Destination Port</div>
        <div class="val">${port}</div>
      </div>
      <div class="grid-cell">
        <div class="label">Quayside Terminal & Berth</div>
        <div class="val">${terminal} (${details.berthSlot})</div>
      </div>
    </div>

    <div class="section-title">Customs Status & Verified Weights</div>
    <div class="grid">
      <div class="grid-cell highlight-cell">
        <div class="label">ICEGATE Customs Clearance</div>
        <div class="val" style="color: #059669;">${details.customsStatus}</div>
      </div>
      <div class="grid-cell">
        <div class="label">Active Milestone</div>
        <div class="val">${milestone}</div>
      </div>
      <div class="grid-cell">
        <div class="label">Verified Gross Mass (VGM)</div>
        <div class="val">${details.grossWeightKg.toLocaleString()} KG (Tare: ${details.tareWeightKg} KG)</div>
      </div>
      <div class="grid-cell">
        <div class="label">High Security Seal No</div>
        <div class="val" style="font-family: monospace;">${details.sealNumber} (SOLAS Pass)</div>
      </div>
    </div>

    <div class="section-title">Recipient & Delivery Dispatch Information</div>
    <div class="grid">
      <div class="grid-cell">
        <div class="label">Dispatched to Mail ID</div>
        <div class="val" style="font-family: monospace;">${recipientEmail}</div>
      </div>
      <div class="grid-cell">
        <div class="label">Dispatched to WhatsApp</div>
        <div class="val" style="font-family: monospace;">${recipientPhone}</div>
      </div>
    </div>

    <div class="barcode-box">
      <div style="font-size: 11px; font-weight: bold; color: #64748b; letter-spacing: 1px;">
        TERMINAL BOOM BARRIER OUT-GATE PASS BARCODE
      </div>
      <div class="barcode">||| | ||||| || |||| ||||| |||</div>
      <div style="font-size: 12px; font-weight: bold; color: #334155;">*${containerNo}-ARRIVED-2026*</div>
      <div style="font-size: 10px; color: #94a3b8; margin-top: 4px;">
        Scan at port terminal gate to authorize trailer exit without physical paperwork
      </div>
    </div>

    <div class="footer-note">
      This document constitutes an official Arrival Notice generated autonomously by Sudarsen Cargo Pvt Ltd in accordance with Indian Customs ICEGATE, Major Ports Trust Acts, and PCS 1x EDI standards.
      <br>Contact Support: <strong>+91 9863 122 122</strong> | Desk: <strong>support@sudarsencargo.com</strong>
    </div>
  </div>
</body>
</html>`;

  const blob = new Blob([htmlContent], { type: "text/html;charset=utf-8" });
  const url = URL.createObjectURL(blob);
  const link = document.createElement("a");
  link.href = url;
  const fileName = notification.attachmentName.endsWith(".pdf")
    ? notification.attachmentName.replace(/\.pdf$/, ".html")
    : `${notification.attachmentName}.html`;
  link.download = fileName;
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
  URL.revokeObjectURL(url);
}

/**
 * Downloads shipment manifest as CSV file
 */
export function downloadShipmentManifestCSV(notification: ShipmentNotification): void {
  const headers = [
    "Container No",
    "Master BL",
    "Vessel Name",
    "Voyage",
    "Liner",
    "Port",
    "Terminal",
    "Gross Weight (KG)",
    "Tare Weight (KG)",
    "Seal Number",
    "Customs Status",
    "Milestone",
    "Timestamp",
    "Consignee",
    "Contact Email",
    "WhatsApp Contact",
  ];

  const row = [
    notification.containerNo,
    notification.blNumber,
    notification.vesselName,
    notification.voyage,
    notification.details.carrier,
    notification.port,
    notification.terminal,
    notification.details.grossWeightKg,
    notification.details.tareWeightKg,
    notification.details.sealNumber,
    notification.details.customsStatus,
    notification.milestone,
    notification.timestamp,
    notification.details.consignee,
    notification.recipientEmail,
    notification.recipientPhone,
  ];

  const escapeCSV = (val: any) => `"${String(val ?? "").replace(/"/g, '""')}"`;
  const csvContent = "\uFEFF" + [headers.map(escapeCSV).join(","), row.map(escapeCSV).join(",")].join("\r\n");

  const blob = new Blob([csvContent], { type: "text/csv;charset=utf-8;" });
  const url = URL.createObjectURL(blob);
  const link = document.createElement("a");
  link.href = url;
  link.download = `Manifest_${notification.containerNo}.csv`;
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
  URL.revokeObjectURL(url);
}

/**
 * Formats and launches WhatsApp dispatch link
 */
export function triggerWhatsAppMessage(notification: ShipmentNotification, targetPhone?: string): string {
  const phone = (targetPhone || notification.recipientPhone).replace(/[^0-9]/g, "");
  const message = `*SUDARSEN CARGO PVT LTD - SHIPMENT ARRIVAL NOTICE*\n\n` +
    `Hello *John Lanny*,\n` +
    `Your container *${notification.containerNo}* (BL: *${notification.blNumber}*) has arrived at *${notification.port}*.\n\n` +
    `🚢 *Vessel*: ${notification.vesselName} (Voy ${notification.voyage})\n` +
    `📍 *Terminal*: ${notification.terminal}\n` +
    `📌 *Status*: ${notification.milestone}\n` +
    `🛡️ *Customs*: ${notification.details.customsStatus}\n` +
    `⚖️ *Gross Weight*: ${notification.details.grossWeightKg.toLocaleString()} KG\n` +
    `📎 *Attachment*: ${notification.attachmentName} (Available in your Sudarsen Cargo Portal Profile)\n\n` +
    `Boom Barrier Gate-Out Barcode Token: *${notification.containerNo}-ARRIVED-2026*\n\n` +
    `Need assistance? Call: +91 9863 122 122`;

  const encoded = encodeURIComponent(message);
  const waUrl = `https://wa.me/${phone}?text=${encoded}`;
  return waUrl;
}
