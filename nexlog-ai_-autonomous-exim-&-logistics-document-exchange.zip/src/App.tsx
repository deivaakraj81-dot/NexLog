/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from "react";
import { NexLogPortalHeader } from "./components/NexLogPortalHeader";
import { NexLogPortalNav, PortalNavTab } from "./components/NexLogPortalNav";
import { NexLogProcessCards } from "./components/NexLogProcessCards";
import { HblModule } from "./components/HblModule";
import { CfsDpdModule } from "./components/CfsDpdModule";
import { InvoiceModule } from "./components/InvoiceModule";
import { FloatingHelpWidget } from "./components/FloatingHelpWidget";
import { MetricCards } from "./components/MetricCards";
import { DocumentScanner } from "./components/DocumentScanner";
import { ApprovalQueue } from "./components/ApprovalQueue";
import { AuditLog } from "./components/AuditLog";
import { ArchitectureDiagram } from "./components/ArchitectureDiagram";
import { JsonViewer } from "./components/JsonViewer";
import { DossierModal } from "./components/DossierModal";
import { ToastContainer, ToastMessage } from "./components/Toast";
import { IntroLoginModal } from "./components/IntroLoginModal";
import { NexLogTopBar, NEXLOG_COUNTRIES, CountryNode } from "./components/OdexTopBar";
import { NexLogHeroBanner } from "./components/OdexHeroBanner";
import { NexLogServicesGrid } from "./components/OdexServicesGrid";
import { NexLogStakeholdersAndFooter } from "./components/OdexStakeholdersAndFooter";
import { InteractiveFeatureModals } from "./components/InteractiveFeatureModals";
import { InteractiveShipStream } from "./components/InteractiveShipStream";
import { LiveContainerTrackingModal } from "./components/LiveContainerTrackingModal";
import { ShipmentNotificationModal } from "./components/ShipmentNotificationModal";
import { UserProfileNotificationDrawer } from "./components/UserProfileNotificationDrawer";
import { UserProfileSpaceModal } from "./components/UserProfileSpaceModal";
import {
  PlatformSettingsModal,
  PlatformSettingsState,
  DEFAULT_PLATFORM_SETTINGS,
} from "./components/PlatformSettingsModal";
import {
  ShipmentNotification,
  UserNotificationPreferences,
  INITIAL_NOTIFICATIONS,
  DEFAULT_USER_PREFERENCES,
} from "./types/notifications";
import { CountryFlag } from "./components/CountryFlag";
import { INITIAL_QUEUE_ITEMS, INITIAL_AUDIT_LOGS } from "./data/sampleDocuments";
import { QueueItem, AuditLogItem, ShippingAuditResult } from "./types";
import {
  Ship,
  Sparkles,
  ArrowRight,
  ShieldCheck,
  Clock,
  Layers,
  ChevronRight,
  ExternalLink,
} from "lucide-react";

export default function App() {
  // Navigation State
  const [currentTab, setCurrentTab] = useState<PortalNavTab>("portal-home");
  const [selectedCountry, setSelectedCountry] = useState<CountryNode>(NEXLOG_COUNTRIES[0]);
  const [showIntroModal, setShowIntroModal] = useState<boolean>(true); // Logo pop-up open on initial load
  const [darkMode, setDarkMode] = useState<boolean>(false);
  const [activeFeatureModal, setActiveFeatureModal] = useState<string | null>(null);
  const [featureModalData, setFeatureModalData] = useState<any>(null);
  const [trackingModalOpen, setTrackingModalOpen] = useState<boolean>(false);
  const [trackingQuery, setTrackingQuery] = useState<string>("MSKU9182341");

  const handleOpenTracking = (query: string) => {
    setTrackingQuery(query);
    setTrackingModalOpen(true);
  };

  // User & Company Session State
  const [isLoggedIn, setIsLoggedIn] = useState<boolean>(true);
  const [userName, setUserName] = useState<string>("John Lanny");
  const [companyName, setCompanyName] = useState<string>("Sudarsen Cargo Pvt Ltd");
  const [currentUserRole, setCurrentUserRole] = useState<string>("Senior Logistics Manager & EXIM Authority");
  const [userEmail, setUserEmail] = useState<string>("deivaakraj81@gmail.com");
  const [userPhone, setUserPhone] = useState<string>("+91 9863 122 122");

  // Profile Space & Platform Settings Modals
  const [profileModalOpen, setProfileModalOpen] = useState<boolean>(false);
  const [settingsModalOpen, setSettingsModalOpen] = useState<boolean>(false);
  const [platformSettings, setPlatformSettings] = useState<PlatformSettingsState>(DEFAULT_PLATFORM_SETTINGS);

  // Shipment Notifications & Profile Alerts State
  const [notifications, setNotifications] = useState<ShipmentNotification[]>(INITIAL_NOTIFICATIONS);
  const [userPreferences, setUserPreferences] = useState<UserNotificationPreferences>(DEFAULT_USER_PREFERENCES);
  const [profileDrawerOpen, setProfileDrawerOpen] = useState<boolean>(false);
  const [notificationModalOpen, setNotificationModalOpen] = useState<boolean>(false);
  const [notificationTarget, setNotificationTarget] = useState<any>({
    containerNo: "MSKU9182341",
    blNumber: "MAEU98214470",
    vesselName: "M/V SUDARSEN TITAN",
    port: "Nhava Sheva (JNPT)",
    terminal: "APM Terminals Berth 04",
    status: "Container Discharged Quayside & Customs OOC Granted",
  });

  const handleOpenNotificationModalWithContainer = (record?: any) => {
    if (record) {
      setNotificationTarget({
        containerNo: record.containerNo || "MSKU9182341",
        blNumber: record.blNumber || "MAEU98214470",
        vesselName: record.vesselName || "M/V SUDARSEN TITAN",
        port: record.destPort || "Nhava Sheva (JNPT)",
        terminal: record.terminalBerth || "APM Terminals Berth 04",
        status: record.currentStatus || "Container Discharged Quayside & Customs OOC Granted",
      });
    }
    setNotificationModalOpen(true);
  };

  const handleSaveNotification = (
    newNotif: ShipmentNotification,
    options: { sendEmail: boolean; sendWhatsApp: boolean; saveToProfile: boolean }
  ) => {
    if (options.saveToProfile) {
      setNotifications((prev) => [newNotif, ...prev]);
    }
  };

  const handleMarkAsRead = (id: string) => {
    setNotifications((prev) =>
      prev.map((n) => (n.id === id ? { ...n, read: true } : n))
    );
  };

  const handleMarkAllAsRead = () => {
    setNotifications((prev) => prev.map((n) => ({ ...n, read: true })));
  };

  const handleUpdatePreferences = (prefs: Partial<UserNotificationPreferences>) => {
    setUserPreferences((prev) => ({ ...prev, ...prefs }));
  };

  // Operational State
  const [queueItems, setQueueItems] = useState<QueueItem[]>(INITIAL_QUEUE_ITEMS);
  const [auditLogs, setAuditLogs] = useState<AuditLogItem[]>(INITIAL_AUDIT_LOGS);
  const [totalUploaded, setTotalUploaded] = useState<number>(142);
  const [accuracy, setAccuracy] = useState<number>(98.4);
  const [timeSavedHours, setTimeSavedHours] = useState<number>(84);
  const [latestAuditResult, setLatestAuditResult] = useState<ShippingAuditResult | null>(
    INITIAL_QUEUE_ITEMS[0].auditResult
  );
  const [inspectedItem, setInspectedItem] = useState<QueueItem | null>(null);
  const [toasts, setToasts] = useState<ToastMessage[]>([]);

  // Pending items count
  const pendingCount = queueItems.filter((i) => i.status === "PENDING_APPROVAL").length;

  // Add toast helper
  const addToast = (type: "success" | "warning" | "error" | "info", title: string, message: string) => {
    const id = `toast-${Date.now()}-${Math.random()}`;
    const newToast: ToastMessage = { id, type, title, message };
    setToasts((prev) => [...prev, newToast]);

    setTimeout(() => {
      setToasts((prev) => prev.filter((t) => t.id !== id));
    }, 4500);
  };

  const dismissToast = (id: string) => {
    setToasts((prev) => prev.filter((t) => t.id !== id));
  };

  // Handler: When a document is audited in the Scanner
  const handleAuditComplete = (result: ShippingAuditResult, rawText: string) => {
    setLatestAuditResult(result);
    setTotalUploaded((prev) => prev + 1);
    setTimeSavedHours((prev) => +(prev + 0.6).toFixed(1));

    const newLog: AuditLogItem = {
      id: `log-${Date.now()}`,
      timestamp: new Date().toISOString().replace("T", " ").slice(0, 19),
      docId: result.metadata.documentNumber || "DOC-NEW",
      containerId: result.metadata.containerId || "CONTAINER-PENDING",
      action: result.riskAssessment.riskScore > 60 ? "SOLAS_FLAGGED" : "AI_SCANNED",
      actor: "Google Gemini (gemini-3.8-flash)",
      riskScore: result.riskAssessment.riskScore,
      notes: `Autonomous AI audit completed: ${result.documentClassification} classified with ${result.confidenceScore}% confidence.`,
      hash: `0x${Math.random().toString(16).substring(2, 6)}...${Math.random().toString(16).substring(2, 6)}`,
    };

    setAuditLogs((prev) => [newLog, ...prev]);

    addToast(
      result.riskAssessment.riskScore > 60 ? "warning" : "success",
      `Document Audited: ${result.documentClassification}`,
      `Risk Score: ${result.riskAssessment.riskScore}/100 • Recommendation: ${result.riskAssessment.recommendedAction}`
    );
  };

  // Handler: Add audited document from Scanner into Queue
  const handleSendToQueue = (item: QueueItem) => {
    setQueueItems((prev) => [item, ...prev]);
    addToast(
      "info",
      `Added to Approval Queue`,
      `Document ${item.docId} (${item.containerId}) is awaiting Manager Gate Sign-Off.`
    );
  };

  // Handler: Manager Approves Document
  const handleApprove = (item: QueueItem) => {
    setQueueItems((prev) =>
      prev.map((i) =>
        i.id === item.id
          ? {
              ...i,
              status: "VERIFIED_DISPATCHED",
              dispatchedAt: new Date().toLocaleTimeString(),
              gatePassBarcode: `${item.containerId}-GATE-PASS`,
            }
          : i
      )
    );

    setTimeSavedHours((prev) => +(prev + 0.6).toFixed(1));

    const newLog: AuditLogItem = {
      id: `log-${Date.now()}`,
      timestamp: new Date().toISOString().replace("T", " ").slice(0, 19),
      docId: item.docId,
      containerId: item.containerId,
      action: "PORT_GATE_DISPATCHED",
      actor: currentUserRole,
      riskScore: item.riskScore,
      notes: `Approved & Dispatched to Port Gate. PCS 1x EDIFACT CUSCAR manifest generated. Boom Barrier pass issued.`,
      hash: `0x${Math.random().toString(16).substring(2, 6)}...${Math.random().toString(16).substring(2, 6)}`,
    };
    setAuditLogs((prev) => [newLog, ...prev]);

    addToast(
      "success",
      `Verified & Dispatched to Port Gate`,
      `Document ${item.docId} (${item.containerId}) cleared! Boom barrier barcode generated & dispatched via PCS 1x.`
    );
  };

  // Handler: Manager Rejects Document
  const handleReject = (item: QueueItem, reason: string) => {
    setQueueItems((prev) =>
      prev.map((i) =>
        i.id === item.id
          ? {
              ...i,
              status: "REJECTED",
              rejectionReason: reason,
            }
          : i
      )
    );

    const newLog: AuditLogItem = {
      id: `log-${Date.now()}`,
      timestamp: new Date().toISOString().replace("T", " ").slice(0, 19),
      docId: item.docId,
      containerId: item.containerId,
      action: "MANAGER_REJECTED",
      actor: currentUserRole,
      riskScore: item.riskScore,
      notes: `Rejected by Gate Manager. Reason: ${reason}`,
      hash: `0x${Math.random().toString(16).substring(2, 6)}...${Math.random().toString(16).substring(2, 6)}`,
    };
    setAuditLogs((prev) => [newLog, ...prev]);

    addToast(
      "error",
      `Document Rejected: ${item.docId}`,
      `Non-compliance notice dispatched to ${item.shipper} via NexLog Electronic Data Interchange.`
    );
  };

  // Handler: Batch Approve Low Risk
  const handleBatchApproveLowRisk = () => {
    const lowRiskPending = queueItems.filter(
      (i) => i.status === "PENDING_APPROVAL" && i.riskLevel === "LOW"
    );

    if (lowRiskPending.length === 0) return;

    setQueueItems((prev) =>
      prev.map((i) =>
        i.status === "PENDING_APPROVAL" && i.riskLevel === "LOW"
          ? {
              ...i,
              status: "VERIFIED_DISPATCHED",
              dispatchedAt: new Date().toLocaleTimeString(),
              gatePassBarcode: `${i.containerId}-GATE-PASS`,
            }
          : i
      )
    );

    lowRiskPending.forEach((item) => {
      const newLog: AuditLogItem = {
        id: `log-${Date.now()}-${item.id}`,
        timestamp: new Date().toISOString().replace("T", " ").slice(0, 19),
        docId: item.docId,
        containerId: item.containerId,
        action: "PORT_GATE_DISPATCHED",
        actor: "Batch STP Gate Engine",
        riskScore: item.riskScore,
        notes: `Straight-Through Processing (STP) batch authorization: zero discrepancies detected.`,
        hash: `0x${Math.random().toString(16).substring(2, 6)}...${Math.random().toString(16).substring(2, 6)}`,
      };
      setAuditLogs((prev) => [newLog, ...prev]);
    });

    addToast(
      "success",
      `Batch STP Gate Approval Complete`,
      `${lowRiskPending.length} low-risk documents verified & dispatched directly to terminal gate.`
    );
  };

  // Open feature modals
  const handleOpenFeatureModal = (key: string, data?: any) => {
    setActiveFeatureModal(key);
    setFeatureModalData(data || null);
  };

  // Process card click execution
  const handleProcessCardExecution = (target: string, port: string, cardTitle: string) => {
    addToast(
      "info",
      `${cardTitle} Initiated`,
      `Routing to ${cardTitle} operational desk for ${port} Terminal.`
    );
    if (target === "cfs-search") setCurrentTab("cfs-search");
    else if (target === "invoice-search") setCurrentTab("invoice-search");
    else if (target === "hbl-search") setCurrentTab("hbl-search");
    else if (target === "scanner") setCurrentTab("scanner");
  };

  return (
    <div className={`min-h-screen ${darkMode ? "bg-slate-950 text-slate-100" : "bg-[#f4f7fa] text-slate-900"} flex flex-col font-sans transition-colors duration-200`}>
      {/* 1. Authentic Top Cyan Header (Matching Screenshot 1) */}
      <NexLogPortalHeader
        darkMode={darkMode}
        onToggleDarkMode={() => setDarkMode(!darkMode)}
        onHomeClick={() => setCurrentTab("portal-home")}
        onSupportClick={() => {
          addToast("info", "NexLog 24/7 Desk", "Emergency Gate: +91 8828 822 244 | support@nexlogglobal.com");
        }}
        onSettingsClick={() => setSettingsModalOpen(true)}
        onOpenAiScanner={() => setCurrentTab("scanner")}
        selectedCountry={selectedCountry}
        onSelectCountry={(c) => {
          setSelectedCountry(c);
          addToast("info", `Active Terminal: ${c.name}`, `Terminal set to ${c.terminal} (${c.currencyCode} ${c.currencySymbol.trim()})`);
        }}
        onOpenIntroModal={() => setShowIntroModal(true)}
        isLoggedIn={isLoggedIn}
        userName={userName}
        companyName={companyName}
        onLogin={() => setShowIntroModal(true)}
        onLogout={() => {
          setIsLoggedIn(false);
          addToast("info", "Logged Out", `Signed out of ${companyName} session.`);
        }}
        unreadNotificationCount={notifications.filter((n) => !n.read).length}
        onOpenProfileNotifications={() => setProfileDrawerOpen(true)}
        onOpenProfile={() => setProfileModalOpen(true)}
      />

      {/* 2. Top Navigation Bar & Harbor Backdrop Search Bar (Matching Screenshots 1 & 5) */}
      <NexLogPortalNav
        currentTab={currentTab}
        onSelectTab={(tab) => setCurrentTab(tab)}
        onSearchMbl={(query) => {
          handleOpenTracking(query);
          addToast("info", "Search Executed", `Searching Port Community records for '${query}'`);
        }}
        onOpenTracking={handleOpenTracking}
        pendingQueueCount={pendingCount}
      />

      {/* 3. Main Workspace Views */}
      <main className="flex-1 w-full pb-16">
        {/* VIEW 1: Portal Home Dashboard (Screenshots 1, 2, 3, 4) */}
        {currentTab === "portal-home" && (
          <div className="space-y-6">
            {/* 6 Process Cards (Counter, ePayment, eSB, eForm13, eHBL, eVGM) with local country currency */}
            <NexLogProcessCards
              onExecuteProcess={handleProcessCardExecution}
              currencySymbol={selectedCountry.currencySymbol}
            />

            {/* Cinematic Interactive Ship Video Stream & Live AIS Telematics */}
            <div className="max-w-7xl mx-auto px-4 sm:px-6">
              <InteractiveShipStream
                companyName={companyName}
                userName={userName}
                country={selectedCountry}
                onNavigateToInvoice={() => setCurrentTab("invoice-search")}
                onNavigateToScanner={() => setCurrentTab("scanner")}
                onNavigateToQueue={() => setCurrentTab("queue")}
                onAddToast={addToast}
              />
            </div>

            {/* Metrics & Operations Section */}
            <div className="max-w-7xl mx-auto px-4 sm:px-6 space-y-6">
              {/* Top 4 Required Metric Cards */}
              <MetricCards
                totalUploaded={totalUploaded}
                accuracy={accuracy}
                pendingApprovals={pendingCount}
                timeSavedHours={timeSavedHours}
                onNavigateToQueue={() => setCurrentTab("queue")}
                onNavigateToScanner={() => setCurrentTab("scanner")}
              />

              {/* Operations Control Center Grid */}
              <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
                {/* Left: AI Gateway */}
                <div className="lg:col-span-7 p-6 rounded-2xl bg-white border border-slate-200 shadow-sm space-y-5">
                  <div className="flex items-center justify-between pb-3 border-b border-slate-100">
                    <div className="flex items-center gap-2.5">
                      <div className="p-2 rounded-xl bg-sky-50 text-[#0098db] border border-sky-200">
                        <Sparkles className="w-5 h-5" />
                      </div>
                      <div>
                        <h3 className="text-sm font-bold text-slate-800 tracking-tight">
                          Autonomous AI Intake Gateway (Google Gemini 3.8 Flash)
                        </h3>
                        <p className="text-xs text-slate-500">
                          Solve paper delays by auditing Bill of Lading, VGM & Customs passes before manager sign-off
                        </p>
                      </div>
                    </div>
                    <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-emerald-100 text-emerald-800 font-bold">
                      Zero-Paper Gate
                    </span>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                    <button
                      onClick={() => setCurrentTab("scanner")}
                      className="p-3.5 rounded-xl bg-slate-50 border border-slate-200 hover:border-sky-400 hover:bg-sky-50/50 transition-all text-left cursor-pointer group"
                    >
                      <span className="text-[10px] font-bold uppercase tracking-wider text-sky-600 block mb-1">
                        Ocean Freight
                      </span>
                      <div className="text-xs font-bold text-slate-800 group-hover:text-sky-700">
                        Audit Bill of Lading
                      </div>
                      <p className="text-[11px] text-slate-500 mt-1">
                        Verify container ID, vessel name, and seal ISO 17712.
                      </p>
                    </button>

                    <button
                      onClick={() => setCurrentTab("scanner")}
                      className="p-3.5 rounded-xl bg-slate-50 border border-slate-200 hover:border-emerald-400 hover:bg-emerald-50/50 transition-all text-left cursor-pointer group"
                    >
                      <span className="text-[10px] font-bold uppercase tracking-wider text-emerald-600 block mb-1">
                        IMO SOLAS VI
                      </span>
                      <div className="text-xs font-bold text-slate-800 group-hover:text-emerald-700">
                        Verify VGM Certificate
                      </div>
                      <p className="text-[11px] text-slate-500 mt-1">
                        Compute tare vs gross weights within ±5% tolerance.
                      </p>
                    </button>

                    <button
                      onClick={() => setCurrentTab("scanner")}
                      className="p-3.5 rounded-xl bg-slate-50 border border-slate-200 hover:border-rose-400 hover:bg-rose-50/50 transition-all text-left cursor-pointer group"
                    >
                      <span className="text-[10px] font-bold uppercase tracking-wider text-rose-600 block mb-1">
                        Discrepancy Test
                      </span>
                      <div className="text-xs font-bold text-slate-800 group-hover:text-rose-700">
                        Test Damaged Form 13
                      </div>
                      <p className="text-[11px] text-slate-500 mt-1">
                        Simulate overweight container and missing seal alert.
                      </p>
                    </button>
                  </div>

                  <div className="flex items-center justify-between pt-2">
                    <div className="flex items-center gap-2 text-xs text-slate-500">
                      <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse"></span>
                      <span>Average AI Audit Latency: <strong className="text-slate-800 font-mono">390 ms</strong></span>
                    </div>

                    <button
                      onClick={() => setCurrentTab("scanner")}
                      className="flex items-center gap-2 px-4 py-2 rounded-lg bg-[#0098db] hover:bg-[#0086c2] text-white text-xs font-bold shadow-sm transition-all cursor-pointer"
                    >
                      <span>Open Document Scanner</span>
                      <ArrowRight className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>

                {/* Right: Real-time Terminal Operations Feed */}
                <div className="lg:col-span-5 p-6 rounded-2xl bg-white border border-slate-200 shadow-sm space-y-4">
                  <div className="flex items-center justify-between pb-3 border-b border-slate-100">
                    <div className="flex items-center gap-2 text-xs font-bold uppercase tracking-wider text-slate-700">
                      <Ship className="w-4 h-4 text-[#0098db]" />
                      <span>Live Terminal Operations (JNPT / Mundra)</span>
                    </div>
                    <span className="text-[10px] text-sky-600 font-mono font-bold">PCS 1x Live</span>
                  </div>

                  <div className="space-y-2.5">
                    <div className="p-3 rounded-lg bg-slate-50 border border-slate-200 flex items-center justify-between text-xs">
                      <div>
                        <div className="font-bold text-slate-800">Berth 04B - TIM S</div>
                        <div className="text-[11px] text-slate-500 font-mono">Voy 043E • Cutoff: 4h 12m</div>
                      </div>
                      <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-sky-100 text-[#0098db]">
                        GTI Terminal
                      </span>
                    </div>

                    <div className="p-3 rounded-lg bg-slate-50 border border-slate-200 flex items-center justify-between text-xs">
                      <div>
                        <div className="font-bold text-slate-800">Berth 02A - MSC OSCAR</div>
                        <div className="text-[11px] text-slate-500 font-mono">Voy 2611W • MSC Mediterranean</div>
                      </div>
                      <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-emerald-100 text-emerald-800">
                        NSICT Gate
                      </span>
                    </div>

                    <div className="p-3 rounded-lg bg-slate-50 border border-slate-200 flex items-center justify-between text-xs">
                      <div>
                        <div className="font-bold text-slate-800">Gate-In Boom Barrier 01</div>
                        <div className="text-[11px] text-emerald-600 font-mono">RFID / OCR Automation Active</div>
                      </div>
                      <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-emerald-100 text-emerald-800">
                        OPEN
                      </span>
                    </div>
                  </div>

                  <div className="p-3 rounded-lg bg-slate-50 border border-slate-200 text-[11px] text-slate-500 flex items-center justify-between">
                    <span>Straight-Through Rate (STP):</span>
                    <span className="font-bold text-emerald-600 font-mono">78.4%</span>
                  </div>
                </div>
              </div>

              {/* Pending Approval Queue Quick Glance */}
              <div className="p-6 rounded-2xl bg-white border border-slate-200 shadow-sm space-y-4">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <div className="p-1.5 rounded-lg bg-amber-100 text-amber-700">
                      <Clock className="w-4 h-4" />
                    </div>
                    <div>
                      <h3 className="text-sm font-bold text-slate-800 tracking-tight">
                        Pending Manager Approval Queue (Human-in-the-Loop)
                      </h3>
                      <p className="text-xs text-slate-500">
                        {pendingCount} documents currently require human superintendent sign-off before port gate dispatch.
                      </p>
                    </div>
                  </div>

                  <button
                    onClick={() => setCurrentTab("queue")}
                    className="flex items-center gap-1.5 text-xs font-bold text-[#0098db] hover:text-[#0086c2] transition-colors cursor-pointer"
                  >
                    <span>View Full Queue</span>
                    <ChevronRight className="w-4 h-4" />
                  </button>
                </div>

                {/* Quick Row Preview */}
                <div className="space-y-2">
                  {queueItems
                    .filter((i) => i.status === "PENDING_APPROVAL")
                    .slice(0, 3)
                    .map((item) => (
                      <div
                        key={item.id}
                        className="p-3 rounded-xl bg-slate-50 border border-slate-200 flex flex-wrap items-center justify-between gap-3 text-xs"
                      >
                        <div className="flex items-center gap-3">
                          <span className="font-mono font-bold text-slate-900">{item.docId}</span>
                          <span className="text-slate-400">•</span>
                          <span className="font-semibold text-slate-700">{item.documentType}</span>
                          <span className="text-slate-400">•</span>
                          <span className="text-[#0098db] font-mono font-bold">{item.containerId}</span>
                          <span className="hidden sm:inline text-slate-500">({item.shipper})</span>
                        </div>

                        <div className="flex items-center gap-3">
                          <span
                            className={`px-2 py-0.5 rounded text-[10px] font-bold font-mono uppercase ${
                              item.riskLevel === "LOW"
                                ? "bg-emerald-100 text-emerald-800"
                                : item.riskLevel === "MEDIUM"
                                ? "bg-amber-100 text-amber-800"
                                : "bg-rose-100 text-rose-800"
                            }`}
                          >
                            Risk: {item.riskScore}/100 ({item.riskLevel})
                          </span>

                          <button
                            onClick={() => setInspectedItem(item)}
                            className="px-2.5 py-1 rounded-md bg-white border border-slate-300 hover:bg-slate-100 text-slate-700 text-xs font-semibold cursor-pointer"
                          >
                            Inspect
                          </button>

                          <button
                            onClick={() => handleApprove(item)}
                            className="px-3 py-1 rounded-md bg-[#10b981] hover:bg-[#059669] text-white text-xs font-bold shadow-xs cursor-pointer"
                          >
                            Approve
                          </button>
                        </div>
                      </div>
                    ))}
                </div>
              </div>
            </div>

            {/* Stakeholders & Corporate Footer */}
            <NexLogStakeholdersAndFooter
              onSelectAssociation={(name) => handleOpenFeatureModal("association", name)}
              onSelectWhatWeDo={(key) => handleOpenFeatureModal(key)}
              onOpenPolicy={(policy) => {
                addToast(
                  "info",
                  policy === "terms" ? "NexLog Terms & Conditions" : "Privacy & Policy",
                  "ISO 9001:2015 & ISO/IEC 27001 Certified EXIM Operations."
                );
              }}
              onAddToast={addToast}
            />
          </div>
        )}

        {/* VIEW 2: HBL Module (Screenshots 5, 7, 8, 9, 10) */}
        {(currentTab === "hbl-search" || currentTab === "hbl-create") && (
          <HblModule
            initialView={currentTab === "hbl-create" ? "create" : "search"}
            onAddToast={addToast}
            onOpenTracking={handleOpenTracking}
            onOpenScannerWithData={(data) => {
              setCurrentTab("scanner");
            }}
            isLoggedIn={isLoggedIn}
            userName={userName}
            companyName={companyName}
            onRequireLogin={() => setShowIntroModal(true)}
          />
        )}

        {/* VIEW 3: CFS / DPD / ICD Request Module (Screenshots 6, 11, 12, 13) */}
        {(currentTab === "cfs-search" || currentTab === "cfs-create") && (
          <CfsDpdModule
            initialView={currentTab === "cfs-create" ? "create" : "search"}
            onAddToast={addToast}
            isLoggedIn={isLoggedIn}
            userName={userName}
            companyName={companyName}
            onRequireLogin={() => setShowIntroModal(true)}
          />
        )}

        {/* VIEW 4: Invoice Module (Screenshots 15, 16) */}
        {(currentTab === "invoice-search" || currentTab === "invoice-create") && (
          <InvoiceModule
            initialView={currentTab === "invoice-create" ? "create" : "search"}
            onAddToast={addToast}
            country={selectedCountry}
            isLoggedIn={isLoggedIn}
            userName={userName}
            companyName={companyName}
            onRequireLogin={() => setShowIntroModal(true)}
          />
        )}

        {/* VIEW 5: Gemini Autonomous Intake Scanner */}
        {currentTab === "scanner" && (
          <div className="max-w-7xl mx-auto px-4 sm:px-6 py-6">
            <DocumentScanner
              onAuditComplete={handleAuditComplete}
              onSendToQueue={handleSendToQueue}
              onViewJson={(res) => {
                setLatestAuditResult(res);
                setCurrentTab("json-viewer");
              }}
            />
          </div>
        )}

        {/* VIEW 6: Manager Approval Queue (Human-in-the-Loop) */}
        {currentTab === "queue" && (
          <div className="max-w-7xl mx-auto px-4 sm:px-6 py-6">
            <ApprovalQueue
              queueItems={queueItems}
              onApprove={handleApprove}
              onReject={handleReject}
              onInspect={(item) => setInspectedItem(item)}
              onBatchApproveLowRisk={handleBatchApproveLowRisk}
            />
          </div>
        )}

        {/* VIEW 7: Audit Log */}
        {currentTab === "logs" && (
          <div className="max-w-7xl mx-auto px-4 sm:px-6 py-6">
            <AuditLog logs={auditLogs} />
          </div>
        )}

        {/* VIEW 8: System Architecture (Expo) */}
        {currentTab === "architecture" && (
          <div className="max-w-7xl mx-auto px-4 sm:px-6 py-6">
            <ArchitectureDiagram />
          </div>
        )}

        {/* VIEW 9: Raw Gemini JSON Inspector (Expo) */}
        {currentTab === "json-viewer" && (
          <div className="max-w-7xl mx-auto px-4 sm:px-6 py-6">
            <JsonViewer auditResult={latestAuditResult} />
          </div>
        )}

        {/* VIEW 10: Public Expo Landing View */}
        {currentTab === "public-home" && (
          <div className="space-y-0">
            <NexLogTopBar
              selectedCountry={selectedCountry}
              onSelectCountry={(c) => {
                setSelectedCountry(c);
                addToast("info", `Active Terminal: ${c.name}`, `Connected to ${c.terminal} (${c.currencyCode} ${c.currencySymbol.trim()}).`);
              }}
              onOpenLoginModal={() => setShowIntroModal(true)}
              onSelectService={(svc) => handleOpenFeatureModal(svc)}
              onNavigateTab={(tab) => {
                if (tab === "home") setCurrentTab("portal-home");
                else if (tab === "scanner") setCurrentTab("scanner");
                else if (tab === "contact") {
                  addToast("info", "NexLog Support", "Email: platinunmsupport@nexlogglobal.com | Call: +91 8828 822 244");
                }
              }}
              isLoggedIn={isLoggedIn}
              userName={userName}
              companyName={companyName}
              onLogout={() => {
                setIsLoggedIn(false);
                addToast("info", "Logged Out", `Signed out of ${companyName} session.`);
              }}
            />

            <NexLogHeroBanner
              onLearnMoreUae={() => handleOpenFeatureModal("uae-mpci")}
              onPlayVideo={() => handleOpenFeatureModal("uae-mpci")}
              onLaunchScanner={() => setCurrentTab("scanner")}
            />

            <NexLogServicesGrid
              onOpenService={(key) => handleOpenFeatureModal(key)}
            />

            <NexLogStakeholdersAndFooter
              onSelectAssociation={(name) => handleOpenFeatureModal("association", name)}
              onSelectWhatWeDo={(key) => handleOpenFeatureModal(key)}
              onOpenPolicy={(policy) => {
                addToast("info", "Policy", "ISO 9001:2015 & ISO/IEC 27001 Certified.");
              }}
              onAddToast={addToast}
            />
          </div>
        )}
      </main>

      {/* 4. Floating Right "HELP" Tab & Slide-Out Support Drawer (Matching Screenshots 1, 3, 5, 6) */}
      <FloatingHelpWidget
        onAddToast={addToast}
        onOpenNotifications={() => setProfileDrawerOpen(true)}
      />

      {/* 5. Intro Logo Pop-Up & Login Modal (Screenshots 1 & 2) */}
      <IntroLoginModal
        isOpen={showIntroModal}
        onClose={() => setShowIntroModal(false)}
        onLoginSuccess={(role, uName, cName) => {
          setIsLoggedIn(true);
          if (uName) setUserName(uName);
          if (cName) setCompanyName(cName);
          setCurrentUserRole(role);
          addToast(
            "success",
            "Welcome to NexLog AI",
            `Authenticated as ${uName || userName} (${cName || companyName}). Port clearance engine active.`
          );
          setCurrentTab("portal-home");
        }}
        onOpenBookDemo={() => {
          setShowIntroModal(false);
          handleOpenFeatureModal("demo");
        }}
      />

      {/* 6. Interactive Feature Modals */}
      <InteractiveFeatureModals
        activeModal={activeFeatureModal}
        modalData={featureModalData}
        onClose={() => setActiveFeatureModal(null)}
        onNavigateToScanner={() => setCurrentTab("scanner")}
        onNavigateToQueue={() => setCurrentTab("queue")}
      />

      {/* 7. Deep-Dive Inspection Dossier Modal */}
      <DossierModal
        item={inspectedItem}
        onClose={() => setInspectedItem(null)}
        onApprove={handleApprove}
        onReject={handleReject}
      />

      {/* Live Container Telematics & Milestones Tracking Modal */}
      <LiveContainerTrackingModal
        isOpen={trackingModalOpen}
        onClose={() => setTrackingModalOpen(false)}
        initialQuery={trackingQuery}
        country={selectedCountry}
        onNavigateToInvoice={() => setCurrentTab("invoice-search")}
        onNavigateToCfs={() => setCurrentTab("cfs-search")}
        onOpenNotificationSetup={(rec) => handleOpenNotificationModalWithContainer(rec)}
        onAddToast={addToast}
      />

      {/* Shipment Arrival & Milestone Notifications Setup Modal */}
      <ShipmentNotificationModal
        isOpen={notificationModalOpen}
        onClose={() => setNotificationModalOpen(false)}
        initialContainerNo={notificationTarget.containerNo}
        initialBlNumber={notificationTarget.blNumber}
        initialVesselName={notificationTarget.vesselName}
        initialPort={notificationTarget.port}
        initialTerminal={notificationTarget.terminal}
        initialStatus={notificationTarget.status}
        defaultEmail={userPreferences.email}
        defaultPhone={userPreferences.whatsappPhone}
        onSaveNotification={handleSaveNotification}
        onAddToast={addToast}
      />

      {/* User Profile & Notification Center Drawer */}
      <UserProfileNotificationDrawer
        isOpen={profileDrawerOpen}
        onClose={() => setProfileDrawerOpen(false)}
        userName={userName}
        companyName={companyName}
        notifications={notifications}
        onMarkAsRead={handleMarkAsRead}
        onMarkAllAsRead={handleMarkAllAsRead}
        onOpenTriggerModal={() => {
          setNotificationModalOpen(true);
        }}
        userPreferences={userPreferences}
        onUpdatePreferences={handleUpdatePreferences}
        onAddToast={addToast}
      />

      {/* Dedicated User Profile Space Modal (Triggered by clicking PRN 100653 / John Lanny) */}
      <UserProfileSpaceModal
        isOpen={profileModalOpen}
        onClose={() => setProfileModalOpen(false)}
        userName={userName}
        companyName={companyName}
        userRole={currentUserRole}
        userEmail={userEmail}
        userPhone={userPhone}
        onUpdateProfile={(updated) => {
          setUserName(updated.name);
          setCurrentUserRole(updated.role);
          setUserEmail(updated.email);
          setUserPhone(updated.phone);
          setUserPreferences((prev) => ({
            ...prev,
            email: updated.email,
            whatsappPhone: updated.phone,
          }));
        }}
        onLogout={() => {
          setIsLoggedIn(false);
          addToast("info", "Logged Out", `Signed out of ${companyName} session.`);
        }}
        onOpenNotifications={() => {
          setProfileModalOpen(false);
          setProfileDrawerOpen(true);
        }}
        onAddToast={addToast}
      />

      {/* Platform & EXIM Operations Settings Modal (Triggered by clicking Settings Gear) */}
      <PlatformSettingsModal
        isOpen={settingsModalOpen}
        onClose={() => setSettingsModalOpen(false)}
        settings={platformSettings}
        onUpdateSettings={(newSettings) => {
          setPlatformSettings(newSettings);
          setUserPreferences((prev) => ({
            ...prev,
            email: newSettings.defaultEmail,
            whatsappPhone: newSettings.defaultWhatsApp,
          }));
        }}
        selectedCountry={selectedCountry}
        onSelectCountry={(c) => {
          setSelectedCountry(c);
          addToast("info", `Active Terminal: ${c.name}`, `Terminal set to ${c.terminal} (${c.currencyCode} ${c.currencySymbol.trim()})`);
        }}
        onToggleDarkMode={() => setDarkMode(!darkMode)}
        onAddToast={addToast}
      />

      {/* 8. Toast Notifications */}
      <ToastContainer toasts={toasts} onDismiss={dismissToast} />
    </div>
  );
}
