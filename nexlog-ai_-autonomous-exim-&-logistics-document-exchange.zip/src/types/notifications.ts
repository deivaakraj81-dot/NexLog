export interface ShipmentNotification {
  id: string;
  containerNo: string;
  blNumber: string;
  vesselName: string;
  voyage: string;
  port: string;
  terminal: string;
  milestone: string;
  status: "ARRIVED" | "DISCHARGED" | "CUSTOMS_CLEARED" | "GATE_OUT_READY" | "IN_TRANSIT";
  timestamp: string;
  read: boolean;
  channelsSent: ("EMAIL" | "WHATSAPP" | "PROFILE")[];
  recipientEmail: string;
  recipientPhone: string;
  attachmentName: string;
  attachmentType: "PDF" | "DOSSIER" | "BARCODE_PASS" | "CSV";
  summary: string;
  details: {
    grossWeightKg: number;
    tareWeightKg: number;
    sealNumber: string;
    customsStatus: string;
    consignee: string;
    berthSlot: string;
    carrier: string;
  };
}

export interface UserNotificationPreferences {
  email: string;
  whatsappPhone: string;
  emailEnabled: boolean;
  whatsappEnabled: boolean;
  profileFeedEnabled: boolean;
  attachPdfDossier: boolean;
  attachGatePassBarcode: boolean;
  attachCsvManifest: boolean;
  notifyOnBerthing: boolean;
  notifyOnDischarge: boolean;
  notifyOnCustomsOoc: boolean;
  notifyOnGateOut: boolean;
}

export const DEFAULT_USER_PREFERENCES: UserNotificationPreferences = {
  email: "deivaakraj81@gmail.com",
  whatsappPhone: "+91 9863 122 122",
  emailEnabled: true,
  whatsappEnabled: true,
  profileFeedEnabled: true,
  attachPdfDossier: true,
  attachGatePassBarcode: true,
  attachCsvManifest: false,
  notifyOnBerthing: true,
  notifyOnDischarge: true,
  notifyOnCustomsOoc: true,
  notifyOnGateOut: true,
};

export const INITIAL_NOTIFICATIONS: ShipmentNotification[] = [
  {
    id: "notif-001",
    containerNo: "MSKU9182341",
    blNumber: "MAEU98214470",
    vesselName: "M/V SUDARSEN TITAN",
    voyage: "2611E",
    port: "Nhava Sheva (JNPT)",
    terminal: "APM Terminals Berth 04",
    milestone: "Container Discharged Quayside & Customs OOC Granted",
    status: "CUSTOMS_CLEARED",
    timestamp: "2026-11-03 06:15 IST",
    read: false,
    channelsSent: ["EMAIL", "WHATSAPP", "PROFILE"],
    recipientEmail: "deivaakraj81@gmail.com",
    recipientPhone: "+91 9863 122 122",
    attachmentName: "Arrival_Notice_MSKU9182341.pdf",
    attachmentType: "PDF",
    summary: "Shipment arrived and successfully discharged at Nhava Sheva. Customs Green Channel Out of Charge (OOC) granted.",
    details: {
      grossWeightKg: 28450,
      tareWeightKg: 3900,
      sealNumber: "ML-IN994812",
      customsStatus: "Green Channel OOC Cleared via ICEGATE",
      consignee: "Sudarsen Cargo Pvt Ltd",
      berthSlot: "Berth 04 / Yard Block 4-B",
      carrier: "MAERSK LINE",
    },
  },
  {
    id: "notif-002",
    containerNo: "KMTC8829104",
    blNumber: "KMTCXGG3096868",
    vesselName: "M/V KMTC DUBAI",
    voyage: "2610W",
    port: "Mundra Port (INMUN)",
    terminal: "DP World Terminal MICT",
    milestone: "Vessel Berthed at Quayside - Discharge Commenced",
    status: "ARRIVED",
    timestamp: "2026-11-02 23:30 IST",
    read: false,
    channelsSent: ["EMAIL", "WHATSAPP", "PROFILE"],
    recipientEmail: "deivaakraj81@gmail.com",
    recipientPhone: "+91 9863 122 122",
    attachmentName: "Arrival_Notice_KMTC8829104.pdf",
    attachmentType: "PDF",
    summary: "Vessel M/V KMTC DUBAI berthed at Mundra Port. Container discharge underway. Delivery Order generated.",
    details: {
      grossWeightKg: 26200,
      tareWeightKg: 3820,
      sealNumber: "KM-992104-A",
      customsStatus: "Bill of Entry Filed (BOE-2026-88192)",
      consignee: "Sudarsen Cargo Pvt Ltd",
      berthSlot: "Berth 02 (MICT)",
      carrier: "KMTC LINE",
    },
  },
  {
    id: "notif-003",
    containerNo: "MSCU1928374",
    blNumber: "MEDUAFW55891",
    vesselName: "M/V MSC MEDITERRANEAN",
    voyage: "8841S",
    port: "Chennai Port (INMAA)",
    terminal: "CITPL Enclave",
    milestone: "Authorized for CFS Transfer & Port Gate Out",
    status: "GATE_OUT_READY",
    timestamp: "2026-11-01 16:45 IST",
    read: true,
    channelsSent: ["EMAIL", "PROFILE"],
    recipientEmail: "deivaakraj81@gmail.com",
    recipientPhone: "+91 9863 122 122",
    attachmentName: "GatePass_Barcode_MSCU1928374.pdf",
    attachmentType: "BARCODE_PASS",
    summary: "CFS movement nominated to Sudarsen Cargo Logistics Hub. Boom barrier trailer exit token issued.",
    details: {
      grossWeightKg: 24100,
      tareWeightKg: 3750,
      sealNumber: "MSC-774912",
      customsStatus: "Out of Charge (OOC) Validated",
      consignee: "Sudarsen Cargo Pvt Ltd",
      berthSlot: "Gate 03 Evacuation Lane",
      carrier: "MSC MEDITERRANEAN",
    },
  },
];
