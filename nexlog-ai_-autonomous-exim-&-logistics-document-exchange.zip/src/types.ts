export type DocumentType =
  | "Bill of Lading"
  | "VGM Certificate"
  | "Form 13 Gate-In Permit"
  | "Commercial Invoice & Packing List"
  | "Customs Shipping Bill";

export type RiskLevel = "LOW" | "MEDIUM" | "HIGH";
export type Recommendation = "Approve" | "Needs Manual Review" | "Reject";

export interface ComplianceCheck {
  category: string;
  status: "PASS" | "WARN" | "FAIL";
  finding: string;
  regulation: string;
}

export interface WeightVerification {
  isPayloadValid: boolean;
  declaredGrossKg: number;
  calculatedSumKg: number;
  discrepancyKg: number;
  withinSolasTolerance: boolean;
}

export interface ShippingMetadata {
  documentNumber: string;
  containerId: string;
  shipperName: string;
  consigneeName: string;
  notifyParty: string;
  vesselName: string;
  voyageNumber: string;
  grossWeightKg: number;
  tareWeightKg: number;
  netWeightKg: number;
  portOfLoading: string;
  portOfDischarge: string;
  sealNumber: string;
  issueDate: string;
  hsCode: string;
  declaredValue: string;
}

export interface RiskAssessment {
  riskScore: number;
  riskLevel: RiskLevel;
  recommendedAction: Recommendation;
  summary: string;
  discrepancies: string[];
  complianceChecks: ComplianceCheck[];
  weightVerification: WeightVerification;
}

export interface ShippingAuditResult {
  documentClassification: string;
  confidenceScore: number;
  metadata: ShippingMetadata;
  riskAssessment: RiskAssessment;
  managerNotes: string;
  analyzedBy: string;
  timestamp: string;
  rawText?: string;
}

export interface QueueItem {
  id: string;
  docId: string;
  documentType: DocumentType | string;
  shipper: string;
  consignee: string;
  vessel: string;
  containerId: string;
  riskScore: number;
  riskLevel: RiskLevel;
  aiRecommendation: Recommendation;
  status: "PENDING_APPROVAL" | "VERIFIED_DISPATCHED" | "REJECTED";
  submittedAt: string;
  dispatchedAt?: string;
  rejectionReason?: string;
  auditResult: ShippingAuditResult;
  rawText: string;
  gatePassBarcode?: string;
}

export interface AuditLogItem {
  id: string;
  timestamp: string;
  docId: string;
  containerId: string;
  action: "AI_SCANNED" | "MANAGER_APPROVED" | "MANAGER_REJECTED" | "PORT_GATE_DISPATCHED" | "SOLAS_FLAGGED";
  actor: string;
  riskScore: number;
  notes: string;
  hash: string;
}
