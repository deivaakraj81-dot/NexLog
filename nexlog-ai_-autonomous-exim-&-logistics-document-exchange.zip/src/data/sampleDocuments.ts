export interface SampleDoc {
  id: string;
  name: string;
  badge: string;
  badgeColor: string;
  typeHint: string;
  description: string;
  content: string;
}

export const SAMPLE_DOCUMENTS: SampleDoc[] = [
  {
    id: "sample-bol",
    name: "Sample Bill of Lading",
    badge: "MSC Sea Waybill",
    badgeColor: "bg-blue-900/60 text-blue-300 border-blue-700/50",
    typeHint: "Bill of Lading",
    description: "Ocean Negotiable B/L for reefer pharmaceuticals from Nhava Sheva to Rotterdam.",
    content: `================================================================================
MEDITERRANEAN SHIPPING COMPANY (MSC) S.A. - GENEVA
NON-NEGOTIABLE OCEAN BILL OF LADING / SEA WAYBILL
================================================================================
B/L NUMBER: MSCU-NSA-8921044             BOOKING REF: BK-90218841
DATE OF ISSUE: 2026-10-28                 CARRIER CODE: MSCU

1. SHIPPER / EXPORTER:
   BHARAT AGRO-FOODS & EXIM PVT LTD
   PLOT 42-A, TTC INDUSTRIAL AREA, MIDC
   NAVI MUMBAI, MAHARASHTRA 400705, INDIA
   GSTIN: 27AABCB1234F1Z8 | IEC NO: 0312089441

2. CONSIGNEE:
   ROTTERDAM EUROGATE LOGISTICS B.V.
   MAASVLAKTE HAVEN 4200, 3008 AB ROTTERDAM
   THE NETHERLANDS | EORI: NL820491023

3. NOTIFY PARTY:
   BENELUX COLD CHAIN FREIGHT FORWARDING BV
   HAVEN SPOOR 12, ROTTERDAM PORT AUTHORITY

4. VESSEL & VOYAGE:
   OCEAN VESSEL: MSC OSCAR
   VOYAGE NO: 2611W
   CALL SIGN: 9HA3940 | IMO NO: 9703291

5. PORTS & PLACES:
   PORT OF LOADING (POL): INNSA - Nhava Sheva (JNPT Mumbai)
   PORT OF DISCHARGE (POD): NLRTM - Port of Rotterdam
   PLACE OF DELIVERY: Rotterdam Cold Distribution Hub 3

6. CONTAINER & CARGO PARTICULARS:
   CONTAINER NO: MSKU7291840 (40ft High Cube Reefer)
   CUSTOMS HIGH-SECURITY SEAL NO: SEAL-IN-98421 (ISO 17712 Compliant)
   GROSS CARGO WEIGHT: 26,450.00 KGS
   TARE WEIGHT: 3,950.00 KGS
   VERIFIED GROSS MASS (VGM): 30,400.00 KGS
   MEASUREMENT: 67.80 CBM

7. CARGO DESCRIPTION & HS TARIFF:
   1,420 CARTONS CERTIFIED ORGANIC BASMATI RICE & GRAINS
   TEMPERATURE CONTROLLED: AMBIENT (+18°C)
   HS CODE: 1006.30.20
   DECLARED COMMERCIAL VALUE: USD 142,500.00 CIF ROTTERDAM

8. FREIGHT & CHARGES:
   FREIGHT PREPAID AT MUMBAI
   SHIPPED ON BOARD DATE: 2026-10-29
================================================================================`,
  },
  {
    id: "sample-vgm",
    name: "Sample VGM Certificate",
    badge: "IMO SOLAS Verified",
    badgeColor: "bg-emerald-900/60 text-emerald-300 border-emerald-700/50",
    typeHint: "VGM Certificate",
    description: "Verified Gross Mass weighing certificate issued under SOLAS Chapter VI Method 1.",
    content: `================================================================================
INTERNATIONAL MARITIME ORGANIZATION (IMO) SOLAS CHAPTER VI REGULATION 2
VERIFIED GROSS MASS (VGM) WEIGHING CERTIFICATE
================================================================================
VGM CERTIFICATE NO: VGM-2026-INNSA-44910
WEIGHBRIDGE TICKET NO: WB-JNPT-09281
WEIGHING STATION: JNPT TERMINAL CALIBRATED WEIGHBRIDGE #4
GOVERNMENT ACCREDITATION NO: NABL/WB/2026/0912
DATE & TIME OF WEIGHING: 2026-10-31 09:14:22 IST

1. SHIPPER / PRINCIPAL DETAILS:
   RELIANCE PETROCHEM EXPORTS LIMITED
   RELIANCE GREENS, MOTIKHAVDI, JAMNAGAR, GUJARAT, INDIA
   AUTHORISED SIGNATORY: RAJESH VERMA (DIRECTOR - GLOBAL SUPPLY)

2. CONTAINER & SHIPPING IDENTIFIERS:
   CONTAINER NUMBER: HLCU8192047
   CONTAINER SIZE / TYPE: 40ft DRY VAN (45G1)
   MAX GROSS PAYLOAD RATING: 32,500 KG
   SHIPPING LINE: HAPAG-LLOYD AG
   BOOKING REFERENCE: HL-99410291
   VESSEL / VOYAGE: AL ZUBARA / 2644E
   PORT OF LOADING: INNSA (Nhava Sheva - GTI Terminal)
   PORT OF DISCHARGE: DEHAM (Port of Hamburg, Germany)

3. WEIGHING METHOD & MEASUREMENTS (METHOD 1 - WHOLE CONTAINER WEIGHING):
   GROSS TRAILER + CONTAINER + CARGO WEIGHT: 42,120 KG
   TARE TRUCK / CHASSIS WEIGHT: 13,670 KG
   ----------------------------------------------------------------------
   CALCULATED VERIFIED GROSS MASS (VGM): 28,450.00 KG
   CONTAINER TARE WEIGHT (STAMPED): 3,880.00 KG
   NET CARGO WEIGHT: 24,570.00 KG
   ----------------------------------------------------------------------
   DISCREPANCY VARIANCE: +/- 0.12% (Permissible regulatory limit: +/- 5.0%)
   CALIBRATION EXPIRY DATE: 2027-04-15
   BOLT SEAL NO: HLG-SEAL-889104 (ISO 17712 CERTIFIED)

4. REGULATORY DECLARATION:
   "I hereby certify that the Verified Gross Mass declared has been obtained in
   strict accordance with IMO SOLAS VI Regulation 2 and DG Shipping Circular 04/2016."
================================================================================`,
  },
  {
    id: "sample-invalid-f13",
    name: "Load Damaged / Invalid Form 13",
    badge: "Critical Discrepancy",
    badgeColor: "bg-rose-900/60 text-rose-300 border-rose-700/50",
    typeHint: "Form 13 Gate-In Permit",
    description: "Terminal Gate Entry pass containing weight mismatch (+2,150 kg) & missing customs seal.",
    content: `================================================================================
PORT COMMUNITY SYSTEM (PCS 1x) / JNPT TERMINAL OPERATING SYSTEM
FORM 13: TERMINAL GATE-IN PERMIT & PRE-ADVICE NOTIFICATION
================================================================================
PERMIT REF: F13-ERR-2026-00918
STATUS: PRE-ADVICE SUBMITTED (AUDIT PENDING)
TERMINAL: NHAVA SHEVA INTERNATIONAL CONTAINER TERMINAL (NSICT)

1. TRUCKING & TRANSPORTER:
   TRANSPORTER: SHREE RAM TRANSPORT SERVICES
   TRUCK / VEHICLE REG NO: MH-46-AR-8812
   DRIVER NAME: SUNIL GUPTA (LIC: DL-MH46-2018091)
   GATE PASS TIME-WINDOW: 2026-10-31 02:00 TO 06:00 (EXPIRED)

2. SHIPPER / EXPORTER:
   ADANI AGRI COMMODITIES PVT LTD
   PLOT 18, SEZ MUNDRA, GUJARAT, INDIA

3. VESSEL & BOOKING:
   LINE / CARRIER: CMA CGM
   VESSEL NAME: CMA CGM ANTOINE DE SAINT EXUPERY
   VOYAGE: 2609W | ROTATION NO: 26901
   PORT OF LOADING: INNSA (Nhava Sheva)
   PORT OF DISCHARGE: FRLEH (Le Havre, France)

4. CRITICAL ANOMALIES & AUDIT FLAGS:
   CONTAINER NUMBER: CMAU9102481
   DECLARED FORM 13 GROSS WEIGHT: 24,200 KG
   TERMINAL IN-GATE WEIGHBRIDGE RECORD: 26,350 KG
   *** DETECTED DISCREPANCY: +2,150 KG (+8.88% OVER DECLARED WEIGHT) ***
   *** EXCEEDS SOLAS 5% MAXIMUM TOLERANCE MARGIN ***

   SEAL DETAILS:
   SHIPPING LINE SEAL: [EMPTY / NOT PROVIDED]
   CUSTOMS BOLT SEAL NO: DAMAGED / TAMPERED TAPE DETECTED (MISSING ISO 17712 SEAL)
   CONTAINER CONDITION REPORT: LEFT DOOR LOWER HINGE BENT; SEAL ATTACHMENT FAULTY.

5. SYSTEM ACTION:
   GATE-IN ENTRY PERMIT BLOCKED AT BOOM BARRIER 02.
   MANDATORY REVIEW BY CUSTOMS APPRAISER & TERMINAL GATE SUPERINTENDENT REQUIRED.
================================================================================`,
  },
  {
    id: "sample-invoice",
    name: "Sample Commercial Invoice",
    badge: "Customs Valuation",
    badgeColor: "bg-purple-900/60 text-purple-300 border-purple-700/50",
    typeHint: "Commercial Invoice & Packing List",
    description: "Export invoice & packing list for industrial telecom machinery with HS code audit.",
    content: `================================================================================
COMMERCIAL INVOICE & PACKING LIST (CUSTOMS EXPORT DECLARATION)
================================================================================
INVOICE NO: EXP-INV-2026-7782             DATE: 2026-10-30
TERMS OF SALE: CIF ROTTERDAM (INCOTERMS 2020)
PAYMENT TERMS: IRREVOCABLE LC AT SIGHT #LC992019481

1. EXPORTER:
   TATA COMMUNICATIONS HARDWARE MFG LTD
   PLOT 12, ELECTRONIC CITY PHASE 2, BANGALORE 560100, INDIA
   IEC: 0799014221 | GSTIN: 29AABCT1928N1Z2

2. BUYER / IMPORTER:
   TELECOM EUROPE INFRASTRUCTURE B.V.
   KEIZERSGRACHT 482, 1016 GD AMSTERDAM, NETHERLANDS
   VAT ID: NL882910481B01

3. SHIPMENT DETAILS:
   CONTAINER NO: TCKU4910293 (40ft High Cube)
   CARRIER: MAERSK LINE
   VESSEL / VOYAGE: MAERSK MC-KINNEY MOLLER / 2618W
   PORT OF LOADING: INNSA (Nhava Sheva)
   PORT OF DISCHARGE: NLRTM (Port of Rotterdam)
   CUSTOMS SEAL NO: MAEU-SEAL-774910 (ISO 17712 High Security)

4. GOODS SPECIFICATIONS:
   LINE 1: 48 UNITS OPTICAL TRANSMISSION ROUTERS (MODEL: OT-8000G)
   HS CODE: 8517.62.90
   UNIT PRICE: USD 4,250.00
   TOTAL LINE AMOUNT: USD 204,000.00

   LINE 2: 12 UNITS MODULAR INDUSTRIAL CHASSIS
   HS CODE: 8471.80.00
   UNIT PRICE: USD 3,100.00
   TOTAL LINE AMOUNT: USD 37,200.00

5. TOTAL VALUATION:
   FOB VALUE: USD 241,200.00
   OCEAN FREIGHT: USD 4,800.00
   MARINE INSURANCE: USD 750.00
   ----------------------------------------------------------------------
   TOTAL CIF VALUE: USD 246,750.00 (TWO HUNDRED FORTY SIX THOUSAND SEVEN HUNDRED FIFTY USD)
   ----------------------------------------------------------------------
   GROSS CARGO WEIGHT: 18,920.00 KG
   TARE WEIGHT: 3,920.00 KG
   TOTAL VGM: 22,840.00 KG
================================================================================`,
  },
];

export const INITIAL_QUEUE_ITEMS: Array<any> = [
  {
    id: "queue-1",
    docId: "DOC-9821",
    documentType: "Bill of Lading",
    shipper: "Tata Steel Exim Global Ltd",
    consignee: "Duisburg Hafen Stahlwerke GmbH",
    vessel: "MAERSK MC-KINNEY MOLLER / 2618W",
    containerId: "MSKU-8201948",
    riskScore: 12,
    riskLevel: "LOW",
    aiRecommendation: "Approve",
    status: "PENDING_APPROVAL",
    submittedAt: "10 mins ago",
    rawText: SAMPLE_DOCUMENTS[0].content,
    auditResult: {
      documentClassification: "Bill of Lading",
      confidenceScore: 99.1,
      metadata: {
        documentNumber: "MSCU-NSA-8921044",
        containerId: "MSKU-8201948",
        shipperName: "Tata Steel Exim Global Ltd",
        consigneeName: "Duisburg Hafen Stahlwerke GmbH",
        notifyParty: "Benelux Maritime Agents BV",
        vesselName: "MAERSK MC-KINNEY MOLLER",
        voyageNumber: "2618W",
        grossWeightKg: 27400,
        tareWeightKg: 3850,
        netWeightKg: 23550,
        portOfLoading: "INNSA - Nhava Sheva",
        portOfDischarge: "NLRTM - Rotterdam",
        sealNumber: "SEAL-IN-98421",
        issueDate: "2026-10-31",
        hsCode: "7208.38.00",
        declaredValue: "USD 189,400.00",
      },
      riskAssessment: {
        riskScore: 12,
        riskLevel: "LOW",
        recommendedAction: "Approve",
        summary: "Autonomous pre-audit passed: Container gross weight is within SOLAS tolerance. Seal ISO 17712 certified. Port gate slot confirmed on JNPT Berth 2.",
        discrepancies: [],
        complianceChecks: [
          { category: "IMO SOLAS Chapter VI", status: "PASS", finding: "VGM declared with certified weighbridge slip; 0.3% variance.", regulation: "IMO MSC.1/Circ.1475" },
          { category: "Customs ISO 17712 Seal", status: "PASS", finding: "High-security mechanical bolt seal validated against Central Port Gate Registry.", regulation: "WCO SAFE / ISO PAS 17712" },
          { category: "Terminal Gate Entry Slot", status: "PASS", finding: "Form 13 pre-advice match active vessel booking window.", regulation: "NexLog PCS 1x Terminal TOS" },
          { category: "Tariff & HS Classification", status: "PASS", finding: "Coiled flat-rolled steel alloy code verified against DGFT export schedule.", regulation: "WCO HS 2026 Revision" },
        ],
        weightVerification: {
          isPayloadValid: true,
          declaredGrossKg: 27400,
          calculatedSumKg: 27400,
          discrepancyKg: 0,
          withinSolasTolerance: true,
        },
      },
      managerNotes: "Eligible for Zero-Touch Straight-Through Processing (STP). Dispatched to Port Gate boom barrier upon authorization.",
      analyzedBy: "Google Gemini (gemini-3.8-flash)",
      timestamp: "2026-11-02T07:22:10Z",
    },
  },
  {
    id: "queue-2",
    docId: "DOC-9822",
    documentType: "VGM Certificate",
    shipper: "Reliance Petrochem Exports Limited",
    consignee: "Antwerp Chemical Terminal N.V.",
    vessel: "AL ZUBARA / 2644E",
    containerId: "HLCU-8192047",
    riskScore: 42,
    riskLevel: "MEDIUM",
    aiRecommendation: "Needs Manual Review",
    status: "PENDING_APPROVAL",
    submittedAt: "28 mins ago",
    rawText: SAMPLE_DOCUMENTS[1].content,
    auditResult: {
      documentClassification: "VGM Certificate",
      confidenceScore: 98.4,
      metadata: {
        documentNumber: "VGM-2026-INNSA-44910",
        containerId: "HLCU-8192047",
        shipperName: "Reliance Petrochem Exports Limited",
        consigneeName: "Antwerp Chemical Terminal N.V.",
        notifyParty: "Haven Transport Brokers",
        vesselName: "AL ZUBARA",
        voyageNumber: "2644E",
        grossWeightKg: 28450,
        tareWeightKg: 3880,
        netWeightKg: 24570,
        portOfLoading: "INNSA - Nhava Sheva",
        portOfDischarge: "BEANR - Port of Antwerp",
        sealNumber: "HLG-SEAL-889104",
        issueDate: "2026-10-31",
        hsCode: "3901.10.00",
        declaredValue: "USD 94,800.00",
      },
      riskAssessment: {
        riskScore: 42,
        riskLevel: "MEDIUM",
        recommendedAction: "Needs Manual Review",
        summary: "Tare weight stamped on container door deviates by 210 kg from the carrier registry database master record, though total gross remains within SOLAS tolerance.",
        discrepancies: [
          "Container tare discrepancy of 210 kg detected between physical stamp (3,880 kg) and Hapag-Lloyd equipment fleet database (3,670 kg).",
          "Shipper Authorized Signatory digital signature certificate expires in 48 hours.",
        ],
        complianceChecks: [
          { category: "IMO SOLAS Chapter VI", status: "PASS", finding: "Method 1 weighbridge calibration certificate is active and valid until 2027.", regulation: "IMO MSC.1/Circ.1475" },
          { category: "Container Equipment Master", status: "WARN", finding: "Physical tare vs EDI equipment file discrepancy of 210 kg.", regulation: "BIC Container Master Table" },
          { category: "Customs ISO 17712 Seal", status: "PASS", finding: "Bolt seal registered and undamaged.", regulation: "WCO SAFE Framework" },
        ],
        weightVerification: {
          isPayloadValid: true,
          declaredGrossKg: 28450,
          calculatedSumKg: 28660,
          discrepancyKg: 210,
          withinSolasTolerance: true,
        },
      },
      managerNotes: "Manager discretion required: accept physical weighbridge reading or demand revised shipper VGM filing.",
      analyzedBy: "Google Gemini (gemini-3.8-flash)",
      timestamp: "2026-11-02T07:05:40Z",
    },
  },
  {
    id: "queue-3",
    docId: "DOC-9823",
    documentType: "Form 13 Gate-In Permit",
    shipper: "Adani Agri Commodities Pvt Ltd",
    consignee: "Le Havre Grain Terminal SAS",
    vessel: "CMA CGM ANTOINE DE SAINT EXUPERY",
    containerId: "CMAU-9102481",
    riskScore: 89,
    riskLevel: "HIGH",
    aiRecommendation: "Reject",
    status: "PENDING_APPROVAL",
    submittedAt: "45 mins ago",
    rawText: SAMPLE_DOCUMENTS[2].content,
    auditResult: {
      documentClassification: "Form 13 Gate-In Permit",
      confidenceScore: 97.9,
      metadata: {
        documentNumber: "F13-ERR-2026-00918",
        containerId: "CMAU-9102481",
        shipperName: "Adani Agri Commodities Pvt Ltd",
        consigneeName: "Le Havre Grain Terminal SAS",
        notifyParty: "Normandy Freight Services",
        vesselName: "CMA CGM ANTOINE DE SAINT EXUPERY",
        voyageNumber: "2609W",
        grossWeightKg: 26350,
        tareWeightKg: 3900,
        netWeightKg: 22450,
        portOfLoading: "INNSA - Nhava Sheva",
        portOfDischarge: "FRLEH - Le Havre",
        sealNumber: "MISSING / DAMAGED",
        issueDate: "2026-10-31",
        hsCode: "1201.90.00",
        declaredValue: "USD 62,300.00",
      },
      riskAssessment: {
        riskScore: 89,
        riskLevel: "HIGH",
        recommendedAction: "Reject",
        summary: "CRITICAL COMPLIANCE BREACH: Terminal weighbridge detected +2,150 kg discrepancy (+8.88% variance) exceeding SOLAS 5% legal limit. Customs high-security ISO 17712 bolt seal is missing.",
        discrepancies: [
          "Terminal in-gate scale recorded 26,350 kg vs declared Form 13 weight of 24,200 kg (+2,150 kg overweight).",
          "Customs bolt seal omitted; container door taped with commercial paper seal.",
          "Transporter gate pass window expired at 06:00 IST.",
        ],
        complianceChecks: [
          { category: "IMO SOLAS Chapter VI", status: "FAIL", finding: "Exceeds 5% maximum permissible variance (+8.88% discrepancy).", regulation: "IMO SOLAS Reg VI/2" },
          { category: "Customs ISO 17712 Seal", status: "FAIL", finding: "High security bolt seal missing. Security protocol non-compliant.", regulation: "ISO 17712:2013 / WCO" },
          { category: "Terminal Gate Entry Slot", status: "FAIL", finding: "Gate pass time expired. Truck held in staging bay 03.", regulation: "JNPT Port Operating System" },
        ],
        weightVerification: {
          isPayloadValid: false,
          declaredGrossKg: 24200,
          calculatedSumKg: 26350,
          discrepancyKg: 2150,
          withinSolasTolerance: false,
        },
      },
      managerNotes: "Immediate rejection recommended. Issue electronic notice to freight forwarder and require customs physical re-inspection.",
      analyzedBy: "Google Gemini (gemini-3.8-flash)",
      timestamp: "2026-11-02T06:50:12Z",
    },
  },
];

export const INITIAL_AUDIT_LOGS = [
  {
    id: "log-1",
    timestamp: "2026-11-02 07:15:33",
    docId: "DOC-9818",
    containerId: "TGHU-9401284",
    action: "PORT_GATE_DISPATCHED" as const,
    actor: "Chief Port Manager (System)",
    riskScore: 8,
    notes: "Automated gate pass barcode issued. Dispatched to JNPT Gate 3 Boom Barrier via PCS 1x.",
    hash: "0x8f2d...c419",
  },
  {
    id: "log-2",
    timestamp: "2026-11-02 07:08:12",
    docId: "DOC-9819",
    containerId: "MEDU-3910482",
    action: "MANAGER_APPROVED" as const,
    actor: "Devraj K. (Lead Terminal Appraiser)",
    riskScore: 16,
    notes: "Verified VGM certificate against NABL weighbridge calibration ticket. Approved.",
    hash: "0x3e1a...7b89",
  },
  {
    id: "log-3",
    timestamp: "2026-11-02 06:58:45",
    docId: "DOC-9820",
    containerId: "CMAU-9102481",
    action: "SOLAS_FLAGGED" as const,
    actor: "NexLog AI Engine (Autonomous)",
    riskScore: 89,
    notes: "Overweight anomaly detected (+2,150 kg). ISO seal missing. Escalated to Human-in-the-loop Queue.",
    hash: "0xa91b...e552",
  },
  {
    id: "log-4",
    timestamp: "2026-11-02 06:44:19",
    docId: "DOC-9817",
    containerId: "MSKU-1920384",
    action: "PORT_GATE_DISPATCHED" as const,
    actor: "NexLog AI Engine (Autonomous)",
    riskScore: 6,
    notes: "Straight-Through Processing (STP) triggered. Clean Bill of Lading matched customs shipping bill.",
    hash: "0x51c4...fa30",
  },
];
