import React from "react";

interface CountryFlagProps {
  code: string;
  className?: string;
  size?: "sm" | "md" | "lg";
}

export const CountryFlag: React.FC<CountryFlagProps> = ({
  code,
  className = "",
  size = "md",
}) => {
  const dimensionClass =
    size === "sm"
      ? "w-4 h-3"
      : size === "lg"
      ? "w-7 h-5"
      : "w-5 h-3.5";

  switch (code.toUpperCase()) {
    case "IN": // India
      return (
        <svg
          className={`shrink-0 rounded-xs shadow-xs border border-slate-300/30 ${dimensionClass} ${className}`}
          viewBox="0 0 900 600"
          xmlns="http://www.w3.org/2000/svg"
        >
          <rect width="900" height="200" fill="#FF9933" />
          <rect y="200" width="900" height="200" fill="#FFFFFF" />
          <rect y="400" width="900" height="200" fill="#128807" />
          <circle cx="450" cy="300" r="75" fill="none" stroke="#000080" strokeWidth="10" />
          <circle cx="450" cy="300" r="15" fill="#000080" />
          {/* Ashoka Chakra 24 spokes */}
          {Array.from({ length: 24 }).map((_, i) => (
            <line
              key={i}
              x1="450"
              y1="300"
              x2={450 + 75 * Math.cos((i * 15 * Math.PI) / 180)}
              y2={300 + 75 * Math.sin((i * 15 * Math.PI) / 180)}
              stroke="#000080"
              strokeWidth="4"
            />
          ))}
        </svg>
      );

    case "AE": // UAE
      return (
        <svg
          className={`shrink-0 rounded-xs shadow-xs border border-slate-300/30 ${dimensionClass} ${className}`}
          viewBox="0 0 600 300"
          xmlns="http://www.w3.org/2000/svg"
        >
          <rect width="600" height="100" fill="#00732f" />
          <rect y="100" width="600" height="100" fill="#ffffff" />
          <rect y="200" width="600" height="100" fill="#000000" />
          <rect width="150" height="300" fill="#ff0000" />
        </svg>
      );

    case "GH": // Ghana
      return (
        <svg
          className={`shrink-0 rounded-xs shadow-xs border border-slate-300/30 ${dimensionClass} ${className}`}
          viewBox="0 0 600 400"
          xmlns="http://www.w3.org/2000/svg"
        >
          <rect width="600" height="133.3" fill="#cf0921" />
          <rect y="133.3" width="600" height="133.3" fill="#fcd20e" />
          <rect y="266.6" width="600" height="133.4" fill="#006b3f" />
          <polygon
            points="300,145 320,195 375,195 330,225 350,275 300,245 250,275 270,225 225,195 280,195"
            fill="#000000"
          />
        </svg>
      );

    case "QA": // Qatar
      return (
        <svg
          className={`shrink-0 rounded-xs shadow-xs border border-slate-300/30 ${dimensionClass} ${className}`}
          viewBox="0 0 700 280"
          xmlns="http://www.w3.org/2000/svg"
        >
          <rect width="700" height="280" fill="#8d1b3d" />
          <polygon
            points="0,0 200,0 240,15.5 200,31.1 240,46.6 200,62.2 240,77.7 200,93.3 240,108.8 200,124.4 240,140 200,155.5 240,171.1 200,186.6 240,202.2 200,217.7 240,233.3 200,248.8 240,264.4 200,280 0,280"
            fill="#ffffff"
          />
        </svg>
      );

    case "BH": // Bahrain
      return (
        <svg
          className={`shrink-0 rounded-xs shadow-xs border border-slate-300/30 ${dimensionClass} ${className}`}
          viewBox="0 0 500 300"
          xmlns="http://www.w3.org/2000/svg"
        >
          <rect width="500" height="300" fill="#ce1126" />
          <polygon
            points="0,0 120,0 180,30 120,60 180,90 120,120 180,150 120,180 180,210 120,240 180,270 120,300 0,300"
            fill="#ffffff"
          />
        </svg>
      );

    case "KW": // Kuwait
      return (
        <svg
          className={`shrink-0 rounded-xs shadow-xs border border-slate-300/30 ${dimensionClass} ${className}`}
          viewBox="0 0 600 300"
          xmlns="http://www.w3.org/2000/svg"
        >
          <rect width="600" height="100" fill="#007a3d" />
          <rect y="100" width="600" height="100" fill="#ffffff" />
          <rect y="200" width="600" height="100" fill="#ce1126" />
          <polygon points="0,0 150,75 150,225 0,300" fill="#000000" />
        </svg>
      );

    case "NG": // Nigeria
      return (
        <svg
          className={`shrink-0 rounded-xs shadow-xs border border-slate-300/30 ${dimensionClass} ${className}`}
          viewBox="0 0 600 300"
          xmlns="http://www.w3.org/2000/svg"
        >
          <rect width="200" height="300" fill="#008751" />
          <rect x="200" width="200" height="300" fill="#ffffff" />
          <rect x="400" width="200" height="300" fill="#008751" />
        </svg>
      );

    case "SN": // Senegal
      return (
        <svg
          className={`shrink-0 rounded-xs shadow-xs border border-slate-300/30 ${dimensionClass} ${className}`}
          viewBox="0 0 600 400"
          xmlns="http://www.w3.org/2000/svg"
        >
          <rect width="200" height="400" fill="#00853f" />
          <rect x="200" width="200" height="400" fill="#fdef42" />
          <rect x="400" width="200" height="400" fill="#e31b23" />
          <polygon
            points="300,150 315,190 355,190 322,215 335,255 300,230 265,255 278,215 245,190 285,190"
            fill="#00853f"
          />
        </svg>
      );

    case "US": // USA
      return (
        <svg
          className={`shrink-0 rounded-xs shadow-xs border border-slate-300/30 ${dimensionClass} ${className}`}
          viewBox="0 0 741 390"
          xmlns="http://www.w3.org/2000/svg"
        >
          <rect width="741" height="390" fill="#b22234" />
          {[30, 90, 150, 210, 270, 330].map((y) => (
            <rect key={y} y={y} width="741" height="30" fill="#ffffff" />
          ))}
          <rect width="296" height="210" fill="#3c3b6e" />
          {/* Simple star cluster grid simulation */}
          {Array.from({ length: 15 }).map((_, i) => (
            <circle
              key={i}
              cx={40 + (i % 5) * 55}
              cy={35 + Math.floor(i / 5) * 55}
              r="8"
              fill="#ffffff"
            />
          ))}
        </svg>
      );

    case "SG": // Singapore
      return (
        <svg
          className={`shrink-0 rounded-xs shadow-xs border border-slate-300/30 ${dimensionClass} ${className}`}
          viewBox="0 0 600 400"
          xmlns="http://www.w3.org/2000/svg"
        >
          <rect width="600" height="200" fill="#ed2939" />
          <rect y="200" width="600" height="200" fill="#ffffff" />
          <circle cx="150" cy="100" r="60" fill="#ffffff" />
          <circle cx="170" cy="100" r="50" fill="#ed2939" />
          {Array.from({ length: 5 }).map((_, i) => {
            const angle = (i * 72 * Math.PI) / 180;
            return (
              <circle
                key={i}
                cx={180 + 22 * Math.cos(angle)}
                cy={100 + 22 * Math.sin(angle)}
                r="6"
                fill="#ffffff"
              />
            );
          })}
        </svg>
      );

    case "ZA": // South Africa
      return (
        <svg
          className={`shrink-0 rounded-xs shadow-xs border border-slate-300/30 ${dimensionClass} ${className}`}
          viewBox="0 0 600 400"
          xmlns="http://www.w3.org/2000/svg"
        >
          <rect width="600" height="200" fill="#e03c31" />
          <rect y="200" width="600" height="200" fill="#001489" />
          <polygon points="0,0 200,200 0,400" fill="#000000" />
          <polygon points="0,0 220,200 0,400 0,360 180,200 0,40" fill="#ffb81c" />
          <polygon points="0,40 180,200 0,360" fill="#000000" />
          <polygon points="180,200 240,200 600,60 600,0 240,160" fill="#ffffff" />
          <polygon points="180,200 240,200 600,340 600,400 240,240" fill="#ffffff" />
          <polygon points="0,170 240,170 600,20 600,100 300,200 600,300 600,380 240,230 0,230" fill="#007749" />
        </svg>
      );

    case "MY": // Malaysia
      return (
        <svg
          className={`shrink-0 rounded-xs shadow-xs border border-slate-300/30 ${dimensionClass} ${className}`}
          viewBox="0 0 600 300"
          xmlns="http://www.w3.org/2000/svg"
        >
          <rect width="600" height="300" fill="#cc0000" />
          {Array.from({ length: 7 }).map((_, i) => (
            <rect key={i} y={i * 42.8 + 21.4} width="600" height="21.4" fill="#ffffff" />
          ))}
          <rect width="300" height="171.4" fill="#000066" />
          <circle cx="150" cy="85.7" r="45" fill="#ffcc00" />
          <circle cx="165" cy="85.7" r="38" fill="#000066" />
          <polygon
            points="180,85.7 200,75 195,95 210,85 198,100 215,105 195,110 200,125 185,115 180,130 175,115 160,125 165,110 145,105 162,100 150,85 165,95 160,75"
            fill="#ffcc00"
          />
        </svg>
      );

    case "KE": // Kenya
      return (
        <svg
          className={`shrink-0 rounded-xs shadow-xs border border-slate-300/30 ${dimensionClass} ${className}`}
          viewBox="0 0 600 400"
          xmlns="http://www.w3.org/2000/svg"
        >
          <rect width="600" height="110" fill="#000000" />
          <rect y="110" width="600" height="20" fill="#ffffff" />
          <rect y="130" width="600" height="140" fill="#bb0000" />
          <rect y="270" width="600" height="20" fill="#ffffff" />
          <rect y="290" width="600" height="110" fill="#006600" />
          {/* Maasai shield symbol */}
          <ellipse cx="300" cy="200" rx="35" ry="70" fill="#bb0000" stroke="#000000" strokeWidth="6" />
          <ellipse cx="300" cy="200" rx="15" ry="50" fill="#ffffff" />
          <line x1="250" y1="130" x2="350" y2="270" stroke="#ffffff" strokeWidth="6" />
          <line x1="350" y1="130" x2="250" y2="270" stroke="#ffffff" strokeWidth="6" />
        </svg>
      );

    case "JO": // Jordan
      return (
        <svg
          className={`shrink-0 rounded-xs shadow-xs border border-slate-300/30 ${dimensionClass} ${className}`}
          viewBox="0 0 600 300"
          xmlns="http://www.w3.org/2000/svg"
        >
          <rect width="600" height="100" fill="#000000" />
          <rect y="100" width="600" height="100" fill="#ffffff" />
          <rect y="200" width="600" height="100" fill="#007a3d" />
          <polygon points="0,0 200,150 0,300" fill="#ce1126" />
          <polygon
            points="80,140 85,150 95,148 90,158 98,165 88,165 85,175 80,166 70,167 77,159 72,150 81,152"
            fill="#ffffff"
          />
        </svg>
      );

    default:
      return (
        <div className={`bg-slate-700 text-white font-mono text-[9px] font-bold rounded flex items-center justify-center ${dimensionClass} ${className}`}>
          {code}
        </div>
      );
  }
};
