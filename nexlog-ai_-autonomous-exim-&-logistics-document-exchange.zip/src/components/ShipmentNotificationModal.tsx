import React, { useState } from "react";
import {
  X,
  Bell,
  Mail,
  MessageSquare,
  FileText,
  Download,
  CheckCircle2,
  Send,
  Sparkles,
  Ship,
  ShieldCheck,
  Smartphone,
  ExternalLink,
  Barcode,
  Layers,
} from "lucide-react";
import { ShipmentNotification } from "../types/notifications";
import {
  downloadArrivalNoticeAttachment,
  downloadShipmentManifestCSV,
  triggerWhatsAppMessage,
} from "../utils/shipmentAttachmentGenerator";
import confetti from "canvas-confetti";

interface ShipmentNotificationModalProps {
  isOpen: boolean;
  onClose: () => void;
  initialContainerNo?: string;
  initialBlNumber?: string;
  initialVesselName?: string;
  initialPort?: string;
  initialTerminal?: string;
  initialStatus?: string;
  defaultEmail?: string;
  defaultPhone?: string;
  onSaveNotification: (
    notif: ShipmentNotification,
    options: { sendEmail: boolean; sendWhatsApp: boolean; saveToProfile: boolean }
  ) => void;
  onAddToast: (type: "success" | "warning" | "error" | "info", title: string, message: string) => void;
}

export const ShipmentNotificationModal: React.FC<ShipmentNotificationModalProps> = ({
  isOpen,
  onClose,
  initialContainerNo = "MSKU9182341",
  initialBlNumber = "MAEU98214470",
  initialVesselName = "M/V SUDARSEN TITAN",
  initialPort = "Nhava Sheva (JNPT)",
  initialTerminal = "APM Terminals Berth 04",
  initialStatus = "Container Discharged Quayside & Customs OOC Granted",
  defaultEmail = "deivaakraj81@gmail.com",
  defaultPhone = "+91 9863 122 122",
  onSaveNotification,
  onAddToast,
}) => {
  const [containerNo, setContainerNo] = useState(initialContainerNo);
  const [blNumber, setBlNumber] = useState(initialBlNumber);
  const [vesselName, setVesselName] = useState(initialVesselName);
  const [port, setPort] = useState(initialPort);

  // Channels selection
  const [emailEnabled, setEmailEnabled] = useState(true);
  const [emailInput, setEmailInput] = useState(defaultEmail);

  const [whatsappEnabled, setWhatsappEnabled] = useState(true);
  const [whatsappPhone, setWhatsappPhone] = useState(defaultPhone);

  const [profileFeedEnabled, setProfileFeedEnabled] = useState(true);

  // Attachment formats
  const [attachmentFormat, setAttachmentFormat] = useState<"PDF" | "CSV" | "BOTH">("PDF");

  // Milestone triggers
  const [notifyOnBerthing, setNotifyOnBerthing] = useState(true);
  const [notifyOnDischarge, setNotifyOnDischarge] = useState(true);
  const [notifyOnCustomsOoc, setNotifyOnCustomsOoc] = useState(true);
  const [notifyOnGateOut, setNotifyOnGateOut] = useState(true);

  const [isSubmitting, setIsSubmitting] = useState(false);

  // Update when initialContainerNo changes
  React.useEffect(() => {
    if (initialContainerNo) setContainerNo(initialContainerNo);
    if (initialBlNumber) setBlNumber(initialBlNumber);
    if (initialVesselName) setVesselName(initialVesselName);
    if (initialPort) setPort(initialPort);
  }, [initialContainerNo, initialBlNumber, initialVesselName, initialPort]);

  if (!isOpen) return null;

  const handleSendNotificationNow = () => {
    if (!emailEnabled && !whatsappEnabled && !profileFeedEnabled) {
      onAddToast("warning", "Select at least one channel", "Please enable Email, WhatsApp, or Profile notifications.");
      return;
    }

    if (emailEnabled && !emailInput.trim()) {
      onAddToast("error", "Email Required", "Please provide a valid recipient mail ID.");
      return;
    }

    if (whatsappEnabled && !whatsappPhone.trim()) {
      onAddToast("error", "WhatsApp Required", "Please enter a recipient WhatsApp mobile number.");
      return;
    }

    setIsSubmitting(true);

    const newNotification: ShipmentNotification = {
      id: `notif-${Date.now()}`,
      containerNo: containerNo.toUpperCase().trim(),
      blNumber: blNumber.toUpperCase().trim(),
      vesselName,
      voyage: "2611E",
      port,
      terminal: initialTerminal,
      milestone: initialStatus,
      status: "CUSTOMS_CLEARED",
      timestamp: new Date().toLocaleString() + " IST",
      read: false,
      channelsSent: [
        ...(emailEnabled ? (["EMAIL"] as const) : []),
        ...(whatsappEnabled ? (["WHATSAPP"] as const) : []),
        ...(profileFeedEnabled ? (["PROFILE"] as const) : []),
      ],
      recipientEmail: emailInput.trim(),
      recipientPhone: whatsappPhone.trim(),
      attachmentName: `Arrival_Notice_${containerNo.toUpperCase().trim()}.pdf`,
      attachmentType: attachmentFormat === "CSV" ? "CSV" : "PDF",
      summary: `Automated arrival alert: ${containerNo} berthed & discharged at ${port}. Customs OOC cleared for Sudarsen Cargo Pvt Ltd.`,
      details: {
        grossWeightKg: 28450,
        tareWeightKg: 3900,
        sealNumber: "ML-IN994812",
        customsStatus: "Green Channel OOC Cleared via ICEGATE",
        consignee: "Sudarsen Cargo Pvt Ltd",
        berthSlot: "Berth 04 APM Terminals",
        carrier: "MAERSK LINE",
      },
    };

    setTimeout(() => {
      setIsSubmitting(false);

      // Save notification to parent/profile state
      onSaveNotification(newNotification, {
        sendEmail: emailEnabled,
        sendWhatsApp: whatsappEnabled,
        saveToProfile: profileFeedEnabled,
      });

      // Automatically trigger real attachment file download
      if (attachmentFormat === "PDF" || attachmentFormat === "BOTH") {
        downloadArrivalNoticeAttachment(newNotification);
      }
      if (attachmentFormat === "CSV" || attachmentFormat === "BOTH") {
        downloadShipmentManifestCSV(newNotification);
      }

      // If WhatsApp enabled, show link trigger
      if (whatsappEnabled) {
        const waLink = triggerWhatsAppMessage(newNotification, whatsappPhone);
        // Note: We don't force popup window.open; user can click or copy
      }

      confetti({
        particleCount: 50,
        spread: 60,
        origin: { y: 0.6 },
      });

      const channelList = [
        emailEnabled ? `Email (${emailInput})` : "",
        whatsappEnabled ? `WhatsApp (${whatsappPhone})` : "",
        profileFeedEnabled ? "Profile Page Feed" : "",
      ]
        .filter(Boolean)
        .join(" & ");

      onAddToast(
        "success",
        "Shipment Notification Dispatched",
        `Arrival notice and official PDF attachment sent to ${channelList}. Attachment downloaded to your device.`
      );

      onClose();
    }, 600);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/75 backdrop-blur-xs p-3 sm:p-4 overflow-y-auto animate-in fade-in duration-200 select-none">
      <div className="bg-white rounded-2xl shadow-2xl border border-slate-300 w-full max-w-2xl overflow-hidden my-4 flex flex-col max-h-[92vh]">
        {/* Top Header */}
        <div className="bg-[#0098db] text-white px-5 py-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-white/15 border border-white/30 flex items-center justify-center">
              <Bell className="w-5 h-5 text-amber-300" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="text-base font-bold tracking-tight">
                  Shipment Arrival & Milestones Notifications
                </h3>
                <span className="px-2 py-0.2 rounded-full bg-amber-400 text-slate-950 text-[10px] font-black uppercase">
                  Multi-Channel
                </span>
              </div>
              <p className="text-xs text-sky-100">
                Receive instant arrival alerts with official document attachments to Mail, WhatsApp, or Profile
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-white/80 hover:text-white hover:bg-white/10 transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Body */}
        <div className="p-5 sm:p-6 overflow-y-auto space-y-5 text-xs text-slate-700">
          {/* Target Shipment Identification Banner */}
          <div className="p-3.5 rounded-xl bg-slate-900 text-white border border-slate-700 flex flex-wrap items-center justify-between gap-3">
            <div>
              <div className="text-[10px] font-bold text-sky-400 uppercase tracking-wider">
                Target Cargo Tracking Reference
              </div>
              <div className="flex items-center gap-2 mt-0.5">
                <span className="text-base font-black font-mono text-white">{containerNo}</span>
                <span className="text-slate-400">•</span>
                <span className="font-mono text-sky-300">BL: {blNumber}</span>
              </div>
              <div className="text-[11px] text-slate-400 mt-0.5">
                {vesselName} • Destination: <strong className="text-slate-200">{port}</strong>
              </div>
            </div>

            <span className="px-2.5 py-1 rounded-md bg-emerald-500/20 text-emerald-300 border border-emerald-400/30 text-[11px] font-bold font-mono">
              ✓ Arrived at Terminal
            </span>
          </div>

          {/* Section 1: Delivery Channels */}
          <div className="space-y-3">
            <h4 className="font-bold text-slate-900 text-xs uppercase tracking-wider flex items-center gap-1.5">
              <Send className="w-3.5 h-3.5 text-[#0098db]" />
              <span>Select Alert Delivery Channels</span>
            </h4>

            {/* Channel 1: Mail ID */}
            <div
              className={`p-3.5 rounded-xl border transition-all ${
                emailEnabled ? "bg-sky-50/70 border-sky-300 shadow-xs" : "bg-slate-50 border-slate-200 opacity-80"
              }`}
            >
              <div className="flex items-center justify-between">
                <label className="flex items-center gap-2.5 cursor-pointer font-bold text-slate-800">
                  <input
                    type="checkbox"
                    checked={emailEnabled}
                    onChange={(e) => setEmailEnabled(e.target.checked)}
                    className="w-4 h-4 text-[#0098db] rounded accent-[#0098db] cursor-pointer"
                  />
                  <div className="flex items-center gap-1.5">
                    <Mail className="w-4 h-4 text-[#0098db]" />
                    <span>Send to Mail ID (Email Notification)</span>
                  </div>
                </label>
                <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-sky-200 text-sky-900">
                  Instant SMTP / PCS 1x
                </span>
              </div>

              {emailEnabled && (
                <div className="mt-2.5 pt-2.5 border-t border-sky-200/80">
                  <label className="block text-[11px] font-semibold text-slate-600 mb-1">
                    Recipient Email Address:
                  </label>
                  <input
                    type="email"
                    value={emailInput}
                    onChange={(e) => setEmailInput(e.target.value)}
                    placeholder="Enter email address (e.g. deivaakraj81@gmail.com)"
                    className="w-full px-3 py-1.5 text-xs bg-white border border-slate-300 rounded-lg font-mono text-slate-900 focus:outline-hidden focus:border-[#0098db]"
                  />
                  <span className="text-[10px] text-slate-500 mt-1 block">
                    Official Arrival Notice PDF dossier and customs OOC release will be attached.
                  </span>
                </div>
              )}
            </div>

            {/* Channel 2: WhatsApp with File Attachment */}
            <div
              className={`p-3.5 rounded-xl border transition-all ${
                whatsappEnabled ? "bg-emerald-50/70 border-emerald-300 shadow-xs" : "bg-slate-50 border-slate-200 opacity-80"
              }`}
            >
              <div className="flex items-center justify-between">
                <label className="flex items-center gap-2.5 cursor-pointer font-bold text-slate-800">
                  <input
                    type="checkbox"
                    checked={whatsappEnabled}
                    onChange={(e) => setWhatsappEnabled(e.target.checked)}
                    className="w-4 h-4 text-emerald-600 rounded accent-emerald-600 cursor-pointer"
                  />
                  <div className="flex items-center gap-1.5">
                    <MessageSquare className="w-4 h-4 text-emerald-600" />
                    <span>Send to WhatsApp (with File & Barcode Attachment)</span>
                  </div>
                </label>
                <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-emerald-200 text-emerald-900">
                  WhatsApp Business API
                </span>
              </div>

              {whatsappEnabled && (
                <div className="mt-2.5 pt-2.5 border-t border-emerald-200/80">
                  <label className="block text-[11px] font-semibold text-slate-600 mb-1">
                    Recipient WhatsApp Mobile Number:
                  </label>
                  <input
                    type="tel"
                    value={whatsappPhone}
                    onChange={(e) => setWhatsappPhone(e.target.value)}
                    placeholder="e.g. +91 9863 122 122"
                    className="w-full px-3 py-1.5 text-xs bg-white border border-slate-300 rounded-lg font-mono text-slate-900 focus:outline-hidden focus:border-emerald-600"
                  />
                  <span className="text-[10px] text-emerald-700 mt-1 block">
                    Sends direct arrival notification with boom barrier gate pass barcode and instant download link.
                  </span>
                </div>
              )}
            </div>

            {/* Channel 3: Profile Page Feed */}
            <div
              className={`p-3.5 rounded-xl border transition-all ${
                profileFeedEnabled ? "bg-amber-50/70 border-amber-300 shadow-xs" : "bg-slate-50 border-slate-200 opacity-80"
              }`}
            >
              <div className="flex items-center justify-between">
                <label className="flex items-center gap-2.5 cursor-pointer font-bold text-slate-800">
                  <input
                    type="checkbox"
                    checked={profileFeedEnabled}
                    onChange={(e) => setProfileFeedEnabled(e.target.checked)}
                    className="w-4 h-4 text-amber-600 rounded accent-amber-600 cursor-pointer"
                  />
                  <div className="flex items-center gap-1.5">
                    <Bell className="w-4 h-4 text-amber-600" />
                    <span>Display in User Profile Page (In-App Arrival Alerts Feed)</span>
                  </div>
                </label>
                <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-amber-200 text-amber-900">
                  Portal Dashboard
                </span>
              </div>
              <p className="text-[10px] text-slate-500 mt-1 pl-6">
                Stores notification in John Lanny’s corporate profile drawer with 1-click attachment re-download anytime.
              </p>
            </div>
          </div>

          {/* Section 2: Attachment File Type */}
          <div className="space-y-2">
            <h4 className="font-bold text-slate-900 text-xs uppercase tracking-wider flex items-center gap-1.5">
              <FileText className="w-3.5 h-3.5 text-slate-700" />
              <span>Attached File Format</span>
            </h4>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5">
              <button
                type="button"
                onClick={() => setAttachmentFormat("PDF")}
                className={`p-3 rounded-xl border text-left cursor-pointer transition-all ${
                  attachmentFormat === "PDF"
                    ? "bg-sky-50 border-[#0098db] text-sky-900 ring-2 ring-sky-300"
                    : "bg-white border-slate-200 hover:border-slate-300"
                }`}
              >
                <div className="font-bold text-xs flex items-center justify-between">
                  <span>PDF Arrival Notice</span>
                  <FileText className="w-3.5 h-3.5 text-rose-500" />
                </div>
                <div className="text-[10px] text-slate-500 mt-1">
                  Official physical-filing letterhead dossier with boom barrier barcode.
                </div>
              </button>

              <button
                type="button"
                onClick={() => setAttachmentFormat("CSV")}
                className={`p-3 rounded-xl border text-left cursor-pointer transition-all ${
                  attachmentFormat === "CSV"
                    ? "bg-sky-50 border-[#0098db] text-sky-900 ring-2 ring-sky-300"
                    : "bg-white border-slate-200 hover:border-slate-300"
                }`}
              >
                <div className="font-bold text-xs flex items-center justify-between">
                  <span>CSV Manifest Data</span>
                  <Layers className="w-3.5 h-3.5 text-emerald-600" />
                </div>
                <div className="text-[10px] text-slate-500 mt-1">
                  Structured spreadsheet of weighbridge VGM, seal, and port timestamps.
                </div>
              </button>

              <button
                type="button"
                onClick={() => setAttachmentFormat("BOTH")}
                className={`p-3 rounded-xl border text-left cursor-pointer transition-all ${
                  attachmentFormat === "BOTH"
                    ? "bg-sky-50 border-[#0098db] text-sky-900 ring-2 ring-sky-300"
                    : "bg-white border-slate-200 hover:border-slate-300"
                }`}
              >
                <div className="font-bold text-xs flex items-center justify-between">
                  <span>Both (PDF + CSV)</span>
                  <Sparkles className="w-3.5 h-3.5 text-amber-500" />
                </div>
                <div className="text-[10px] text-slate-500 mt-1">
                  Complete documentation package for accounts and gate clearance.
                </div>
              </button>
            </div>
          </div>

          {/* Section 3: Milestone Trigger Events */}
          <div className="space-y-2">
            <h4 className="font-bold text-slate-900 text-xs uppercase tracking-wider">
              Trigger Notification On These Milestones:
            </h4>
            <div className="grid grid-cols-2 gap-2 text-[11px]">
              <label className="flex items-center gap-2 p-2 rounded-lg bg-slate-50 border border-slate-200 cursor-pointer">
                <input
                  type="checkbox"
                  checked={notifyOnBerthing}
                  onChange={(e) => setNotifyOnBerthing(e.target.checked)}
                  className="rounded text-[#0098db]"
                />
                <span className="font-medium text-slate-700">Vessel Berthing at Quayside</span>
              </label>

              <label className="flex items-center gap-2 p-2 rounded-lg bg-slate-50 border border-slate-200 cursor-pointer">
                <input
                  type="checkbox"
                  checked={notifyOnDischarge}
                  onChange={(e) => setNotifyOnDischarge(e.target.checked)}
                  className="rounded text-[#0098db]"
                />
                <span className="font-medium text-slate-700">Quayside Crane Discharge</span>
              </label>

              <label className="flex items-center gap-2 p-2 rounded-lg bg-slate-50 border border-slate-200 cursor-pointer">
                <input
                  type="checkbox"
                  checked={notifyOnCustomsOoc}
                  onChange={(e) => setNotifyOnCustomsOoc(e.target.checked)}
                  className="rounded text-[#0098db]"
                />
                <span className="font-medium text-slate-700">Customs ICEGATE OOC Release</span>
              </label>

              <label className="flex items-center gap-2 p-2 rounded-lg bg-slate-50 border border-slate-200 cursor-pointer">
                <input
                  type="checkbox"
                  checked={notifyOnGateOut}
                  onChange={(e) => setNotifyOnGateOut(e.target.checked)}
                  className="rounded text-[#0098db]"
                />
                <span className="font-medium text-slate-700">Boom Barrier Gate-Out Ready</span>
              </label>
            </div>
          </div>
        </div>

        {/* Modal Footer */}
        <div className="bg-slate-50 border-t border-slate-200 px-5 py-3.5 flex flex-wrap items-center justify-between gap-3">
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-2 rounded-lg border border-slate-300 hover:bg-slate-100 font-bold text-slate-700 text-xs transition-colors cursor-pointer"
          >
            Cancel
          </button>

          <div className="flex items-center gap-2">
            <button
              type="button"
              disabled={isSubmitting}
              onClick={handleSendNotificationNow}
              className="px-5 py-2.5 rounded-lg bg-[#0098db] hover:bg-[#0086c2] text-white font-bold text-xs shadow-md transition-all cursor-pointer flex items-center gap-2 hover:scale-102"
            >
              <Send className="w-3.5 h-3.5" />
              <span>
                {isSubmitting ? "Dispatching..." : "Send Instant Notification & Download Attachment"}
              </span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
