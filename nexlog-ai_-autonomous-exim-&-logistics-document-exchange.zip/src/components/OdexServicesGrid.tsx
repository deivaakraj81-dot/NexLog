import React from "react";
import { Globe, PackageCheck, Network, Landmark, ArrowRight, Sparkles, Ship, Truck } from "lucide-react";

interface NexLogServicesGridProps {
  onOpenService: (serviceKey: "export" | "import" | "erp" | "pay-later") => void;
}

export const NexLogServicesGrid: React.FC<NexLogServicesGridProps> = ({ onOpenService }) => {
  const services = [
    {
      key: "export" as const,
      title: "Export",
      description: "Simplified Way of Processing Exports Information, Documentation & Payments",
      imageThumb: "/assets/images/cargo_ship.jpg",
      icon: (
        <svg
          className="w-12 h-12 text-[#ea580c]"
          viewBox="0 0 64 64"
          fill="none"
          stroke="currentColor"
          strokeWidth="2"
          strokeLinecap="round"
          strokeLinejoin="round"
        >
          <circle cx="32" cy="32" r="22" stroke="#ea580c" />
          <ellipse cx="32" cy="32" rx="10" ry="22" stroke="#ea580c" />
          <line x1="10" y1="32" x2="54" y2="32" stroke="#ea580c" />
          <path d="M38 18 L50 30 L38 42" stroke="#ea580c" strokeWidth="2.5" />
          <path d="M22 30 L48 30" stroke="#ea580c" strokeWidth="2.5" />
        </svg>
      ),
      badge: "Form 13 & VGM",
      photoTag: "Ocean Vessel Clearance",
    },
    {
      key: "import" as const,
      title: "Import",
      description: "Discover Simple Way of Processing Imports Information, Documents & Payments.",
      imageThumb: "/assets/images/container_yard.jpg",
      icon: (
        <svg
          className="w-12 h-12 text-[#ea580c]"
          viewBox="0 0 64 64"
          fill="none"
          stroke="currentColor"
          strokeWidth="2"
          strokeLinecap="round"
          strokeLinejoin="round"
        >
          <rect x="14" y="20" width="36" height="24" rx="3" stroke="#ea580c" />
          <line x1="26" y1="20" x2="26" y2="44" stroke="#ea580c" />
          <line x1="38" y1="20" x2="38" y2="44" stroke="#ea580c" />
          <path d="M8 32 L14 32" stroke="#ea580c" strokeWidth="2.5" />
          <path d="M42 12 L50 12 L50 20" stroke="#ea580c" strokeWidth="2" />
          <circle cx="32" cy="52" r="3" fill="#ea580c" />
        </svg>
      ),
      badge: "e-Delivery Order (eDO)",
      photoTag: "Container Stacks In-Gate",
    },
    {
      key: "erp" as const,
      title: "ERP Integration",
      description: "Avoid Multiple Data Entry for Seamless Data Flow...",
      imageThumb: "/assets/images/container_yard.jpg",
      icon: (
        <svg
          className="w-12 h-12 text-[#ea580c]"
          viewBox="0 0 64 64"
          fill="none"
          stroke="currentColor"
          strokeWidth="2"
          strokeLinecap="round"
          strokeLinejoin="round"
        >
          <polygon points="32,10 50,20 50,42 32,52 14,42 14,20" stroke="#ea580c" />
          <circle cx="32" cy="31" r="5" stroke="#ea580c" fill="#fff7ed" />
          <line x1="32" y1="10" x2="32" y2="26" stroke="#ea580c" />
          <line x1="50" y1="42" x2="36" y2="33" stroke="#ea580c" />
          <line x1="14" y1="42" x2="28" y2="33" stroke="#ea580c" />
        </svg>
      ),
      badge: "SAP / CargoWise API",
      photoTag: "Automated TOS Sync",
    },
    {
      key: "pay-later" as const,
      title: "NexLog Pay Later",
      subtitle: "Powered by DBS",
      description: "Enjoy Seamless & Hassle-Free Credit for your Import Invoices...",
      imageThumb: "/assets/images/cargo_ship.jpg",
      icon: (
        <svg
          className="w-12 h-12 text-[#ea580c]"
          viewBox="0 0 64 64"
          fill="none"
          stroke="currentColor"
          strokeWidth="2"
          strokeLinecap="round"
          strokeLinejoin="round"
        >
          <path d="M12 24 L32 12 L52 24 Z" stroke="#ea580c" />
          <line x1="16" y1="24" x2="16" y2="44" stroke="#ea580c" />
          <line x1="26" y1="24" x2="26" y2="44" stroke="#ea580c" />
          <line x1="38" y1="24" x2="38" y2="44" stroke="#ea580c" />
          <line x1="48" y1="24" x2="48" y2="44" stroke="#ea580c" />
          <rect x="10" y="44" width="44" height="6" stroke="#ea580c" />
          <path d="M40 8 L54 8 L54 22" stroke="#ea580c" strokeWidth="2" />
        </svg>
      ),
      badge: "Instant Trade Credit",
      photoTag: "Duty & Freight Escrow",
    },
  ];

  return (
    <section className="py-12 bg-white text-slate-900 border-b border-slate-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6">
        <div className="text-center max-w-2xl mx-auto mb-10">
          <span className="text-[11px] font-bold tracking-widest uppercase text-orange-600 bg-orange-50 px-3 py-1 rounded-full border border-orange-200">
            Enterprise EXIM Services Suite
          </span>
          <h2 className="text-2xl sm:text-3xl font-extrabold text-slate-900 tracking-tight mt-2">
            Automating EXIM Logistics & Ocean Gate Operations
          </h2>
          <p className="text-xs sm:text-sm text-slate-500 mt-1">
            Click any service pillar below to launch the live interactive workflow module.
          </p>
        </div>

        {/* 4 Cards Grid with Real Cargo Imagery and Action Buttons */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {services.map((svc) => (
            <div
              key={svc.key}
              onClick={() => onOpenService(svc.key)}
              className="group p-6 rounded-2xl bg-white border border-slate-200 hover:border-orange-500 shadow-sm hover:shadow-xl transition-all duration-300 flex flex-col justify-between cursor-pointer relative overflow-hidden"
            >
              <div>
                {/* Real Cargo Image Thumbnail at Top of Card */}
                <div className="relative w-full h-32 rounded-xl overflow-hidden mb-4 border border-slate-100 shadow-inner">
                  <img
                    src={svc.imageThumb}
                    alt={svc.title}
                    className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-slate-950/70 to-transparent"></div>
                  <span className="absolute bottom-2 left-2 text-[10px] font-bold text-white uppercase tracking-wider bg-slate-900/80 px-2 py-0.5 rounded backdrop-blur-sm">
                    {svc.photoTag}
                  </span>
                  <span className="absolute top-2 right-2 text-[10px] font-semibold text-orange-950 bg-amber-100/90 px-2 py-0.5 rounded-full shadow-sm backdrop-blur-sm">
                    {svc.badge}
                  </span>
                </div>

                {/* Line-art Icon */}
                <div className="my-2 p-2 flex items-center justify-center">
                  {svc.icon}
                </div>

                {/* Titles */}
                <div className="space-y-1 text-center">
                  <h3 className="text-xl font-bold text-slate-900 group-hover:text-orange-600 transition-colors">
                    {svc.title}
                  </h3>
                  {svc.subtitle && (
                    <div className="text-[11px] font-bold text-slate-700 tracking-wider">
                      {svc.subtitle}
                    </div>
                  )}
                  <p className="text-xs text-slate-500 leading-relaxed pt-2 px-1">
                    {svc.description}
                  </p>
                </div>
              </div>

              {/* Salmon / Pink-Orange Circular Arrow Button */}
              <div className="mt-6 mx-auto w-10 h-10 rounded-full bg-[#fed7aa]/60 group-hover:bg-[#f97316] text-[#ea580c] group-hover:text-white flex items-center justify-center transition-all duration-300 shadow-sm">
                <ArrowRight className="w-4 h-4 group-hover:translate-x-0.5 transition-transform" />
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

// Export alias
export const OdexServicesGrid = NexLogServicesGrid;
