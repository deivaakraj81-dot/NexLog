import React, { useState } from "react";
import {
  UploadCloud,
  Cpu,
  ShieldCheck,
  UserCheck,
  CheckCircle2,
  ArrowRight,
  Server,
  Layers,
  Database,
  Barcode,
  Sparkles,
  Info,
  Clock,
  Terminal,
} from "lucide-react";

export const ArchitectureDiagram: React.FC = () => {
  const [activeStep, setActiveStep] = useState<number>(2);

  const steps = [
    {
      id: 1,
      title: "1. Intake & Multi-Modal Ingestion",
      tag: "Raw Ingestion Layer",
      icon: UploadCloud,
      color: "from-blue-600 to-cyan-500",
      borderColor: "border-blue-500",
      latency: "15 ms",
      summary: "Carrier OCR, PDF Scans, UN/EDIFACT streams & Forms",
      description:
        "Ingests non-standardized multi-party shipping documents (Bill of Lading, VGM slips, Form 13 Gate Passes, Commercial Invoices) via drag-and-drop, REST endpoints, and carrier SFTP feeds.",
      protocols: ["HTTP/2 Multipart", "EDIFACT ANSI X12", "Base64 PDF stream"],
    },
    {
      id: 2,
      title: "2. Google Gemini 3.8 Flash Extraction",
      tag: "Autonomous AI Engine",
      icon: Cpu,
      color: "from-indigo-600 to-purple-500",
      borderColor: "border-purple-500",
      latency: "410 ms",
      summary: "Strict Schema-driven entity extraction & normalization",
      description:
        "Invokes `@google/genai` with `Type.OBJECT` responseSchema on server-side Express runtime. Parses container ISO codes, shipper/consignee entities, gross weights, HS codes, and seals without regex fragility.",
      protocols: ["@google/genai SDK", "responseMimeType: application/json", "Type.OBJECT Schema"],
    },
    {
      id: 3,
      title: "3. Maritime & Customs Compliance Engine",
      tag: "Regulatory Audit Layer",
      icon: ShieldCheck,
      color: "from-amber-600 to-orange-500",
      borderColor: "border-amber-500",
      latency: "45 ms",
      summary: "IMO SOLAS VI, ISO 17712 & Port TOS cross-verification",
      description:
        "Validates gross payload against container safe working load (SWL), verifies Method 1/2 weighing tolerance (±5%), checks high-security bolt seal integrity, and scores risk from 0 to 100.",
      protocols: ["IMO MSC.1/Circ.1475", "ISO PAS 17712", "WCO SAFE Framework"],
    },
    {
      id: 4,
      title: "4. Human-in-the-Loop Approval Gate",
      tag: "Governance & Review",
      icon: UserCheck,
      color: "from-emerald-600 to-teal-500",
      borderColor: "border-emerald-500",
      latency: "Real-Time",
      summary: "Terminal Superintendent exception review & Straight-Through Processing",
      description:
        "Clean, low-risk documents qualify for Zero-Touch Straight-Through Processing (STP). Discrepant or high-risk manifests are held in the Human-in-the-loop queue for superintendent sign-off or instant rejection notice.",
      protocols: ["Role-Based Access Control", "Cryptographic Audit Ledger", "Dual-Signoff"],
    },
    {
      id: 5,
      title: "5. Port Community System Dispatch (PCS 1x)",
      tag: "Port Gate Execution",
      icon: Barcode,
      color: "from-blue-600 to-emerald-500",
      borderColor: "border-emerald-500",
      latency: "80 ms",
      summary: "Boom barrier gate-in barcode & EDIFACT CUSCAR dispatch",
      description:
        "Transmits approved pre-advice manifest to Port Operating Systems (JNPT, Mundra, Rotterdam) and NexLog, opening the terminal gate boom barrier for physical truck entry.",
      protocols: ["NexLog EDI CUSCAR", "PCS 1x XML", "Terminal TOS Barcode API"],
    },
  ];

  const current = steps.find((s) => s.id === activeStep) || steps[1];
  const CurrentIcon = current.icon;

  return (
    <div className="space-y-6">
      {/* Top Banner */}
      <div className="p-5 rounded-2xl bg-gradient-to-r from-slate-900 via-slate-900 to-purple-950/40 border border-slate-800">
        <div className="flex items-center gap-2">
          <span className="px-2.5 py-0.5 rounded-full text-xs font-bold uppercase tracking-wider bg-purple-500/20 text-purple-300 border border-purple-500/30 flex items-center gap-1">
            <Sparkles className="w-3.5 h-3.5" />
            Project Expo System Architecture
          </span>
          <h2 className="text-xl font-bold text-white tracking-tight">
            End-to-End Autonomous Document Exchange Pipeline
          </h2>
        </div>
        <p className="text-xs text-slate-400 mt-1">
          High-performance enterprise architecture showing the handoff from Carrier ingestion to Gemini multimodal extraction, maritime compliance validation, and Port Community System gate dispatch.
        </p>
      </div>

      {/* Interactive Horizontal Pipeline Visual */}
      <div className="grid grid-cols-1 md:grid-cols-5 gap-3">
        {steps.map((step, idx) => {
          const Icon = step.icon;
          const isSelected = activeStep === step.id;
          return (
            <div key={step.id} className="relative">
              <button
                onClick={() => setActiveStep(step.id)}
                className={`w-full text-left p-4 rounded-2xl border transition-all h-full flex flex-col justify-between ${
                  isSelected
                    ? "bg-slate-800 border-blue-500 ring-2 ring-blue-500/30 shadow-xl shadow-blue-500/10"
                    : "bg-slate-900/80 border-slate-800 hover:border-slate-700 hover:bg-slate-800/40"
                }`}
              >
                <div>
                  <div className="flex items-center justify-between mb-2">
                    <div
                      className={`w-9 h-9 rounded-xl bg-gradient-to-tr ${step.color} p-0.5 shadow-md flex items-center justify-center text-white`}
                    >
                      <Icon className="w-4 h-4" />
                    </div>
                    <span className="text-[10px] font-mono text-slate-400 bg-slate-950 px-2 py-0.5 rounded border border-slate-800">
                      {step.latency}
                    </span>
                  </div>

                  <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400 block mb-0.5">
                    {step.tag}
                  </span>
                  <h3 className="text-xs font-bold text-white leading-tight">
                    {step.title.replace(/^\d+\.\s*/, "")}
                  </h3>
                </div>

                <p className="text-[11px] text-slate-400 mt-2 leading-relaxed">
                  {step.summary}
                </p>
              </button>

              {/* Arrow Connector for Desktop */}
              {idx < steps.length - 1 && (
                <div className="hidden md:flex absolute -right-2.5 top-1/2 -translate-y-1/2 z-10 w-5 h-5 rounded-full bg-slate-950 border border-slate-700 items-center justify-center text-slate-400 text-[10px]">
                  →
                </div>
              )}
            </div>
          );
        })}
      </div>

      {/* Deep-Dive Card for Selected Architecture Stage */}
      <div className="p-6 rounded-2xl bg-slate-900/90 border border-slate-800 space-y-4 shadow-xl">
        <div className="flex flex-wrap items-center justify-between gap-4 pb-4 border-b border-slate-800">
          <div className="flex items-center gap-3">
            <div
              className={`w-12 h-12 rounded-2xl bg-gradient-to-tr ${current.color} flex items-center justify-center text-white shadow-lg`}
            >
              <CurrentIcon className="w-6 h-6" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="text-xs font-bold text-blue-400 uppercase tracking-wider font-mono">
                  Stage {current.id} of 5
                </span>
                <span className="text-xs text-slate-400">•</span>
                <span className="text-xs font-mono text-emerald-400 bg-emerald-950/60 px-2 py-0.5 rounded border border-emerald-800/40 flex items-center gap-1">
                  <Clock className="w-3 h-3" /> Latency: {current.latency}
                </span>
              </div>
              <h3 className="text-base font-bold text-white tracking-tight mt-0.5">
                {current.title}
              </h3>
            </div>
          </div>

          <div className="flex items-center gap-2">
            {steps.map((s) => (
              <button
                key={s.id}
                onClick={() => setActiveStep(s.id)}
                className={`w-7 h-7 rounded-lg text-xs font-bold font-mono transition-all ${
                  activeStep === s.id
                    ? "bg-blue-600 text-white"
                    : "bg-slate-800 text-slate-400 hover:text-white"
                }`}
              >
                {s.id}
              </button>
            ))}
          </div>
        </div>

        <p className="text-xs text-slate-300 leading-relaxed max-w-3xl">
          {current.description}
        </p>

        {/* Technical Protocols and Specifications */}
        <div className="pt-2">
          <span className="text-[11px] font-semibold uppercase tracking-wider text-slate-400 block mb-2">
            Technical Stack & Standard Protocols:
          </span>
          <div className="flex flex-wrap gap-2">
            {current.protocols.map((proto, i) => (
              <span
                key={i}
                className="px-3 py-1 rounded-lg bg-slate-950 border border-slate-800 text-xs font-mono text-blue-300 flex items-center gap-1.5"
              >
                <Terminal className="w-3.5 h-3.5 text-blue-400" />
                {proto}
              </span>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};
