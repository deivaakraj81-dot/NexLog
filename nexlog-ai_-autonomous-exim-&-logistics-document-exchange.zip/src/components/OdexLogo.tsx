import React from "react";

interface NexLogLogoProps {
  className?: string;
  size?: "sm" | "md" | "lg" | "xl";
  showSubtitle?: boolean;
}

export const NexLogLogo: React.FC<NexLogLogoProps> = ({
  className = "",
  size = "md",
  showSubtitle = false,
}) => {
  const isSm = size === "sm";
  const isLg = size === "lg";
  const isXl = size === "xl";

  const iconSize = isXl ? "w-12 h-12" : isLg ? "w-10 h-10" : isSm ? "w-6 h-6" : "w-8 h-8";
  const textSize = isXl ? "text-3xl" : isLg ? "text-2xl" : isSm ? "text-lg" : "text-xl";

  return (
    <div className={`flex items-center gap-2 select-none ${className}`}>
      {/* NexLog Geometric Container Ship & Digital Exchange Icon */}
      <svg
        className={`${iconSize} shrink-0`}
        viewBox="0 0 100 100"
        fill="none"
        xmlns="http://www.w3.org/2000/svg"
      >
        {/* Pixel container grid */}
        <rect x="8" y="24" width="9" height="9" rx="2" fill="#0284c7" />
        <rect x="20" y="24" width="9" height="9" rx="2" fill="#0ea5e9" />
        <rect x="8" y="36" width="9" height="9" rx="2" fill="#38bdf8" />
        <rect x="20" y="36" width="9" height="9" rx="2" fill="#0284c7" />
        <rect x="14" y="48" width="9" height="9" rx="2" fill="#f97316" />

        {/* Hull & Origami Bow Fold (Deep Maritime Blue) */}
        <path
          d="M28 46 L58 16 L72 34 L46 58 Z"
          fill="url(#blueGradNex)"
          className="drop-shadow-sm"
        />
        {/* Container Deck Carrier (Vibrant Port Orange) */}
        <path
          d="M22 56 L76 56 L64 80 L32 80 Z"
          fill="url(#orangeGradNex)"
          className="drop-shadow-sm"
        />
        {/* Autonomous AI Sail Angle (Cyan Glow) */}
        <path
          d="M52 22 L80 48 L62 52 Z"
          fill="#38bdf8"
          opacity="0.9"
        />
        <defs>
          <linearGradient id="blueGradNex" x1="28" y1="16" x2="72" y2="58" gradientUnits="userSpaceOnUse">
            <stop stopColor="#0284c7" />
            <stop offset="1" stopColor="#0369a1" />
          </linearGradient>
          <linearGradient id="orangeGradNex" x1="22" y1="56" x2="76" y2="80" gradientUnits="userSpaceOnUse">
            <stop stopColor="#f97316" />
            <stop offset="1" stopColor="#ea580c" />
          </linearGradient>
        </defs>
      </svg>

      <div className="flex flex-col">
        <div className={`font-black tracking-tight flex items-baseline ${textSize}`}>
          <span className="text-[#0284c7] font-extrabold tracking-tight">Nex</span>
          <span className="text-[#0ea5e9] font-black">Log</span>
          <span className="ml-1 text-[11px] font-bold text-amber-500 font-mono tracking-widest uppercase bg-amber-500/10 px-1.5 py-0.2 rounded border border-amber-500/20">
            AI
          </span>
        </div>
        {showSubtitle && (
          <span className="text-[9px] uppercase tracking-widest font-bold text-slate-500">
            Autonomous EXIM Exchange
          </span>
        )}
      </div>
    </div>
  );
};

// Backwards compatibility export
export const OdexLogo = NexLogLogo;
