import React, { useState } from "react";
import {
  X,
  RefreshCw,
  Phone,
  Mail,
  ShieldCheck,
  CheckCircle2,
  Lock,
  User,
  ArrowRight,
  Globe,
  Sparkles,
  Laptop,
  Smartphone,
  FileText,
  Stamp,
  Package,
  Layers,
  Crown,
  Ship,
  Anchor,
} from "lucide-react";
import { NexLogLogo } from "./OdexLogo";
import { CountryFlag } from "./CountryFlag";

interface IntroLoginModalProps {
  isOpen: boolean;
  onClose: () => void;
  onLoginSuccess: (userRole: string, userName?: string, companyName?: string) => void;
  onOpenBookDemo: () => void;
}

export const IntroLoginModal: React.FC<IntroLoginModalProps> = ({
  isOpen,
  onClose,
  onLoginSuccess,
  onOpenBookDemo,
}) => {
  const [userId, setUserId] = useState<string>("john.lanny@sudarsencargo.com");
  const [password, setPassword] = useState<string>("••••••••••");
  const [captchaCode, setCaptchaCode] = useState<string>("1 r T 2 p a 0");
  const [userCaptcha, setUserCaptcha] = useState<string>("");
  const [isPlatinumMode, setIsPlatinumMode] = useState<boolean>(false);
  const [activeView, setActiveView] = useState<"AFTER" | "BEFORE">("AFTER");
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  if (!isOpen) return null;

  // Generate random captcha string
  const reloadCaptcha = () => {
    const chars = "ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnpqrstuvwxyz23456789";
    let res = "";
    for (let i = 0; i < 6; i++) {
      res += chars.charAt(Math.floor(Math.random() * chars.length)) + " ";
    }
    setCaptchaCode(res.trim());
    setUserCaptcha("");
  };

  const handleSignIn = (e: React.FormEvent) => {
    e.preventDefault();
    if (!userId.trim()) {
      setErrorMessage("Please enter your User ID or Corporate IEC code.");
      return;
    }
    onLoginSuccess(
      isPlatinumMode ? "NexLog Platinum Enterprise" : "Logistics Manager",
      "John Lanny",
      "Sudarsen Cargo Pvt Ltd"
    );
    onClose();
  };

  const handleReset = () => {
    setUserId("");
    setPassword("");
    setUserCaptcha("");
    setErrorMessage(null);
  };

  const handleQuickDemoLogin = () => {
    onLoginSuccess("Logistics Manager", "John Lanny", "Sudarsen Cargo Pvt Ltd");
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-slate-950/85 backdrop-blur-md overflow-y-auto animate-in fade-in duration-300">
      <div className="relative w-full max-w-5xl bg-white text-slate-800 rounded-3xl shadow-2xl overflow-hidden border border-slate-200 my-auto">
        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-4 right-4 z-20 w-9 h-9 rounded-full bg-slate-900/60 hover:bg-slate-900 text-white flex items-center justify-center transition-all shadow-md backdrop-blur-sm"
          aria-label="Close intro login pop up"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Top Contact Strip from Screenshot */}
        <div className="bg-slate-50 border-b border-slate-200 px-6 py-2.5 flex flex-wrap items-center justify-between text-xs text-slate-600">
          <div className="flex items-center gap-6">
            <div className="flex items-center gap-1.5 font-semibold text-slate-700">
              <Phone className="w-3.5 h-3.5 text-blue-600" />
              <span>Support Contact: <strong className="text-slate-900">+91 9863 122 122</strong></span>
            </div>
            <div className="hidden sm:flex items-center gap-1.5 font-semibold text-slate-700">
              <Mail className="w-3.5 h-3.5 text-orange-600" />
              <span>Email: <strong className="text-slate-900">support@nexlogglobal.com</strong></span>
            </div>
          </div>

          <div className="flex items-center gap-2 text-[11px] font-mono text-emerald-800 bg-emerald-50 px-3 py-1 rounded-full border border-emerald-200">
            <div className="flex items-center gap-1.5">
              <CountryFlag code="IN" size="sm" />
              <CountryFlag code="AE" size="sm" />
              <CountryFlag code="US" size="sm" />
              <CountryFlag code="SG" size="sm" />
            </div>
            <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse ml-1"></span>
            <span>UAE MPCI & JNPT Port Live Gate v4.2</span>
          </div>
        </div>

        {/* Main Split Layout: Left = Sign In Form; Right = Before/After eBL Showcase with Real Cargo Ship Photo */}
        <div className="grid grid-cols-1 lg:grid-cols-12 min-h-[580px]">
          {/* Left: NexLog Login Form (5 cols) */}
          <div className="lg:col-span-5 p-6 sm:p-8 bg-white flex flex-col justify-between border-r border-slate-200">
            <div className="space-y-4">
              {/* NexLog Logo */}
              <div className="flex items-center justify-between">
                <NexLogLogo size="lg" showSubtitle={true} />
              </div>

              {/* Platinum Login Banner Button */}
              <button
                type="button"
                onClick={() => setIsPlatinumMode(!isPlatinumMode)}
                className={`w-full py-3 px-4 rounded-xl font-extrabold text-sm uppercase tracking-wider transition-all shadow-md flex items-center justify-center gap-2 ${
                  isPlatinumMode
                    ? "bg-gradient-to-r from-amber-600 via-amber-500 to-yellow-500 text-slate-950 ring-2 ring-amber-400"
                    : "bg-gradient-to-r from-[#d4af37] via-[#f3e5ab] to-[#c5a059] text-slate-900 hover:brightness-105"
                }`}
              >
                <Crown className="w-4 h-4 text-amber-900" />
                <span>{isPlatinumMode ? "PLATINUM VIP ACTIVE" : "Click Here For PLATINUM LOGIN"}</span>
              </button>

              {/* Form Container */}
              <div className="rounded-2xl bg-slate-50 p-5 border border-slate-200 shadow-sm space-y-4">
                <div className="bg-[#475569] text-white py-2 px-4 rounded-lg text-center font-extrabold text-sm tracking-wider uppercase shadow-inner">
                  {isPlatinumMode ? "NEXLOG PLATINUM SIGN IN" : "SIGN IN NOW"}
                </div>

                {errorMessage && (
                  <div className="p-2.5 rounded-lg bg-rose-50 border border-rose-200 text-rose-700 text-xs font-medium">
                    {errorMessage}
                  </div>
                )}

                <form onSubmit={handleSignIn} className="space-y-3 text-xs">
                  {/* User ID */}
                  <div>
                    <label className="block text-[11px] font-bold text-slate-600 mb-1">
                      User ID / Corporate IEC
                    </label>
                    <div className="relative">
                      <input
                        type="text"
                        value={userId}
                        onChange={(e) => setUserId(e.target.value)}
                        placeholder="Enter User ID"
                        className="w-full bg-white border border-slate-300 rounded-lg px-3 py-2 text-xs font-semibold text-slate-800 focus:outline-none focus:border-blue-600 focus:ring-1 focus:ring-blue-600"
                      />
                    </div>
                  </div>

                  {/* Password */}
                  <div>
                    <label className="block text-[11px] font-bold text-slate-600 mb-1">
                      Password
                    </label>
                    <div className="relative">
                      <input
                        type="password"
                        value={password}
                        onChange={(e) => setPassword(e.target.value)}
                        placeholder="Enter Password"
                        className="w-full bg-white border border-slate-300 rounded-lg px-3 py-2 text-xs text-slate-800 focus:outline-none focus:border-blue-600 focus:ring-1 focus:ring-blue-600"
                      />
                    </div>
                  </div>

                  {/* Captcha Box from Screenshot */}
                  <div>
                    <div className="flex items-center justify-between p-2 rounded-lg bg-slate-700 text-white font-mono tracking-[0.3em] font-extrabold text-sm mb-1.5 shadow-inner select-none">
                      <span className="italic pl-2">{captchaCode}</span>
                      <button
                        type="button"
                        onClick={reloadCaptcha}
                        className="p-1 hover:bg-slate-600 rounded text-slate-300 hover:text-white transition-colors"
                        title="Reload Captcha Code"
                      >
                        <RefreshCw className="w-4 h-4" />
                      </button>
                    </div>
                    <input
                      type="text"
                      value={userCaptcha}
                      onChange={(e) => setUserCaptcha(e.target.value)}
                      placeholder="Please enter captcha code"
                      className="w-full bg-white border border-slate-300 rounded-lg px-3 py-1.5 text-xs text-slate-800 focus:outline-none focus:border-blue-600"
                    />
                  </div>

                  {/* Buttons: Sign in & Reset */}
                  <div className="grid grid-cols-2 gap-2 pt-1">
                    <button
                      type="submit"
                      className="py-2.5 rounded-lg bg-[#334155] hover:bg-[#1e293b] text-white font-bold text-xs uppercase tracking-wider transition-all shadow-sm"
                    >
                      Sign in
                    </button>
                    <button
                      type="button"
                      onClick={handleReset}
                      className="py-2.5 rounded-lg bg-[#ef4444] hover:bg-[#dc2626] text-white font-bold text-xs uppercase tracking-wider transition-all shadow-sm"
                    >
                      Reset
                    </button>
                  </div>
                </form>

                {/* Instant 1-Click Demo Login Button */}
                <button
                  type="button"
                  onClick={handleQuickDemoLogin}
                  className="w-full py-2.5 px-3 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs flex items-center justify-center gap-1.5 shadow-md shadow-emerald-700/20 transition-all hover:scale-[1.01] cursor-pointer"
                >
                  <Sparkles className="w-3.5 h-3.5" />
                  <span>Login as John Lanny (Sudarsen Cargo Pvt Ltd)</span>
                  <ArrowRight className="w-3.5 h-3.5" />
                </button>
              </div>

              {/* Utility links */}
              <div className="grid grid-cols-2 gap-2 text-[11px] text-slate-600 font-medium pt-1">
                <button
                  type="button"
                  onClick={() => alert("Password reset token dispatched to registered corporate email.")}
                  className="text-left hover:text-blue-600 flex items-center gap-1 cursor-pointer"
                >
                  <Lock className="w-3 h-3 text-slate-400" />
                  <span>Forgot password?</span>
                </button>
                <button
                  type="button"
                  onClick={() => alert("Opening corporate registration gateway for Shipper/CHA onboarding.")}
                  className="text-left hover:text-blue-600 flex items-center gap-1 cursor-pointer"
                >
                  <CheckCircle2 className="w-3 h-3 text-emerald-600" />
                  <span>Register New Company</span>
                </button>
                <button
                  type="button"
                  onClick={() => alert("NexLog Terms & Conditions: Regulated under DG Shipping & PCS 1x standards.")}
                  className="text-left hover:text-blue-600 flex items-center gap-1 cursor-pointer"
                >
                  <FileText className="w-3 h-3 text-slate-400" />
                  <span>Terms & Conditions</span>
                </button>
                <button
                  type="button"
                  onClick={() => alert("Privacy Policy: ISO 27001 & WCO SAFE compliant data protection.")}
                  className="text-left hover:text-blue-600 flex items-center gap-1 cursor-pointer"
                >
                  <ShieldCheck className="w-3 h-3 text-blue-600" />
                  <span>Privacy Policy</span>
                </button>
              </div>
            </div>

            {/* Direct Dashboard bypass */}
            <div className="pt-4 border-t border-slate-100 text-center">
              <button
                onClick={onClose}
                className="text-xs font-bold text-blue-600 hover:text-blue-800 hover:underline cursor-pointer"
              >
                Skip Login & Explore NexLog AI Exchange Directly →
              </button>
            </div>
          </div>

          {/* Right: "Move from Paper BL to eBL" with Real Cargo Ship Photo (7 cols) */}
          <div className="lg:col-span-7 p-6 sm:p-10 bg-slate-900 text-white flex flex-col justify-between relative overflow-hidden">
            {/* Real Ship Photo Background with Gradient Overlay */}
            <div className="absolute inset-0 z-0">
              <img
                src="/assets/images/cinematic_cargo_ship_port.jpg"
                alt="Container Ship Maritime Logistics with Gantry Cranes"
                className="w-full h-full object-cover opacity-40 filter saturate-125 brightness-95"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-slate-950 via-slate-900/80 to-slate-900/60"></div>
            </div>

            <div className="space-y-6 relative z-10">
              {/* Co-branding header */}
              <div className="flex items-center gap-3">
                <div className="text-xl font-extrabold tracking-tight flex items-center gap-2">
                  <span className="text-cyan-400">NexLog</span>
                  <span className="text-slate-500">|</span>
                  <span className="text-amber-400 font-serif tracking-widest font-black">IQAX</span>
                </div>
                <span className="text-[10px] px-2.5 py-0.5 rounded-full bg-blue-950/90 text-blue-300 border border-blue-700/80 font-mono backdrop-blur-sm">
                  Autonomous Paperless Trade
                </span>
              </div>

              {/* Catchy headline */}
              <div>
                <h2 className="text-3xl sm:text-4xl font-extrabold tracking-tight leading-tight">
                  Move from <br className="hidden sm:inline" />
                  <span className="text-blue-400 underline decoration-blue-500/50">Paper BL</span> to{" "}
                  <span className="text-transparent bg-clip-text bg-gradient-to-r from-orange-400 to-amber-300">
                    eBL
                  </span>
                </h2>
                <p className="text-slate-300 text-sm mt-2 font-medium">
                  Receive, transfer and surrender shipping documents digitally with Google Gemini AI compliance verification.
                </p>
              </div>

              {/* Real Cargo Thumbnail Strip */}
              <div className="flex items-center gap-3 p-2.5 rounded-xl bg-slate-950/80 border border-slate-800 backdrop-blur-md">
                <img
                  src="/assets/images/container_yard.jpg"
                  alt="Container Yard Stacks"
                  className="w-20 h-14 object-cover rounded-lg border border-slate-700"
                />
                <div className="text-xs leading-tight">
                  <div className="font-bold text-slate-200">Autonomous Gate Intakes Live</div>
                  <div className="text-slate-400 text-[11px] mt-0.5">
                    Real-time container yard synchronization at JNPT & Jebel Ali
                  </div>
                </div>
              </div>

              {/* Working BEFORE / AFTER Interactive Switcher */}
              <div className="space-y-3">
                <div className="flex items-center gap-2">
                  <button
                    onClick={() => setActiveView("BEFORE")}
                    className={`px-4 py-1.5 rounded-full text-xs font-extrabold transition-all ${
                      activeView === "BEFORE"
                        ? "bg-slate-700 text-white ring-2 ring-slate-500"
                        : "bg-slate-800/80 text-slate-400 hover:text-white"
                    }`}
                  >
                    BEFORE
                  </button>
                  <button
                    onClick={() => setActiveView("AFTER")}
                    className={`px-4 py-1.5 rounded-full text-xs font-extrabold transition-all flex items-center gap-1 ${
                      activeView === "AFTER"
                        ? "bg-blue-600 text-white shadow-lg shadow-blue-500/40 ring-2 ring-blue-400"
                        : "bg-slate-800/80 text-slate-400 hover:text-white"
                    }`}
                  >
                    <span>AFTER</span>
                    <CheckCircle2 className="w-3.5 h-3.5 text-emerald-300" />
                  </button>
                  <span className="text-[11px] text-slate-400 font-mono ml-2">
                    (Click toggle to compare)
                  </span>
                </div>

                {/* Simulated Visual comparison */}
                {activeView === "BEFORE" ? (
                  <div className="p-5 rounded-2xl bg-slate-900/90 border border-rose-900/50 shadow-xl space-y-3 animate-in fade-in duration-200 backdrop-blur-sm">
                    <div className="flex items-center justify-between text-xs text-rose-300 font-bold">
                      <span className="flex items-center gap-1.5">
                        <Package className="w-4 h-4 text-rose-400" />
                        Traditional Physical Courier Chain
                      </span>
                      <span className="text-rose-400 font-mono">48-72h Latency</span>
                    </div>

                    <div className="p-3.5 rounded-xl bg-slate-950/90 border border-slate-800 text-xs text-slate-300 space-y-2">
                      <div className="flex items-center justify-between">
                        <span className="font-semibold text-slate-200">Paper Bill of Lading (3 Original Sets)</span>
                        <span className="text-red-400 font-bold border border-red-500/40 px-2 py-0.5 rounded text-[10px]">
                          ORIGINAL STAMPED
                        </span>
                      </div>
                      <p className="text-[11px] text-slate-400 leading-relaxed">
                        Physical couriering between Shipper → Bank → Importer → Port Gate. Subject to missing seals, weighbridge discrepancies, demurrage charges, and physical document loss.
                      </p>
                    </div>

                    <div className="grid grid-cols-3 gap-2 text-center text-[10px]">
                      <div className="p-2 rounded-lg bg-rose-950/50 border border-rose-800/50 text-rose-200">
                        <div className="font-bold text-sm">3 Days</div>
                        <span>Transit Time</span>
                      </div>
                      <div className="p-2 rounded-lg bg-rose-950/50 border border-rose-800/50 text-rose-200">
                        <div className="font-bold text-sm">$180</div>
                        <span>Courier / Set</span>
                      </div>
                      <div className="p-2 rounded-lg bg-rose-950/50 border border-rose-800/50 text-rose-200">
                        <div className="font-bold text-sm">High</div>
                        <span>Fraud Risk</span>
                      </div>
                    </div>
                  </div>
                ) : (
                  <div className="p-5 rounded-2xl bg-slate-900/90 border border-emerald-500/50 shadow-xl space-y-3 animate-in fade-in duration-200 backdrop-blur-sm">
                    <div className="flex items-center justify-between text-xs text-emerald-300 font-bold">
                      <span className="flex items-center gap-1.5">
                        <Laptop className="w-4 h-4 text-emerald-400" />
                        Autonomous eBL (NexLog AI Platform)
                      </span>
                      <span className="text-emerald-400 font-mono flex items-center gap-1">
                        <Sparkles className="w-3 h-3" />
                        410ms Instant Gate Clearance
                      </span>
                    </div>

                    {/* eBL Digital Details simulated screen */}
                    <div className="p-3.5 rounded-xl bg-slate-950/90 border border-slate-800 text-xs text-slate-200 space-y-2.5">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-2">
                          <span className="font-mono font-bold text-blue-300">eBL # EBL-NEX-8921044</span>
                          <span className="px-1.5 py-0.2 rounded text-[10px] font-bold bg-emerald-950 text-emerald-300 border border-emerald-800">
                            Active
                          </span>
                        </div>
                        <span className="text-[10px] text-slate-400 font-mono">MSC OSCAR / Voy 2611W</span>
                      </div>

                      {/* Transfer timeline */}
                      <div className="space-y-1.5 pt-1 text-[11px] font-mono border-t border-slate-800">
                        <div className="flex items-center justify-between text-slate-300">
                          <span>09 May 2024</span>
                          <span className="text-slate-400">Received By: ABC Shipping Co.</span>
                        </div>
                        <div className="flex items-center justify-between text-slate-300">
                          <span>10 May 2024</span>
                          <span className="text-blue-400">Transferred To: Global Trade Ltd</span>
                        </div>
                        <div className="flex items-center justify-between text-slate-300">
                          <span>14 May 2024</span>
                          <span className="text-emerald-400 font-bold">Surrendered By: Oceanic Imports ✓</span>
                        </div>
                      </div>
                    </div>

                    <div className="grid grid-cols-3 gap-2 text-center text-[10px]">
                      <div className="p-2 rounded-lg bg-emerald-950/50 border border-emerald-800/50 text-emerald-200">
                        <div className="font-bold text-sm">Instant</div>
                        <span>Surrender Time</span>
                      </div>
                      <div className="p-2 rounded-lg bg-emerald-950/50 border border-emerald-800/50 text-emerald-200">
                        <div className="font-bold text-sm">Zero</div>
                        <span>Paper Cost</span>
                      </div>
                      <div className="p-2 rounded-lg bg-emerald-950/50 border border-emerald-800/50 text-emerald-200">
                        <div className="font-bold text-sm">100%</div>
                        <span>ISO Cryptographic</span>
                      </div>
                    </div>
                  </div>
                )}
              </div>
            </div>

            {/* Bottom action pills */}
            <div className="pt-6 flex flex-wrap items-center gap-3 relative z-10 border-t border-slate-800">
              <button
                type="button"
                onClick={onOpenBookDemo}
                className="px-5 py-2.5 rounded-full bg-white hover:bg-slate-100 text-slate-900 font-bold text-xs flex items-center gap-2 shadow-lg transition-all hover:scale-[1.02]"
              >
                <Sparkles className="w-3.5 h-3.5 text-blue-600" />
                <span>Book a Demo</span>
              </button>

              <button
                type="button"
                onClick={() => alert("Connecting to NexLog global network infrastructure & EDI nodes.")}
                className="px-5 py-2.5 rounded-full bg-[#f97316] hover:bg-[#ea580c] text-white font-bold text-xs flex items-center gap-2 shadow-lg shadow-orange-900/30 transition-all hover:scale-[1.02]"
              >
                <Globe className="w-3.5 h-3.5 text-white" />
                <span>www.nexlogglobal.com</span>
              </button>

              <button
                type="button"
                onClick={onClose}
                className="ml-auto text-xs font-semibold text-slate-400 hover:text-white transition-colors underline"
              >
                Enter Portal Workspace
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
