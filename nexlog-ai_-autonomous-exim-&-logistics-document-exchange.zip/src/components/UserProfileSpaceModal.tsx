import React, { useState } from "react";
import {
  X,
  User,
  Building2,
  Mail,
  Phone,
  ShieldCheck,
  Award,
  FileText,
  Download,
  Edit2,
  Check,
  Calendar,
  Lock,
  QrCode,
  Barcode,
  Ship,
  Sparkles,
  ExternalLink,
  LogOut,
  RefreshCw,
  Clock,
  Key,
  Layers,
} from "lucide-react";
import confetti from "canvas-confetti";

interface UserProfileSpaceModalProps {
  isOpen: boolean;
  onClose: () => void;
  userName: string;
  companyName: string;
  userRole?: string;
  userEmail?: string;
  userPhone?: string;
  onUpdateProfile?: (updated: { name: string; email: string; phone: string; role: string }) => void;
  onLogout?: () => void;
  onOpenNotifications?: () => void;
  onAddToast: (type: "success" | "warning" | "error" | "info", title: string, message: string) => void;
}

export const UserProfileSpaceModal: React.FC<UserProfileSpaceModalProps> = ({
  isOpen,
  onClose,
  userName,
  companyName,
  userRole = "Senior Logistics Manager & EXIM Authority",
  userEmail = "deivaakraj81@gmail.com",
  userPhone = "+91 9863 122 122",
  onUpdateProfile,
  onLogout,
  onOpenNotifications,
  onAddToast,
}) => {
  const [activeTab, setActiveTab] = useState<"overview" | "port_pass" | "authorizations" | "security">("overview");

  // Editable state
  const [isEditing, setIsEditing] = useState(false);
  const [nameInput, setNameInput] = useState(userName);
  const [roleInput, setRoleInput] = useState(userRole);
  const [emailInput, setEmailInput] = useState(userEmail);
  const [phoneInput, setPhoneInput] = useState(userPhone);

  React.useEffect(() => {
    setNameInput(userName);
    setRoleInput(userRole);
    setEmailInput(userEmail);
    setPhoneInput(userPhone);
  }, [userName, userRole, userEmail, userPhone]);

  if (!isOpen) return null;

  const handleSaveProfile = () => {
    if (!nameInput.trim() || !emailInput.trim()) {
      onAddToast("error", "Validation Error", "Name and Email cannot be empty.");
      return;
    }

    if (onUpdateProfile) {
      onUpdateProfile({
        name: nameInput.trim(),
        role: roleInput.trim(),
        email: emailInput.trim(),
        phone: phoneInput.trim(),
      });
    }

    setIsEditing(false);
    confetti({ particleCount: 40, spread: 50, origin: { y: 0.6 } });
    onAddToast(
      "success",
      "Profile Updated Successfully",
      `Credentials for ${nameInput} (${companyName}) have been saved.`
    );
  };

  // Download printable official Port Pass ID Card
  const handleDownloadPortPass = () => {
    const htmlContent = `<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <title>Port Access Identity Card - John Lanny (PRN 100653)</title>
  <style>
    body {
      font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
      margin: 0;
      padding: 30px;
      background: #f1f5f9;
      display: flex;
      justify-content: center;
      align-items: center;
      min-height: 90vh;
    }
    .id-card {
      width: 420px;
      background: #ffffff;
      border-radius: 16px;
      overflow: hidden;
      border: 2px solid #0098db;
      box-shadow: 0 10px 25px rgba(0,0,0,0.15);
    }
    .header {
      background: #0098db;
      color: #ffffff;
      padding: 16px 20px;
      text-align: center;
      border-bottom: 3px solid #0086c2;
    }
    .header h2 { margin: 0; font-size: 16px; letter-spacing: 0.5px; text-transform: uppercase; }
    .header p { margin: 3px 0 0 0; font-size: 11px; opacity: 0.9; }
    .body { padding: 20px; }
    .profile-row {
      display: flex;
      align-items: center;
      gap: 16px;
      margin-bottom: 16px;
      padding-bottom: 16px;
      border-bottom: 1px dashed #cbd5e1;
    }
    .avatar {
      width: 64px;
      height: 64px;
      border-radius: 50%;
      background: #0f172a;
      color: #38bdf8;
      display: flex;
      align-items: center;
      justify-content: center;
      font-size: 24px;
      font-weight: 900;
      border: 3px solid #0098db;
    }
    .info h3 { margin: 0; font-size: 16px; color: #0f172a; }
    .info .role { font-size: 12px; color: #64748b; margin-top: 2px; }
    .info .org { font-size: 12px; font-weight: bold; color: #0098db; margin-top: 2px; }
    .grid {
      display: grid;
      grid-template-columns: 1fr 1fr;
      gap: 10px;
      font-size: 11px;
      margin-bottom: 16px;
    }
    .grid-cell { background: #f8fafc; padding: 8px 10px; border-radius: 6px; border: 1px solid #e2e8f0; }
    .label { color: #64748b; font-size: 9px; text-transform: uppercase; font-weight: bold; }
    .val { font-weight: bold; color: #0f172a; font-family: monospace; }
    .barcode-area {
      text-align: center;
      background: #f8fafc;
      padding: 12px;
      border-radius: 8px;
      border: 1px solid #cbd5e1;
    }
    .barcode {
      font-family: 'Courier New', monospace;
      font-size: 24px;
      letter-spacing: 4px;
      font-weight: bold;
      color: #0f172a;
    }
    .footer {
      background: #0f172a;
      color: #94a3b8;
      padding: 10px 16px;
      text-align: center;
      font-size: 10px;
    }
    .print-btn {
      display: block;
      margin: 16px auto 0 auto;
      background: #0098db;
      color: white;
      border: none;
      padding: 8px 20px;
      border-radius: 6px;
      font-weight: bold;
      cursor: pointer;
    }
    @media print {
      body { background: white; padding: 0; }
      .print-btn { display: none; }
    }
  </style>
</head>
<body>
  <div>
    <div class="id-card">
      <div class="header">
        <h2>Port Trust Access Pass</h2>
        <p>PCS 1x Major Ports EXIM Security Authority</p>
      </div>
      <div class="body">
        <div class="profile-row">
          <div class="avatar">JL</div>
          <div class="info">
            <h3>${nameInput}</h3>
            <div class="role">${roleInput}</div>
            <div class="org">${companyName}</div>
          </div>
        </div>

        <div class="grid">
          <div class="grid-cell">
            <div class="label">Permanent Ref No (PRN)</div>
            <div class="val" style="color: #0098db;">PRN-100653</div>
          </div>
          <div class="grid-cell">
            <div class="label">Corporate IEC</div>
            <div class="val">0308019284</div>
          </div>
          <div class="grid-cell">
            <div class="label">Access Clearance</div>
            <div class="val" style="color: #10b981;">Tier 4 (All Terminals)</div>
          </div>
          <div class="grid-cell">
            <div class="label">ICEGATE ID</div>
            <div class="val">ICE_SUDARSEN_MUM</div>
          </div>
        </div>

        <div class="barcode-area">
          <div style="font-size: 9px; font-weight: bold; color: #64748b; margin-bottom: 4px;">TERMINAL AUTOMATED GATE PASS BARCODE</div>
          <div class="barcode">||| |||| | |||| ||| |||||</div>
          <div style="font-size: 11px; font-weight: bold; margin-top: 2px;">*PRN100653-JOHN-LANNY*</div>
        </div>
      </div>
      <div class="footer">
        Authorized by JNPT / Mundra / Chennai Port Community System • Valid till 31-12-2028
      </div>
    </div>
    <button class="print-btn" onclick="window.print()">Print Official ID Card</button>
  </div>
</body>
</html>`;

    const blob = new Blob([htmlContent], { type: "text/html;charset=utf-8" });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.href = url;
    link.download = `PortPass_PRN100653_${nameInput.replace(/\s+/g, "_")}.html`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);

    onAddToast(
      "success",
      "Digital Port Pass Downloaded",
      `Official Terminal Gate Access Pass for ${nameInput} (PRN 100653) downloaded.`
    );
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/75 backdrop-blur-xs p-3 sm:p-5 overflow-y-auto animate-in fade-in duration-200 select-none">
      <div className="bg-white rounded-2xl shadow-2xl border border-slate-300 w-full max-w-3xl overflow-hidden my-4 flex flex-col max-h-[92vh]">
        {/* 1. Modal Top Banner with User Card branding */}
        <div className="bg-gradient-to-r from-[#0098db] via-sky-600 to-[#0284c7] text-white p-5 sm:p-6 flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-sky-500 relative">
          <div className="flex items-center gap-4">
            {/* User Avatar Circle */}
            <div className="relative">
              <div className="w-16 h-16 rounded-2xl bg-white/20 border-2 border-white/50 backdrop-blur-md flex items-center justify-center text-white font-black text-2xl shadow-lg">
                JL
              </div>
              <span className="absolute -bottom-1 -right-1 w-5 h-5 rounded-full bg-emerald-400 border-2 border-white flex items-center justify-center" title="ICEGATE & PCS 1x Verified Active">
                <Check className="w-3 h-3 text-slate-950 font-bold" />
              </span>
            </div>

            <div>
              <div className="flex flex-wrap items-center gap-2">
                <span className="px-2.5 py-0.5 rounded-full bg-sky-900/60 border border-sky-300/40 text-amber-300 font-mono text-xs font-bold tracking-wider">
                  PRN - 100653
                </span>
                <span className="px-2.5 py-0.5 rounded-full bg-emerald-950/60 border border-emerald-400/50 text-emerald-300 text-[11px] font-bold">
                  ● ACTIVE EXIM CLEARANCE
                </span>
              </div>
              <h2 className="text-xl sm:text-2xl font-black tracking-tight text-white mt-1">
                {nameInput}
              </h2>
              <div className="flex flex-wrap items-center gap-2 text-xs text-sky-100 font-medium mt-0.5">
                <span className="font-bold text-white">{companyName}</span>
                <span>•</span>
                <span>{roleInput}</span>
              </div>
            </div>
          </div>

          <div className="flex items-center gap-2 self-start sm:self-center">
            <button
              onClick={() => setIsEditing(!isEditing)}
              className="px-3 py-1.5 rounded-lg bg-white/15 hover:bg-white/25 border border-white/30 text-white font-bold text-xs flex items-center gap-1.5 transition-all cursor-pointer shadow-xs"
              title="Edit Profile Information"
            >
              <Edit2 className="w-3.5 h-3.5" />
              <span>{isEditing ? "Cancel" : "Edit Profile"}</span>
            </button>

            <button
              onClick={onClose}
              className="p-1.5 text-white/80 hover:text-white rounded-lg hover:bg-white/10 transition-colors cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* 2. Navigation Tabs */}
        <div className="bg-slate-100 border-b border-slate-200 px-5 flex items-center gap-1 sm:gap-2 text-xs font-bold overflow-x-auto">
          <button
            onClick={() => setActiveTab("overview")}
            className={`py-3 px-3 border-b-2 transition-colors cursor-pointer flex items-center gap-1.5 whitespace-nowrap ${
              activeTab === "overview"
                ? "border-[#0098db] text-[#0098db]"
                : "border-transparent text-slate-500 hover:text-slate-800"
            }`}
          >
            <User className="w-4 h-4" />
            <span>Profile & Credentials</span>
          </button>

          <button
            onClick={() => setActiveTab("port_pass")}
            className={`py-3 px-3 border-b-2 transition-colors cursor-pointer flex items-center gap-1.5 whitespace-nowrap ${
              activeTab === "port_pass"
                ? "border-[#0098db] text-[#0098db]"
                : "border-transparent text-slate-500 hover:text-slate-800"
            }`}
          >
            <Award className="w-4 h-4" />
            <span>Digital Port Gate Pass</span>
          </button>

          <button
            onClick={() => setActiveTab("authorizations")}
            className={`py-3 px-3 border-b-2 transition-colors cursor-pointer flex items-center gap-1.5 whitespace-nowrap ${
              activeTab === "authorizations"
                ? "border-[#0098db] text-[#0098db]"
                : "border-transparent text-slate-500 hover:text-slate-800"
            }`}
          >
            <Ship className="w-4 h-4" />
            <span>Carrier Line Authorizations</span>
          </button>

          <button
            onClick={() => setActiveTab("security")}
            className={`py-3 px-3 border-b-2 transition-colors cursor-pointer flex items-center gap-1.5 whitespace-nowrap ${
              activeTab === "security"
                ? "border-[#0098db] text-[#0098db]"
                : "border-transparent text-slate-500 hover:text-slate-800"
            }`}
          >
            <Lock className="w-4 h-4" />
            <span>Digital Signature & Security</span>
          </button>
        </div>

        {/* 3. Modal Body (Scrollable) */}
        <div className="p-5 sm:p-6 overflow-y-auto space-y-5 text-xs text-slate-700 flex-1">
          {/* TAB 1: OVERVIEW & CREDENTIALS */}
          {activeTab === "overview" && (
            <div className="space-y-4">
              {isEditing ? (
                /* Edit Profile Form */
                <div className="bg-sky-50/70 p-4 rounded-xl border border-sky-200 space-y-3">
                  <h4 className="font-bold text-slate-900 text-xs uppercase tracking-wider flex items-center gap-1.5">
                    <Edit2 className="w-4 h-4 text-[#0098db]" />
                    <span>Edit User Details</span>
                  </h4>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    <div>
                      <label className="block text-[10px] font-bold text-slate-500 uppercase">
                        Full Name:
                      </label>
                      <input
                        type="text"
                        value={nameInput}
                        onChange={(e) => setNameInput(e.target.value)}
                        className="w-full px-3 py-1.5 text-xs bg-white border border-slate-300 rounded-lg font-semibold text-slate-900 focus:outline-hidden focus:border-[#0098db]"
                      />
                    </div>

                    <div>
                      <label className="block text-[10px] font-bold text-slate-500 uppercase">
                        EXIM Role / Designation:
                      </label>
                      <input
                        type="text"
                        value={roleInput}
                        onChange={(e) => setRoleInput(e.target.value)}
                        className="w-full px-3 py-1.5 text-xs bg-white border border-slate-300 rounded-lg font-semibold text-slate-900 focus:outline-hidden focus:border-[#0098db]"
                      />
                    </div>

                    <div>
                      <label className="block text-[10px] font-bold text-slate-500 uppercase">
                        Registered Mail ID:
                      </label>
                      <input
                        type="email"
                        value={emailInput}
                        onChange={(e) => setEmailInput(e.target.value)}
                        className="w-full px-3 py-1.5 text-xs bg-white border border-slate-300 rounded-lg font-mono text-slate-900 focus:outline-hidden focus:border-[#0098db]"
                      />
                    </div>

                    <div>
                      <label className="block text-[10px] font-bold text-slate-500 uppercase">
                        Registered WhatsApp Number:
                      </label>
                      <input
                        type="tel"
                        value={phoneInput}
                        onChange={(e) => setPhoneInput(e.target.value)}
                        className="w-full px-3 py-1.5 text-xs bg-white border border-slate-300 rounded-lg font-mono text-slate-900 focus:outline-hidden focus:border-[#0098db]"
                      />
                    </div>
                  </div>

                  <div className="pt-2 flex justify-end gap-2">
                    <button
                      type="button"
                      onClick={() => setIsEditing(false)}
                      className="px-3 py-1.5 border border-slate-300 rounded-lg text-slate-700 font-bold hover:bg-slate-100 cursor-pointer"
                    >
                      Cancel
                    </button>
                    <button
                      type="button"
                      onClick={handleSaveProfile}
                      className="px-4 py-1.5 bg-[#0098db] hover:bg-[#0086c2] text-white font-bold rounded-lg flex items-center gap-1.5 cursor-pointer shadow-xs"
                    >
                      <Check className="w-3.5 h-3.5" />
                      <span>Save Changes</span>
                    </button>
                  </div>
                </div>
              ) : null}

              {/* Verified EXIM Credentials Grid */}
              <div className="bg-slate-50 p-4 rounded-xl border border-slate-200 space-y-3">
                <div className="flex items-center justify-between">
                  <h4 className="font-bold text-slate-800 text-xs uppercase tracking-wider flex items-center gap-1.5">
                    <ShieldCheck className="w-4 h-4 text-emerald-600" />
                    <span>Government Regulatory & Port Community Registrations</span>
                  </h4>
                  <span className="text-[10px] font-bold text-emerald-700 bg-emerald-100 px-2 py-0.5 rounded-full">
                    ALL VERIFIED ACTIVE
                  </span>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-3 font-mono">
                  <div className="bg-white p-3 rounded-lg border border-slate-200">
                    <span className="text-[10px] text-slate-400 uppercase font-sans font-semibold">Corporate IEC</span>
                    <div className="text-sm font-bold text-slate-900 mt-0.5">0308019284</div>
                    <div className="text-[10px] text-emerald-600 font-sans mt-0.5">✓ DGFT Active Status</div>
                  </div>

                  <div className="bg-white p-3 rounded-lg border border-slate-200">
                    <span className="text-[10px] text-slate-400 uppercase font-sans font-semibold">Corporate GSTIN</span>
                    <div className="text-sm font-bold text-slate-900 mt-0.5">27AAACS1094J1Z8</div>
                    <div className="text-[10px] text-emerald-600 font-sans mt-0.5">✓ Maharashtra State (IN)</div>
                  </div>

                  <div className="bg-white p-3 rounded-lg border border-slate-200">
                    <span className="text-[10px] text-slate-400 uppercase font-sans font-semibold">Corporate PAN</span>
                    <div className="text-sm font-bold text-slate-900 mt-0.5">AAACS1094J</div>
                    <div className="text-[10px] text-slate-500 font-sans mt-0.5">Income Tax Dept</div>
                  </div>

                  <div className="bg-white p-3 rounded-lg border border-slate-200">
                    <span className="text-[10px] text-slate-400 uppercase font-sans font-semibold">PCS 1x User ID</span>
                    <div className="text-sm font-bold text-sky-700 mt-0.5">SUDARSEN_MUM_EXIM</div>
                    <div className="text-[10px] text-slate-500 font-sans mt-0.5">Direct Port Community</div>
                  </div>

                  <div className="bg-white p-3 rounded-lg border border-slate-200">
                    <span className="text-[10px] text-slate-400 uppercase font-sans font-semibold">ICEGATE Customs ID</span>
                    <div className="text-sm font-bold text-slate-900 mt-0.5">ICE_SUDARSEN_MUM</div>
                    <div className="text-[10px] text-emerald-600 font-sans mt-0.5">✓ Green Channel OOC</div>
                  </div>

                  <div className="bg-white p-3 rounded-lg border border-slate-200">
                    <span className="text-[10px] text-slate-400 uppercase font-sans font-semibold">Permanent Ref No</span>
                    <div className="text-sm font-bold text-[#0098db] mt-0.5">PRN - 100653</div>
                    <div className="text-[10px] text-slate-500 font-sans mt-0.5">Port Terminal Pass</div>
                  </div>
                </div>
              </div>

              {/* Direct Communication Channels */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div className="bg-white p-3.5 rounded-xl border border-slate-200 space-y-1">
                  <div className="flex items-center gap-2 text-slate-800 font-bold">
                    <Mail className="w-4 h-4 text-[#0098db]" />
                    <span>Official Mail ID</span>
                  </div>
                  <div className="font-mono text-xs text-slate-900 font-bold">{emailInput}</div>
                  <p className="text-[10px] text-slate-500">
                    Used for eDO delivery order releases, payment receipts, and customs manifests.
                  </p>
                </div>

                <div className="bg-white p-3.5 rounded-xl border border-slate-200 space-y-1">
                  <div className="flex items-center gap-2 text-slate-800 font-bold">
                    <Phone className="w-4 h-4 text-emerald-600" />
                    <span>WhatsApp EXIM Dispatch</span>
                  </div>
                  <div className="font-mono text-xs text-slate-900 font-bold">{phoneInput}</div>
                  <p className="text-[10px] text-slate-500">
                    Instant container arrival milestones & boom barrier gate-pass barcodes.
                  </p>
                </div>
              </div>

              {/* Quick shortcut to Notifications */}
              {onOpenNotifications && (
                <div className="p-3 bg-amber-50 rounded-xl border border-amber-200 flex items-center justify-between gap-3">
                  <div className="flex items-center gap-2">
                    <Sparkles className="w-4 h-4 text-amber-600 shrink-0" />
                    <span className="text-xs text-amber-900 font-medium">
                      Looking for container arrival notifications & PDF attachment downloads?
                    </span>
                  </div>
                  <button
                    onClick={() => {
                      onClose();
                      onOpenNotifications();
                    }}
                    className="px-3 py-1 bg-amber-600 hover:bg-amber-700 text-white font-bold rounded-lg text-xs cursor-pointer whitespace-nowrap shadow-xs"
                  >
                    Open Arrival Feed
                  </button>
                </div>
              )}
            </div>
          )}

          {/* TAB 2: DIGITAL PORT GATE PASS */}
          {activeTab === "port_pass" && (
            <div className="space-y-4">
              <div className="max-w-md mx-auto bg-gradient-to-b from-slate-900 to-slate-950 text-white p-5 rounded-2xl shadow-xl border border-slate-700 relative overflow-hidden">
                <div className="flex items-start justify-between border-b border-slate-800 pb-3 mb-3">
                  <div>
                    <span className="text-[10px] font-mono text-[#38bdf8] font-bold uppercase tracking-wider block">
                      Indian Major Ports & Terminals
                    </span>
                    <h3 className="text-base font-black text-white">ELECTRONIC PORT ENTRY PASS</h3>
                  </div>
                  <span className="px-2 py-0.5 rounded bg-emerald-500/20 text-emerald-300 border border-emerald-400/40 text-[10px] font-bold font-mono">
                    VALID 2028
                  </span>
                </div>

                <div className="flex items-center gap-3.5 mb-4">
                  <div className="w-14 h-14 rounded-xl bg-slate-800 border border-sky-400/40 flex items-center justify-center font-black text-xl text-sky-400 font-mono">
                    JL
                  </div>
                  <div>
                    <h4 className="font-bold text-sm text-white">{nameInput}</h4>
                    <p className="text-[11px] text-slate-400">{roleInput}</p>
                    <p className="text-xs font-bold text-[#38bdf8]">{companyName}</p>
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-2 text-[11px] font-mono mb-4 bg-slate-900/90 p-2.5 rounded-lg border border-slate-800">
                  <div>
                    <span className="text-[9px] text-slate-500 font-sans block">PRN Reference</span>
                    <strong className="text-sky-300">PRN - 100653</strong>
                  </div>
                  <div>
                    <span className="text-[9px] text-slate-500 font-sans block">Security Tier</span>
                    <strong className="text-emerald-400">Tier 4 (All Gates)</strong>
                  </div>
                  <div>
                    <span className="text-[9px] text-slate-500 font-sans block">Port Coverage</span>
                    <strong className="text-slate-200">JNPT, Mundra, Chennai</strong>
                  </div>
                  <div>
                    <span className="text-[9px] text-slate-500 font-sans block">Biometric ID</span>
                    <strong className="text-slate-200">BIO-AUTH-VERIFIED</strong>
                  </div>
                </div>

                {/* Gate Barcode */}
                <div className="bg-white text-slate-900 p-2.5 rounded-lg text-center">
                  <div className="text-[9px] text-slate-500 font-bold mb-1">SCAN AT BOOM BARRIER TERMINAL GATE</div>
                  <div className="font-mono text-xl tracking-widest font-black leading-none py-1">
                    ||| | ||||| || |||| ||||| |||
                  </div>
                  <div className="text-[10px] font-mono font-bold text-slate-700 mt-1">
                    *PRN100653-PORTPASS-2026*
                  </div>
                </div>
              </div>

              <div className="text-center pt-2">
                <button
                  type="button"
                  onClick={handleDownloadPortPass}
                  className="px-5 py-2.5 bg-[#0098db] hover:bg-[#0086c2] text-white font-bold rounded-lg shadow-md transition-all cursor-pointer inline-flex items-center gap-2 hover:scale-102"
                >
                  <Download className="w-4 h-4" />
                  <span>Download Printable Port Access ID Pass</span>
                </button>
              </div>
            </div>
          )}

          {/* TAB 3: CARRIER LINE AUTHORIZATIONS */}
          {activeTab === "authorizations" && (
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <h4 className="font-bold text-slate-800 text-xs uppercase tracking-wider">
                  Delegated Shipping Line Authorizations for Sudarsen Cargo Pvt Ltd
                </h4>
                <span className="text-[10px] font-mono text-slate-500">6 Active Liners</span>
              </div>

              <div className="space-y-2">
                {[
                  { liner: "MAERSK LINE", code: "MAEU", poa: "POA-2026-MSK-9912", status: "Active Direct eDO", expiry: "2028-12-31" },
                  { liner: "MSC MEDITERRANEAN", code: "MEDU", poa: "POA-2026-MSC-8841", status: "Active Direct eDO", expiry: "2028-12-31" },
                  { liner: "KMTC LINE", code: "KMTC", poa: "POA-2026-KMT-4402", status: "Direct Terminal Release", expiry: "2027-10-15" },
                  { liner: "CMA CGM GROUP", code: "CMDU", poa: "POA-2026-CMA-7719", status: "Active Direct eDO", expiry: "2028-06-30" },
                  { liner: "HAPAG-LLOYD", code: "HLCU", poa: "POA-2026-HAP-1104", status: "Active Direct eDO", expiry: "2027-12-31" },
                  { liner: "ONE (OCEAN NETWORK EXPRESS)", code: "ONEY", poa: "POA-2026-ONE-3321", status: "Active Direct eDO", expiry: "2028-11-20" },
                ].map((item) => (
                  <div key={item.code} className="p-3 bg-slate-50 rounded-xl border border-slate-200 flex flex-wrap items-center justify-between gap-2">
                    <div>
                      <div className="flex items-center gap-2">
                        <strong className="text-slate-900 font-bold">{item.liner}</strong>
                        <span className="font-mono text-[10px] px-1.5 py-0.2 rounded bg-slate-200 text-slate-700 font-bold">
                          {item.code}
                        </span>
                      </div>
                      <div className="text-[10px] text-slate-500 font-mono mt-0.5">
                        POA Number: {item.poa} • Valid until {item.expiry}
                      </div>
                    </div>

                    <span className="px-2.5 py-0.5 rounded-full bg-emerald-100 text-emerald-800 font-bold text-[10px] flex items-center gap-1">
                      <Check className="w-3 h-3 text-emerald-600" />
                      <span>{item.status}</span>
                    </span>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* TAB 4: SECURITY & DIGITAL SIGNATURE */}
          {activeTab === "security" && (
            <div className="space-y-4">
              <div className="bg-slate-50 p-4 rounded-xl border border-slate-200 space-y-3">
                <h4 className="font-bold text-slate-800 text-xs uppercase tracking-wider flex items-center gap-1.5">
                  <Key className="w-4 h-4 text-[#0098db]" />
                  <span>Class 3 Digital Signature Certificate (DSC) Token</span>
                </h4>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 font-mono">
                  <div className="bg-white p-3 rounded-lg border border-slate-200">
                    <span className="text-[10px] text-slate-400 font-sans block">Certificate Holder</span>
                    <strong className="text-slate-900">{nameInput}</strong>
                    <span className="text-[10px] text-slate-500 font-sans block mt-0.5">Sudarsen Cargo Pvt Ltd</span>
                  </div>

                  <div className="bg-white p-3 rounded-lg border border-slate-200">
                    <span className="text-[10px] text-slate-400 font-sans block">Certifying Authority (CA)</span>
                    <strong className="text-slate-900">eMudhra Consumer Services</strong>
                    <span className="text-[10px] text-emerald-600 font-sans block mt-0.5">✓ CCA India Licensed</span>
                  </div>

                  <div className="bg-white p-3 rounded-lg border border-slate-200">
                    <span className="text-[10px] text-slate-400 font-sans block">Token Serial / SHA-256</span>
                    <strong className="text-xs text-sky-700 truncate block">4A:9F:8B:12:00:E4:91</strong>
                    <span className="text-[10px] text-slate-500 font-sans block mt-0.5">Hardware USB PKI Token</span>
                  </div>

                  <div className="bg-white p-3 rounded-lg border border-slate-200">
                    <span className="text-[10px] text-slate-400 font-sans block">Validity Period</span>
                    <strong className="text-emerald-600">Valid until 31-Dec-2028</strong>
                    <span className="text-[10px] text-slate-500 font-sans block mt-0.5">692 Days Remaining</span>
                  </div>
                </div>
              </div>

              {/* Active Session & Security Checklist */}
              <div className="bg-slate-50 p-4 rounded-xl border border-slate-200 space-y-2">
                <h4 className="font-bold text-slate-800 text-xs uppercase tracking-wider">
                  Authentication & Device Security
                </h4>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-[11px]">
                  <div className="flex items-center gap-2 p-2 bg-white rounded border border-slate-200">
                    <ShieldCheck className="w-4 h-4 text-emerald-600" />
                    <span>Two-Factor Authentication (2FA): <strong>Enabled (TOTP)</strong></span>
                  </div>
                  <div className="flex items-center gap-2 p-2 bg-white rounded border border-slate-200">
                    <Clock className="w-4 h-4 text-[#0098db]" />
                    <span>Current Session: <strong>Active (TLS 1.3 / AES-256)</strong></span>
                  </div>
                </div>
              </div>
            </div>
          )}
        </div>

        {/* 4. Modal Footer */}
        <div className="bg-slate-50 border-t border-slate-200 px-5 py-3.5 flex flex-wrap items-center justify-between gap-3 text-xs">
          <div className="flex items-center gap-2 text-slate-500">
            <span>PRN: <strong>100653</strong></span>
            <span>•</span>
            <span>Organization: <strong>{companyName}</strong></span>
          </div>

          <div className="flex items-center gap-2">
            {onLogout && (
              <button
                type="button"
                onClick={() => {
                  onClose();
                  onLogout();
                }}
                className="px-3 py-1.5 rounded-lg bg-rose-50 hover:bg-rose-100 text-rose-700 font-bold border border-rose-200 cursor-pointer transition-colors flex items-center gap-1.5"
              >
                <LogOut className="w-3.5 h-3.5" />
                <span>Log Out</span>
              </button>
            )}

            <button
              type="button"
              onClick={onClose}
              className="px-4 py-1.5 bg-white border border-slate-300 hover:bg-slate-100 text-slate-700 font-bold rounded-lg cursor-pointer transition-colors"
            >
              Close Profile
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
