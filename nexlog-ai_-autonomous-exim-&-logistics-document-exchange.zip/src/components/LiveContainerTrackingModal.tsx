import React, { useState } from "react";
import {
  Search,
  X,
  Truck,
  Ship,
  CheckCircle2,
  Clock,
  MapPin,
  AlertCircle,
  FileText,
  Download,
  Barcode,
  ArrowRight,
  ShieldCheck,
  RefreshCw,
  Anchor,
  Layers,
  Thermometer,
  Calendar,
  Building2,
  ExternalLink,
  Sparkles,
  QrCode,
  Check,
  Bell,
  Mail,
  MessageSquare,
} from "lucide-react";
import confetti from "canvas-confetti";
import { CountryNode } from "./OdexTopBar";

export interface TrackingMilestone {
  step: string;
  location: string;
  timestamp: string;
  completed: boolean;
  current: boolean;
  details: string;
  vessel?: string;
}

export interface ContainerTrackingRecord {
  containerNo: string;
  blNumber: string;
  liner: string;
  vesselName: string;
  voyage: string;
  containerType: string;
  originPort: string;
  originPortCode: string;
  destPort: string;
  destPortCode: string;
  currentStatus: string;
  statusBadgeColor: "emerald" | "amber" | "sky" | "blue" | "rose";
  lastEventDate: string;
  eta: string;
  grossWeightKg: number;
  tareWeightKg: number;
  sealNumber: string;
  terminalBerth: string;
  yardBlockSlot: string;
  temperature?: string;
  consignee: string;
  customsStatus: string;
  edoStatus: "Issued & Cleared" | "Pending Payment" | "Not Requested";
  milestones: TrackingMilestone[];
}

const PRESET_TRACKING_DATA: Record<string, ContainerTrackingRecord> = {
  MSKU9182341: {
    containerNo: "MSKU9182341",
    blNumber: "MAEU98214470",
    liner: "MAERSK LINE",
    vesselName: "M/V SUDARSEN TITAN",
    voyage: "2611E",
    containerType: "40' High Cube Dry (40HC)",
    originPort: "Shanghai Yangshan Port",
    originPortCode: "CNSHA",
    destPort: "Nhava Sheva (JNPT)",
    destPortCode: "INNSA",
    currentStatus: "Discharged by Crane • Awaiting Port Gate Out",
    statusBadgeColor: "emerald",
    lastEventDate: "2026-11-03 06:15 IST",
    eta: "2026-11-02 (Arrived)",
    grossWeightKg: 28450,
    tareWeightKg: 3900,
    sealNumber: "ML-IN994812",
    terminalBerth: "Berth 04 (APM Terminals JNPT)",
    yardBlockSlot: "Block 4-B, Row 12, Tier 3",
    consignee: "Sudarsen Cargo Pvt Ltd",
    customsStatus: "Out of Charge (OOC) Granted via ICEGATE",
    edoStatus: "Issued & Cleared",
    milestones: [
      {
        step: "Empty Equipment Released",
        location: "Shanghai Depot (CNSHA)",
        timestamp: "2026-10-22 09:30 CST",
        completed: true,
        current: false,
        details: "Shipper hauled container to manufacturing plant.",
      },
      {
        step: "Gate-In at Origin Terminal",
        location: "Shanghai Yangshan Port (CNSHA)",
        timestamp: "2026-10-24 14:15 CST",
        completed: true,
        current: false,
        details: "VGM 28,450 KG certified via calibrated weighbridge.",
      },
      {
        step: "Loaded on Ocean Vessel",
        location: "Shanghai Yangshan Port",
        timestamp: "2026-10-26 19:40 CST",
        completed: true,
        current: false,
        details: "Stowed under hatch Bay 24 on M/V SUDARSEN TITAN.",
        vessel: "M/V SUDARSEN TITAN (VOY 2611E)",
      },
      {
        step: "Departed Transshipment Hub",
        location: "Singapore Port PSA (SGSIN)",
        timestamp: "2026-10-30 08:12 SGT",
        completed: true,
        current: false,
        details: "Fast-track transshipment clearance completed.",
      },
      {
        step: "Vessel Berthed at Destination",
        location: "Nhava Sheva Port JNPT (INNSA)",
        timestamp: "2026-11-02 22:45 IST",
        completed: true,
        current: false,
        details: "Moored at Berth 04 with harbor pilot escort.",
      },
      {
        step: "Container Discharged Quayside",
        location: "Nhava Sheva Terminal",
        timestamp: "2026-11-03 04:18 IST",
        completed: true,
        current: false,
        details: "Lifted by Super Post-Panamax Crane STS-07.",
      },
      {
        step: "Customs OOC & PCS 1x EDI Integration",
        location: "Nhava Sheva Customs Enclave",
        timestamp: "2026-11-03 06:15 IST",
        completed: true,
        current: true,
        details: "Green Channel OOC cleared. Delivery Order released to Sudarsen Cargo Pvt Ltd.",
      },
      {
        step: "Gate-Out to CFS / Direct Port Delivery (DPD)",
        location: "Sudarsen Cargo CFS Logistics Hub",
        timestamp: "Expected 2026-11-03 16:00 IST",
        completed: false,
        current: false,
        details: "Scheduled trailer evacuation via Boom Barrier Gate 02.",
      },
    ],
  },
  KMTCXGG3096868: {
    containerNo: "KMTC8829104",
    blNumber: "KMTCXGG3096868",
    liner: "KMTC LINE",
    vesselName: "TIM S",
    voyage: "043E",
    containerType: "40' High Cube Dry (40HC)",
    originPort: "Busan New Port",
    originPortCode: "KRPUS",
    destPort: "Nhava Sheva (JNPT)",
    destPortCode: "INNSA",
    currentStatus: "eDO Released • Ready for Terminal Boom Barrier Gate-Out",
    statusBadgeColor: "emerald",
    lastEventDate: "2026-11-03 09:42 IST",
    eta: "2026-11-03 (Arrived)",
    grossWeightKg: 24600,
    tareWeightKg: 3850,
    sealNumber: "KMTC-771829",
    terminalBerth: "Berth 02 (GTI Terminal)",
    yardBlockSlot: "Block 2-A, Row 08, Tier 2",
    consignee: "Sudarsen Cargo Pvt Ltd",
    customsStatus: "Customs Out of Charge (OOC) Granted",
    edoStatus: "Issued & Cleared",
    milestones: [
      {
        step: "Origin Gate-In",
        location: "Busan New Port (KRPUS)",
        timestamp: "2026-10-21 11:20 KST",
        completed: true,
        current: false,
        details: "VGM 24,600 KG verified by Korean register.",
      },
      {
        step: "Loaded on Ocean Carrier",
        location: "Busan Port",
        timestamp: "2026-10-23 16:50 KST",
        completed: true,
        current: false,
        details: "Vessel TIM S departed eastbound.",
      },
      {
        step: "Vessel Discharged at Destination",
        location: "Nhava Sheva GTI (INNSA)",
        timestamp: "2026-11-03 02:10 IST",
        completed: true,
        current: false,
        details: "Discharged onto terminal tractor.",
      },
      {
        step: "Delivery Order Cleared via ePayment",
        location: "NexLog Autonomous Portal",
        timestamp: "2026-11-03 09:42 IST",
        completed: true,
        current: true,
        details: "Invoice INV-KMTC-2026-9921 settled via SBI Netbanking UTR: UTR-SBIN2630718921.",
      },
      {
        step: "Gate Out to DPD Consignee Warehouse",
        location: "Sudarsen Cargo Logistics Cell",
        timestamp: "Expected 2026-11-03 14:30 IST",
        completed: false,
        current: false,
        details: "Truck pass generated for driver Ramesh Singh.",
      },
    ],
  },
  MEDUAFW55891: {
    containerNo: "MEDU4928172",
    blNumber: "MEDUAFW55891",
    liner: "MSC MEDITERRANEAN",
    vesselName: "MSC OSCAR",
    voyage: "2611W",
    containerType: "20' General Purpose Standard (20GP)",
    originPort: "Ningbo-Zhoushan Port",
    originPortCode: "CNNGB",
    destPort: "Mundra Port (Adani Terminal)",
    destPortCode: "INMUN",
    currentStatus: "Discharged Quayside • Pending eDO Issuance Fee Settlement",
    statusBadgeColor: "amber",
    lastEventDate: "2026-11-02 18:30 IST",
    eta: "2026-11-02 (Arrived)",
    grossWeightKg: 18200,
    tareWeightKg: 2200,
    sealNumber: "MSC-5529104",
    terminalBerth: "Berth 01 (Mundra CT-3)",
    yardBlockSlot: "Block 1-C, Row 04, Tier 1",
    consignee: "Sudarsen Cargo Pvt Ltd",
    customsStatus: "Customs Assessed • Bill of Entry Filed",
    edoStatus: "Pending Payment",
    milestones: [
      {
        step: "Origin Gate-In",
        location: "Ningbo Port (CNNGB)",
        timestamp: "2026-10-19 10:00 CST",
        completed: true,
        current: false,
        details: "Container gated in and loaded on MSC OSCAR.",
      },
      {
        step: "Vessel Berthed at Mundra",
        location: "Mundra Port CT-3 (INMUN)",
        timestamp: "2026-11-02 14:20 IST",
        completed: true,
        current: false,
        details: "Vessel berthed on schedule.",
      },
      {
        step: "Container Discharged to Yard",
        location: "Mundra CT-3 Container Yard",
        timestamp: "2026-11-02 18:30 IST",
        completed: true,
        current: true,
        details: "Stacking in Block 1-C. Invoice INV-MSC-2026-3841 is pending ePayment.",
      },
      {
        step: "Delivery Order (eDO) Issuance",
        location: "NexLog ePayment Gateway",
        timestamp: "Awaiting Action",
        completed: false,
        current: false,
        details: "Clear DO fee (₹21,240) to unlock terminal boom barrier barcode.",
      },
    ],
  },
  HLXU7721903: {
    containerNo: "HLXU7721903",
    blNumber: "HLCUHAM982140",
    liner: "HAPAG-LLOYD",
    vesselName: "AL ZUBARA",
    voyage: "2644E",
    containerType: "40' High Cube Reefer (Cold Chain)",
    originPort: "Rotterdam Port",
    originPortCode: "NLRTM",
    destPort: "Chennai Port (CITPL)",
    destPortCode: "INMAA",
    currentStatus: "Yard Connected to Reefer Monitor (-18.2°C Stable)",
    statusBadgeColor: "blue",
    lastEventDate: "2026-11-03 08:00 IST",
    eta: "2026-11-03 (Arrived)",
    grossWeightKg: 26800,
    tareWeightKg: 4200,
    sealNumber: "HL-EU882194",
    terminalBerth: "Berth 03 (CITPL Chennai)",
    yardBlockSlot: "Reefer Yard R-02, Plug 14",
    temperature: "-18.2°C (Set: -18.0°C • Normal)",
    consignee: "Sudarsen Cargo Pvt Ltd",
    customsStatus: "FSSAI & Plant Quarantine Clearance Approved",
    edoStatus: "Issued & Cleared",
    milestones: [
      {
        step: "Cold Treatment Started",
        location: "Rotterdam Port (NLRTM)",
        timestamp: "2026-10-15 12:00 CET",
        completed: true,
        current: false,
        details: "Pre-trip inspection passed. Temp set to -18.0°C.",
      },
      {
        step: "Ocean Transit via Suez",
        location: "Arabian Sea Corridor",
        timestamp: "2026-10-28 20:00 UTC",
        completed: true,
        current: false,
        details: "Live IoT telematics: steady temp log throughout voyage.",
      },
      {
        step: "Discharged to Reefer Gantry",
        location: "Chennai Port (INMAA)",
        timestamp: "2026-11-03 04:30 IST",
        completed: true,
        current: true,
        details: "Plugged into terminal power grid within 22 minutes.",
      },
    ],
  },
};

interface LiveContainerTrackingModalProps {
  isOpen: boolean;
  onClose: () => void;
  initialQuery?: string;
  country: CountryNode;
  onNavigateToInvoice?: () => void;
  onNavigateToCfs?: () => void;
  onOpenNotificationSetup?: (record: ContainerTrackingRecord) => void;
  onAddToast: (type: "success" | "warning" | "error" | "info", title: string, message: string) => void;
}

export const LiveContainerTrackingModal: React.FC<LiveContainerTrackingModalProps> = ({
  isOpen,
  onClose,
  initialQuery = "MSKU9182341",
  country,
  onNavigateToInvoice,
  onNavigateToCfs,
  onOpenNotificationSetup,
  onAddToast,
}) => {
  const [searchInput, setSearchInput] = useState(initialQuery);
  const [activeRecord, setActiveRecord] = useState<ContainerTrackingRecord>(() => {
    return lookupRecord(initialQuery, country);
  });
  const [isRefreshing, setIsRefreshing] = useState(false);
  const [activeTab, setActiveTab] = useState<"timeline" | "specs" | "terminal_map">("timeline");

  // Keep synced if initialQuery changes
  React.useEffect(() => {
    if (initialQuery) {
      setSearchInput(initialQuery);
      setActiveRecord(lookupRecord(initialQuery, country));
    }
  }, [initialQuery, country]);

  if (!isOpen) return null;

  // Search lookup function
  function lookupRecord(query: string, c: CountryNode): ContainerTrackingRecord {
    const q = query.trim().toUpperCase().replace(/[\s-]/g, "");

    // 1. Direct key match
    for (const key of Object.keys(PRESET_TRACKING_DATA)) {
      if (key.toUpperCase() === q) return PRESET_TRACKING_DATA[key];
    }

    // 2. Search inside records for BL number or containerNo
    for (const rec of Object.values(PRESET_TRACKING_DATA)) {
      if (
        rec.containerNo.toUpperCase().includes(q) ||
        rec.blNumber.toUpperCase().includes(q) ||
        rec.liner.toUpperCase().includes(q)
      ) {
        return rec;
      }
    }

    // 3. Fallback: Generate real dynamic tracking object for any user entered query
    const fallbackCtr = q.startsWith("CTR") ? q : q.length > 4 ? q : `SUDU${Math.floor(1000000 + Math.random() * 9000000)}`;
    const fallbackBl = `BL-${fallbackCtr.slice(0, 4)}-${Math.floor(100000 + Math.random() * 900000)}`;

    return {
      containerNo: fallbackCtr,
      blNumber: fallbackBl,
      liner: "SUDARSEN ALLIANCE LINE",
      vesselName: "M/V SUDARSEN TITAN",
      voyage: "2611E",
      containerType: "40' High Cube Dry (40HC)",
      originPort: "Shanghai Port (CNSHA)",
      originPortCode: "CNSHA",
      destPort: `${c.terminal} (${c.port})`,
      destPortCode: c.port,
      currentStatus: "Discharged at Terminal • Verified Gross Mass (VGM) Matched",
      statusBadgeColor: "emerald",
      lastEventDate: new Date().toLocaleString() + " IST",
      eta: "Today (Berthed)",
      grossWeightKg: 27800,
      tareWeightKg: 3880,
      sealNumber: `SL-IN${Math.floor(100000 + Math.random() * 900000)}`,
      terminalBerth: `Berth 04 (${c.terminal})`,
      yardBlockSlot: "Block 4-B, Slot 14-02",
      consignee: "Sudarsen Cargo Pvt Ltd",
      customsStatus: "Out of Charge (OOC) Granted via ICEGATE",
      edoStatus: "Issued & Cleared",
      milestones: [
        {
          step: "Origin Gate-In & SOLAS Weighbridge",
          location: "Shanghai Port (CNSHA)",
          timestamp: "2026-10-25 10:15 CST",
          completed: true,
          current: false,
          details: "Verified gross mass recorded in terminal system.",
        },
        {
          step: "Loaded on Ocean Vessel",
          location: "M/V SUDARSEN TITAN",
          timestamp: "2026-10-27 18:30 CST",
          completed: true,
          current: false,
          details: "Vessel departed origin port on maritime corridor.",
        },
        {
          step: "Vessel Berthed at Destination Port",
          location: `${c.terminal} (${c.port})`,
          timestamp: "2026-11-03 04:00 IST",
          completed: true,
          current: false,
          details: `Safe berthing at Berth 04 completed for ${c.name}.`,
        },
        {
          step: "Container Discharged Quayside",
          location: `${c.terminal}`,
          timestamp: new Date().toLocaleTimeString() + " IST",
          completed: true,
          current: true,
          details: "Container stacked in DPD enclave for Sudarsen Cargo Pvt Ltd.",
        },
        {
          step: "Boom Barrier Port Gate Out",
          location: "Terminal Out Gate 02",
          timestamp: "Expected 4 Hours",
          completed: false,
          current: false,
          details: "Authorized for direct trailer dispatch.",
        },
      ],
    };
  }

  // Trigger search execution
  const handleExecuteSearch = (val?: string) => {
    const query = val !== undefined ? val : searchInput;
    if (!query.trim()) return;

    setIsRefreshing(true);
    setTimeout(() => {
      setIsRefreshing(false);
      const res = lookupRecord(query, country);
      setActiveRecord(res);
      onAddToast(
        "success",
        `Tracking Found: ${res.containerNo}`,
        `Current Milestone: ${res.currentStatus} at ${res.destPort}`
      );
    }, 400);
  };

  // Simulate advancing the milestone in real-time
  const handleSimulateNextMilestone = () => {
    setIsRefreshing(true);
    setTimeout(() => {
      setIsRefreshing(false);
      setActiveRecord((prev) => {
        const nextMilestones = prev.milestones.map((m, idx, arr) => {
          if (m.current && idx < arr.length - 1) {
            return { ...m, current: false, completed: true };
          }
          if (idx > 0 && arr[idx - 1].current) {
            return { ...m, current: true, completed: true };
          }
          return m;
        });

        return {
          ...prev,
          currentStatus: "Gate-Out Dispatch Verified • Trailer Loaded",
          statusBadgeColor: "emerald",
          lastEventDate: new Date().toLocaleTimeString() + " IST (Live Ping)",
          milestones: nextMilestones,
        };
      });

      confetti({ particleCount: 50, spread: 60, origin: { y: 0.6 } });
      onAddToast(
        "success",
        "Live Milestone Advanced",
        `Container ${activeRecord.containerNo} has cleared the Terminal Boom Barrier!`
      );
    }, 600);
  };

  // Download official Gate Barcode Pass PDF
  const handleDownloadGatePass = () => {
    const htmlContent = `<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <title>Port Gate Pass & Barcode - ${activeRecord.containerNo}</title>
  <style>
    body { font-family: monospace, sans-serif; padding: 40px; color: #0f172a; line-height: 1.6; }
    .card { border: 3px solid #0098db; padding: 24px; border-radius: 8px; max-width: 700px; margin: auto; }
    .header { display: flex; justify-content: space-between; align-items: center; border-bottom: 2px solid #e2e8f0; padding-bottom: 12px; }
    .title { font-size: 18px; font-weight: bold; color: #0098db; }
    table { width: 100%; border-collapse: collapse; margin-top: 16px; font-size: 13px; }
    th, td { border: 1px solid #cbd5e1; padding: 8px 12px; text-align: left; }
    th { background: #f8fafc; }
    .barcode-box { text-align: center; margin-top: 24px; padding: 16px; background: #f1f5f9; border-radius: 6px; }
    .barcode { font-size: 32px; letter-spacing: 6px; font-weight: bold; font-family: 'Courier New', monospace; }
  </style>
</head>
<body>
  <div class="card">
    <div class="header">
      <div>
        <div class="title">PORT BOOM BARRIER GATE PASS & DELIVERY ORDER</div>
        <div style="font-size: 11px; color: #64748b;">Sudarsen Cargo Pvt Ltd • NexLog Autonomous EXIM Exchange</div>
      </div>
      <span style="background: #10b981; color: white; padding: 4px 10px; font-weight: bold; border-radius: 4px; font-size: 12px;">GATE PASS CLEARED</span>
    </div>

    <table>
      <tr><th>Container Number</th><td><strong>${activeRecord.containerNo}</strong> (${activeRecord.containerType})</td></tr>
      <tr><th>Master BL Number</th><td><strong style="color: #0098db;">${activeRecord.blNumber}</strong></td></tr>
      <tr><th>Shipping Line</th><td>${activeRecord.liner}</td></tr>
      <tr><th>Vessel / Voyage</th><td>${activeRecord.vesselName} / ${activeRecord.voyage}</td></tr>
      <tr><th>Terminal & Berth</th><td>${activeRecord.terminalBerth}</td></tr>
      <tr><th>Yard Block & Slot</th><td>${activeRecord.yardBlockSlot}</td></tr>
      <tr><th>Verified Gross Mass (VGM)</th><td>${activeRecord.grossWeightKg.toLocaleString()} KG (Tare: ${activeRecord.tareWeightKg} KG)</td></tr>
      <tr><th>Seal Number</th><td>${activeRecord.sealNumber}</td></tr>
      <tr><th>Customs ICEGATE Clearance</th><td>${activeRecord.customsStatus}</td></tr>
      <tr><th>Consignee / Logistics Agent</th><td>Sudarsen Cargo Pvt Ltd (John Lanny)</td></tr>
    </table>

    <div class="barcode-box">
      <div style="font-size: 11px; color: #64748b; margin-bottom: 6px;">SCAN AT TERMINAL OUT-GATE BOOM BARRIER</div>
      <div class="barcode">||| | ||||| || |||| ||||| |||</div>
      <div style="font-size: 12px; font-weight: bold; margin-top: 4px;">*${activeRecord.containerNo}-GATEPASS-2026*</div>
    </div>
  </div>
</body>
</html>`;

    const blob = new Blob([htmlContent], { type: "text/html;charset=utf-8" });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.href = url;
    link.download = `GatePass_${activeRecord.containerNo}.html`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);

    onAddToast(
      "success",
      "Gate Barcode Pass Downloaded",
      `Official Terminal Gate Pass for container ${activeRecord.containerNo} downloaded for Sudarsen Cargo Pvt Ltd.`
    );
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 backdrop-blur-xs p-2 sm:p-4 overflow-y-auto animate-in fade-in duration-200 select-none">
      <div className="bg-white rounded-2xl shadow-2xl border border-slate-300 w-full max-w-4xl overflow-hidden my-4 flex flex-col max-h-[92vh]">
        {/* 1. Modal Top Bar */}
        <div className="bg-[#0f172a] text-white px-5 py-3.5 flex items-center justify-between border-b border-slate-800">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-[#0098db]/20 border border-[#0098db]/40 flex items-center justify-center text-[#0098db]">
              <Truck className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="font-bold text-sm sm:text-base tracking-tight">
                  Live Container Telematics & Milestones
                </span>
                <span className="px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-400/30 text-[10px] font-bold font-mono">
                  PCS 1x CONNECTED
                </span>
              </div>
              <p className="text-xs text-slate-400">
                Direct Port Community System & Shipping Line IoT Telematics
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={() => handleExecuteSearch(activeRecord.containerNo)}
              className="p-1.5 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800 transition-colors cursor-pointer"
              title="Refresh live container ping"
            >
              <RefreshCw className={`w-4 h-4 ${isRefreshing ? "animate-spin text-sky-400" : ""}`} />
            </button>
            <button
              type="button"
              onClick={onClose}
              className="p-1.5 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800 transition-colors cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* 2. Search & Filter Bar */}
        <div className="bg-slate-100 p-3 sm:px-5 border-b border-slate-200">
          <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-2">
            <div className="relative flex-1">
              <input
                type="text"
                value={searchInput}
                onChange={(e) => setSearchInput(e.target.value)}
                onKeyDown={(e) => e.key === "Enter" && handleExecuteSearch()}
                placeholder="Search any Container ID (e.g. MSKU9182341) or BL Number..."
                className="w-full pl-9 pr-4 py-2 text-xs sm:text-sm bg-white border border-slate-300 rounded-lg font-mono font-bold text-slate-900 focus:outline-hidden focus:border-[#0098db]"
              />
              <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
            </div>

            <button
              type="button"
              disabled={isRefreshing}
              onClick={() => handleExecuteSearch()}
              className="px-5 py-2 bg-[#0098db] hover:bg-[#0086c2] text-white text-xs font-bold rounded-lg shadow-sm transition-all cursor-pointer flex items-center justify-center gap-1.5"
            >
              <Search className="w-3.5 h-3.5" />
              <span>Track Container</span>
            </button>
          </div>

          {/* Quick preset chips */}
          <div className="flex flex-wrap items-center gap-1.5 mt-2.5 text-[11px]">
            <span className="text-slate-500 font-semibold">Try sample IDs:</span>
            {Object.keys(PRESET_TRACKING_DATA).map((key) => {
              const rec = PRESET_TRACKING_DATA[key];
              const isSelected = activeRecord.containerNo === rec.containerNo;
              return (
                <button
                  key={key}
                  type="button"
                  onClick={() => {
                    setSearchInput(rec.containerNo);
                    handleExecuteSearch(rec.containerNo);
                  }}
                  className={`px-2 py-0.5 rounded text-[10px] font-mono font-bold transition-all cursor-pointer ${
                    isSelected
                      ? "bg-[#0098db] text-white shadow-xs"
                      : "bg-white text-slate-700 border border-slate-300 hover:border-[#0098db]"
                  }`}
                >
                  {rec.containerNo} ({rec.liner.split(" ")[0]})
                </button>
              );
            })}
          </div>
        </div>

        {/* 3. Main Result Content (Scrollable) */}
        <div className="p-4 sm:p-6 overflow-y-auto space-y-5 flex-1">
          {/* Hero Container Identification Card */}
          <div className="bg-gradient-to-r from-slate-900 to-[#1e293b] text-white p-4 sm:p-5 rounded-xl shadow-md border border-slate-700 relative overflow-hidden">
            <div className="absolute right-0 top-0 bottom-0 w-1/3 bg-radial from-cyan-500/10 to-transparent pointer-events-none" />

            <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 relative z-10">
              <div>
                <div className="flex items-center gap-2">
                  <span className="text-xl sm:text-2xl font-black font-mono tracking-tight text-white">
                    {activeRecord.containerNo}
                  </span>
                  <span className="px-2.5 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-400/30 text-xs font-bold font-mono">
                    {activeRecord.containerType}
                  </span>
                  {activeRecord.temperature && (
                    <span className="px-2 py-0.5 rounded-full bg-blue-500/20 text-blue-300 border border-blue-400/30 text-[10px] font-bold font-mono flex items-center gap-1">
                      <Thermometer className="w-3 h-3 text-blue-400" />
                      {activeRecord.temperature}
                    </span>
                  )}
                </div>

                <div className="flex flex-wrap items-center gap-3 text-xs text-slate-300 mt-1.5 font-medium">
                  <span>Liner: <strong className="text-white">{activeRecord.liner}</strong></span>
                  <span>•</span>
                  <span>Master BL: <strong className="font-mono text-[#38bdf8]">{activeRecord.blNumber}</strong></span>
                  <span>•</span>
                  <span>Vessel: <strong className="text-white">{activeRecord.vesselName}</strong> (Voy {activeRecord.voyage})</span>
                </div>
              </div>

              {/* Status Badge & Actions */}
              <div className="text-left md:text-right space-y-1">
                <div className="text-[10px] font-bold uppercase tracking-wider text-slate-400">
                  Current Maritime Status
                </div>
                <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-md bg-emerald-950/80 text-emerald-300 border border-emerald-500/50 text-xs font-bold font-mono shadow-xs">
                  <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
                  <span>{activeRecord.currentStatus}</span>
                </div>
                <div className="text-[11px] text-slate-400">
                  Pinged: {activeRecord.lastEventDate}
                </div>
              </div>
            </div>

            {/* Origin to Destination Route Bar */}
            <div className="mt-4 pt-3 border-t border-slate-700/60 flex items-center justify-between text-xs">
              <div className="flex items-center gap-2">
                <MapPin className="w-3.5 h-3.5 text-slate-400" />
                <span className="text-slate-400">Origin:</span>
                <span className="font-bold text-white">{activeRecord.originPort} ({activeRecord.originPortCode})</span>
              </div>

              <div className="hidden sm:flex items-center gap-2 text-slate-500 text-xs">
                <span>Direct Maritime Corridor</span>
                <ArrowRight className="w-4 h-4 text-[#0098db]" />
              </div>

              <div className="flex items-center gap-2">
                <Anchor className="w-3.5 h-3.5 text-emerald-400" />
                <span className="text-slate-400">Destination:</span>
                <span className="font-bold text-emerald-300">{activeRecord.destPort}</span>
              </div>
            </div>
          </div>

          {/* Quick Details Grid */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs">
            <div className="bg-slate-50 p-3 rounded-lg border border-slate-200">
              <span className="text-[10px] font-bold text-slate-400 uppercase tracking-tight">Verified Gross Mass (VGM)</span>
              <div className="text-sm font-bold font-mono text-slate-900 mt-0.5">
                {activeRecord.grossWeightKg.toLocaleString()} KG
              </div>
              <div className="text-[10px] text-slate-500">Tare: {activeRecord.tareWeightKg} KG • SOLAS Cert</div>
            </div>

            <div className="bg-slate-50 p-3 rounded-lg border border-slate-200">
              <span className="text-[10px] font-bold text-slate-400 uppercase tracking-tight">Terminal Berth & Quayside</span>
              <div className="text-sm font-bold text-slate-900 mt-0.5">
                {activeRecord.terminalBerth}
              </div>
              <div className="text-[10px] text-slate-500">{activeRecord.yardBlockSlot}</div>
            </div>

            <div className="bg-slate-50 p-3 rounded-lg border border-slate-200">
              <span className="text-[10px] font-bold text-slate-400 uppercase tracking-tight">Customs Out of Charge</span>
              <div className="text-sm font-bold text-emerald-700 mt-0.5 flex items-center gap-1">
                <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
                <span>OOC Granted</span>
              </div>
              <div className="text-[10px] text-slate-500 font-mono">ICEGATE Auto-Cleared</div>
            </div>

            <div className="bg-slate-50 p-3 rounded-lg border border-slate-200">
              <span className="text-[10px] font-bold text-slate-400 uppercase tracking-tight">Delivery Order (eDO)</span>
              <div className="text-sm font-bold text-slate-900 mt-0.5">
                <span className={`px-2 py-0.5 rounded text-[11px] font-bold ${
                  activeRecord.edoStatus === "Issued & Cleared"
                    ? "bg-emerald-100 text-emerald-800"
                    : "bg-amber-100 text-amber-800"
                }`}>
                  {activeRecord.edoStatus}
                </span>
              </div>
              <div className="text-[10px] text-slate-500 mt-0.5 font-mono">Seal: {activeRecord.sealNumber}</div>
            </div>
          </div>

          {/* View Mode Tabs */}
          <div className="border-b border-slate-200 flex gap-4 text-xs font-bold">
            <button
              type="button"
              onClick={() => setActiveTab("timeline")}
              className={`pb-2.5 border-b-2 transition-colors cursor-pointer flex items-center gap-1.5 ${
                activeTab === "timeline"
                  ? "border-[#0098db] text-[#0098db]"
                  : "border-transparent text-slate-500 hover:text-slate-800"
              }`}
            >
              <Clock className="w-4 h-4" />
              <span>Milestone Timeline ({activeRecord.milestones.length})</span>
            </button>

            <button
              type="button"
              onClick={() => setActiveTab("specs")}
              className={`pb-2.5 border-b-2 transition-colors cursor-pointer flex items-center gap-1.5 ${
                activeTab === "specs"
                  ? "border-[#0098db] text-[#0098db]"
                  : "border-transparent text-slate-500 hover:text-slate-800"
              }`}
            >
              <FileText className="w-4 h-4" />
              <span>Vessel & Cargo Manifest Dossier</span>
            </button>

            <button
              type="button"
              onClick={() => setActiveTab("terminal_map")}
              className={`pb-2.5 border-b-2 transition-colors cursor-pointer flex items-center gap-1.5 ${
                activeTab === "terminal_map"
                  ? "border-[#0098db] text-[#0098db]"
                  : "border-transparent text-slate-500 hover:text-slate-800"
              }`}
            >
              <MapPin className="w-4 h-4" />
              <span>Yard Berth & Slot Map</span>
            </button>
          </div>

          {/* TAB 1: MILESTONE TIMELINE */}
          {activeTab === "timeline" && (
            <div className="space-y-4 pt-1">
              <div className="relative pl-6 space-y-6 before:absolute before:left-2.5 before:top-2 before:bottom-2 before:w-0.5 before:bg-slate-200">
                {activeRecord.milestones.map((m, idx) => (
                  <div key={idx} className="relative flex items-start gap-3">
                    {/* Step Icon */}
                    <div
                      className={`absolute -left-6 top-0.5 w-5 h-5 rounded-full flex items-center justify-center ring-4 ring-white ${
                        m.current
                          ? "bg-emerald-600 text-white ring-emerald-100"
                          : m.completed
                          ? "bg-[#0098db] text-white ring-sky-100"
                          : "bg-slate-300 text-white"
                      }`}
                    >
                      {m.completed ? (
                        <Check className="w-3 h-3 stroke-[3]" />
                      ) : (
                        <span className="w-1.5 h-1.5 rounded-full bg-white" />
                      )}
                    </div>

                    {/* Step Details */}
                    <div className="flex-1 bg-slate-50 hover:bg-slate-100/70 p-3 rounded-lg border border-slate-200 transition-colors">
                      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-1">
                        <div className="flex items-center gap-2">
                          <span className={`text-xs font-bold ${m.current ? "text-emerald-700" : "text-slate-900"}`}>
                            {m.step}
                          </span>
                          {m.current && (
                            <span className="px-2 py-0.2 rounded-full bg-emerald-100 text-emerald-800 text-[10px] font-bold uppercase">
                              Active Milestone
                            </span>
                          )}
                        </div>
                        <span className="text-[11px] font-mono text-slate-500">{m.timestamp}</span>
                      </div>

                      <div className="text-[11px] text-slate-600 font-medium mt-1">
                        Location: <strong className="text-slate-800">{m.location}</strong>
                      </div>

                      <p className="text-xs text-slate-500 mt-0.5">{m.details}</p>
                    </div>
                  </div>
                ))}
              </div>

              {/* Simulation CTA to advance live milestone */}
              <div className="pt-2 flex flex-col sm:flex-row items-center justify-between gap-3 bg-sky-50 border border-sky-200 rounded-xl p-3.5 text-xs text-sky-900">
                <div>
                  <strong className="block font-bold">Simulate Live Telematics Milestone Ping</strong>
                  <span className="text-[11px] text-sky-700">
                    Advance container through terminal boom barrier to test real-time gate pass triggers.
                  </span>
                </div>
                <button
                  type="button"
                  disabled={isRefreshing}
                  onClick={handleSimulateNextMilestone}
                  className="px-4 py-2 bg-[#0098db] hover:bg-[#0086c2] text-white rounded-lg font-bold shadow-xs transition-all cursor-pointer whitespace-nowrap flex items-center gap-1.5"
                >
                  <RefreshCw className={`w-3.5 h-3.5 ${isRefreshing ? "animate-spin" : ""}`} />
                  <span>Simulate Next Event</span>
                </button>
              </div>
            </div>
          )}

          {/* TAB 2: SPECS & MANIFEST */}
          {activeTab === "specs" && (
            <div className="space-y-3 text-xs">
              <div className="bg-slate-50 p-4 rounded-xl border border-slate-200 space-y-3">
                <h4 className="font-bold text-slate-800 uppercase tracking-wider text-[11px]">
                  Customs & Manifest Filing Parameters
                </h4>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 font-mono">
                  <div>
                    <span className="text-[10px] text-slate-400 uppercase font-sans">Billed Consignee</span>
                    <div className="font-bold text-slate-900">{activeRecord.consignee}</div>
                  </div>
                  <div>
                    <span className="text-[10px] text-slate-400 uppercase font-sans">Authorized Logistics Manager</span>
                    <div className="font-bold text-slate-900">John Lanny (PRN 100653)</div>
                  </div>
                  <div>
                    <span className="text-[10px] text-slate-400 uppercase font-sans">Gross Mass (Weighbridge)</span>
                    <div className="font-bold text-slate-900">{activeRecord.grossWeightKg} KG (Tare: {activeRecord.tareWeightKg} KG)</div>
                  </div>
                  <div>
                    <span className="text-[10px] text-slate-400 uppercase font-sans">Seal Security Check</span>
                    <div className="font-bold text-emerald-600">✓ {activeRecord.sealNumber} (Intact at Quayside)</div>
                  </div>
                  <div>
                    <span className="text-[10px] text-slate-400 uppercase font-sans">Customs Entry (IGM No)</span>
                    <div className="font-bold text-slate-900">IGM-2026-99182 / Item 12</div>
                  </div>
                  <div>
                    <span className="text-[10px] text-slate-400 uppercase font-sans">Commodity Description</span>
                    <div className="font-bold text-slate-900">Solar Inverter Modules & Power Cells</div>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* TAB 3: TERMINAL YARD BERTH MAP */}
          {activeTab === "terminal_map" && (
            <div className="space-y-3 text-xs">
              <div className="bg-slate-900 text-white p-4 rounded-xl border border-slate-700 space-y-3">
                <div className="flex items-center justify-between">
                  <span className="font-bold text-sm text-sky-400">
                    Terminal Berth 04 Stacking Grid
                  </span>
                  <span className="text-[11px] font-mono text-emerald-400">
                    Location: {activeRecord.yardBlockSlot}
                  </span>
                </div>

                {/* Stacking Grid Illustration */}
                <div className="grid grid-cols-4 sm:grid-cols-6 gap-2 p-3 bg-slate-950 rounded-lg border border-slate-800">
                  {["A1", "A2", "B1", "B2 (Target)", "B3", "B4", "C1", "C2", "C3", "C4", "D1", "D2"].map((slot) => {
                    const isTarget = slot.includes("Target");
                    return (
                      <div
                        key={slot}
                        className={`p-2.5 rounded text-center border font-mono text-[10px] font-bold ${
                          isTarget
                            ? "bg-emerald-500 text-slate-950 border-emerald-400 shadow-md ring-2 ring-emerald-300"
                            : "bg-slate-900 text-slate-400 border-slate-800"
                        }`}
                      >
                        {slot.split(" ")[0]}
                        {isTarget && (
                          <div className="text-[8px] font-sans font-black mt-0.5">
                            {activeRecord.containerNo.slice(-4)}
                          </div>
                        )}
                      </div>
                    );
                  })}
                </div>

                <div className="text-[11px] text-slate-400">
                  Direct Port Delivery (DPD) fast-track lane active. Container is ready for boom barrier release.
                </div>
              </div>
            </div>
          )}
        </div>

        {/* 4. Modal Footer Action Bar */}
        <div className="bg-slate-50 border-t border-slate-200 px-5 py-3 flex flex-wrap items-center justify-between gap-3 text-xs">
          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={handleDownloadGatePass}
              className="px-4 py-2 bg-slate-800 hover:bg-slate-900 text-white font-bold rounded-lg shadow-xs transition-all cursor-pointer flex items-center gap-1.5"
            >
              <Download className="w-3.5 h-3.5" />
              <span>Download Gate Pass & Barcode</span>
            </button>

            {onOpenNotificationSetup && (
              <button
                type="button"
                onClick={() => onOpenNotificationSetup(activeRecord)}
                className="px-4 py-2 bg-[#0098db] hover:bg-[#0086c2] text-white font-bold rounded-lg shadow-xs transition-all cursor-pointer flex items-center gap-1.5"
                title="Configure and dispatch arrival alerts to Email, WhatsApp, and Profile"
              >
                <Bell className="w-3.5 h-3.5 text-amber-300" />
                <span>Get Arrival Alerts (Email / WhatsApp / Profile)</span>
              </button>
            )}

            {activeRecord.edoStatus === "Pending Payment" && onNavigateToInvoice && (
              <button
                type="button"
                onClick={() => {
                  onClose();
                  onNavigateToInvoice();
                }}
                className="px-4 py-2 bg-emerald-600 hover:bg-emerald-500 text-white font-bold rounded-lg shadow-xs transition-all cursor-pointer flex items-center gap-1.5"
              >
                <FileText className="w-3.5 h-3.5" />
                <span>Pay DO Fee & Clear eDO</span>
              </button>
            )}

            {onNavigateToCfs && (
              <button
                type="button"
                onClick={() => {
                  onClose();
                  onNavigateToCfs();
                }}
                className="px-3 py-2 bg-white hover:bg-slate-100 text-slate-700 border border-slate-300 font-semibold rounded-lg transition-colors cursor-pointer"
              >
                Assign CFS Yard Hub
              </button>
            )}
          </div>

          <button
            type="button"
            onClick={onClose}
            className="px-5 py-2 bg-white border border-slate-300 text-slate-700 font-semibold rounded-lg hover:bg-slate-100 transition-colors cursor-pointer ml-auto"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
};
