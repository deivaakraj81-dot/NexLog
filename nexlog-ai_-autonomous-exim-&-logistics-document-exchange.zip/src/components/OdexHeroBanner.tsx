import React, { useState, useEffect } from "react";
import { Play, ArrowRight, ShieldCheck, Sparkles, ChevronLeft, ChevronRight, CheckCircle2, Ship, Box, Anchor } from "lucide-react";

interface NexLogHeroBannerProps {
  onLearnMoreUae: () => void;
  onPlayVideo: () => void;
  onLaunchScanner: () => void;
}

export const NexLogHeroBanner: React.FC<NexLogHeroBannerProps> = ({
  onLearnMoreUae,
  onPlayVideo,
  onLaunchScanner,
}) => {
  const [currentSlide, setCurrentSlide] = useState<number>(0);

  const slides = [
    {
      id: 0,
      badge: "SEAMLESS PORT & EDI ARCHITECTURE",
      title: "Discover the Power of our Autonomous Integration Framework",
      description:
        "Automating Paper BL to eBL conversions with Google Gemini 3.8 Flash. Instant SOLAS weighing compliance and Form 13 gate-in verification across 100+ global container terminals.",
      ctaPrimary: "Launch AI Intake",
      onPrimaryClick: onLaunchScanner,
      showPlay: true,
      imageSrc: "/assets/images/harbor_cranes_ship.jpg",
      imageAlt: "Commercial container cargo ship berthed under massive green and blue gantry cranes at ocean harbor",
      theme: "harbor",
    },
    {
      id: 1,
      badge: "OFFICIAL REGULATORY APPROVAL",
      title: "NexLog is Officially Certified for UAE's MPCI Compliance",
      description:
        "Certified by UAE authorities. Connected to NAIC. Powered by automation. Submit cargo data directly via NexLog—real-time, compliant, and hassle-free.",
      ctaPrimary: "Learn More",
      onPrimaryClick: onLearnMoreUae,
      showPlay: true,
      imageSrc: "/assets/images/cargo_ship.jpg",
      imageAlt: "Modern ocean container ship docked at terminal",
      theme: "tech",
    },
    {
      id: 2,
      badge: "STRAIGHT-THROUGH TERMINAL CLEARANCE",
      title: "Direct Port Delivery (DPD) & CFS Container Gate Automation",
      description:
        "Eliminate demurrage penalties and gate queues with instant OCR barcode generation and PCS 1x customs manifest integration.",
      ctaPrimary: "Explore Operations",
      onPrimaryClick: onLaunchScanner,
      showPlay: false,
      imageSrc: "/assets/images/container_yard.jpg",
      imageAlt: "Busy container terminal yard with cranes and trucks",
      theme: "terminal",
    },
  ];

  // Auto-advance slides smoothly every 8 seconds
  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentSlide((prev) => (prev + 1) % slides.length);
    }, 8000);
    return () => clearInterval(timer);
  }, [slides.length]);

  const slide = slides[currentSlide];

  return (
    <div className="relative w-full overflow-hidden select-none bg-slate-950 text-white min-h-[420px] sm:min-h-[480px] flex items-center shadow-2xl border-b border-slate-800">
      {/* Real Maritime Photography Background */}
      <div className="absolute inset-0 z-0">
        <img
          src={slide.imageSrc}
          alt={slide.imageAlt}
          className="w-full h-full object-cover filter brightness-[0.45] contrast-125 transition-all duration-1000 scale-105"
        />
        {/* Deep blue/slate gradient overlay for readable enterprise typography */}
        <div className="absolute inset-0 bg-gradient-to-r from-slate-950 via-slate-950/90 to-transparent"></div>
        <div className="absolute inset-0 bg-gradient-to-t from-slate-950 via-transparent to-slate-950/40"></div>
      </div>

      {/* Main Content Container */}
      <div className="relative z-10 max-w-7xl mx-auto px-6 sm:px-10 py-12 w-full flex flex-col justify-center">
        <div className="max-w-2xl space-y-4">
          {/* Regulatory / Tech Badge */}
          <div className="inline-flex items-center gap-2 px-3.5 py-1 rounded-full bg-blue-950/80 border border-sky-400/50 text-[11px] font-extrabold uppercase tracking-widest text-sky-300 shadow-md backdrop-blur-md">
            <span className="w-2 h-2 rounded-full bg-orange-500 animate-ping"></span>
            <span>{slide.badge}</span>
          </div>

          {/* Headline */}
          <h1 className="text-3xl sm:text-4xl md:text-5xl font-extrabold tracking-tight text-white leading-tight drop-shadow-md">
            {slide.title}
          </h1>

          {/* Description */}
          <p className="text-slate-200 text-sm sm:text-base leading-relaxed max-w-xl font-normal drop-shadow-sm">
            {slide.description}
          </p>

          {/* CTA Buttons */}
          <div className="pt-3 flex flex-wrap items-center gap-4">
            <button
              onClick={slide.onPrimaryClick}
              className="px-7 py-3 rounded-xl bg-[#f97316] hover:bg-[#ea580c] text-white font-extrabold text-sm tracking-wide shadow-lg shadow-orange-600/40 transition-all hover:scale-[1.02] active:scale-[0.98] flex items-center gap-2"
            >
              <span>{slide.ctaPrimary}</span>
              <ArrowRight className="w-4 h-4" />
            </button>

            {slide.showPlay && (
              <button
                onClick={onPlayVideo}
                className="w-12 h-12 rounded-full bg-white hover:bg-slate-100 text-[#f97316] flex items-center justify-center shadow-lg transition-all hover:scale-105 active:scale-95 group"
                title="Watch UAE MPCI Regulatory Walkthrough"
              >
                <Play className="w-5 h-5 fill-[#f97316] ml-0.5 group-hover:scale-110 transition-transform" />
              </button>
            )}

            <button
              onClick={onLaunchScanner}
              className="flex items-center gap-2 px-5 py-3 rounded-xl bg-slate-900/90 hover:bg-slate-800 text-slate-100 hover:text-white border border-slate-700 text-xs font-bold backdrop-blur-md transition-all shadow-md"
            >
              <Sparkles className="w-3.5 h-3.5 text-sky-400" />
              <span>Try Live Document Scanner</span>
            </button>
          </div>
        </div>
      </div>

      {/* Floating Real Vessel Status Card in Bottom Right */}
      <div className="hidden lg:flex absolute right-10 bottom-8 z-10 p-3.5 rounded-2xl bg-slate-900/85 border border-slate-700/80 backdrop-blur-md shadow-2xl items-center gap-3 max-w-sm">
        <img
          src={slide.imageSrc}
          alt="Vessel Thumbnail"
          className="w-16 h-12 object-cover rounded-xl border border-slate-600"
        />
        <div className="text-xs">
          <div className="font-bold text-white flex items-center gap-1.5">
            <Ship className="w-3.5 h-3.5 text-sky-400" />
            <span>JNPT Berth 04B / Jebel Ali Port</span>
          </div>
          <div className="text-[11px] text-emerald-400 font-mono mt-0.5">
            99.8% Automated Gate Clearance
          </div>
        </div>
      </div>

      {/* Slide Navigation Controls */}
      <div className="absolute bottom-5 left-6 sm:left-10 z-20 flex items-center gap-2">
        <button
          onClick={() => setCurrentSlide((prev) => (prev === 0 ? slides.length - 1 : prev - 1))}
          className="w-8 h-8 rounded-full bg-slate-900/80 hover:bg-slate-800 text-white border border-slate-700 flex items-center justify-center transition-all text-xs"
          aria-label="Previous slide"
        >
          <ChevronLeft className="w-4 h-4" />
        </button>

        <div className="flex items-center gap-1.5 px-2">
          {slides.map((s, idx) => (
            <button
              key={s.id}
              onClick={() => setCurrentSlide(idx)}
              className={`h-2 rounded-full transition-all ${
                currentSlide === idx ? "w-6 bg-orange-500" : "w-2 bg-slate-500"
              }`}
              aria-label={`Go to slide ${idx + 1}`}
            />
          ))}
        </div>

        <button
          onClick={() => setCurrentSlide((prev) => (prev + 1) % slides.length)}
          className="w-8 h-8 rounded-full bg-slate-900/80 hover:bg-slate-800 text-white border border-slate-700 flex items-center justify-center transition-all text-xs"
          aria-label="Next slide"
        >
          <ChevronRight className="w-4 h-4" />
        </button>
      </div>
    </div>
  );
};

// Export alias for backward compatibility
export const OdexHeroBanner = NexLogHeroBanner;
