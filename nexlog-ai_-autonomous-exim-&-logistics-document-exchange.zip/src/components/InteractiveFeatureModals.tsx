import React, { useState } from "react";
import {
  X,
  CheckCircle2,
  AlertTriangle,
  ArrowRight,
  ShieldCheck,
  Building,
  CreditCard,
  FileText,
  Truck,
  Sparkles,
  Server,
  Zap,
  Globe,
  DollarSign,
  Calendar,
  Lock,
} from "lucide-react";
import confetti from "canvas-confetti";

interface FeatureModalProps {
  activeModal: string | null;
  modalData?: any;
  onClose: () => void;
  onNavigateToScanner: () => void;
  onNavigateToQueue: () => void;
}

export const InteractiveFeatureModals: React.FC<FeatureModalProps> = ({
  activeModal,
  modalData,
  onClose,
  onNavigateToScanner,
  onNavigateToQueue,
}) => {
  // Pay Later Calculator State
  const [invoiceAmount, setInvoiceAmount] = useState<number>(45000);
  const [tenorDays, setTenorDays] = useState<number>(60);
  const [creditApproved, setCreditApproved] = useState<boolean>(false);

  // Export Wizard State
  const [containerNumber, setContainerNumber] = useState<string>("MSKU9481023");
  const [bookingRef, setBookingRef] = useState<string>("BK-2026-INNSA-991");
  const [exportSubmitted, setExportSubmitted] = useState<boolean>(false);

  // Import Wizard State
  const [blNumber, setBlNumber] = useState<string>("MSCU-NSA-8921044");
  const [importStatus, setImportStatus] = useState<string>("IDLE");

  // Book a Demo State
  const [demoCompany, setDemoCompany] = useState<string>("Apex Global Freight Ltd");
  const [demoEmail, setDemoEmail] = useState<string>("ops@apexfreight.com");
  const [demoBooked, setDemoBooked] = useState<boolean>(false);

  if (!activeModal) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-md overflow-y-auto animate-in fade-in duration-200">
      <div className="relative w-full max-w-2xl bg-white text-slate-900 rounded-3xl shadow-2xl overflow-hidden border border-slate-200 my-auto">
        {/* Header */}
        <div className="px-6 py-4 bg-slate-50 border-b border-slate-200 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-orange-100 border border-orange-200 flex items-center justify-center text-orange-600 font-bold">
              {activeModal === "export" && <Truck className="w-5 h-5" />}
              {activeModal === "import" && <FileText className="w-5 h-5" />}
              {activeModal === "erp" && <Server className="w-5 h-5" />}
              {activeModal === "pay-later" && <CreditCard className="w-5 h-5 text-red-600" />}
              {activeModal === "uae-mpci" && <Globe className="w-5 h-5 text-blue-600" />}
              {activeModal === "demo" && <Sparkles className="w-5 h-5 text-blue-600" />}
              {activeModal === "association" && <Building className="w-5 h-5 text-blue-600" />}
            </div>
            <div>
              <h3 className="text-base font-bold text-slate-900">
                {activeModal === "export" && "NexLog Export Processing & Form 13 Gate-In"}
                {activeModal === "import" && "NexLog Import Processing & e-Delivery Order (eDO)"}
                {activeModal === "erp" && "NexLog ERP Integration Framework"}
                {activeModal === "pay-later" && "NexLog Pay Later (Powered by DBS Bank)"}
                {activeModal === "uae-mpci" && "UAE MPCI Compliance & NAIC Cargo Gateway"}
                {activeModal === "demo" && "Book a Live NexLog EXIM AI Demonstration"}
                {activeModal === "association" && `Trade Association: ${modalData || "Maritime Council"}`}
              </h3>
              <p className="text-xs text-slate-500 font-medium">
                Autonomous EXIM Document Exchange Architecture
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="w-8 h-8 rounded-full bg-slate-200 hover:bg-slate-300 text-slate-600 hover:text-slate-900 flex items-center justify-center transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Modal Body Content */}
        <div className="p-6 overflow-y-auto max-h-[75vh] space-y-5 text-xs text-slate-700">
          {/* 1. EXPORT MODULE MODAL */}
          {activeModal === "export" && (
            <div className="space-y-4">
              <div className="p-3.5 rounded-xl bg-blue-50 border border-blue-200 text-blue-900 leading-relaxed">
                <strong>Simplified Export Processing:</strong> Generate electronic Form 13 Gate-In permits, pre-advise terminal weighbridge tickets, and file verified VGM records directly to Port Gate TOS.
              </div>

              {exportSubmitted ? (
                <div className="p-6 rounded-2xl bg-emerald-50 border border-emerald-200 text-center space-y-3">
                  <CheckCircle2 className="w-12 h-12 text-emerald-600 mx-auto" />
                  <div className="font-bold text-base text-emerald-900">
                    Form 13 Gate-In Permit Generated Successfully!
                  </div>
                  <p className="text-emerald-700">
                    Permit Ref: <strong className="font-mono">F13-EXP-{Date.now().toString().slice(-6)}</strong> has been registered with JNPT / Nhava Sheva Terminal Gate 4.
                  </p>
                  <div className="pt-2 flex justify-center gap-3">
                    <button
                      onClick={() => {
                        onClose();
                        onNavigateToScanner();
                      }}
                      className="px-4 py-2 rounded-xl bg-blue-600 text-white font-bold hover:bg-blue-500"
                    >
                      Audit with Gemini AI Scanner →
                    </button>
                  </div>
                </div>
              ) : (
                <div className="space-y-3">
                  <div className="grid grid-cols-2 gap-3">
                    <div>
                      <label className="block text-[11px] font-bold text-slate-600 mb-1">
                        Container Number (ISO 6346)
                      </label>
                      <input
                        type="text"
                        value={containerNumber}
                        onChange={(e) => setContainerNumber(e.target.value)}
                        className="w-full bg-slate-50 border border-slate-300 rounded-lg p-2.5 font-mono font-bold text-slate-800"
                      />
                    </div>
                    <div>
                      <label className="block text-[11px] font-bold text-slate-600 mb-1">
                        Shipping Line Booking Ref
                      </label>
                      <input
                        type="text"
                        value={bookingRef}
                        onChange={(e) => setBookingRef(e.target.value)}
                        className="w-full bg-slate-50 border border-slate-300 rounded-lg p-2.5 font-mono text-slate-800"
                      />
                    </div>
                  </div>

                  <div className="p-3 rounded-xl bg-slate-50 border border-slate-200 space-y-1.5">
                    <div className="font-bold text-slate-800">Autonomous Gate Pre-Checks:</div>
                    <div className="flex items-center gap-2 text-emerald-700">
                      <CheckCircle2 className="w-3.5 h-3.5" />
                      <span>IMO SOLAS Method 1 Weighbridge Integration: ACTIVE</span>
                    </div>
                    <div className="flex items-center gap-2 text-emerald-700">
                      <CheckCircle2 className="w-3.5 h-3.5" />
                      <span>Customs Shipping Bill Match (ICEGATE): VERIFIED</span>
                    </div>
                  </div>

                  <button
                    onClick={() => {
                      confetti({ particleCount: 50 });
                      setExportSubmitted(true);
                    }}
                    className="w-full py-3 rounded-xl bg-orange-600 hover:bg-orange-500 text-white font-bold text-xs uppercase tracking-wider shadow-md transition-all"
                  >
                    Generate Electronic Form 13 Gate Pass
                  </button>
                </div>
              )}
            </div>
          )}

          {/* 2. IMPORT MODULE MODAL */}
          {activeModal === "import" && (
            <div className="space-y-4">
              <div className="p-3.5 rounded-xl bg-orange-50 border border-orange-200 text-orange-950 leading-relaxed">
                <strong>Electronic Delivery Order (eDO):</strong> Automate shipping line DO release, digitize Master & House Bill of Lading surrenders, and eliminate terminal detention charges.
              </div>

              <div className="space-y-3">
                <div>
                  <label className="block text-[11px] font-bold text-slate-600 mb-1">
                    Bill of Lading Number
                  </label>
                  <input
                    type="text"
                    value={blNumber}
                    onChange={(e) => setBlNumber(e.target.value)}
                    className="w-full bg-slate-50 border border-slate-300 rounded-lg p-2.5 font-mono font-bold text-slate-800"
                  />
                </div>

                <div className="grid grid-cols-3 gap-2 text-center">
                  <div className="p-3 rounded-xl bg-slate-50 border border-slate-200">
                    <span className="text-[10px] text-slate-500 block">Ocean Freight</span>
                    <strong className="text-emerald-700">PAID</strong>
                  </div>
                  <div className="p-3 rounded-xl bg-slate-50 border border-slate-200">
                    <span className="text-[10px] text-slate-500 block">THC Charges</span>
                    <strong className="text-emerald-700">SETTLED</strong>
                  </div>
                  <div className="p-3 rounded-xl bg-slate-50 border border-slate-200">
                    <span className="text-[10px] text-slate-500 block">Customs Clearance</span>
                    <strong className="text-blue-700">INSPECTION CLEARED</strong>
                  </div>
                </div>

                {importStatus === "RELEASED" ? (
                  <div className="p-4 rounded-xl bg-emerald-50 border border-emerald-300 text-center space-y-2">
                    <CheckCircle2 className="w-8 h-8 text-emerald-600 mx-auto" />
                    <div className="font-bold text-emerald-900 text-sm">
                      eDO Released to Transporter MH-46-AR-8812!
                    </div>
                    <p className="text-[11px] text-emerald-700">
                      Dispatched electronically to Port Gate Boom Barrier via PCS 1x API.
                    </p>
                  </div>
                ) : (
                  <button
                    onClick={() => {
                      confetti({ particleCount: 50 });
                      setImportStatus("RELEASED");
                    }}
                    className="w-full py-3 rounded-xl bg-blue-600 hover:bg-blue-500 text-white font-bold text-xs uppercase tracking-wider shadow-md transition-all"
                  >
                    Release Instant Electronic Delivery Order (eDO)
                  </button>
                )}
              </div>
            </div>
          )}

          {/* 3. ERP INTEGRATION FRAMEWORK MODAL */}
          {activeModal === "erp" && (
            <div className="space-y-4">
              <div className="p-3.5 rounded-xl bg-slate-50 border border-slate-200 text-slate-700 leading-relaxed">
                <strong>Unified ERP & EDI Connectors:</strong> Real-time bi-directional data flow eliminating manual double entry across SAP, Oracle TMS, CargoWise, and Port Community Systems.
              </div>

              <div className="space-y-2">
                {[
                  { name: "SAP S/4HANA Supply Chain", status: "CONNECTED", latency: "12ms", protocol: "ODATA v4" },
                  { name: "CargoWise One (WiseTech)", status: "CONNECTED", latency: "24ms", protocol: "eAdaptor XML" },
                  { name: "Oracle Transportation Mgmt (OTM)", status: "SYNCING", latency: "45ms", protocol: "EDI 304/310" },
                  { name: "Microsoft Dynamics 365", status: "CONNECTED", latency: "18ms", protocol: "REST Webhook" },
                  { name: "NexLog PCS 1x EDIFACT CUSCAR", status: "LIVE ENGINE", latency: "5ms", protocol: "UN/EDIFACT D.00B" },
                ].map((erp, i) => (
                  <div
                    key={i}
                    className="flex items-center justify-between p-3 rounded-xl bg-slate-50 border border-slate-200"
                  >
                    <div>
                      <div className="font-bold text-slate-900">{erp.name}</div>
                      <div className="text-[10px] text-slate-500 font-mono">
                        {erp.protocol} • Latency: {erp.latency}
                      </div>
                    </div>
                    <span className="px-2.5 py-1 rounded-md text-[10px] font-bold font-mono bg-emerald-100 text-emerald-800 border border-emerald-300">
                      {erp.status}
                    </span>
                  </div>
                ))}
              </div>

              <button
                onClick={() => alert("Sync test passed! Simulated 1,240 records harmonized with zero errors.")}
                className="w-full py-2.5 rounded-xl bg-slate-800 hover:bg-slate-900 text-white font-bold text-xs"
              >
                Trigger Live ERP Synchronization Test
              </button>
            </div>
          )}

          {/* 4. NEXLOG PAY LATER (POWERED BY DBS) MODAL */}
          {activeModal === "pay-later" && (
            <div className="space-y-4">
              <div className="p-3.5 rounded-xl bg-gradient-to-r from-red-50 to-orange-50 border border-red-200 text-slate-800 flex items-center justify-between">
                <div>
                  <div className="font-bold text-red-700 text-sm">NexLog Pay Later (Powered by DBS Bank)</div>
                  <div className="text-[11px] text-slate-600">
                    Instant collateral-free credit for ocean freight, terminal handling, and customs duty.
                  </div>
                </div>
                <span className="font-black text-red-600 text-base bg-white px-3 py-1 rounded-lg shadow-sm border border-red-200">
                  XDBS
                </span>
              </div>

              {creditApproved ? (
                <div className="p-6 rounded-2xl bg-emerald-50 border border-emerald-300 text-center space-y-3">
                  <CheckCircle2 className="w-12 h-12 text-emerald-600 mx-auto" />
                  <div className="font-bold text-base text-emerald-900">
                    Trade Credit Sanctioned: ${invoiceAmount.toLocaleString()} USD!
                  </div>
                  <p className="text-emerald-700">
                    Disbursed directly to Shipping Line escrow account. Term: {tenorDays} Days. Interest Rate: 0.85% / month.
                  </p>
                  <button
                    onClick={() => setCreditApproved(false)}
                    className="px-4 py-2 rounded-xl bg-slate-800 text-white font-semibold text-xs"
                  >
                    Calculate Another Invoice
                  </button>
                </div>
              ) : (
                <div className="space-y-4">
                  <div>
                    <label className="block text-[11px] font-bold text-slate-700 mb-1">
                      Import Invoice / Duty Amount: <strong className="text-orange-600">${invoiceAmount.toLocaleString()} USD</strong>
                    </label>
                    <input
                      type="range"
                      min={5000}
                      max={250000}
                      step={5000}
                      value={invoiceAmount}
                      onChange={(e) => setInvoiceAmount(Number(e.target.value))}
                      className="w-full accent-orange-600"
                    />
                  </div>

                  <div>
                    <label className="block text-[11px] font-bold text-slate-700 mb-1">
                      Financing Tenor Period
                    </label>
                    <div className="grid grid-cols-3 gap-2">
                      {[30, 60, 90].map((days) => (
                        <button
                          key={days}
                          onClick={() => setTenorDays(days)}
                          className={`py-2 rounded-xl font-bold text-xs transition-all ${
                            tenorDays === days
                              ? "bg-red-600 text-white shadow-md"
                              : "bg-slate-100 text-slate-700 hover:bg-slate-200"
                          }`}
                        >
                          {days} Days
                        </button>
                      ))}
                    </div>
                  </div>

                  <div className="p-3.5 rounded-xl bg-slate-50 border border-slate-200 text-xs space-y-1">
                    <div className="flex justify-between">
                      <span className="text-slate-500">Processing Fee:</span>
                      <span className="font-bold text-slate-800">0.25% (Waived for NexLog Platinum)</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-slate-500">Estimated Monthly Repayment:</span>
                      <span className="font-bold text-emerald-700">
                        ${Math.round((invoiceAmount / (tenorDays / 30)) * 1.0085).toLocaleString()} USD
                      </span>
                    </div>
                  </div>

                  <button
                    onClick={() => {
                      confetti({ particleCount: 60 });
                      setCreditApproved(true);
                    }}
                    className="w-full py-3 rounded-xl bg-red-600 hover:bg-red-700 text-white font-bold text-xs uppercase tracking-wider shadow-lg shadow-red-600/30 transition-all"
                  >
                    Apply for Instant DBS Credit Sanction
                  </button>
                </div>
              )}
            </div>
          )}

          {/* 5. UAE MPCI CERTIFICATION MODAL */}
          {activeModal === "uae-mpci" && (
            <div className="space-y-4">
              <div className="p-4 rounded-xl bg-blue-50 border border-blue-200 text-blue-900 leading-relaxed">
                <h4 className="font-bold text-sm mb-1">UAE Maritime Port Community Infrastructure (MPCI)</h4>
                NexLog is officially accredited by UAE Ministry of Energy & Infrastructure and connected to the National Advanced Information Center (NAIC) for automated cargo pre-arrival manifest filings.
              </div>

              <div className="space-y-2">
                <div className="p-3 rounded-xl bg-slate-50 border border-slate-200 flex justify-between items-center">
                  <div>
                    <strong className="block text-slate-800">DP World Jebel Ali Terminal (AEJEA)</strong>
                    <span className="text-[11px] text-slate-500">Direct PCS integration with Dubai Trade</span>
                  </div>
                  <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-emerald-100 text-emerald-800">
                    CERTIFIED
                  </span>
                </div>

                <div className="p-3 rounded-xl bg-slate-50 border border-slate-200 flex justify-between items-center">
                  <div>
                    <strong className="block text-slate-800">Abu Dhabi Ports - Khalifa Port (AEKHL)</strong>
                    <span className="text-[11px] text-slate-500">Maqta Gateway automated manifest feed</span>
                  </div>
                  <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-emerald-100 text-emerald-800">
                    CERTIFIED
                  </span>
                </div>
              </div>

              <button
                onClick={() => alert("Connecting to UAE NAIC Gateway test portal.")}
                className="w-full py-2.5 rounded-xl bg-blue-600 hover:bg-blue-500 text-white font-bold text-xs"
              >
                Test Live UAE MPCI Pre-Filing Payload
              </button>
            </div>
          )}

          {/* 6. BOOK A DEMO MODAL */}
          {activeModal === "demo" && (
            <div className="space-y-4">
              {demoBooked ? (
                <div className="p-6 rounded-2xl bg-emerald-50 border border-emerald-300 text-center space-y-3">
                  <CheckCircle2 className="w-12 h-12 text-emerald-600 mx-auto" />
                  <div className="font-bold text-base text-emerald-900">
                    Demo Scheduled with NexLog Enterprise Team!
                  </div>
                  <p className="text-emerald-700">
                    Calendar invite and dedicated demo credentials dispatched to <strong className="font-mono">{demoEmail}</strong>.
                  </p>
                </div>
              ) : (
                <div className="space-y-3">
                  <div>
                    <label className="block text-[11px] font-bold text-slate-700 mb-1">Company / Freight Organization</label>
                    <input
                      type="text"
                      value={demoCompany}
                      onChange={(e) => setDemoCompany(e.target.value)}
                      className="w-full bg-slate-50 border border-slate-300 rounded-lg p-2.5 text-slate-800 font-semibold"
                    />
                  </div>
                  <div>
                    <label className="block text-[11px] font-bold text-slate-700 mb-1">Corporate Email Address</label>
                    <input
                      type="email"
                      value={demoEmail}
                      onChange={(e) => setDemoEmail(e.target.value)}
                      className="w-full bg-slate-50 border border-slate-300 rounded-lg p-2.5 text-slate-800 font-semibold"
                    />
                  </div>
                  <button
                    onClick={() => {
                      confetti({ particleCount: 50 });
                      setDemoBooked(true);
                    }}
                    className="w-full py-3 rounded-xl bg-orange-600 hover:bg-orange-500 text-white font-bold text-xs uppercase tracking-wider shadow-md transition-all"
                  >
                    Confirm Enterprise Demonstration Booking
                  </button>
                </div>
              )}
            </div>
          )}

          {/* 7. TRADE ASSOCIATION DETAILS */}
          {activeModal === "association" && (
            <div className="space-y-3">
              <div className="p-4 rounded-xl bg-slate-50 border border-slate-200 space-y-2">
                <div className="font-bold text-sm text-slate-900">{modalData}</div>
                <p className="text-slate-600 leading-relaxed">
                  Official Maritime Trade Partner accredited with NexLog and the Port Community System (PCS 1x). Facilitates digital documentation adoption, SOLAS compliance guidelines, and customs EDI integration for shipping agents, forwarders, and logistics operators.
                </p>
              </div>

              <div className="grid grid-cols-2 gap-2 text-center text-[11px]">
                <div className="p-3 rounded-xl bg-blue-50 text-blue-900 font-semibold">
                  Member Terminals: 100+
                </div>
                <div className="p-3 rounded-xl bg-emerald-50 text-emerald-900 font-semibold">
                  Digital Adoption: 94.8%
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Modal Footer */}
        <div className="px-6 py-3.5 bg-slate-50 border-t border-slate-200 flex justify-end">
          <button
            onClick={onClose}
            className="px-5 py-2 rounded-xl bg-slate-800 hover:bg-slate-900 text-white text-xs font-bold transition-colors"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
};
