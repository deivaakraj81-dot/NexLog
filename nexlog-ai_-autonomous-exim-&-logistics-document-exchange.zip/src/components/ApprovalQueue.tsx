import React, { useState } from "react";
import {
  CheckCircle2,
  XCircle,
  Eye,
  Search,
  Filter,
  AlertTriangle,
  ArrowRight,
  ShieldCheck,
  Truck,
  Sparkles,
  ExternalLink,
  Barcode,
  Layers,
  FileCheck,
  Send,
  X,
  Download,
} from "lucide-react";
import confetti from "canvas-confetti";
import { QueueItem } from "../types";
import { openPrintableTableReport, openPrintableGatePass } from "../utils/tableExport";

interface ApprovalQueueProps {
  queueItems: QueueItem[];
  onApprove: (item: QueueItem) => void;
  onReject: (item: QueueItem, reason: string) => void;
  onInspect: (item: QueueItem) => void;
  onBatchApproveLowRisk: () => void;
}

export const ApprovalQueue: React.FC<ApprovalQueueProps> = ({
  queueItems,
  onApprove,
  onReject,
  onInspect,
  onBatchApproveLowRisk,
}) => {
  const [filterStatus, setFilterStatus] = useState<"ALL" | "PENDING_APPROVAL" | "VERIFIED_DISPATCHED" | "REJECTED">("ALL");
  const [searchQuery, setSearchQuery] = useState<string>("");
  const [rejectingItem, setRejectingItem] = useState<QueueItem | null>(null);
  const [customRejectReason, setCustomRejectReason] = useState<string>("");

  // Filtered queue items
  const filteredItems = queueItems.filter((item) => {
    const matchesStatus = filterStatus === "ALL" || item.status === filterStatus;
    const q = searchQuery.toLowerCase();
    const matchesSearch =
      !q ||
      item.docId.toLowerCase().includes(q) ||
      item.containerId.toLowerCase().includes(q) ||
      item.shipper.toLowerCase().includes(q) ||
      item.documentType.toLowerCase().includes(q) ||
      item.vessel.toLowerCase().includes(q);
    return matchesStatus && matchesSearch;
  });

  const pendingCount = queueItems.filter((i) => i.status === "PENDING_APPROVAL").length;
  const pendingLowRiskCount = queueItems.filter(
    (i) => i.status === "PENDING_APPROVAL" && i.riskLevel === "LOW"
  ).length;

  const handleApproveClick = (item: QueueItem) => {
    // Fire confetti for celebration
    confetti({
      particleCount: 55,
      spread: 60,
      origin: { y: 0.8 },
      colors: ["#10b981", "#3b82f6", "#60a5fa"],
    });

    onApprove(item);
  };

  const handleOpenRejectModal = (item: QueueItem) => {
    setRejectingItem(item);
    setCustomRejectReason(
      item.auditResult.riskAssessment.discrepancies[0] ||
        "Non-compliant documentation. Correct tare weight and re-file with Port Authority."
    );
  };

  const handleConfirmReject = () => {
    if (!rejectingItem) return;
    onReject(rejectingItem, customRejectReason);
    setRejectingItem(null);
  };

  const handleDownloadPdf = () => {
    const exportData = {
      title: "Port Gate Approval & Verification Manifest Register",
      filenamePrefix: "Approval_Queue_Manifest",
      headers: [
        "#",
        "DOC ID",
        "DOCUMENT TYPE",
        "CONTAINER ID",
        "SHIPPER",
        "VESSEL & VOYAGE",
        "RISK SCORE",
        "AI RECOMMENDATION",
        "STATUS",
        "GATE DISPATCH",
      ],
      rows: filteredItems.map((item, idx) => [
        idx + 1,
        item.docId,
        item.documentType,
        item.containerId,
        item.shipper,
        item.vessel,
        `${item.riskScore}/100 (${item.riskLevel})`,
        item.auditResult?.riskAssessment?.recommendedAction || "Approved",
        item.status === "VERIFIED_DISPATCHED" ? "Dispatched" : item.status === "REJECTED" ? "Rejected" : "Pending Review",
        item.dispatchedAt || "Awaiting Sign-Off",
      ]),
      metadata: {
        Company: "Sudarsen Cargo Pvt Ltd",
        Superintendent: "John Lanny (Logistics Manager)",
        Terminal: "JNPT Nhava Sheva / Mundra (PCS 1x)",
        FilterStatus: filterStatus === "ALL" ? "All Queue Items" : filterStatus,
        TotalVerifiedRecords: `${filteredItems.length} documents`,
        ComplianceCertification: "IMO SOLAS VI & WCO SAFE Verified for Physical Filing",
      },
    };
    openPrintableTableReport(exportData, false);
  };

  return (
    <div className="space-y-6">
      {/* Top Banner & Batch Actions */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 p-5 rounded-2xl bg-gradient-to-r from-slate-900 via-slate-900 to-amber-950/40 border border-slate-800">
        <div>
          <div className="flex items-center gap-2">
            <span className="px-2.5 py-0.5 rounded-full text-xs font-bold uppercase tracking-wider bg-amber-500/20 text-amber-300 border border-amber-500/30">
              Core Feature 2
            </span>
            <h2 className="text-xl font-bold text-white tracking-tight">
              Smart Approval Queue (Human-In-The-Loop)
            </h2>
          </div>
          <p className="text-xs text-slate-400 mt-1">
            Superintendent review gate for pre-audited ocean shipping manifests before automated PCS 1x Port Gate barcode issuance.
          </p>
        </div>

        {/* Action Buttons: Download PDF & Batch STP */}
        <div className="flex items-center gap-2.5 flex-wrap">
          <button
            onClick={handleDownloadPdf}
            className="flex items-center gap-2 px-4 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-white font-semibold text-xs border border-slate-700 shadow-sm transition-all hover:scale-[1.02] active:scale-[0.98] cursor-pointer"
            title="Download verified shipping records as PDF for physical filing"
          >
            <Download className="w-4 h-4 text-sky-400" />
            <span>Download as PDF</span>
          </button>

          {/* Batch STP Approval Button */}
          {pendingLowRiskCount > 0 && (
            <button
              onClick={() => {
                confetti({ particleCount: 80, spread: 70, origin: { y: 0.7 } });
                onBatchApproveLowRisk();
              }}
              className="flex items-center gap-2 px-4 py-2.5 rounded-xl bg-gradient-to-r from-emerald-600 to-teal-500 hover:from-emerald-500 hover:to-teal-400 text-white font-bold text-xs shadow-lg shadow-emerald-900/30 transition-all hover:scale-[1.02] active:scale-[0.98] cursor-pointer"
            >
              <Sparkles className="w-4 h-4 text-emerald-200" />
              <span>Approve All {pendingLowRiskCount} Low-Risk STP Docs</span>
            </button>
          )}
        </div>
      </div>

      {/* Filter and Search Bar */}
      <div className="flex flex-col sm:flex-row items-center justify-between gap-3 p-3 rounded-2xl bg-slate-900/90 border border-slate-800">
        {/* Status Tabs */}
        <div className="flex items-center gap-1.5 w-full sm:w-auto overflow-x-auto pb-1 sm:pb-0">
          {(
            [
              { key: "ALL", label: "All Items", count: queueItems.length, highlight: false },
              {
                key: "PENDING_APPROVAL",
                label: "Pending Review",
                count: pendingCount,
                highlight: pendingCount > 0,
              },
              {
                key: "VERIFIED_DISPATCHED",
                label: "Dispatched to Gate",
                count: queueItems.filter((i) => i.status === "VERIFIED_DISPATCHED").length,
                highlight: false,
              },
              {
                key: "REJECTED",
                label: "Rejected / Defective",
                count: queueItems.filter((i) => i.status === "REJECTED").length,
                highlight: false,
              },
            ] as const
          ).map((tab) => {
            const isActive = filterStatus === tab.key;
            return (
              <button
                key={tab.key}
                onClick={() => setFilterStatus(tab.key)}
                className={`px-3 py-1.5 rounded-xl text-xs font-semibold transition-all whitespace-nowrap flex items-center gap-1.5 ${
                  isActive
                    ? "bg-blue-600 text-white shadow-sm"
                    : "text-slate-400 hover:text-slate-200 hover:bg-slate-800"
                }`}
              >
                <span>{tab.label}</span>
                <span
                  className={`text-[10px] px-1.5 py-0.2 rounded-full font-mono ${
                    isActive
                      ? "bg-blue-700 text-white"
                      : tab.highlight
                      ? "bg-amber-500/20 text-amber-300 font-bold"
                      : "bg-slate-800 text-slate-400"
                  }`}
                >
                  {tab.count}
                </span>
              </button>
            );
          })}
        </div>

        {/* Search input */}
        <div className="relative w-full sm:w-64">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search container, shipper, doc ID..."
            className="w-full bg-slate-950 border border-slate-800 rounded-xl pl-9 pr-3 py-1.5 text-xs text-slate-200 placeholder-slate-400 focus:outline-none focus:border-blue-500 transition-all font-sans"
          />
        </div>
      </div>

      {/* Core Feature 2 Live Table */}
      <div className="rounded-2xl bg-slate-900/90 border border-slate-800 overflow-hidden shadow-xl">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs border-collapse">
            <thead>
              <tr className="bg-slate-950/80 border-b border-slate-800 text-slate-400 uppercase tracking-wider text-[11px] font-bold">
                <th className="py-3.5 px-4">Doc ID</th>
                <th className="py-3.5 px-4">Document Type</th>
                <th className="py-3.5 px-4">Shipper / Container</th>
                <th className="py-3.5 px-4 text-center">Gemini Risk Score</th>
                <th className="py-3.5 px-4 text-center">AI Recommendation</th>
                <th className="py-3.5 px-4 text-right">Action</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/80">
              {filteredItems.length === 0 ? (
                <tr>
                  <td colSpan={6} className="text-center py-12 text-slate-400">
                    No documents found matching the selected filter.
                  </td>
                </tr>
              ) : (
                filteredItems.map((item) => {
                  const isPending = item.status === "PENDING_APPROVAL";
                  const isDispatched = item.status === "VERIFIED_DISPATCHED";
                  const isRejected = item.status === "REJECTED";

                  return (
                    <tr
                      key={item.id}
                      className={`hover:bg-slate-800/40 transition-colors ${
                        isPending && item.riskLevel === "HIGH"
                          ? "bg-rose-950/10"
                          : isPending && item.riskLevel === "MEDIUM"
                          ? "bg-amber-950/10"
                          : ""
                      }`}
                    >
                      {/* Column 1: Doc ID */}
                      <td className="py-4 px-4 font-mono font-bold text-slate-200 whitespace-nowrap">
                        <div className="flex items-center gap-2">
                          <span>{item.docId}</span>
                          {isPending && (
                            <span className="w-2 h-2 rounded-full bg-amber-400 animate-pulse"></span>
                          )}
                        </div>
                        <span className="text-[10px] text-slate-400 font-sans block mt-0.5">
                          {item.submittedAt}
                        </span>
                      </td>

                      {/* Column 2: Document Type */}
                      <td className="py-4 px-4 font-semibold text-slate-200 whitespace-nowrap">
                        <div className="flex items-center gap-1.5">
                          <span>{item.documentType}</span>
                        </div>
                        <span className="text-[10px] text-slate-400 font-mono block mt-0.5">
                          {item.vessel}
                        </span>
                      </td>

                      {/* Column 3: Shipper & Container ID */}
                      <td className="py-4 px-4 max-w-xs">
                        <div className="font-semibold text-slate-200 truncate">
                          {item.shipper}
                        </div>
                        <div className="flex items-center gap-2 mt-0.5">
                          <span className="font-mono text-[11px] text-blue-300 bg-blue-950/80 px-1.5 py-0.2 rounded border border-blue-900/60">
                            {item.containerId}
                          </span>
                          <span className="text-[10px] text-slate-400 truncate">
                            {item.consignee}
                          </span>
                        </div>
                      </td>

                      {/* Column 4: Gemini Risk Score */}
                      <td className="py-4 px-4 text-center whitespace-nowrap">
                        <div className="inline-flex items-center gap-2">
                          <div
                            className={`w-10 h-10 rounded-xl flex flex-col items-center justify-center font-mono font-extrabold border ${
                              item.riskLevel === "LOW"
                                ? "bg-emerald-950/60 text-emerald-300 border-emerald-800/80"
                                : item.riskLevel === "MEDIUM"
                                ? "bg-amber-950/60 text-amber-300 border-amber-800/80"
                                : "bg-rose-950/60 text-rose-300 border-rose-800/80"
                            }`}
                          >
                            <span className="text-sm leading-none">{item.riskScore}</span>
                            <span className="text-[8px] uppercase tracking-tighter text-slate-400">
                              /100
                            </span>
                          </div>
                          <div className="text-left">
                            <span
                              className={`text-[10px] font-bold block ${
                                item.riskLevel === "LOW"
                                  ? "text-emerald-400"
                                  : item.riskLevel === "MEDIUM"
                                  ? "text-amber-400"
                                  : "text-rose-400"
                              }`}
                            >
                              {item.riskLevel} RISK
                            </span>
                            <span className="text-[9px] text-slate-400 font-mono">
                              SOLAS VI Reg 2
                            </span>
                          </div>
                        </div>
                      </td>

                      {/* Column 5: AI Recommendation */}
                      <td className="py-4 px-4 text-center whitespace-nowrap">
                        <span
                          className={`inline-flex items-center gap-1 px-3 py-1 rounded-full text-[11px] font-extrabold uppercase border ${
                            item.aiRecommendation === "Approve"
                              ? "bg-emerald-950/80 text-emerald-300 border-emerald-700/60"
                              : item.aiRecommendation === "Needs Manual Review"
                              ? "bg-amber-950/80 text-amber-300 border-amber-700/60"
                              : "bg-rose-950/80 text-rose-300 border-rose-700/60"
                          }`}
                        >
                          {item.aiRecommendation === "Approve" && (
                            <CheckCircle2 className="w-3.5 h-3.5" />
                          )}
                          {item.aiRecommendation === "Needs Manual Review" && (
                            <AlertTriangle className="w-3.5 h-3.5" />
                          )}
                          {item.aiRecommendation === "Reject" && (
                            <XCircle className="w-3.5 h-3.5" />
                          )}
                          <span>{item.aiRecommendation}</span>
                        </span>
                      </td>

                      {/* Column 6: Action */}
                      <td className="py-4 px-4 text-right whitespace-nowrap">
                        <div className="flex items-center justify-end gap-2">
                          {/* Inspect Dossier Button */}
                          <button
                            onClick={() => onInspect(item)}
                            title="Inspect AI Extraction Dossier"
                            className="p-2 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white transition-colors border border-slate-700 cursor-pointer"
                          >
                            <Eye className="w-3.5 h-3.5" />
                          </button>

                          {/* Print / Download Gate Pass Dossier as PDF */}
                          <button
                            onClick={() => openPrintableGatePass(item)}
                            title="Download Port Gate Pass & Verification Dossier as PDF for physical filing"
                            className="p-2 rounded-lg bg-slate-800 hover:bg-slate-700 text-sky-400 hover:text-white transition-colors border border-slate-700 cursor-pointer"
                          >
                            <Download className="w-3.5 h-3.5" />
                          </button>

                          {/* Dynamic Action Buttons for Pending items */}
                          {isPending && (
                            <>
                              <button
                                onClick={() => handleApproveClick(item)}
                                className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs shadow-md shadow-emerald-900/30 transition-all hover:scale-[1.02] active:scale-[0.98]"
                              >
                                <CheckCircle2 className="w-3.5 h-3.5" />
                                <span>Approve Document</span>
                              </button>

                              <button
                                onClick={() => handleOpenRejectModal(item)}
                                className="flex items-center gap-1 px-2.5 py-1.5 rounded-lg bg-rose-600/20 hover:bg-rose-600 text-rose-300 hover:text-white font-semibold text-xs border border-rose-700/50 transition-all"
                              >
                                <XCircle className="w-3.5 h-3.5" />
                                <span>Reject</span>
                              </button>
                            </>
                          )}

                          {/* Verified & Dispatched Status Pill */}
                          {isDispatched && (
                            <div className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-emerald-950/70 border border-emerald-800 text-emerald-300 text-xs font-semibold">
                              <Barcode className="w-3.5 h-3.5 text-emerald-400" />
                              <span>Verified & Dispatched to Port Gate</span>
                            </div>
                          )}

                          {/* Rejected Status Pill */}
                          {isRejected && (
                            <div className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-rose-950/70 border border-rose-800 text-rose-300 text-xs font-semibold">
                              <XCircle className="w-3.5 h-3.5 text-rose-400" />
                              <span>Rejected & Notice Sent</span>
                            </div>
                          )}
                        </div>
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Reject Modal */}
      {rejectingItem && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70 backdrop-blur-sm animate-in fade-in duration-200">
          <div className="w-full max-w-lg rounded-2xl bg-slate-900 border border-rose-800/80 shadow-2xl p-6 space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-slate-800">
              <div className="flex items-center gap-2 text-rose-400 font-bold text-base">
                <AlertTriangle className="w-5 h-5" />
                <span>Reject Shipping Document ({rejectingItem.docId})</span>
              </div>
              <button
                onClick={() => setRejectingItem(null)}
                className="text-slate-400 hover:text-white p-1"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="text-xs text-slate-300 space-y-2">
              <p>
                Specify the compliance non-conformance notice to be dispatched to Shipper{" "}
                <strong className="text-white">{rejectingItem.shipper}</strong> and Port Terminal Gate TOS:
              </p>

              {/* Quick Preset Rejection Reasons */}
              <div className="space-y-1.5 pt-1">
                <span className="text-[11px] font-semibold uppercase text-slate-400">
                  Quick Regulatory Violations (Click to Apply):
                </span>
                <div className="grid grid-cols-1 gap-1.5">
                  {[
                    "Weight variance exceeds IMO SOLAS 5% margin (+2,150 kg overweight). Require amended weighbridge slip.",
                    "ISO 17712 High-Security Bolt Seal missing or recorded as tampered.",
                    "Form 13 Gate pass time window expired. Reschedule booking slot.",
                    "Tariff classification mismatch between commercial invoice and DGFT export declaration.",
                  ].map((preset, idx) => (
                    <button
                      key={idx}
                      onClick={() => setCustomRejectReason(preset)}
                      className="text-left p-2 rounded-lg bg-slate-950/80 hover:bg-slate-800 border border-slate-800 text-[11px] text-slate-300 hover:text-white transition-colors"
                    >
                      • {preset}
                    </button>
                  ))}
                </div>
              </div>

              {/* Text Area */}
              <div className="pt-2">
                <label className="block text-[11px] font-semibold text-slate-400 mb-1">
                  Manager Non-Compliance Notice:
                </label>
                <textarea
                  value={customRejectReason}
                  onChange={(e) => setCustomRejectReason(e.target.value)}
                  rows={3}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl p-3 text-xs text-slate-200 focus:outline-none focus:border-rose-500 font-mono"
                />
              </div>
            </div>

            <div className="flex items-center justify-end gap-3 pt-2">
              <button
                onClick={() => setRejectingItem(null)}
                className="px-4 py-2 rounded-xl bg-slate-800 text-slate-300 hover:text-white text-xs font-semibold"
              >
                Cancel
              </button>
              <button
                onClick={handleConfirmReject}
                className="px-5 py-2 rounded-xl bg-rose-600 hover:bg-rose-500 text-white text-xs font-bold shadow-md shadow-rose-900/30 flex items-center gap-1.5"
              >
                <XCircle className="w-4 h-4" />
                <span>Confirm Rejection & Dispatch Notice</span>
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
