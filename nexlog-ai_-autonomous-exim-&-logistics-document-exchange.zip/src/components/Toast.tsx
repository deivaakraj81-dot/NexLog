import React from "react";
import { CheckCircle2, AlertTriangle, XCircle, Info, X } from "lucide-react";

export interface ToastMessage {
  id: string;
  type: "success" | "warning" | "error" | "info";
  title: string;
  message: string;
  timestamp?: string;
}

interface ToastProps {
  toasts: ToastMessage[];
  onDismiss: (id: string) => void;
}

export const ToastContainer: React.FC<ToastProps> = ({ toasts, onDismiss }) => {
  if (toasts.length === 0) return null;

  return (
    <div className="fixed bottom-5 right-5 z-50 flex flex-col gap-2 max-w-md w-full pointer-events-none">
      {toasts.map((toast) => {
        const isSuccess = toast.type === "success";
        const isWarning = toast.type === "warning";
        const isError = toast.type === "error";

        const borderClass = isSuccess
          ? "border-emerald-500/50 bg-slate-900/95 text-emerald-100 shadow-emerald-950/50"
          : isWarning
          ? "border-amber-500/50 bg-slate-900/95 text-amber-100 shadow-amber-950/50"
          : isError
          ? "border-rose-500/50 bg-slate-900/95 text-rose-100 shadow-rose-950/50"
          : "border-blue-500/50 bg-slate-900/95 text-blue-100 shadow-blue-950/50";

        const icon = isSuccess ? (
          <CheckCircle2 className="w-5 h-5 text-emerald-400 shrink-0 mt-0.5" />
        ) : isWarning ? (
          <AlertTriangle className="w-5 h-5 text-amber-400 shrink-0 mt-0.5" />
        ) : isError ? (
          <XCircle className="w-5 h-5 text-rose-400 shrink-0 mt-0.5" />
        ) : (
          <Info className="w-5 h-5 text-blue-400 shrink-0 mt-0.5" />
        );

        return (
          <div
            key={toast.id}
            className={`pointer-events-auto flex items-start gap-3 p-4 rounded-xl border shadow-xl backdrop-blur-md transition-all duration-300 animate-in slide-in-from-bottom-3 ${borderClass}`}
          >
            {icon}
            <div className="flex-1 text-sm">
              <div className="font-semibold text-slate-100 tracking-tight">{toast.title}</div>
              <div className="text-slate-300 text-xs mt-0.5 leading-relaxed">{toast.message}</div>
            </div>
            <button
              onClick={() => onDismiss(toast.id)}
              className="text-slate-400 hover:text-slate-200 transition-colors p-1"
              aria-label="Dismiss toast"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        );
      })}
    </div>
  );
};
