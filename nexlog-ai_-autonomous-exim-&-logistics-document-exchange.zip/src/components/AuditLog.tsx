import React, { useState } from "react";
import {
  FileClock,
  Download,
  Search,
  CheckCircle2,
  XCircle,
  AlertTriangle,
  Barcode,
  Sparkles,
  ShieldCheck,
  Hash,
} from "lucide-react";
import { AuditLogItem } from "../types";
import { openPrintableTableReport } from "../utils/tableExport";

interface AuditLogProps {
  logs: AuditLogItem[];
}

export const AuditLog: React.FC<AuditLogProps> = ({ logs }) => {
  const [filterAction, setFilterAction] = useState<string>("ALL");
  const [searchQuery, setSearchQuery] = useState<string>("");

  const filteredLogs = logs.filter((log) => {
    const matchesAction = filterAction === "ALL" || log.action === filterAction;
    const q = searchQuery.toLowerCase();
    const matchesSearch =
      !q ||
      log.docId.toLowerCase().includes(q) ||
      log.containerId.toLowerCase().includes(q) ||
      log.actor.toLowerCase().includes(q) ||
      log.notes.toLowerCase().includes(q);
    return matchesAction && matchesSearch;
  });

  const handleDownloadPdf = () => {
    const exportData = {
      title: "Cryptographic Audit Ledger & Compliance Trail",
      filenamePrefix: "NexLog_Audit_Trail",
      headers: [
        "#",
        "TIMESTAMP",
        "DOCUMENT ID",
        "CONTAINER ID",
        "ACTION",
        "ACTOR",
        "RISK SCORE",
        "CHECKSUM HASH",
        "AUDIT DISPATCH NOTES",
      ],
      rows: filteredLogs.map((l, idx) => [
        idx + 1,
        l.timestamp,
        l.docId,
        l.containerId,
        l.action,
        l.actor,
        `${l.riskScore}/100`,
        l.hash,
        l.notes,
      ]),
      metadata: {
        Company: "Sudarsen Cargo Pvt Ltd",
        Superintendent: "John Lanny (Logistics Manager)",
        Standards: "IMO SOLAS VI, WCO SAFE Framework & Port Customs Certified",
        TotalLoggedEvents: `${filteredLogs.length} verified events`,
        ActionFilter: filterAction === "ALL" ? "All Event Types" : filterAction,
        ExportPurpose: "Official Port Customs Physical Filing & Compliance Inspection",
      },
    };
    openPrintableTableReport(exportData, false);
  };

  const exportCSV = () => {
    const headers = ["Timestamp", "Document ID", "Container ID", "Action", "Actor", "Risk Score", "Hash", "Notes"];
    const rows = filteredLogs.map((l) => [
      `"${l.timestamp}"`,
      `"${l.docId}"`,
      `"${l.containerId}"`,
      `"${l.action}"`,
      `"${l.actor}"`,
      l.riskScore,
      `"${l.hash}"`,
      `"${l.notes.replace(/"/g, '""')}"`,
    ]);

    const csvContent = "data:text/csv;charset=utf-8," + [headers.join(","), ...rows.map((r) => r.join(","))].join("\n");
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement("a");
    link.setAttribute("href", encodedUri);
    link.setAttribute("download", `NexLog_Audit_Trail_${Date.now()}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="space-y-6">
      {/* Top Banner */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 p-5 rounded-2xl bg-gradient-to-r from-slate-900 via-slate-900 to-emerald-950/40 border border-slate-800">
        <div>
          <div className="flex items-center gap-2">
            <span className="px-2.5 py-0.5 rounded-full text-xs font-bold uppercase tracking-wider bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 flex items-center gap-1">
              <ShieldCheck className="w-3.5 h-3.5" />
              Cryptographic Audit Ledger
            </span>
            <h2 className="text-xl font-bold text-white tracking-tight">
              Audit & Analytics Compliance Trail
            </h2>
          </div>
          <p className="text-xs text-slate-400 mt-1">
            Immutable log of all autonomous and human actions. Certified for IMO SOLAS, WCO SAFE Framework, and Port Customs inspection.
          </p>
        </div>

        <div className="flex items-center gap-2.5 flex-wrap">
          <button
            onClick={handleDownloadPdf}
            className="flex items-center gap-2 px-4 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-white font-semibold text-xs border border-slate-700 shadow-sm transition-all hover:scale-[1.02] active:scale-[0.98] cursor-pointer"
            title="Download verified audit records as PDF for physical filing and customs inspection"
          >
            <Download className="w-4 h-4 text-sky-400" />
            <span>Download as PDF</span>
          </button>

          <button
            onClick={exportCSV}
            className="flex items-center gap-2 px-4 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-white font-semibold text-xs border border-slate-700 shadow-sm transition-all hover:scale-[1.02] active:scale-[0.98] cursor-pointer"
          >
            <Download className="w-4 h-4 text-emerald-400" />
            <span>Export Compliance CSV</span>
          </button>
        </div>
      </div>

      {/* Filter and Search */}
      <div className="flex flex-col sm:flex-row items-center justify-between gap-3 p-3 rounded-2xl bg-slate-900/90 border border-slate-800">
        <div className="flex items-center gap-2 overflow-x-auto w-full sm:w-auto pb-1 sm:pb-0">
          {[
            { key: "ALL", label: "All Transactions" },
            { key: "PORT_GATE_DISPATCHED", label: "Gate Dispatched" },
            { key: "MANAGER_APPROVED", label: "Approved" },
            { key: "MANAGER_REJECTED", label: "Rejected" },
            { key: "SOLAS_FLAGGED", label: "SOLAS Flagged" },
          ].map((tab) => (
            <button
              key={tab.key}
              onClick={() => setFilterAction(tab.key)}
              className={`px-3 py-1.5 rounded-xl text-xs font-semibold whitespace-nowrap transition-all ${
                filterAction === tab.key
                  ? "bg-blue-600 text-white shadow-sm"
                  : "text-slate-400 hover:text-slate-200 hover:bg-slate-800"
              }`}
            >
              {tab.label}
            </button>
          ))}
        </div>

        <div className="relative w-full sm:w-64">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search audit trail..."
            className="w-full bg-slate-950 border border-slate-800 rounded-xl pl-9 pr-3 py-1.5 text-xs text-slate-200 focus:outline-none focus:border-blue-500 font-sans"
          />
        </div>
      </div>

      {/* Audit Log Table */}
      <div className="rounded-2xl bg-slate-900/90 border border-slate-800 overflow-hidden shadow-xl">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs border-collapse">
            <thead>
              <tr className="bg-slate-950/80 border-b border-slate-800 text-slate-400 uppercase tracking-wider text-[11px] font-bold">
                <th className="py-3.5 px-4">Timestamp</th>
                <th className="py-3.5 px-4">Document / Container</th>
                <th className="py-3.5 px-4">Action Event</th>
                <th className="py-3.5 px-4">Authorized Actor</th>
                <th className="py-3.5 px-4 text-center">Risk Score</th>
                <th className="py-3.5 px-4">Audit Notes & Hash</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/80">
              {filteredLogs.length === 0 ? (
                <tr>
                  <td colSpan={6} className="text-center py-10 text-slate-400">
                    No audit records matching query.
                  </td>
                </tr>
              ) : (
                filteredLogs.map((log) => {
                  const isGateDispatched = log.action === "PORT_GATE_DISPATCHED";
                  const isApproved = log.action === "MANAGER_APPROVED";
                  const isRejected = log.action === "MANAGER_REJECTED";
                  const isFlagged = log.action === "SOLAS_FLAGGED";

                  return (
                    <tr key={log.id} className="hover:bg-slate-800/40 transition-colors">
                      <td className="py-3.5 px-4 font-mono text-slate-400 whitespace-nowrap">
                        {log.timestamp}
                      </td>

                      <td className="py-3.5 px-4 whitespace-nowrap">
                        <span className="font-bold text-slate-200 font-mono block">
                          {log.docId}
                        </span>
                        <span className="text-[10px] text-blue-300 font-mono">
                          {log.containerId}
                        </span>
                      </td>

                      <td className="py-3.5 px-4 whitespace-nowrap">
                        <span
                          className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded-md text-[10px] font-extrabold uppercase border ${
                            isGateDispatched
                              ? "bg-emerald-950 text-emerald-300 border-emerald-800"
                              : isApproved
                              ? "bg-blue-950 text-blue-300 border-blue-800"
                              : isRejected
                              ? "bg-rose-950 text-rose-300 border-rose-800"
                              : "bg-amber-950 text-amber-300 border-amber-800"
                          }`}
                        >
                          {isGateDispatched && <Barcode className="w-3 h-3 text-emerald-400" />}
                          {isApproved && <CheckCircle2 className="w-3 h-3 text-blue-400" />}
                          {isRejected && <XCircle className="w-3 h-3 text-rose-400" />}
                          {isFlagged && <AlertTriangle className="w-3 h-3 text-amber-400" />}
                          <span>{log.action.replace(/_/g, " ")}</span>
                        </span>
                      </td>

                      <td className="py-3.5 px-4 text-slate-300 font-medium">
                        {log.actor}
                      </td>

                      <td className="py-3.5 px-4 text-center font-mono font-bold">
                        <span
                          className={
                            log.riskScore < 20
                              ? "text-emerald-400"
                              : log.riskScore < 60
                              ? "text-amber-400"
                              : "text-rose-400"
                          }
                        >
                          {log.riskScore}
                        </span>
                      </td>

                      <td className="py-3.5 px-4 max-w-sm">
                        <div className="text-slate-300 text-xs truncate">{log.notes}</div>
                        <div className="flex items-center gap-1 font-mono text-[10px] text-slate-400 mt-0.5">
                          <Hash className="w-3 h-3 text-slate-400" />
                          <span>{log.hash}</span>
                        </div>
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
