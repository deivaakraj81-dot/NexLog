import React, { useState } from "react";
import {
  Home,
  Building2,
  Settings,
  Share2,
  PhoneCall,
  ChevronDown,
  Globe2,
  Crown,
  LogIn,
  Check,
} from "lucide-react";
import { NexLogLogo } from "./OdexLogo";
import { CountryFlag } from "./CountryFlag";

export interface CountryNode {
  code: string;
  name: string;
  flag: string;
  port: string;
  terminal: string;
  currencyCode: string;
  currencySymbol: string;
  rateToInr: number; // 1 INR in local currency unit
}

export const NEXLOG_COUNTRIES: CountryNode[] = [
  { code: "IN", name: "INDIA", flag: "🇮🇳", port: "INNSA", terminal: "Nhava Sheva (JNPT)", currencyCode: "INR", currencySymbol: "₹", rateToInr: 1.0 },
  { code: "AE", name: "UAE", flag: "🇦🇪", port: "AEJEA", terminal: "Jebel Ali Port (DP World)", currencyCode: "AED", currencySymbol: "AED ", rateToInr: 0.044 },
  { code: "GH", name: "GHANA", flag: "🇬🇭", port: "GHTEM", terminal: "Port of Tema", currencyCode: "GHS", currencySymbol: "GH₵", rateToInr: 0.18 },
  { code: "QA", name: "QATAR", flag: "🇶🇦", port: "QAHMD", terminal: "Hamad Port", currencyCode: "QAR", currencySymbol: "QAR ", rateToInr: 0.044 },
  { code: "BH", name: "BAHRAIN", flag: "🇧🇭", port: "BHKBS", terminal: "Khalifa Bin Salman Port", currencyCode: "BHD", currencySymbol: "BD ", rateToInr: 0.0045 },
  { code: "KW", name: "KUWAIT", flag: "🇰🇼", port: "KWSAA", terminal: "Shuaiba Port", currencyCode: "KWD", currencySymbol: "KD ", rateToInr: 0.0037 },
  { code: "NG", name: "NIGERIA", flag: "🇳🇬", port: "NGLOS", terminal: "Lagos / Apapa Port", currencyCode: "NGN", currencySymbol: "₦", rateToInr: 18.2 },
  { code: "SN", name: "SENEGAL", flag: "🇸🇳", port: "SNDKR", terminal: "Port of Dakar", currencyCode: "XOF", currencySymbol: "CFA ", rateToInr: 7.2 },
  { code: "US", name: "USA", flag: "🇺🇸", port: "USLAX", terminal: "Port of Los Angeles", currencyCode: "USD", currencySymbol: "$", rateToInr: 0.012 },
  { code: "SG", name: "SINGAPORE", flag: "🇸🇬", port: "SGSIN", terminal: "PSA Singapore Terminal", currencyCode: "SGD", currencySymbol: "S$", rateToInr: 0.016 },
  { code: "ZA", name: "SOUTH AFRICA", flag: "🇿🇦", port: "ZADUR", terminal: "Durban Container Terminal", currencyCode: "ZAR", currencySymbol: "R ", rateToInr: 0.22 },
  { code: "MY", name: "MALAYSIA", flag: "🇲🇾", port: "MYPKG", terminal: "Port Klang", currencyCode: "MYR", currencySymbol: "RM ", rateToInr: 0.053 },
  { code: "KE", name: "KENYA", flag: "🇰🇪", port: "KEMBA", terminal: "Kilindini Harbour Mombasa", currencyCode: "KES", currencySymbol: "KSh ", rateToInr: 1.55 },
  { code: "JO", name: "JORDAN", flag: "🇯🇴", port: "JOAQJ", terminal: "Port of Aqaba", currencyCode: "JOD", currencySymbol: "JD ", rateToInr: 0.0085 },
];

export const ODEX_COUNTRIES = NEXLOG_COUNTRIES;

import { LogOut } from "lucide-react";

interface NexLogTopBarProps {
  selectedCountry: CountryNode;
  onSelectCountry: (country: CountryNode) => void;
  onOpenLoginModal: () => void;
  onSelectService: (serviceName: string) => void;
  onNavigateTab: (tab: string) => void;
  isLoggedIn?: boolean;
  userName?: string;
  companyName?: string;
  onLogout?: () => void;
}

export const NexLogTopBar: React.FC<NexLogTopBarProps> = ({
  selectedCountry,
  onSelectCountry,
  onOpenLoginModal,
  onSelectService,
  onNavigateTab,
  isLoggedIn = true,
  userName = "John Lanny",
  companyName = "Sudarsen Cargo Pvt Ltd",
  onLogout,
}) => {
  const [activeDropdown, setActiveDropdown] = useState<string | null>(null);

  const toggleDropdown = (name: string) => {
    setActiveDropdown(activeDropdown === name ? null : name);
  };

  return (
    <div className="w-full bg-white text-slate-800 border-b border-slate-200 select-none shadow-sm relative z-40">
      {/* 1. Top Global Jurisdiction Bar */}
      <div className="bg-[#0284c7] text-white px-4 py-1.5 overflow-x-auto scrollbar-none flex items-center justify-between text-[11px] font-semibold border-b border-sky-600">
        <div className="flex items-center gap-1 shrink-0 mr-3 text-sky-200 uppercase tracking-wider text-[10px]">
          <Globe2 className="w-3.5 h-3.5 text-sky-300" />
          <span>Active Jurisdictions:</span>
        </div>

        <div className="flex items-center gap-4 shrink-0">
          {NEXLOG_COUNTRIES.map((c) => {
            const isSelected = selectedCountry.code === c.code;
            return (
              <button
                key={c.code}
                onClick={() => onSelectCountry(c)}
                className={`flex items-center gap-1.5 py-1 px-2.5 rounded-md transition-all whitespace-nowrap cursor-pointer ${
                  isSelected
                    ? "bg-white text-sky-950 font-extrabold shadow-sm scale-105"
                    : "text-sky-100 hover:text-white hover:bg-sky-700/60"
                }`}
              >
                <CountryFlag code={c.code} size="sm" />
                <span className="tracking-wide text-[10px]">{c.name}</span>
                <span className={`text-[9px] font-mono font-bold px-1 py-0.2 rounded ${isSelected ? "bg-sky-100 text-sky-900" : "bg-sky-800 text-sky-200"}`}>
                  {c.currencySymbol.trim() || c.currencyCode}
                </span>
                {isSelected && <span className="w-1.5 h-1.5 rounded-full bg-emerald-500"></span>}
              </button>
            );
          })}
        </div>
      </div>

      {/* 2. Main NexLog Brand Navigation Header */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 py-3 flex items-center justify-between gap-4">
        {/* Logo */}
        <div className="flex items-center gap-3">
          <button
            onClick={() => onNavigateTab("home")}
            className="flex items-center hover:opacity-95 transition-opacity cursor-pointer"
          >
            <NexLogLogo size="lg" />
          </button>

          {/* Active Terminal Indicator with Flag Logo & Currency */}
          <div className="hidden lg:flex items-center gap-2 pl-3 border-l border-slate-200 text-xs">
            <span className="text-slate-500 font-medium">Terminal:</span>
            <div className="flex items-center gap-1.5 font-bold text-slate-900 font-mono bg-slate-100 px-2 py-0.5 rounded border border-slate-200 shadow-xs">
              <CountryFlag code={selectedCountry.code} size="sm" />
              <span>{selectedCountry.terminal} ({selectedCountry.port})</span>
              <span className="ml-1 text-[10px] font-bold text-[#0098db] bg-sky-50 px-1 rounded border border-sky-200">
                {selectedCountry.currencyCode} ({selectedCountry.currencySymbol.trim()})
              </span>
            </div>
          </div>
        </div>

        {/* Navigation Items from Screenshot */}
        <nav className="hidden md:flex items-center gap-6 text-sm font-semibold text-slate-700">
          {/* Home */}
          <button
            onClick={() => onNavigateTab("home")}
            className="flex items-center gap-1.5 text-slate-800 hover:text-orange-600 transition-colors py-1"
          >
            <Home className="w-4 h-4 text-orange-600" />
            <span>Home</span>
          </button>

          {/* Company Dropdown */}
          <div className="relative">
            <button
              onClick={() => toggleDropdown("company")}
              className="flex items-center gap-1.5 hover:text-orange-600 transition-colors py-1"
            >
              <Building2 className="w-4 h-4 text-orange-600" />
              <span>Company</span>
              <ChevronDown className="w-3.5 h-3.5 text-slate-400" />
            </button>
            {activeDropdown === "company" && (
              <div className="absolute top-full left-0 mt-2 w-56 bg-white rounded-xl shadow-xl border border-slate-200 py-2 z-50 text-xs animate-in fade-in-50 duration-150">
                <button
                  onClick={() => {
                    onNavigateTab("stakeholders");
                    setActiveDropdown(null);
                  }}
                  className="w-full text-left px-4 py-2 hover:bg-slate-50 text-slate-700 hover:text-blue-600 font-medium"
                >
                  Our Stakeholders (Allcargo, BKT, EMU)
                </button>
                <button
                  onClick={() => {
                    onNavigateTab("certifications");
                    setActiveDropdown(null);
                  }}
                  className="w-full text-left px-4 py-2 hover:bg-slate-50 text-slate-700 hover:text-blue-600 font-medium"
                >
                  Certifications (ISO 9001 / 27001)
                </button>
                <button
                  onClick={() => {
                    onNavigateTab("trade-associations");
                    setActiveDropdown(null);
                  }}
                  className="w-full text-left px-4 py-2 hover:bg-slate-50 text-slate-700 hover:text-blue-600 font-medium"
                >
                  Trade Associations (AMTOI, CSLA, FFFAI)
                </button>
              </div>
            )}
          </div>

          {/* Services Dropdown */}
          <div className="relative">
            <button
              onClick={() => toggleDropdown("services")}
              className="flex items-center gap-1.5 hover:text-orange-600 transition-colors py-1"
            >
              <Settings className="w-4 h-4 text-orange-600" />
              <span>Services</span>
              <ChevronDown className="w-3.5 h-3.5 text-slate-400" />
            </button>
            {activeDropdown === "services" && (
              <div className="absolute top-full left-0 mt-2 w-64 bg-white rounded-xl shadow-xl border border-slate-200 py-2 z-50 text-xs animate-in fade-in-50 duration-150">
                <button
                  onClick={() => {
                    onSelectService("export");
                    setActiveDropdown(null);
                  }}
                  className="w-full text-left px-4 py-2.5 hover:bg-slate-50 text-slate-700 hover:text-orange-600 font-medium"
                >
                  <div className="font-bold">Export Processing</div>
                  <div className="text-[11px] text-slate-400">Form 13 Gate-in & Shipping Bills</div>
                </button>
                <button
                  onClick={() => {
                    onSelectService("import");
                    setActiveDropdown(null);
                  }}
                  className="w-full text-left px-4 py-2.5 hover:bg-slate-50 text-slate-700 hover:text-orange-600 font-medium"
                >
                  <div className="font-bold">Import Processing</div>
                  <div className="text-[11px] text-slate-400">e-Delivery Order (eDO) Release</div>
                </button>
                <button
                  onClick={() => {
                    onSelectService("erp");
                    setActiveDropdown(null);
                  }}
                  className="w-full text-left px-4 py-2.5 hover:bg-slate-50 text-slate-700 hover:text-orange-600 font-medium"
                >
                  <div className="font-bold">ERP Integration</div>
                  <div className="text-[11px] text-slate-400">SAP, Oracle & CargoWise EDI</div>
                </button>
                <button
                  onClick={() => {
                    onSelectService("pay-later");
                    setActiveDropdown(null);
                  }}
                  className="w-full text-left px-4 py-2.5 hover:bg-slate-50 text-slate-700 hover:text-orange-600 font-medium"
                >
                  <div className="font-bold text-orange-600">NexLog Pay Later (DBS)</div>
                  <div className="text-[11px] text-slate-400">Instant Trade Credit & Duty Factoring</div>
                </button>
              </div>
            )}
          </div>

          {/* News & Media */}
          <div className="relative">
            <button
              onClick={() => toggleDropdown("news")}
              className="flex items-center gap-1.5 hover:text-orange-600 transition-colors py-1"
            >
              <Share2 className="w-4 h-4 text-orange-600" />
              <span>News & Media</span>
              <ChevronDown className="w-3.5 h-3.5 text-slate-400" />
            </button>
            {activeDropdown === "news" && (
              <div className="absolute top-full left-0 mt-2 w-64 bg-white rounded-xl shadow-xl border border-slate-200 py-2 z-50 text-xs animate-in fade-in-50 duration-150">
                <button
                  onClick={() => {
                    onSelectService("uae-mpci");
                    setActiveDropdown(null);
                  }}
                  className="w-full text-left px-4 py-2.5 hover:bg-slate-50 text-slate-700 hover:text-blue-600 font-medium"
                >
                  <div className="font-bold">UAE MPCI Official Certification</div>
                  <div className="text-[11px] text-slate-400">Connected to NAIC Automated Manifest</div>
                </button>
                <button
                  onClick={() => {
                    onNavigateTab("scanner");
                    setActiveDropdown(null);
                  }}
                  className="w-full text-left px-4 py-2.5 hover:bg-slate-50 text-slate-700 hover:text-blue-600 font-medium"
                >
                  <div className="font-bold">Google Gemini 3.8 Flash Integration</div>
                  <div className="text-[11px] text-slate-400">Autonomous SOLAS & EXIM Engine</div>
                </button>
              </div>
            )}
          </div>

          {/* Contact */}
          <button
            onClick={() => onNavigateTab("contact")}
            className="flex items-center gap-1.5 hover:text-orange-600 transition-colors py-1"
          >
            <PhoneCall className="w-4 h-4 text-orange-600" />
            <span>Contact</span>
          </button>
        </nav>

        {/* Action Buttons: Log Out or Login */}
        <div className="flex items-center gap-2.5">
          {isLoggedIn ? (
            <div className="flex items-center gap-2">
              <div className="hidden sm:block text-right leading-tight">
                <div className="text-xs font-bold text-slate-800">{userName}</div>
                <div className="text-[10px] text-slate-500 truncate max-w-[140px]">{companyName}</div>
              </div>
              <button
                onClick={onLogout}
                className="px-4 py-2 rounded-lg bg-rose-600 hover:bg-rose-500 text-white font-bold text-xs tracking-wide shadow-md shadow-rose-500/20 hover:scale-[1.02] active:scale-[0.98] transition-all flex items-center gap-1.5 cursor-pointer"
                title="Log out of current session"
              >
                <LogOut className="w-3.5 h-3.5" />
                <span>Log Out</span>
              </button>
            </div>
          ) : (
            <div className="flex items-center gap-2">
              {/* Quick Platinum Login Button */}
              <button
                onClick={onOpenLoginModal}
                className="hidden sm:flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-gradient-to-r from-amber-200 via-amber-100 to-yellow-200 text-amber-950 text-xs font-extrabold border border-amber-300 hover:brightness-105 transition-all shadow-sm cursor-pointer"
              >
                <Crown className="w-3.5 h-3.5 text-amber-800" />
                <span>Platinum</span>
              </button>

              {/* Bright Orange Rounded Login Button */}
              <button
                onClick={onOpenLoginModal}
                className="px-6 py-2 rounded-lg bg-[#f97316] hover:bg-[#ea580c] text-white font-extrabold text-sm tracking-wide shadow-md shadow-orange-500/20 hover:scale-[1.02] active:scale-[0.98] transition-all flex items-center gap-1.5 cursor-pointer"
              >
                <LogIn className="w-4 h-4" />
                <span>Login</span>
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

// Export alias
export const OdexTopBar = NexLogTopBar;
