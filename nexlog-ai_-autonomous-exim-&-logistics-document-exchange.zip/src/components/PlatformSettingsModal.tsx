import React, { useState } from "react";
import {
  X,
  Settings,
  Sliders,
  ShieldCheck,
  Bell,
  CreditCard,
  Globe,
  Database,
  Check,
  RefreshCw,
  Moon,
  Sun,
  Volume2,
  VolumeX,
  Sparkles,
  Smartphone,
  Mail,
  Layers,
  Key,
} from "lucide-react";
import confetti from "canvas-confetti";
import { CountryNode, NEXLOG_COUNTRIES } from "./OdexTopBar";

export interface PlatformSettingsState {
  darkMode: boolean;
  tableDensity: "compact" | "normal" | "spacious";
  autoRefreshIntervalSeconds: number;
  soundEffects: boolean;
  pcs1xDirectMode: boolean;
  icegateAutoOoc: boolean;
  autoSignDsc: boolean;
  solasVgmCheck: boolean;
  defaultEmail: string;
  defaultWhatsApp: string;
  notifyOnBerth: boolean;
  notifyOnDischarge: boolean;
  autoDownloadPdfDossier: boolean;
  preferredCurrency: string;
  enableGstBreakdown: boolean;
  preferredPaymentGateway: "NETBANKING" | "NEFT_RTGS" | "BILLDESK";
}

export const DEFAULT_PLATFORM_SETTINGS: PlatformSettingsState = {
  darkMode: false,
  tableDensity: "normal",
  autoRefreshIntervalSeconds: 30,
  soundEffects: true,
  pcs1xDirectMode: true,
  icegateAutoOoc: true,
  autoSignDsc: true,
  solasVgmCheck: true,
  defaultEmail: "deivaakraj81@gmail.com",
  defaultWhatsApp: "+91 9863 122 122",
  notifyOnBerth: true,
  notifyOnDischarge: true,
  autoDownloadPdfDossier: true,
  preferredCurrency: "INR",
  enableGstBreakdown: true,
  preferredPaymentGateway: "NETBANKING",
};

interface PlatformSettingsModalProps {
  isOpen: boolean;
  onClose: () => void;
  settings: PlatformSettingsState;
  onUpdateSettings: (newSettings: PlatformSettingsState) => void;
  selectedCountry: CountryNode;
  onSelectCountry: (country: CountryNode) => void;
  onToggleDarkMode: () => void;
  onAddToast: (type: "success" | "warning" | "error" | "info", title: string, message: string) => void;
}

export const PlatformSettingsModal: React.FC<PlatformSettingsModalProps> = ({
  isOpen,
  onClose,
  settings,
  onUpdateSettings,
  selectedCountry,
  onSelectCountry,
  onToggleDarkMode,
  onAddToast,
}) => {
  const [activeTab, setActiveTab] = useState<"general" | "exim_edi" | "notifications" | "billing">("general");
  const [localSettings, setLocalSettings] = useState<PlatformSettingsState>(settings);

  React.useEffect(() => {
    setLocalSettings(settings);
  }, [settings]);

  if (!isOpen) return null;

  const handleSave = () => {
    onUpdateSettings(localSettings);
    confetti({ particleCount: 35, spread: 55, origin: { y: 0.6 } });
    onAddToast(
      "success",
      "Settings Saved Successfully",
      "Platform and EXIM EDI configurations have been applied."
    );
    onClose();
  };

  const handleReset = () => {
    setLocalSettings(DEFAULT_PLATFORM_SETTINGS);
    onAddToast(
      "info",
      "Settings Reset",
      "Default platform configurations restored."
    );
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/75 backdrop-blur-xs p-3 sm:p-5 overflow-y-auto animate-in fade-in duration-200 select-none">
      <div className="bg-white rounded-2xl shadow-2xl border border-slate-300 w-full max-w-2xl overflow-hidden my-4 flex flex-col max-h-[92vh]">
        {/* Header */}
        <div className="bg-[#0f172a] text-white px-5 py-4 flex items-center justify-between border-b border-slate-800">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-sky-500/20 border border-sky-400/40 flex items-center justify-center text-[#0098db]">
              <Settings className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="font-bold text-base tracking-tight text-white">
                  Platform & EXIM Operations Settings
                </h3>
                <span className="px-2 py-0.2 rounded-full bg-sky-500/20 text-sky-300 border border-sky-400/30 text-[10px] font-mono font-bold">
                  v2.6 Live
                </span>
              </div>
              <p className="text-xs text-slate-400">
                Configure PCS 1x connections, terminal defaults, notification routes, and display preferences
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800 transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Navigation Tabs */}
        <div className="bg-slate-100 border-b border-slate-200 px-5 flex items-center gap-2 text-xs font-bold overflow-x-auto">
          <button
            onClick={() => setActiveTab("general")}
            className={`py-3 px-3 border-b-2 transition-colors cursor-pointer flex items-center gap-1.5 whitespace-nowrap ${
              activeTab === "general"
                ? "border-[#0098db] text-[#0098db]"
                : "border-transparent text-slate-500 hover:text-slate-800"
            }`}
          >
            <Sliders className="w-4 h-4" />
            <span>General & Interface</span>
          </button>

          <button
            onClick={() => setActiveTab("exim_edi")}
            className={`py-3 px-3 border-b-2 transition-colors cursor-pointer flex items-center gap-1.5 whitespace-nowrap ${
              activeTab === "exim_edi"
                ? "border-[#0098db] text-[#0098db]"
                : "border-transparent text-slate-500 hover:text-slate-800"
            }`}
          >
            <Database className="w-4 h-4" />
            <span>PCS 1x & ICEGATE EDI</span>
          </button>

          <button
            onClick={() => setActiveTab("notifications")}
            className={`py-3 px-3 border-b-2 transition-colors cursor-pointer flex items-center gap-1.5 whitespace-nowrap ${
              activeTab === "notifications"
                ? "border-[#0098db] text-[#0098db]"
                : "border-transparent text-slate-500 hover:text-slate-800"
            }`}
          >
            <Bell className="w-4 h-4" />
            <span>Arrival Notifications</span>
          </button>

          <button
            onClick={() => setActiveTab("billing")}
            className={`py-3 px-3 border-b-2 transition-colors cursor-pointer flex items-center gap-1.5 whitespace-nowrap ${
              activeTab === "billing"
                ? "border-[#0098db] text-[#0098db]"
                : "border-transparent text-slate-500 hover:text-slate-800"
            }`}
          >
            <CreditCard className="w-4 h-4" />
            <span>Invoicing & Currency</span>
          </button>
        </div>

        {/* Body Content */}
        <div className="p-5 sm:p-6 overflow-y-auto space-y-4 text-xs text-slate-700 flex-1">
          {/* TAB 1: GENERAL & INTERFACE */}
          {activeTab === "general" && (
            <div className="space-y-4">
              <div className="bg-slate-50 p-4 rounded-xl border border-slate-200 space-y-3">
                <h4 className="font-bold text-slate-800 uppercase tracking-wider text-[11px]">
                  Display & Terminal Environment
                </h4>

                {/* Country & Port Terminal Selector */}
                <div>
                  <label className="block text-[11px] font-bold text-slate-600 mb-1">
                    Default Terminal & Regional Currency:
                  </label>
                  <select
                    value={selectedCountry.code}
                    onChange={(e) => {
                      const match = NEXLOG_COUNTRIES.find((c) => c.code === e.target.value);
                      if (match) onSelectCountry(match);
                    }}
                    className="w-full p-2 bg-white border border-slate-300 rounded-lg text-xs font-semibold text-slate-900 focus:outline-hidden focus:border-[#0098db]"
                  >
                    {NEXLOG_COUNTRIES.map((c) => (
                      <option key={c.code} value={c.code}>
                        {c.name} — {c.terminal} ({c.currencyCode} {c.currencySymbol.trim()})
                      </option>
                    ))}
                  </select>
                </div>

                {/* Table Row Density */}
                <div>
                  <label className="block text-[11px] font-bold text-slate-600 mb-1">
                    Table Row Layout Density:
                  </label>
                  <div className="grid grid-cols-3 gap-2">
                    {(["compact", "normal", "spacious"] as const).map((d) => (
                      <button
                        key={d}
                        type="button"
                        onClick={() => setLocalSettings({ ...localSettings, tableDensity: d })}
                        className={`p-2 rounded-lg border text-center font-bold capitalize cursor-pointer transition-colors ${
                          localSettings.tableDensity === d
                            ? "bg-sky-50 border-[#0098db] text-[#0098db]"
                            : "bg-white border-slate-200 hover:border-slate-300"
                        }`}
                      >
                        {d}
                      </button>
                    ))}
                  </div>
                </div>

                {/* Live Telematics Auto-Refresh */}
                <div>
                  <label className="block text-[11px] font-bold text-slate-600 mb-1">
                    Live Telematics Refresh Cycle:
                  </label>
                  <select
                    value={localSettings.autoRefreshIntervalSeconds}
                    onChange={(e) =>
                      setLocalSettings({
                        ...localSettings,
                        autoRefreshIntervalSeconds: Number(e.target.value),
                      })
                    }
                    className="w-full p-2 bg-white border border-slate-300 rounded-lg text-xs font-semibold text-slate-900 focus:outline-hidden focus:border-[#0098db]"
                  >
                    <option value={15}>Every 15 Seconds (High Frequency Live)</option>
                    <option value={30}>Every 30 Seconds (Standard Recommended)</option>
                    <option value={60}>Every 60 Seconds (Bandwidth Saver)</option>
                    <option value={0}>Manual Refresh Only</option>
                  </select>
                </div>
              </div>

              {/* Toggles */}
              <div className="space-y-2">
                <label className="flex items-center justify-between p-3 rounded-xl bg-slate-50 border border-slate-200 cursor-pointer">
                  <div>
                    <strong className="block text-slate-900 font-bold">Theme Appearance</strong>
                    <span className="text-[11px] text-slate-500">
                      Switch between Light and Dark visual modes
                    </span>
                  </div>
                  <button
                    type="button"
                    onClick={onToggleDarkMode}
                    className="px-3 py-1 rounded-md bg-[#0098db] text-white font-bold text-xs cursor-pointer flex items-center gap-1.5"
                  >
                    {settings.darkMode ? <Sun className="w-3.5 h-3.5" /> : <Moon className="w-3.5 h-3.5" />}
                    <span>{settings.darkMode ? "Switch to Light" : "Switch to Dark"}</span>
                  </button>
                </label>

                <label className="flex items-center justify-between p-3 rounded-xl bg-slate-50 border border-slate-200 cursor-pointer">
                  <div>
                    <strong className="block text-slate-900 font-bold">Audible Milestone Chimes</strong>
                    <span className="text-[11px] text-slate-500">
                      Play acoustic notifications on container discharge & OOC release
                    </span>
                  </div>
                  <input
                    type="checkbox"
                    checked={localSettings.soundEffects}
                    onChange={(e) =>
                      setLocalSettings({ ...localSettings, soundEffects: e.target.checked })
                    }
                    className="w-4 h-4 text-[#0098db] rounded accent-[#0098db]"
                  />
                </label>
              </div>
            </div>
          )}

          {/* TAB 2: EXIM & EDI PORT CONNECTIONS */}
          {activeTab === "exim_edi" && (
            <div className="space-y-3">
              <div className="bg-slate-50 p-4 rounded-xl border border-slate-200 space-y-3">
                <h4 className="font-bold text-slate-800 uppercase tracking-wider text-[11px] flex items-center gap-1.5">
                  <ShieldCheck className="w-4 h-4 text-emerald-600" />
                  <span>Port Community System (PCS 1x) Gateway Integration</span>
                </h4>

                <label className="flex items-center justify-between p-2.5 rounded-lg bg-white border border-slate-200 cursor-pointer">
                  <div>
                    <strong className="block text-slate-900">Direct PCS 1x Production EDI Tunnel</strong>
                    <span className="text-[11px] text-slate-500">
                      Transmit Bill of Lading & eForm13 directly to port trust servers
                    </span>
                  </div>
                  <input
                    type="checkbox"
                    checked={localSettings.pcs1xDirectMode}
                    onChange={(e) =>
                      setLocalSettings({ ...localSettings, pcs1xDirectMode: e.target.checked })
                    }
                    className="w-4 h-4 text-[#0098db] rounded accent-[#0098db]"
                  />
                </label>

                <label className="flex items-center justify-between p-2.5 rounded-lg bg-white border border-slate-200 cursor-pointer">
                  <div>
                    <strong className="block text-slate-900">ICEGATE Real-Time Customs OOC Sync</strong>
                    <span className="text-[11px] text-slate-500">
                      Auto-fetch Out of Charge (OOC) releases from Indian Customs servers
                    </span>
                  </div>
                  <input
                    type="checkbox"
                    checked={localSettings.icegateAutoOoc}
                    onChange={(e) =>
                      setLocalSettings({ ...localSettings, icegateAutoOoc: e.target.checked })
                    }
                    className="w-4 h-4 text-[#0098db] rounded accent-[#0098db]"
                  />
                </label>

                <label className="flex items-center justify-between p-2.5 rounded-lg bg-white border border-slate-200 cursor-pointer">
                  <div>
                    <strong className="block text-slate-900">Automatic Class 3 DSC Digital Signing</strong>
                    <span className="text-[11px] text-slate-500">
                      Attach eMudhra cryptographic signatures to approved shipping documents
                    </span>
                  </div>
                  <input
                    type="checkbox"
                    checked={localSettings.autoSignDsc}
                    onChange={(e) =>
                      setLocalSettings({ ...localSettings, autoSignDsc: e.target.checked })
                    }
                    className="w-4 h-4 text-[#0098db] rounded accent-[#0098db]"
                  />
                </label>

                <label className="flex items-center justify-between p-2.5 rounded-lg bg-white border border-slate-200 cursor-pointer">
                  <div>
                    <strong className="block text-slate-900">SOLAS VGM Weighbridge Validation</strong>
                    <span className="text-[11px] text-slate-500">
                      Strict tolerance enforcement (±1.5%) before container gate-in
                    </span>
                  </div>
                  <input
                    type="checkbox"
                    checked={localSettings.solasVgmCheck}
                    onChange={(e) =>
                      setLocalSettings({ ...localSettings, solasVgmCheck: e.target.checked })
                    }
                    className="w-4 h-4 text-[#0098db] rounded accent-[#0098db]"
                  />
                </label>
              </div>
            </div>
          )}

          {/* TAB 3: ARRIVAL NOTIFICATIONS */}
          {activeTab === "notifications" && (
            <div className="space-y-3">
              <div className="bg-slate-50 p-4 rounded-xl border border-slate-200 space-y-3">
                <h4 className="font-bold text-slate-800 uppercase tracking-wider text-[11px]">
                  Default Notification Routing Addresses
                </h4>

                <div>
                  <label className="block text-[11px] font-bold text-slate-600 mb-1">
                    Primary Mail ID for Arrival Notices:
                  </label>
                  <input
                    type="email"
                    value={localSettings.defaultEmail}
                    onChange={(e) =>
                      setLocalSettings({ ...localSettings, defaultEmail: e.target.value })
                    }
                    className="w-full p-2 bg-white border border-slate-300 rounded-lg text-xs font-mono text-slate-900 focus:outline-hidden focus:border-[#0098db]"
                  />
                </div>

                <div>
                  <label className="block text-[11px] font-bold text-slate-600 mb-1">
                    Primary WhatsApp Mobile Number:
                  </label>
                  <input
                    type="tel"
                    value={localSettings.defaultWhatsApp}
                    onChange={(e) =>
                      setLocalSettings({ ...localSettings, defaultWhatsApp: e.target.value })
                    }
                    className="w-full p-2 bg-white border border-slate-300 rounded-lg text-xs font-mono text-slate-900 focus:outline-hidden focus:border-[#0098db]"
                  />
                </div>

                <label className="flex items-center justify-between p-2.5 rounded-lg bg-white border border-slate-200 cursor-pointer">
                  <div>
                    <strong className="block text-slate-900">Auto-Download Official PDF Dossier</strong>
                    <span className="text-[11px] text-slate-500">
                      Automatically generate printable PDF arrival notice upon container discharge
                    </span>
                  </div>
                  <input
                    type="checkbox"
                    checked={localSettings.autoDownloadPdfDossier}
                    onChange={(e) =>
                      setLocalSettings({
                        ...localSettings,
                        autoDownloadPdfDossier: e.target.checked,
                      })
                    }
                    className="w-4 h-4 text-[#0098db] rounded accent-[#0098db]"
                  />
                </label>
              </div>
            </div>
          )}

          {/* TAB 4: BILLING & INVOICING */}
          {activeTab === "billing" && (
            <div className="space-y-3">
              <div className="bg-slate-50 p-4 rounded-xl border border-slate-200 space-y-3">
                <h4 className="font-bold text-slate-800 uppercase tracking-wider text-[11px]">
                  EXIM Invoice & Payment Gateway Preferences
                </h4>

                <div>
                  <label className="block text-[11px] font-bold text-slate-600 mb-1">
                    Preferred Online Payment Routing:
                  </label>
                  <select
                    value={localSettings.preferredPaymentGateway}
                    onChange={(e: any) =>
                      setLocalSettings({
                        ...localSettings,
                        preferredPaymentGateway: e.target.value,
                      })
                    }
                    className="w-full p-2 bg-white border border-slate-300 rounded-lg text-xs font-semibold text-slate-900 focus:outline-hidden focus:border-[#0098db]"
                  >
                    <option value="NETBANKING">Direct Net Banking (SBI / HDFC / ICICI / Axis / PNB)</option>
                    <option value="NEFT_RTGS">Corporate NEFT / RTGS Virtual Account</option>
                    <option value="BILLDESK">Bharat BillPay / BillDesk EXIM Gateway</option>
                  </select>
                </div>

                <label className="flex items-center justify-between p-2.5 rounded-lg bg-white border border-slate-200 cursor-pointer">
                  <div>
                    <strong className="block text-slate-900">Show 18% GST / IGST Itemized Breakdown</strong>
                    <span className="text-[11px] text-slate-500">
                      Include Input Tax Credit (ITC) reconciliation fields on exported invoice PDFs
                    </span>
                  </div>
                  <input
                    type="checkbox"
                    checked={localSettings.enableGstBreakdown}
                    onChange={(e) =>
                      setLocalSettings({
                        ...localSettings,
                        enableGstBreakdown: e.target.checked,
                      })
                    }
                    className="w-4 h-4 text-[#0098db] rounded accent-[#0098db]"
                  />
                </label>
              </div>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="bg-slate-50 border-t border-slate-200 px-5 py-3.5 flex flex-wrap items-center justify-between gap-3 text-xs">
          <button
            type="button"
            onClick={handleReset}
            className="text-slate-500 hover:text-slate-800 font-bold cursor-pointer transition-colors"
          >
            Reset Defaults
          </button>

          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 rounded-lg border border-slate-300 hover:bg-slate-100 font-bold text-slate-700 transition-colors cursor-pointer"
            >
              Cancel
            </button>

            <button
              type="button"
              onClick={handleSave}
              className="px-5 py-2 rounded-lg bg-[#0098db] hover:bg-[#0086c2] text-white font-bold shadow-md transition-all cursor-pointer flex items-center gap-1.5 hover:scale-102"
            >
              <Check className="w-3.5 h-3.5" />
              <span>Save & Apply Settings</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
