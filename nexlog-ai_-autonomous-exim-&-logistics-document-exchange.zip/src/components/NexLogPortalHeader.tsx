import React from "react";
import {
  Home,
  Headphones,
  Settings,
  Moon,
  Sun,
  Ship,
  Clock,
  User,
  ShieldCheck,
  Sparkles,
  Bell,
  LogOut,
  LogIn,
} from "lucide-react";
import { CountryFlag } from "./CountryFlag";
import { CountryNode, NEXLOG_COUNTRIES } from "./OdexTopBar";
import { NexLogLogo } from "./OdexLogo";

interface NexLogPortalHeaderProps {
  darkMode: boolean;
  onToggleDarkMode: () => void;
  onHomeClick: () => void;
  onSupportClick: () => void;
  onSettingsClick: () => void;
  onOpenAiScanner: () => void;
  selectedCountry: CountryNode;
  onSelectCountry: (country: CountryNode) => void;
  onOpenIntroModal: () => void;
  isLoggedIn?: boolean;
  userName?: string;
  companyName?: string;
  onLogin?: () => void;
  onLogout?: () => void;
  unreadNotificationCount?: number;
  onOpenProfileNotifications?: () => void;
  onOpenProfile?: () => void;
}

export const NexLogPortalHeader: React.FC<NexLogPortalHeaderProps> = ({
  darkMode,
  onToggleDarkMode,
  onHomeClick,
  onSupportClick,
  onSettingsClick,
  onOpenAiScanner,
  selectedCountry,
  onSelectCountry,
  onOpenIntroModal,
  isLoggedIn = true,
  userName = "John Lanny",
  companyName = "Sudarsen Cargo Pvt Ltd",
  onLogin,
  onLogout,
  unreadNotificationCount = 0,
  onOpenProfileNotifications,
  onOpenProfile,
}) => {
  const [isCountryMenuOpen, setIsCountryMenuOpen] = React.useState(false);
  return (
    <header className="w-full bg-[#0098db] text-white px-4 sm:px-6 py-2 flex items-center justify-between shadow-md select-none border-b border-sky-600 relative z-30">
      {/* Left: Brand Logo & Steamer Icon with Clock (From Screenshot 1) */}
      <div className="flex items-center gap-4">
        {/* White background badge for logo to keep it crisp */}
        <div
          onClick={onHomeClick}
          className="bg-white/95 px-3 py-1 rounded-lg flex items-center shadow-xs cursor-pointer hover:bg-white transition-all"
        >
          <NexLogLogo size="md" />
        </div>

        {/* Steamer Ship Icon with Clock badge from Screenshot */}
        <div
          onClick={onHomeClick}
          className="flex items-center gap-1.5 px-2.5 py-1 rounded-lg bg-sky-600/60 hover:bg-sky-600 border border-sky-400/40 cursor-pointer transition-all shadow-inner"
          title="Terminal Vessel Queue & Steamer Schedules"
        >
          <div className="relative">
            <Ship className="w-5 h-5 text-white" />
            <Clock className="w-2.5 h-2.5 text-amber-300 absolute -top-1 -right-1" />
          </div>
          <span className="hidden md:inline text-xs font-bold font-mono tracking-tight text-sky-100">
            PCS 1x Live
          </span>
        </div>

        {/* Gemini AI Autonomous Engine quick indicator */}
        <button
          onClick={onOpenAiScanner}
          className="hidden lg:flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-emerald-950/40 text-emerald-200 border border-emerald-400/50 text-[11px] font-bold tracking-wide hover:bg-emerald-900/60 transition-all shadow-xs"
        >
          <Sparkles className="w-3.5 h-3.5 text-emerald-300" />
          <span>Gemini 3.8 AI Auditor</span>
          <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse"></span>
        </button>
      </div>

      {/* Right: Dark/Light Mode toggle, User Profile & Navigation Icons (From Screenshot 1) */}
      <div className="flex items-center gap-4 text-xs font-semibold">
        {/* Dark/Light Mode Toggle Switch */}
        <div className="flex items-center gap-2">
          <button
            onClick={onToggleDarkMode}
            className={`w-12 h-6 flex items-center rounded-full p-1 transition-colors duration-300 ${
              darkMode ? "bg-slate-900 border border-slate-700" : "bg-sky-700 border border-sky-500"
            }`}
            title="Toggle Dark / Light Theme"
          >
            <div
              className={`w-4 h-4 rounded-full bg-white text-slate-800 flex items-center justify-center transition-transform duration-300 ${
                darkMode ? "translate-x-6 text-amber-500" : "translate-x-0 text-sky-700"
              }`}
            >
              {darkMode ? <Moon className="w-2.5 h-2.5" /> : <Sun className="w-2.5 h-2.5" />}
            </div>
          </button>
        </div>

        {/* Country & Currency Switcher in Header */}
        <div className="relative">
          <button
            onClick={() => setIsCountryMenuOpen(!isCountryMenuOpen)}
            className="flex items-center gap-1.5 px-2.5 py-1 rounded-lg bg-sky-700 hover:bg-sky-800 border border-sky-400/50 text-[11px] font-bold cursor-pointer transition-all shadow-2xs"
            title="Switch Active Terminal & Currency"
          >
            <CountryFlag code={selectedCountry.code} size="sm" />
            <span className="hidden sm:inline">{selectedCountry.name}</span>
            <span className="font-mono bg-sky-900/80 px-1 py-0.2 rounded text-amber-300">
              {selectedCountry.currencySymbol.trim() || selectedCountry.currencyCode}
            </span>
          </button>

          {isCountryMenuOpen && (
            <div className="absolute top-full right-0 mt-1 w-64 bg-white text-slate-800 rounded-lg shadow-2xl border border-slate-200 py-1 z-50 max-h-72 overflow-y-auto animate-in fade-in duration-150">
              <div className="px-3 py-1.5 bg-slate-100 text-[10px] font-bold uppercase tracking-wider text-slate-500 border-b border-slate-200">
                Select Country & Local Currency
              </div>
              {NEXLOG_COUNTRIES.map((c) => (
                <button
                  key={c.code}
                  onClick={() => {
                    onSelectCountry(c);
                    setIsCountryMenuOpen(false);
                  }}
                  className={`w-full text-left px-3 py-1.5 text-xs font-semibold flex items-center justify-between hover:bg-sky-50 transition-colors cursor-pointer ${
                    selectedCountry.code === c.code ? "bg-sky-100 text-[#0098db] font-bold" : "text-slate-700"
                  }`}
                >
                  <span className="flex items-center gap-2">
                    <CountryFlag code={c.code} size="sm" />
                    <span>{c.name}</span>
                  </span>
                  <span className="font-mono text-[11px] text-slate-500">
                    {c.currencyCode} ({c.currencySymbol.trim()})
                  </span>
                </button>
              ))}
            </div>
          )}
        </div>

        {/* User Badge Info & Auth Controls */}
        {isLoggedIn ? (
          <div className="flex items-center gap-2 sm:gap-3 border-l border-sky-400/40 pl-3">
            {/* Notification Bell with Badge */}
            <button
              onClick={onOpenProfileNotifications}
              className="relative p-1.5 rounded-lg bg-sky-700 hover:bg-sky-800 text-white transition-all cursor-pointer border border-sky-400/40"
              title="Arrival Alerts & Notification Center"
            >
              <Bell className="w-4 h-4 text-amber-300" />
              {unreadNotificationCount > 0 && (
                <span className="absolute -top-1.5 -right-1.5 min-w-[18px] h-[18px] px-1 bg-rose-500 text-white text-[10px] font-black rounded-full flex items-center justify-center ring-2 ring-white animate-pulse">
                  {unreadNotificationCount}
                </span>
              )}
            </button>

            {/* Clickable Profile Card */}
            <button
              type="button"
              onClick={onOpenProfile || onOpenProfileNotifications}
              className="text-right leading-tight hover:bg-sky-600/70 p-1 rounded-md transition-colors cursor-pointer text-left group"
              title="Click to open John Lanny's Profile Space (PRN 100653)"
            >
              <div className="text-[10px] text-sky-200 font-mono tracking-wider flex items-center justify-end gap-1">
                <span className="w-1.5 h-1.5 rounded-full bg-emerald-400"></span>
                <span>PRN - 100653</span>
              </div>
              <div className="font-bold text-white text-xs tracking-tight">
                {userName}
              </div>
              <div className="text-[9px] text-sky-100/90 truncate max-w-[130px] sm:max-w-[180px] font-medium">
                {companyName}
              </div>
            </button>

            {/* Explicit Log Out Option Button */}
            <button
              onClick={onLogout}
              className="flex items-center gap-1 px-2.5 py-1 rounded-md bg-rose-600 hover:bg-rose-500 text-white font-bold text-[11px] shadow-sm cursor-pointer border border-rose-400/50 transition-all hover:scale-102"
              title="Log out of Sudarsen Cargo Pvt Ltd session"
            >
              <LogOut className="w-3.5 h-3.5" />
              <span>Log Out</span>
            </button>
          </div>
        ) : (
          <div className="flex items-center gap-2 border-l border-sky-400/40 pl-3">
            <div className="text-right leading-tight hidden sm:block">
              <div className="text-[10px] text-sky-200 font-mono">Not Signed In</div>
              <div className="font-bold text-white text-xs">Guest Portal</div>
            </div>

            {/* Explicit Login Option Button */}
            <button
              onClick={onLogin || onOpenIntroModal}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-md bg-amber-400 hover:bg-amber-300 text-slate-950 font-black text-xs shadow-md cursor-pointer transition-all hover:scale-102"
              title="Click to Login"
            >
              <LogIn className="w-3.5 h-3.5 text-slate-950 font-bold" />
              <span>Login</span>
            </button>
          </div>
        )}

        {/* Top Control Icons from Screenshot */}
        <div className="flex items-center gap-2 pl-1 border-l border-sky-400/40">
          <button
            onClick={onHomeClick}
            className="p-1.5 rounded-lg hover:bg-sky-600 transition-colors"
            title="Dashboard Home"
          >
            <Home className="w-5 h-5 text-white" />
          </button>

          <button
            onClick={onSupportClick}
            className="p-1.5 rounded-lg hover:bg-sky-600 transition-colors"
            title="Support & Query Resolution (+91 8828 822 244)"
          >
            <Headphones className="w-5 h-5 text-white" />
          </button>

          <button
            onClick={onSettingsClick}
            className="p-1.5 rounded-lg hover:bg-sky-600 transition-colors"
            title="Platform Settings & EDI Configurations"
          >
            <Settings className="w-5 h-5 text-white" />
          </button>
        </div>
      </div>
    </header>
  );
};
