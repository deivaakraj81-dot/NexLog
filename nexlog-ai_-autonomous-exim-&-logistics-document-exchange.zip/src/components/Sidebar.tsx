import React from "react";
import {
  LayoutDashboard,
  ScanText,
  ClipboardCheck,
  FileClock,
  Workflow,
  Code2,
  ShieldCheck,
  CheckCircle2,
  AlertCircle,
  Truck,
  ExternalLink,
} from "lucide-react";

export type TabId =
  | "overview"
  | "scanner"
  | "queue"
  | "logs"
  | "architecture"
  | "json-viewer";

interface SidebarProps {
  currentTab: TabId;
  onSelectTab: (tab: TabId) => void;
  pendingCount: number;
}

export const Sidebar: React.FC<SidebarProps> = ({
  currentTab,
  onSelectTab,
  pendingCount,
}) => {
  const navItems = [
    {
      id: "overview" as TabId,
      label: "Dashboard Overview",
      icon: LayoutDashboard,
      badge: null,
      desc: "Live EXIM throughput & KPIs",
    },
    {
      id: "scanner" as TabId,
      label: "Document Scanner & Intake",
      icon: ScanText,
      badge: "Gemini 3.8",
      badgeColor: "bg-blue-950 text-blue-300 border-blue-800",
      desc: "Autonomous multimodal audit",
    },
    {
      id: "queue" as TabId,
      label: "Approval Queue (HITL)",
      icon: ClipboardCheck,
      badge: pendingCount > 0 ? `${pendingCount} Pending` : "0 Pending",
      badgeColor:
        pendingCount > 0
          ? "bg-amber-950 text-amber-300 border-amber-800 animate-pulse"
          : "bg-emerald-950 text-emerald-300 border-emerald-800",
      desc: "Human-in-the-loop gate",
    },
    {
      id: "logs" as TabId,
      label: "Audit & Analytics Log",
      icon: FileClock,
      badge: null,
      desc: "Tamper-evident ledger",
    },
  ];

  const expoItems = [
    {
      id: "architecture" as TabId,
      label: "System Architecture",
      icon: Workflow,
      badge: "Expo Demo",
      badgeColor: "bg-purple-950 text-purple-300 border-purple-800",
      desc: "End-to-end pipeline flow",
    },
    {
      id: "json-viewer" as TabId,
      label: "Raw Gemini JSON Inspector",
      icon: Code2,
      badge: "Deep Tech",
      badgeColor: "bg-slate-800 text-slate-300 border-slate-700",
      desc: "Structured schema inspector",
    },
  ];

  return (
    <aside className="w-full md:w-64 bg-slate-900/95 border-r border-slate-800/80 flex flex-col justify-between shrink-0 h-auto md:h-[calc(100vh-57px)] sticky top-[57px] overflow-y-auto">
      <div className="p-4 space-y-6">
        {/* Navigation Core */}
        <div>
          <div className="px-2 mb-2 text-[11px] font-semibold tracking-wider uppercase text-slate-400">
            Operations Center
          </div>
          <nav className="space-y-1">
            {navItems.map((item) => {
              const Icon = item.icon;
              const isActive = currentTab === item.id;
              return (
                <button
                  key={item.id}
                  onClick={() => onSelectTab(item.id)}
                  className={`w-full flex items-center justify-between px-3 py-2.5 rounded-xl text-xs font-medium transition-all ${
                    isActive
                      ? "bg-blue-600 text-white shadow-md shadow-blue-600/30"
                      : "text-slate-300 hover:text-white hover:bg-slate-800/60"
                  }`}
                >
                  <div className="flex items-center gap-2.5">
                    <Icon
                      className={`w-4 h-4 ${
                        isActive ? "text-white" : "text-slate-400"
                      }`}
                    />
                    <span className="truncate">{item.label}</span>
                  </div>
                  {item.badge && (
                    <span
                      className={`text-[10px] px-1.5 py-0.5 rounded-full font-semibold border ${
                        isActive
                          ? "bg-blue-700 text-white border-blue-500"
                          : item.badgeColor
                      }`}
                    >
                      {item.badge}
                    </span>
                  )}
                </button>
              );
            })}
          </nav>
        </div>

        {/* Project Expo Demo Sections */}
        <div>
          <div className="px-2 mb-2 text-[11px] font-semibold tracking-wider uppercase text-slate-400">
            Technical Architecture & Expo
          </div>
          <nav className="space-y-1">
            {expoItems.map((item) => {
              const Icon = item.icon;
              const isActive = currentTab === item.id;
              return (
                <button
                  key={item.id}
                  onClick={() => onSelectTab(item.id)}
                  className={`w-full flex items-center justify-between px-3 py-2.5 rounded-xl text-xs font-medium transition-all ${
                    isActive
                      ? "bg-blue-600 text-white shadow-md shadow-blue-600/30"
                      : "text-slate-300 hover:text-white hover:bg-slate-800/60"
                  }`}
                >
                  <div className="flex items-center gap-2.5">
                    <Icon
                      className={`w-4 h-4 ${
                        isActive ? "text-white" : "text-slate-400"
                      }`}
                    />
                    <span className="truncate">{item.label}</span>
                  </div>
                  {item.badge && (
                    <span
                      className={`text-[10px] px-1.5 py-0.5 rounded-full font-semibold border ${
                        isActive
                          ? "bg-blue-700 text-white border-blue-500"
                          : item.badgeColor
                      }`}
                    >
                      {item.badge}
                    </span>
                  )}
                </button>
              );
            })}
          </nav>
        </div>

        {/* Live Port Gate Connectivity Panel */}
        <div className="p-3.5 rounded-xl bg-slate-950/70 border border-slate-800/80 space-y-2.5">
          <div className="flex items-center justify-between">
            <span className="text-[11px] font-semibold text-slate-300 uppercase tracking-wider flex items-center gap-1.5">
              <Truck className="w-3.5 h-3.5 text-blue-400" />
              Gate Integration
            </span>
            <span className="inline-flex items-center gap-1 text-[10px] text-emerald-400 font-semibold">
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-ping"></span>
              ACTIVE
            </span>
          </div>

          <div className="space-y-1.5 text-[11px]">
            <div className="flex items-center justify-between text-slate-400">
              <span>JNPT Berth 4 Barrier</span>
              <span className="text-emerald-400 font-mono">AUTOMATED</span>
            </div>
            <div className="flex items-center justify-between text-slate-400">
              <span>SOLAS Tolerance</span>
              <span className="text-slate-200 font-mono">±5.0% Limit</span>
            </div>
            <div className="flex items-center justify-between text-slate-400">
              <span>NexLog PCS 1x API</span>
              <span className="text-blue-400 font-mono">EDIFACT v4</span>
            </div>
          </div>
        </div>
      </div>

      {/* Footer Info */}
      <div className="p-4 border-t border-slate-800/80 bg-slate-950/40 text-[11px] text-slate-400 flex items-center justify-between">
        <div className="flex items-center gap-1.5">
          <ShieldCheck className="w-3.5 h-3.5 text-blue-400" />
          <span>ISO 27001 & WCO SAFE</span>
        </div>
        <span className="text-slate-400 font-mono">v2.4</span>
      </div>
    </aside>
  );
};
