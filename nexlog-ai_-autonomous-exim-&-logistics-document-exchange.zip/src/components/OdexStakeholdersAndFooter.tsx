import React, { useState } from "react";
import {
  ChevronUp,
  Building,
  ShieldCheck,
  Award,
  Globe2,
  FileText,
  CreditCard,
  Layers,
  ArrowUp,
  Twitter,
  Facebook,
  Instagram,
  Linkedin,
  Youtube,
  Ship,
  Anchor,
} from "lucide-react";
import { SocialProfileModal, SocialPlatform } from "./SocialProfileModal";

interface NexLogStakeholdersAndFooterProps {
  onSelectAssociation: (name: string) => void;
  onSelectWhatWeDo: (action: string) => void;
  onOpenPolicy: (type: "terms" | "privacy") => void;
  onAddToast?: (type: "success" | "info" | "warning" | "error", title: string, message: string) => void;
}

export const NexLogStakeholdersAndFooter: React.FC<NexLogStakeholdersAndFooterProps> = ({
  onSelectAssociation,
  onSelectWhatWeDo,
  onOpenPolicy,
  onAddToast,
}) => {
  const [socialModalOpen, setSocialModalOpen] = useState<boolean>(false);
  const [selectedPlatform, setSelectedPlatform] = useState<SocialPlatform>("linkedin");

  const openSocialProfile = (platform: SocialPlatform) => {
    setSelectedPlatform(platform);
    setSocialModalOpen(true);
  };
  const tradeAssociations = [
    "AMTOI",
    "CSLA",
    "EIC",
    "NISAA",
    "WISTA",
    "FFFAI",
    "MaritimeSheEO",
    "NACFS",
    "BCCI",
    "BCBA",
    "DCBA",
    "CCBA",
  ];

  const whatWeDoList = [
    { label: "MPCI FILING", key: "mpci" },
    { label: "Integrations", key: "integrations" },
    { label: "Exports", key: "exports" },
    { label: "Imports", key: "imports" },
    { label: "Weighbridge Integrations", key: "weighbridge" },
  ];

  const stakeholders = [
    { name: "allcargo logistics ltd.", category: "Ocean Freight", icon: "🚢" },
    { name: "BKT GROWING TOGETHER", category: "Global Exporter", icon: "🚜" },
    { name: "EMU LINES", category: "Container Carrier", icon: "📦" },
    { name: "ADITYA BIRLA GRASIM", category: "Chemical Exim", icon: "🏭" },
    { name: "A.S. CLEARING & FORWARDING", category: "Customs Broker", icon: "📑" },
    { name: "SEAWAYS SHIPPING", category: "Bulk & Feeder", icon: "⚓" },
  ];

  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: "smooth" });
  };

  return (
    <div className="w-full bg-[#f1efe9] text-slate-800 border-t border-slate-200 select-none">
      {/* 1. Real Cargo Ship Panorama Strip */}
      <div className="relative w-full h-44 overflow-hidden border-b border-slate-300">
        <img
          src="/assets/images/cargo_ship.jpg"
          alt="Container Ship Ocean Transit"
          className="w-full h-full object-cover filter contrast-125"
        />
        <div className="absolute inset-0 bg-gradient-to-r from-slate-950/80 via-slate-900/60 to-slate-950/80 flex items-center justify-between px-6 sm:px-12 text-white">
          <div className="space-y-1">
            <span className="text-[11px] font-bold uppercase tracking-widest text-sky-400 font-mono">
              Global Maritime Infrastructure
            </span>
            <h3 className="text-xl sm:text-2xl font-black tracking-tight">
              Powering International Container Terminals & Carriers
            </h3>
            <p className="text-xs text-slate-300 max-w-xl">
              From Nhava Sheva (JNPT) and Jebel Ali to Rotterdam and Los Angeles, NexLog AI orchestrates autonomous EXIM document clearances.
            </p>
          </div>
          <div className="hidden md:flex items-center gap-3">
            <div className="p-3 rounded-2xl bg-slate-900/80 border border-slate-700/80 backdrop-blur-md text-center">
              <div className="text-xl font-black font-mono text-emerald-400">98.4%</div>
              <div className="text-[10px] text-slate-300 uppercase">SOLAS Accuracy</div>
            </div>
            <div className="p-3 rounded-2xl bg-slate-900/80 border border-slate-700/80 backdrop-blur-md text-center">
              <div className="text-xl font-black font-mono text-sky-400">410ms</div>
              <div className="text-[10px] text-slate-300 uppercase">AI Latency</div>
            </div>
          </div>
        </div>
      </div>

      {/* 2. Banking Partner DBS & Stakeholders Showcase */}
      <div className="py-12 px-6 max-w-7xl mx-auto text-center space-y-6">
        {/* Banking Partner strip */}
        <div className="inline-flex items-center gap-2 text-xs font-bold uppercase tracking-wider text-slate-600">
          <span>OUR BANKING PARTNER</span>
          <span className="font-extrabold text-red-600 bg-white px-2 py-0.5 rounded shadow-sm border border-slate-200">
            XDBS
          </span>
        </div>

        {/* Heading from Screenshot */}
        <div>
          <h2 className="text-3xl sm:text-4xl font-extrabold text-[#1e3a8a] tracking-tight">
            Our Stakeholders
          </h2>
          <div className="w-12 h-1 bg-orange-500 mx-auto mt-2 rounded-full"></div>
        </div>

        {/* Stakeholder Logos / Cards Carousel */}
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-4 pt-4">
          {stakeholders.map((s, idx) => (
            <div
              key={idx}
              onClick={() => onSelectAssociation(s.name)}
              className="p-4 rounded-xl bg-white border border-slate-200 hover:border-blue-400 shadow-sm hover:shadow-md transition-all flex flex-col items-center justify-center min-h-[90px] cursor-pointer group"
            >
              <span className="text-2xl mb-1 group-hover:scale-110 transition-transform">{s.icon}</span>
              <span className="text-xs font-extrabold text-slate-800 group-hover:text-blue-600 text-center">
                {s.name}
              </span>
              <span className="text-[10px] text-slate-400 mt-0.5 font-medium">{s.category}</span>
            </div>
          ))}
        </div>
      </div>

      {/* 3. Orange Live Stats Band from Screenshot */}
      <div className="bg-[#f97316] text-white py-6 px-6 shadow-md">
        <div className="max-w-7xl mx-auto grid grid-cols-1 sm:grid-cols-3 gap-6 text-center">
          <div className="space-y-1">
            <div className="text-3xl sm:text-4xl font-black font-mono tracking-tight">
              75,000 +
            </div>
            <div className="text-xs sm:text-sm font-semibold tracking-wide uppercase text-orange-100">
              Documents Audited & Exchanged
            </div>
          </div>

          <div className="space-y-1">
            <div className="text-3xl sm:text-4xl font-black font-mono tracking-tight">
              100 +
            </div>
            <div className="text-xs sm:text-sm font-semibold tracking-wide uppercase text-orange-100">
              Container Terminals & Ports
            </div>
          </div>

          <div className="space-y-1">
            <div className="text-3xl sm:text-4xl font-black font-mono tracking-tight">
              5,000 +
            </div>
            <div className="text-xs sm:text-sm font-semibold tracking-wide uppercase text-orange-100">
              Freight Forwarders, CHAs & Shippers
            </div>
          </div>
        </div>
      </div>

      {/* 4. Trade Associations & Company Directory Columns */}
      <div className="py-14 px-6 max-w-7xl mx-auto grid grid-cols-1 md:grid-cols-12 gap-8 text-xs">
        {/* Column 1: Trade Associations */}
        <div className="md:col-span-5 space-y-3">
          <h3 className="text-lg font-bold text-[#1e3a8a] tracking-tight">
            Trade Associations
          </h3>
          <div className="grid grid-cols-2 gap-x-4 gap-y-2 pt-1">
            {tradeAssociations.map((assoc, idx) => (
              <button
                key={idx}
                onClick={() => onSelectAssociation(assoc)}
                className="text-left text-slate-700 hover:text-orange-600 font-medium border-b border-dotted border-slate-300 pb-1 transition-colors hover:translate-x-0.5"
              >
                {assoc}
              </button>
            ))}
          </div>
        </div>

        {/* Column 2: What We Do */}
        <div className="md:col-span-4 space-y-3">
          <h3 className="text-lg font-bold text-[#1e3a8a] tracking-tight">
            What We Do
          </h3>
          <div className="space-y-2 pt-1">
            {whatWeDoList.map((item, idx) => (
              <button
                key={idx}
                onClick={() => onSelectWhatWeDo(item.key)}
                className="w-full text-left text-slate-700 hover:text-orange-600 font-medium border-b border-dotted border-slate-300 pb-1.5 transition-colors flex items-center justify-between"
              >
                <span>{item.label}</span>
                <span className="text-[10px] text-slate-400">→</span>
              </button>
            ))}
          </div>
        </div>

        {/* Column 3: Company & Financial Services */}
        <div className="md:col-span-3 space-y-3">
          <h3 className="text-lg font-bold text-[#1e3a8a] tracking-tight">
            Company & Solutions
          </h3>
          <div className="space-y-2 pt-1">
            <button
              onClick={() => onSelectWhatWeDo("blogs")}
              className="w-full text-left text-slate-700 hover:text-orange-600 font-medium border-b border-dotted border-slate-300 pb-1.5 transition-colors"
            >
              Blogs & Maritime Insights
            </button>
            <button
              onClick={() => onSelectWhatWeDo("pay-later")}
              className="w-full text-left text-orange-600 font-bold border-b border-dotted border-slate-300 pb-1.5 transition-colors"
            >
              NexLog Pay Later (DBS)
            </button>
            <button
              onClick={() => onSelectWhatWeDo("solas")}
              className="w-full text-left text-slate-700 hover:text-orange-600 font-medium border-b border-dotted border-slate-300 pb-1.5 transition-colors"
            >
              SOLAS Weighbridge Verification
            </button>
            <button
              onClick={() => onSelectWhatWeDo("gemini")}
              className="w-full text-left text-blue-700 font-bold border-b border-dotted border-slate-300 pb-1.5 transition-colors"
            >
              Google Gemini 3.8 Flash Engine
            </button>
          </div>
        </div>
      </div>

      {/* 5. Copyright & ISO Certification Bar */}
      <div className="bg-[#dedad0] border-t border-slate-300/80 py-6 px-6">
        <div className="max-w-7xl mx-auto flex flex-col md:flex-row items-center justify-between gap-4 text-xs text-slate-700">
          {/* Terms & Privacy links */}
          <div className="flex items-center gap-2 font-semibold">
            <button
              onClick={() => onOpenPolicy("terms")}
              className="hover:text-blue-700 hover:underline"
            >
              Terms & Conditions
            </button>
            <span className="text-orange-600 font-bold">•</span>
            <button
              onClick={() => onOpenPolicy("privacy")}
              className="hover:text-blue-700 hover:underline"
            >
              Privacy & Policy
            </button>
          </div>

          {/* Copyright text and ISO Certifications */}
          <div className="text-center space-y-0.5">
            <div className="font-semibold">
              Copyright ©2018–2026{" "}
              <strong className="text-orange-600 font-bold">NexLog Technologies</strong> All rights
              reserved
            </div>
            <div className="text-[11px] text-slate-600">
              An ISO 9001:2015, ISO/IEC 20000-1:2011, ISO/IEC 27001:2013 Certified Company
            </div>
          </div>

          {/* Social Icons & Scroll-to-Top Button */}
          <div className="flex items-center gap-3">
            <div className="flex items-center gap-1.5 text-white">
              <button
                onClick={() => openSocialProfile("twitter")}
                className="w-7 h-7 rounded bg-[#0284c7] hover:bg-[#0369a1] hover:scale-105 active:scale-95 flex items-center justify-center transition-all shadow-xs cursor-pointer"
                title="Twitter / X (@SudarsenCargo)"
              >
                <Twitter className="w-3.5 h-3.5" />
              </button>
              <button
                onClick={() => openSocialProfile("facebook")}
                className="w-7 h-7 rounded bg-[#0284c7] hover:bg-[#0369a1] hover:scale-105 active:scale-95 flex items-center justify-center transition-all shadow-xs cursor-pointer"
                title="Facebook (Sudarsen Cargo Community)"
              >
                <Facebook className="w-3.5 h-3.5" />
              </button>
              <button
                onClick={() => openSocialProfile("instagram")}
                className="w-7 h-7 rounded bg-[#0284c7] hover:bg-[#0369a1] hover:scale-105 active:scale-95 flex items-center justify-center transition-all shadow-xs cursor-pointer"
                title="Instagram (@sudarsencargo_official)"
              >
                <Instagram className="w-3.5 h-3.5" />
              </button>
              <button
                onClick={() => openSocialProfile("linkedin")}
                className="w-7 h-7 rounded bg-[#0284c7] hover:bg-[#0369a1] hover:scale-105 active:scale-95 flex items-center justify-center transition-all shadow-xs cursor-pointer"
                title="LinkedIn (Sudarsen Cargo Pvt Ltd Verified Profile)"
              >
                <Linkedin className="w-3.5 h-3.5" />
              </button>
              <button
                onClick={() => openSocialProfile("youtube")}
                className="w-7 h-7 rounded bg-[#0284c7] hover:bg-[#0369a1] hover:scale-105 active:scale-95 flex items-center justify-center transition-all shadow-xs cursor-pointer"
                title="YouTube (Sudarsen Cargo Maritime TV)"
              >
                <Youtube className="w-3.5 h-3.5" />
              </button>
            </div>

            {/* Cyan Square Scroll-to-Top Button from Screenshot */}
            <button
              onClick={scrollToTop}
              className="w-8 h-8 bg-[#00a3e0] hover:bg-[#008ac0] text-white flex items-center justify-center rounded shadow-md transition-all hover:scale-110 active:scale-95 cursor-pointer"
              title="Scroll to Top"
            >
              <ChevronUp className="w-5 h-5 stroke-[2.5]" />
            </button>
          </div>
        </div>
      </div>

      {/* Interactive Social Media Profile Hub Modal */}
      <SocialProfileModal
        isOpen={socialModalOpen}
        initialPlatform={selectedPlatform}
        onClose={() => setSocialModalOpen(false)}
        onAddToast={onAddToast}
      />
    </div>
  );
};

// Export alias
export const OdexStakeholdersAndFooter = NexLogStakeholdersAndFooter;
