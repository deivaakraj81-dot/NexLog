import React, { useState } from "react";
import {
  X,
  FileText,
  ShieldAlert,
  ShieldCheck,
  CheckCircle2,
  XCircle,
  AlertTriangle,
  Scale,
  Barcode,
  Sparkles,
  Layers,
  Box,
  Anchor,
  Clock,
  Printer,
} from "lucide-react";
import confetti from "canvas-confetti";
import { QueueItem } from "../types";

interface DossierModalProps {
  item: QueueItem | null;
  onClose: () => void;
  onApprove: (item: QueueItem) => void;
  onReject: (item: QueueItem, reason: string) => void;
}

export const DossierModal: React.FC<DossierModalProps> = ({
  item,
  onClose,
  onApprove,
  onReject,
}) => {
  const [activeTab, setActiveTab] = useState<"AUDIT" | "RAW_TEXT" | "PCS_PREVIEW">("AUDIT");

  if (!item) return null;

  const { auditResult } = item;
  const isPending = item.status === "PENDING_APPROVAL";

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-black/80 backdrop-blur-md animate-in fade-in duration-200">
      <div className="w-full max-w-4xl max-h-[92vh] rounded-3xl bg-slate-900 border border-slate-700 shadow-2xl flex flex-col overflow-hidden">
        {/* Modal Header */}
        <div className="px-6 py-4 bg-slate-950/80 border-b border-slate-800 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-blue-950 border border-blue-800 flex items-center justify-center text-blue-400">
              <FileText className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="text-base font-bold text-white tracking-tight">
                  EXIM Compliance Dossier: {item.docId}
                </h3>
                <span
                  className={`text-[10px] px-2.5 py-0.5 rounded-full font-bold uppercase tracking-wider border ${
                    item.riskLevel === "LOW"
                      ? "bg-emerald-950 text-emerald-300 border-emerald-800"
                      : item.riskLevel === "MEDIUM"
                      ? "bg-amber-950 text-amber-300 border-amber-800"
                      : "bg-rose-950 text-rose-300 border-rose-800"
                  }`}
                >
                  {item.riskLevel} RISK ({item.riskScore}/100)
                </span>
              </div>
              <p className="text-xs text-slate-400 font-mono">
                Container: <span className="text-blue-300">{item.containerId}</span> • {item.documentType} • Vessel: {item.vessel}
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={onClose}
              className="p-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-white transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Tab switcher */}
        <div className="px-6 py-2.5 bg-slate-950/40 border-b border-slate-800 flex items-center gap-2">
          <button
            onClick={() => setActiveTab("AUDIT")}
            className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-all ${
              activeTab === "AUDIT"
                ? "bg-blue-600 text-white shadow-sm"
                : "text-slate-400 hover:text-white hover:bg-slate-800"
            }`}
          >
            Gemini Compliance Audit
          </button>
          <button
            onClick={() => setActiveTab("RAW_TEXT")}
            className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-all ${
              activeTab === "RAW_TEXT"
                ? "bg-blue-600 text-white shadow-sm"
                : "text-slate-400 hover:text-white hover:bg-slate-800"
            }`}
          >
            Raw Manifest Text
          </button>
          <button
            onClick={() => setActiveTab("PCS_PREVIEW")}
            className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-all ${
              activeTab === "PCS_PREVIEW"
                ? "bg-blue-600 text-white shadow-sm"
                : "text-slate-400 hover:text-white hover:bg-slate-800"
            }`}
          >
            Port Gate Pre-Advice Pass (PCS 1x)
          </button>
        </div>

        {/* Modal Body */}
        <div className="p-6 overflow-y-auto space-y-6 flex-1">
          {activeTab === "AUDIT" && (
            <div className="space-y-6">
              {/* Executive Summary */}
              <div className="p-4 rounded-2xl bg-slate-950/80 border border-slate-800 space-y-2">
                <span className="text-[11px] font-bold uppercase tracking-wider text-slate-400 flex items-center gap-1.5">
                  <Sparkles className="w-4 h-4 text-emerald-400" />
                  Gemini 3.8 Flash Executive Evaluation
                </span>
                <p className="text-xs text-slate-200 leading-relaxed">
                  {auditResult.riskAssessment.summary}
                </p>
                <div className="pt-2 text-xs text-blue-300 font-mono">
                  Manager Actionable Note: {auditResult.managerNotes}
                </div>
              </div>

              {/* Extracted Metadata Grid */}
              <div className="space-y-3">
                <span className="text-xs font-bold uppercase tracking-wider text-slate-300 flex items-center gap-1.5">
                  <Box className="w-4 h-4 text-blue-400" />
                  Structured Manifest Entities
                </span>
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs">
                  <div className="p-3 rounded-xl bg-slate-950/60 border border-slate-800">
                    <span className="text-[10px] text-slate-400 uppercase block">Document Number</span>
                    <span className="font-bold font-mono text-slate-200 text-sm">
                      {auditResult.metadata.documentNumber}
                    </span>
                  </div>

                  <div className="p-3 rounded-xl bg-slate-950/60 border border-slate-800">
                    <span className="text-[10px] text-slate-400 uppercase block">Container ID</span>
                    <span className="font-bold font-mono text-blue-300 text-sm">
                      {auditResult.metadata.containerId}
                    </span>
                  </div>

                  <div className="p-3 rounded-xl bg-slate-950/60 border border-slate-800">
                    <span className="text-[10px] text-slate-400 uppercase block">Gross Weight</span>
                    <span className="font-bold font-mono text-slate-200 text-sm">
                      {auditResult.metadata.grossWeightKg?.toLocaleString()} KG
                    </span>
                  </div>

                  <div className="p-3 rounded-xl bg-slate-950/60 border border-slate-800">
                    <span className="text-[10px] text-slate-400 uppercase block">Bolt Seal Status</span>
                    <span
                      className={`font-bold font-mono text-xs ${
                        auditResult.metadata.sealNumber?.includes("MISSING")
                          ? "text-rose-400"
                          : "text-emerald-300"
                      }`}
                    >
                      {auditResult.metadata.sealNumber}
                    </span>
                  </div>

                  <div className="p-3 rounded-xl bg-slate-950/60 border border-slate-800 col-span-2">
                    <span className="text-[10px] text-slate-400 uppercase block">Shipper / Exporter</span>
                    <span className="font-semibold text-slate-200 text-xs">
                      {auditResult.metadata.shipperName}
                    </span>
                  </div>

                  <div className="p-3 rounded-xl bg-slate-950/60 border border-slate-800 col-span-2">
                    <span className="text-[10px] text-slate-400 uppercase block">Consignee / Importer</span>
                    <span className="font-semibold text-slate-200 text-xs">
                      {auditResult.metadata.consigneeName}
                    </span>
                  </div>

                  <div className="p-3 rounded-xl bg-slate-950/60 border border-slate-800">
                    <span className="text-[10px] text-slate-400 uppercase block">Port of Loading</span>
                    <span className="font-semibold text-slate-200 text-xs">
                      {auditResult.metadata.portOfLoading}
                    </span>
                  </div>

                  <div className="p-3 rounded-xl bg-slate-950/60 border border-slate-800">
                    <span className="text-[10px] text-slate-400 uppercase block">Port of Discharge</span>
                    <span className="font-semibold text-slate-200 text-xs">
                      {auditResult.metadata.portOfDischarge}
                    </span>
                  </div>

                  <div className="p-3 rounded-xl bg-slate-950/60 border border-slate-800">
                    <span className="text-[10px] text-slate-400 uppercase block">HS Code</span>
                    <span className="font-mono text-slate-200 text-xs">
                      {auditResult.metadata.hsCode}
                    </span>
                  </div>

                  <div className="p-3 rounded-xl bg-slate-950/60 border border-slate-800">
                    <span className="text-[10px] text-slate-400 uppercase block">Declared Value</span>
                    <span className="font-mono text-slate-200 text-xs">
                      {auditResult.metadata.declaredValue}
                    </span>
                  </div>
                </div>
              </div>

              {/* Weight & Discrepancies Verification */}
              <div className="p-4 rounded-2xl bg-slate-950/60 border border-slate-800 space-y-3">
                <span className="text-xs font-bold uppercase tracking-wider text-slate-300 flex items-center gap-1.5">
                  <Scale className="w-4 h-4 text-emerald-400" />
                  IMO SOLAS Verified Gross Mass (VGM) Audit Breakdown
                </span>

                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 text-xs">
                  <div className="p-3 rounded-xl bg-slate-900 border border-slate-800">
                    <span className="text-[10px] text-slate-400 block">Declared Gross Weight</span>
                    <span className="font-mono font-bold text-sm text-slate-200">
                      {auditResult.riskAssessment.weightVerification.declaredGrossKg.toLocaleString()} KG
                    </span>
                  </div>

                  <div className="p-3 rounded-xl bg-slate-900 border border-slate-800">
                    <span className="text-[10px] text-slate-400 block">Terminal Measured Weight</span>
                    <span className="font-mono font-bold text-sm text-slate-200">
                      {auditResult.riskAssessment.weightVerification.calculatedSumKg.toLocaleString()} KG
                    </span>
                  </div>

                  <div className="p-3 rounded-xl bg-slate-900 border border-slate-800">
                    <span className="text-[10px] text-slate-400 block">Variance & Discrepancy</span>
                    <span
                      className={`font-mono font-bold text-sm ${
                        auditResult.riskAssessment.weightVerification.discrepancyKg > 0
                          ? "text-rose-400"
                          : "text-emerald-400"
                      }`}
                    >
                      {auditResult.riskAssessment.weightVerification.discrepancyKg > 0
                        ? `+${auditResult.riskAssessment.weightVerification.discrepancyKg.toLocaleString()} KG (FLAGGED)`
                        : "0.0 KG (Clean)"}
                    </span>
                  </div>
                </div>

                {auditResult.riskAssessment.discrepancies.length > 0 && (
                  <div className="p-3 rounded-xl bg-rose-950/30 border border-rose-800/60 space-y-1">
                    <span className="text-xs font-bold text-rose-300">Regulatory Violations Flagged:</span>
                    <ul className="list-disc list-inside text-xs text-rose-200 space-y-0.5">
                      {auditResult.riskAssessment.discrepancies.map((d, i) => (
                        <li key={i}>{d}</li>
                      ))}
                    </ul>
                  </div>
                )}
              </div>
            </div>
          )}

          {activeTab === "RAW_TEXT" && (
            <div className="p-4 rounded-2xl bg-slate-950 border border-slate-800">
              <pre className="text-xs font-mono text-slate-300 whitespace-pre-wrap leading-relaxed">
                {item.rawText}
              </pre>
            </div>
          )}

          {activeTab === "PCS_PREVIEW" && (
            <div className="p-8 rounded-2xl bg-white text-slate-900 space-y-6 shadow-xl max-w-2xl mx-auto">
              <div className="flex items-center justify-between border-b pb-4 border-slate-200">
                <div>
                  <div className="text-lg font-black tracking-tight text-slate-900">
                    PORT COMMUNITY SYSTEM (PCS 1x)
                  </div>
                  <div className="text-xs text-slate-600">
                    JNPT Container Terminal Gate-In Pre-Advice Pass
                  </div>
                </div>
                <div className="text-right font-mono text-xs text-slate-600">
                  REF: {item.docId}
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4 text-xs">
                <div>
                  <span className="text-slate-500 uppercase block font-semibold text-[10px]">Container No</span>
                  <span className="text-base font-black font-mono">{item.containerId}</span>
                </div>
                <div>
                  <span className="text-slate-500 uppercase block font-semibold text-[10px]">Vessel / Voyage</span>
                  <span className="font-bold">{item.vessel}</span>
                </div>
                <div>
                  <span className="text-slate-500 uppercase block font-semibold text-[10px]">Shipper</span>
                  <span className="font-medium">{item.shipper}</span>
                </div>
                <div>
                  <span className="text-slate-500 uppercase block font-semibold text-[10px]">Status</span>
                  <span
                    className={`font-black uppercase ${
                      item.status === "VERIFIED_DISPATCHED" ? "text-emerald-700" : "text-amber-700"
                    }`}
                  >
                    {item.status.replace(/_/g, " ")}
                  </span>
                </div>
              </div>

              {/* Barcode Simulation */}
              <div className="p-6 rounded-xl bg-slate-100 border border-slate-300 text-center space-y-2">
                <div className="font-mono text-2xl tracking-[0.25em] font-extrabold select-none">
                  ||| | |||| | ||| || |||||| | || |||
                </div>
                <div className="text-[11px] font-mono text-slate-600">
                  *{item.containerId}-JNPT-BOOM-PASS*
                </div>
              </div>

              <div className="text-[10px] text-slate-500 text-center">
                Autonomously audited by NexLog AI powered by Google Gemini. Valid at JNPT Berth 04B.
              </div>
            </div>
          )}
        </div>

        {/* Modal Footer */}
        <div className="px-6 py-4 bg-slate-950/80 border-t border-slate-800 flex items-center justify-between">
          <button
            onClick={onClose}
            className="px-4 py-2 rounded-xl bg-slate-800 text-slate-300 hover:text-white text-xs font-semibold"
          >
            Close Dossier
          </button>

          {isPending && (
            <div className="flex items-center gap-3">
              <button
                onClick={() => {
                  onReject(item, auditResult.riskAssessment.discrepancies[0] || "Compliance failure.");
                  onClose();
                }}
                className="px-4 py-2 rounded-xl bg-rose-600/20 hover:bg-rose-600 text-rose-300 hover:text-white text-xs font-bold border border-rose-700/50 transition-all flex items-center gap-1.5"
              >
                <XCircle className="w-4 h-4" />
                <span>Reject Document</span>
              </button>

              <button
                onClick={() => {
                  confetti({ particleCount: 60, spread: 60 });
                  onApprove(item);
                  onClose();
                }}
                className="px-5 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold shadow-lg shadow-emerald-900/40 transition-all flex items-center gap-1.5"
              >
                <CheckCircle2 className="w-4 h-4" />
                <span>Approve & Dispatch to Gate Barrier</span>
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
