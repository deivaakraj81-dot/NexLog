import React, { useState, useEffect, useRef } from "react";
import {
  Ship,
  Play,
  Pause,
  Maximize2,
  Minimize2,
  Compass,
  Radio,
  Eye,
  Anchor,
  Volume2,
  VolumeX,
  Layers,
  Sparkles,
  Download,
  AlertTriangle,
  CheckCircle2,
  Info,
  Clock,
  Navigation,
  Wind,
  Gauge,
  X,
  FileText,
  Activity,
  Sliders,
  Camera,
} from "lucide-react";
import confetti from "canvas-confetti";
import { CountryNode } from "./OdexTopBar";

interface InteractiveShipStreamProps {
  companyName: string;
  userName: string;
  country: CountryNode;
  onNavigateToInvoice?: () => void;
  onNavigateToScanner?: () => void;
  onNavigateToQueue?: () => void;
  onAddToast: (type: "success" | "warning" | "error" | "info", title: string, message: string) => void;
}

type CameraView = "berth_main" | "gantry_aerial" | "container_yard";

interface Hotspot {
  id: string;
  title: string;
  label: string;
  xPercent: number; // 0 to 100
  yPercent: number;
  category: "vessel" | "crane" | "tug" | "yard";
  details: {
    name: string;
    status: string;
    teu?: string;
    speed?: string;
    operator?: string;
    notes: string;
    actionLabel: string;
  };
}

const HOTSPOTS: Hotspot[] = [
  {
    id: "vessel-bridge",
    title: "Vessel Bridge & AIS",
    label: "SUDARSEN TITAN (24,000 TEU)",
    xPercent: 54,
    yPercent: 55,
    category: "vessel",
    details: {
      name: "M/V SUDARSEN TITAN (ex-EVER ACME)",
      status: "Berth 04 • Moored & Discharging",
      teu: "24,004 TEU (Ultra Large Container Vessel)",
      speed: "0.0 kts (Tied to Bolted Bollards 12-16)",
      operator: "Sudarsen Cargo Pvt Ltd / Ocean Alliance",
      notes: "Draft: 14.8m | Length: 400m | Flag: India Cabotage Approved. 1,420 TEU assigned for JNPT / Mundra CFS DPD direct evacuation.",
      actionLabel: "Audit Vessel Manifest via AI",
    },
  },
  {
    id: "gantry-cranes",
    title: "STS Quay Crane 07",
    label: "Super Post-Panamax STS (34 Moves/hr)",
    xPercent: 46,
    yPercent: 32,
    category: "crane",
    details: {
      name: "ZPMC Super Post-Panamax STS-07",
      status: "Twin-Lift Active Discharge",
      teu: "68 TEU / Hour Lift Rate",
      speed: "Cycle: 98 sec per twin 40HC box",
      operator: "JNPT Terminal Operating System (TOS)",
      notes: "Auto-OCR scanning container numbers (MEDU4928172, KMTC8829104). Verified gross mass matched with VGM certificates.",
      actionLabel: "Inspect Live Weighbridge Data",
    },
  },
  {
    id: "tugboat-escort",
    title: "Harbor Tug Ocean Force",
    label: "Tugboat Ocean Force (70T BP)",
    xPercent: 68,
    yPercent: 70,
    category: "tug",
    details: {
      name: "ASD Harbor Tug Ocean Force",
      status: "Standby Tug Escort (Berth Line)",
      speed: "1.2 kts Station Keeping",
      operator: "Port Marine Operations Wing",
      notes: "Bollard Pull: 70 Tonnes. Harbor Pilot Capt. R. K. Nair completed safe mooring maneuvers at high tide slack water.",
      actionLabel: "View Pilotage & Berthing Log",
    },
  },
  {
    id: "yard-stack",
    title: "Container Yard DPD Cell",
    label: "Block 4-B Direct Port Delivery",
    xPercent: 18,
    yPercent: 52,
    category: "yard",
    details: {
      name: "DPD Customs Enclave - Sudarsen Logistics",
      status: "Green Channel Evacuation Active",
      teu: "340 Containers Pre-Cleared",
      operator: "Sudarsen Cargo CFS Dedicated Fleet",
      notes: "Customs Out-of-Charge (OOC) granted. Direct haulage to Vashi / Taloja / Bhiwandi distribution corridors.",
      actionLabel: "Dispatch Port Gate Truck Passes",
    },
  },
];

export const InteractiveShipStream: React.FC<InteractiveShipStreamProps> = ({
  companyName,
  userName,
  country,
  onNavigateToInvoice,
  onNavigateToScanner,
  onNavigateToQueue,
  onAddToast,
}) => {
  const [isPlaying, setIsPlaying] = useState(true);
  const [currentCamera, setCurrentCamera] = useState<CameraView>("berth_main");
  const [activeHotspot, setActiveHotspot] = useState<Hotspot | null>(null);
  const [lightingMode, setLightingMode] = useState<"dusk" | "night" | "day">("dusk");
  const [panPosition, setPanPosition] = useState(0);
  const [radarDegree, setRadarDegree] = useState(0);
  const [isFullscreen, setIsFullscreen] = useState(false);
  const [showHudOverlay, setShowHudOverlay] = useState(true);
  const [streamQuality, setStreamQuality] = useState<"4K UHD" | "1080p 60fps">("4K UHD");
  const [isHornPlaying, setIsHornPlaying] = useState(false);
  const [vesselEtaHours, setVesselEtaHours] = useState(14);
  const [waterShimmer, setWaterShimmer] = useState(0);

  const containerRef = useRef<HTMLDivElement>(null);
  const animFrameRef = useRef<number | null>(null);

  // Play realistic synthesized Ship Fog Horn using Web Audio API
  const handlePlayShipHorn = () => {
    try {
      const AudioContextClass = window.AudioContext || (window as any).webkitAudioContext;
      if (!AudioContextClass) {
        onAddToast("info", "Ship Fog Horn Sounded", "Vessel SUDARSEN TITAN sounded 2 prolonged blasts (Harbor Departure Signal).");
        return;
      }

      setIsHornPlaying(true);
      const ctx = new AudioContextClass();

      // Master gain
      const masterGain = ctx.createGain();
      masterGain.gain.setValueAtTime(0.001, ctx.currentTime);
      masterGain.gain.exponentialRampToValueAtTime(0.35, ctx.currentTime + 0.15);
      masterGain.gain.setValueAtTime(0.35, ctx.currentTime + 1.2);
      masterGain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 2.0);
      masterGain.connect(ctx.destination);

      // Low frequency fundamentals for deep maritime horn
      const osc1 = ctx.createOscillator();
      osc1.type = "sawtooth";
      osc1.frequency.setValueAtTime(108, ctx.currentTime); // ~A2 low horn
      osc1.connect(masterGain);

      const osc2 = ctx.createOscillator();
      osc2.type = "triangle";
      osc2.frequency.setValueAtTime(162, ctx.currentTime); // Harmonic 5th
      osc2.connect(masterGain);

      const osc3 = ctx.createOscillator();
      osc3.type = "sine";
      osc3.frequency.setValueAtTime(54, ctx.currentTime); // Sub rumble
      osc3.connect(masterGain);

      osc1.start();
      osc2.start();
      osc3.start();

      osc1.stop(ctx.currentTime + 2.05);
      osc2.stop(ctx.currentTime + 2.05);
      osc3.stop(ctx.currentTime + 2.05);

      setTimeout(() => {
        setIsHornPlaying(false);
        ctx.close();
      }, 2100);

      onAddToast(
        "info",
        "Nautical Fog Horn Sounded",
        "🔊 M/V SUDARSEN TITAN sounded 2 prolonged blasts (Navigational Priority Signal)."
      );
    } catch {
      setIsHornPlaying(false);
      onAddToast("info", "Ship Fog Horn Sounded", "Vessel SUDARSEN TITAN sounded harbor navigation horn.");
    }
  };

  // Continuous animation loop for camera drift, radar sweep, and water wave reflections
  useEffect(() => {
    let startTime = performance.now();

    const animate = (time: number) => {
      const elapsed = (time - startTime) / 1000;

      // Radar rotation
      setRadarDegree((prev) => (prev + 1.8) % 360);

      // Subtle water shimmer wave
      setWaterShimmer(Math.sin(elapsed * 1.5) * 5);

      // Ken Burns subtle camera motion when playing
      if (isPlaying) {
        // Slow oscillation between -2% and +2% pan and scale
        const pan = Math.sin(elapsed * 0.18) * 1.8;
        setPanPosition(pan);
      }

      animFrameRef.current = requestAnimationFrame(animate);
    };

    animFrameRef.current = requestAnimationFrame(animate);

    return () => {
      if (animFrameRef.current) cancelAnimationFrame(animFrameRef.current);
    };
  }, [isPlaying]);

  // Current image source based on active camera
  const cameraImages: Record<CameraView, { src: string; title: string; subtitle: string }> = {
    berth_main: {
      src: "/assets/images/cinematic_cargo_ship_port.jpg",
      title: "BERTH 04 QUAYSIDE (MAIN FEED)",
      subtitle: `Deepwater Container Basin • ${country.name} (${country.port})`,
    },
    gantry_aerial: {
      src: "/assets/images/harbor_cranes_ship.jpg",
      title: "STS GANTRY CRANE AERIAL (CAM 02)",
      subtitle: `Twin-Lift STS Operations • ${companyName}`,
    },
    container_yard: {
      src: "/assets/images/container_yard.jpg",
      title: "CFS / DPD CONTAINER YARD (CAM 03)",
      subtitle: "Customs Stacking & Reefer Monitoring Enclave",
    },
  };

  const activeCamConfig = cameraImages[currentCamera];

  // Download Port Berth Entry Certificate
  const handleDownloadBerthPass = () => {
    const content = `<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <title>Port Berthing & Telematics Certificate - ${companyName}</title>
  <style>
    body { font-family: monospace, sans-serif; padding: 40px; color: #0f172a; line-height: 1.6; }
    .border-box { border: 3px double #0098db; padding: 24px; border-radius: 8px; }
    h1 { color: #0098db; font-size: 20px; border-bottom: 2px solid #e2e8f0; padding-bottom: 8px; }
    .badge { background: #10b981; color: #fff; padding: 4px 8px; border-radius: 4px; font-weight: bold; font-size: 11px; }
    table { width: 100%; border-collapse: collapse; margin-top: 16px; font-size: 12px; }
    th, td { border: 1px solid #cbd5e1; padding: 8px 12px; text-align: left; }
    th { background: #f1f5f9; }
  </style>
</head>
<body>
  <div class="border-box">
    <div style="display: flex; justify-content: space-between; align-items: center;">
      <div>
        <h1>PORT BERTHING & MARITIME TELEMATICS CERTIFICATE</h1>
        <div style="font-size: 12px; color: #64748b;">Issued by Port Marine Operations & NexLog Autonomous Network</div>
      </div>
      <span class="badge">OFFICIALLY CLEARED</span>
    </div>

    <table>
      <tr><th>Vessel Name</th><td>M/V SUDARSEN TITAN (IMO 9893890)</td><th>Port Location</th><td>${country.terminal} (${country.port})</td></tr>
      <tr><th>Authorized Consignee</th><td>${companyName}</td><th>Officer</th><td>${userName} (Logistics Manager)</td></tr>
      <tr><th>Berth Assigned</th><td>Berth 04 (Deepwater Basin)</td><th>Draft / Beam</th><td>14.8m / 61.5m (400m LOA)</td></tr>
      <tr><th>Gross TEU Capacity</th><td>24,004 TEU</td><th>Discharge Allocation</th><td>1,420 TEU (Direct Port Delivery)</td></tr>
      <tr><th>Time of Berthing</th><td>${new Date().toISOString()}</td><th>Customs ICEGATE Status</th><td>OOC Granted • Fast-Track PCS 1x</td></tr>
    </table>

    <div style="margin-top: 24px; font-size: 11px; color: #047857;">
      ✓ Cryptographic Berth Sign-off: SHA-256: 0x${Math.random().toString(16).substring(2, 14).toUpperCase()}
      <br>Authorized for Gate Pass Inward Transit & Electronic Delivery Order Issuance.
    </div>
  </div>
</body>
</html>`;

    const blob = new Blob([content], { type: "text/html;charset=utf-8" });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.href = url;
    link.download = `Berth_Certificate_${country.port}_SudarsenCargo.html`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);

    onAddToast(
      "success",
      "Berthing Pass Downloaded",
      `Official Maritime Berth Certificate for M/V SUDARSEN TITAN at ${country.terminal} downloaded.`
    );
  };

  return (
    <div
      ref={containerRef}
      className={`relative rounded-2xl overflow-hidden border border-slate-300 shadow-xl bg-slate-950 text-white select-none transition-all duration-300 ${
        isFullscreen ? "fixed inset-0 z-50 rounded-none border-none" : "min-h-[380px] sm:min-h-[440px]"
      }`}
    >
      {/* 1. Cinematic Ship Video Simulation Feed */}
      <div className="absolute inset-0 overflow-hidden">
        <img
          src={activeCamConfig.src}
          alt={activeCamConfig.title}
          className={`w-full h-full object-cover transition-transform duration-1000 ease-out will-change-transform ${
            lightingMode === "night"
              ? "brightness-75 contrast-125 saturate-110 hue-rotate-15"
              : lightingMode === "day"
              ? "brightness-105 contrast-105 saturate-100"
              : "brightness-90 contrast-115 saturate-115"
          }`}
          style={{
            transform: `scale(${1.04 + Math.abs(panPosition) * 0.015}) translate(${panPosition}%, ${panPosition * 0.5}%)`,
          }}
        />

        {/* Dynamic Water Reflection / Wave Shimmer Overlay */}
        <div
          className="absolute inset-x-0 bottom-0 h-1/3 bg-gradient-to-t from-sky-950/50 via-teal-950/20 to-transparent pointer-events-none mix-blend-overlay transition-opacity duration-700"
          style={{ opacity: 0.6 + Math.abs(waterShimmer) * 0.05 }}
        />

        {/* Ambient Gradient Overlays for Readability */}
        <div className="absolute inset-0 bg-gradient-to-t from-slate-950 via-slate-950/35 to-slate-950/60 pointer-events-none" />
        <div className="absolute inset-0 bg-gradient-to-r from-slate-950/80 via-transparent to-slate-950/50 pointer-events-none" />

        {/* Animated Beacon Light Rays */}
        <div
          className="absolute top-1/3 left-1/2 -translate-x-1/2 w-96 h-96 bg-cyan-400/10 rounded-full blur-3xl pointer-events-none animate-pulse"
          style={{ animationDuration: "3s" }}
        />
      </div>

      {/* 2. Live AIS Transponder Radar & Telemetry HUD Overlay */}
      {showHudOverlay && (
        <div className="absolute top-4 left-4 z-20 flex flex-wrap items-center gap-2">
          {/* Live Recording Pill */}
          <div className="flex items-center gap-2 px-3 py-1 rounded-full bg-slate-950/85 backdrop-blur-md border border-slate-700/80 shadow-md text-xs font-semibold">
            <span className="relative flex h-2.5 w-2.5">
              <span className={`animate-ping absolute inline-flex h-full w-full rounded-full opacity-75 ${isPlaying ? "bg-red-400" : "bg-amber-400"}`} />
              <span className={`relative inline-flex rounded-full h-2.5 w-2.5 ${isPlaying ? "bg-red-500" : "bg-amber-500"}`} />
            </span>
            <span className="font-mono text-[11px] text-slate-200">
              {isPlaying ? "LIVE CAM" : "PAUSED"} • {activeCamConfig.title.split("(")[0]}
            </span>
          </div>

          {/* Quality Indicator */}
          <button
            type="button"
            onClick={() => {
              const next = streamQuality === "4K UHD" ? "1080p 60fps" : "4K UHD";
              setStreamQuality(next);
              onAddToast("info", "Stream Quality", `Switched video stream to ${next}.`);
            }}
            className="px-2.5 py-1 rounded-full bg-slate-900/80 hover:bg-slate-850 backdrop-blur-md border border-cyan-500/40 text-cyan-300 font-mono text-[10px] font-bold tracking-wider cursor-pointer transition-colors"
          >
            {streamQuality}
          </button>

          {/* Rotating Radar Mini-Compass */}
          <div className="hidden sm:flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-slate-950/80 backdrop-blur-md border border-slate-700 text-[11px] text-slate-300">
            <div className="relative w-4 h-4 rounded-full border border-emerald-500/60 flex items-center justify-center overflow-hidden">
              <div
                className="absolute w-full h-[1px] bg-gradient-to-r from-transparent to-emerald-400"
                style={{ transform: `rotate(${radarDegree}deg)` }}
              />
              <div className="w-1 h-1 bg-emerald-400 rounded-full" />
            </div>
            <span className="font-mono text-[10px] text-emerald-400">AIS RADAR 12 NM</span>
          </div>
        </div>
      )}

      {/* Top Right Controls: Camera Switcher & Fullscreen */}
      <div className="absolute top-4 right-4 z-20 flex items-center gap-2">
        {/* Camera Angle Selector Dropdown */}
        <div className="flex items-center bg-slate-950/85 backdrop-blur-md border border-slate-700/80 rounded-lg p-0.5 text-xs shadow-md">
          <button
            type="button"
            onClick={() => {
              setCurrentCamera("berth_main");
              onAddToast("info", "Camera Switched", "Switched to Berth 04 Quayside Main View.");
            }}
            className={`px-2.5 py-1 rounded-md text-[11px] font-bold transition-all cursor-pointer flex items-center gap-1 ${
              currentCamera === "berth_main"
                ? "bg-[#0098db] text-white shadow-xs"
                : "text-slate-400 hover:text-white"
            }`}
          >
            <Ship className="w-3 h-3" />
            <span className="hidden sm:inline">Berth 04</span>
          </button>

          <button
            type="button"
            onClick={() => {
              setCurrentCamera("gantry_aerial");
              onAddToast("info", "Camera Switched", "Switched to STS Gantry Crane Aerial Cam.");
            }}
            className={`px-2.5 py-1 rounded-md text-[11px] font-bold transition-all cursor-pointer flex items-center gap-1 ${
              currentCamera === "gantry_aerial"
                ? "bg-[#0098db] text-white shadow-xs"
                : "text-slate-400 hover:text-white"
            }`}
          >
            <Camera className="w-3 h-3" />
            <span className="hidden sm:inline">STS Crane</span>
          </button>

          <button
            type="button"
            onClick={() => {
              setCurrentCamera("container_yard");
              onAddToast("info", "Camera Switched", "Switched to CFS / DPD Container Yard Cam.");
            }}
            className={`px-2.5 py-1 rounded-md text-[11px] font-bold transition-all cursor-pointer flex items-center gap-1 ${
              currentCamera === "container_yard"
                ? "bg-[#0098db] text-white shadow-xs"
                : "text-slate-400 hover:text-white"
            }`}
          >
            <Layers className="w-3 h-3" />
            <span className="hidden sm:inline">CFS Yard</span>
          </button>
        </div>

        {/* Fullscreen Toggle */}
        <button
          type="button"
          onClick={() => setIsFullscreen(!isFullscreen)}
          className="p-1.5 rounded-lg bg-slate-950/85 hover:bg-slate-800 text-slate-300 hover:text-white border border-slate-700/80 transition-colors cursor-pointer"
          title={isFullscreen ? "Exit Fullscreen" : "Fullscreen View"}
        >
          {isFullscreen ? <Minimize2 className="w-4 h-4" /> : <Maximize2 className="w-4 h-4" />}
        </button>
      </div>

      {/* 3. Interactive Hotspots on the Vessel & Cranes (Clickable Pins) */}
      {showHudOverlay && currentCamera === "berth_main" && (
        <div className="absolute inset-0 z-10 pointer-events-none">
          {HOTSPOTS.map((spot) => (
            <div
              key={spot.id}
              className="absolute pointer-events-auto transform -translate-x-1/2 -translate-y-1/2 transition-transform duration-200 hover:scale-110"
              style={{ left: `${spot.xPercent}%`, top: `${spot.yPercent}%` }}
            >
              <button
                type="button"
                onClick={() => setActiveHotspot(spot)}
                className="group relative flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-slate-950/90 hover:bg-emerald-950 text-white border border-emerald-400/80 shadow-lg cursor-pointer backdrop-blur-md transition-all"
              >
                <span className="relative flex h-2 w-2">
                  <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75" />
                  <span className="relative inline-flex rounded-full h-2 w-2 bg-emerald-500" />
                </span>
                <span className="text-[10px] font-mono font-bold tracking-tight text-emerald-300 group-hover:text-white">
                  {spot.title}
                </span>
              </button>
            </div>
          ))}
        </div>
      )}

      {/* 4. Bottom Hero Content & Control Console */}
      <div className="relative z-10 p-5 sm:p-7 flex flex-col justify-end min-h-[380px] sm:min-h-[440px] pointer-events-auto">
        <div className="max-w-3xl space-y-3">
          {/* Company & Berth Badge */}
          <div className="inline-flex flex-wrap items-center gap-2">
            <span className="px-2.5 py-0.5 rounded-full bg-emerald-950/85 text-emerald-300 border border-emerald-400/50 text-[10px] font-black uppercase tracking-wider flex items-center gap-1.5 backdrop-blur-sm shadow-xs">
              <Anchor className="w-3.5 h-3.5 text-emerald-400" />
              <span>BERTH 04 • {companyName.toUpperCase()}</span>
            </span>

            <span className="px-2.5 py-0.5 rounded-full bg-sky-950/80 text-sky-300 border border-sky-400/40 text-[10px] font-bold font-mono">
              VESSEL: M/V SUDARSEN TITAN • LOA 400M
            </span>

            <span className="hidden sm:inline-flex px-2 py-0.5 rounded bg-slate-900/80 text-slate-300 border border-slate-700 text-[10px] font-mono">
              PORT: {country.name} ({country.currencySymbol.trim()})
            </span>
          </div>

          {/* Heading */}
          <h2 className="text-xl sm:text-3xl font-black tracking-tight text-white drop-shadow-md leading-tight">
            Autonomous Maritime Berthing & Vessel Telematics
          </h2>

          <p className="text-xs sm:text-sm text-slate-200 leading-relaxed font-normal max-w-2xl drop-shadow-sm">
            Live AI stream connected to Indian Port Community System (PCS 1x) & ICEGATE. Real-time weighbridge reconciliation, container tracking, and instant electronic Delivery Order (eDO) release.
          </p>

          {/* 5. Interactive Action Console: Play/Pause, Horn, Lighting, Manifest AI */}
          <div className="pt-2 flex flex-wrap items-center gap-2.5">
            {/* Play / Pause Video Motion */}
            <button
              type="button"
              onClick={() => {
                setIsPlaying(!isPlaying);
                onAddToast(
                  "info",
                  isPlaying ? "Camera Motion Paused" : "Live Camera Motion Resumed",
                  isPlaying ? "Cinematic pan is paused on current frame." : "Continuous port camera drift active."
                );
              }}
              className="px-3 py-1.5 rounded-lg bg-white/10 hover:bg-white/20 text-white backdrop-blur-md border border-white/20 text-xs font-bold transition-all cursor-pointer flex items-center gap-1.5"
            >
              {isPlaying ? <Pause className="w-3.5 h-3.5" /> : <Play className="w-3.5 h-3.5 fill-current" />}
              <span>{isPlaying ? "Pause Video" : "Play Video"}</span>
            </button>

            {/* Sound Fog Horn Button */}
            <button
              type="button"
              disabled={isHornPlaying}
              onClick={handlePlayShipHorn}
              className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all cursor-pointer flex items-center gap-1.5 backdrop-blur-md border ${
                isHornPlaying
                  ? "bg-amber-500 text-slate-950 border-amber-400 animate-pulse"
                  : "bg-slate-900/80 hover:bg-slate-800 text-amber-300 border-amber-500/40"
              }`}
              title="Sound the official maritime fog horn using audio synthesis"
            >
              <Volume2 className="w-3.5 h-3.5" />
              <span>{isHornPlaying ? "Sounding Horn..." : "Sound Fog Horn"}</span>
            </button>

            {/* AI Cargo Manifest Scan */}
            <button
              type="button"
              onClick={() => {
                onAddToast("success", "AI Cargo Manifest Audit", "Audited 1,420 TEU on SUDARSEN TITAN: 0 weight discrepancies, 100% customs compliant.");
                confetti({ particleCount: 50, spread: 60, origin: { y: 0.7 } });
              }}
              className="px-3.5 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold shadow-md transition-all cursor-pointer flex items-center gap-1.5"
            >
              <Sparkles className="w-3.5 h-3.5" />
              <span>AI Manifest Audit</span>
            </button>

            {/* Lighting Mode Selector */}
            <div className="flex items-center bg-slate-900/80 backdrop-blur-md border border-slate-700 rounded-lg p-0.5 text-[11px]">
              <button
                type="button"
                onClick={() => setLightingMode("dusk")}
                className={`px-2 py-1 rounded font-semibold transition-colors ${
                  lightingMode === "dusk" ? "bg-amber-600 text-white" : "text-slate-400 hover:text-white"
                }`}
              >
                Dusk
              </button>
              <button
                type="button"
                onClick={() => setLightingMode("night")}
                className={`px-2 py-1 rounded font-semibold transition-colors ${
                  lightingMode === "night" ? "bg-indigo-700 text-white" : "text-slate-400 hover:text-white"
                }`}
              >
                Night
              </button>
              <button
                type="button"
                onClick={() => setLightingMode("day")}
                className={`px-2 py-1 rounded font-semibold transition-colors ${
                  lightingMode === "day" ? "bg-sky-600 text-white" : "text-slate-400 hover:text-white"
                }`}
              >
                Day
              </button>
            </div>

            {/* Download Port Berthing Certificate */}
            <button
              type="button"
              onClick={handleDownloadBerthPass}
              className="px-3 py-1.5 rounded-lg bg-slate-900/80 hover:bg-slate-800 text-slate-300 hover:text-white border border-slate-700 text-xs font-semibold transition-colors cursor-pointer flex items-center gap-1.5"
            >
              <Download className="w-3.5 h-3.5" />
              <span>Berth Pass</span>
            </button>

            {/* Toggle HUD */}
            <button
              type="button"
              onClick={() => setShowHudOverlay(!showHudOverlay)}
              className="px-2.5 py-1.5 rounded-lg bg-slate-900/80 hover:bg-slate-800 text-slate-400 hover:text-white border border-slate-700 text-xs transition-colors"
              title="Toggle HUD Telemetry"
            >
              <Sliders className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>
      </div>

      {/* 6. Interactive Hotspot Inspection Drawer / Modal */}
      {activeHotspot && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 backdrop-blur-xs p-4 animate-in fade-in duration-200">
          <div className="bg-slate-900 border border-slate-700 rounded-xl shadow-2xl w-full max-w-lg overflow-hidden text-white">
            {/* Modal Header */}
            <div className="bg-slate-950 px-5 py-4 border-b border-slate-800 flex items-center justify-between">
              <div className="flex items-center gap-2.5">
                <div className="w-8 h-8 rounded-lg bg-emerald-500/20 text-emerald-400 flex items-center justify-center font-bold">
                  <Ship className="w-4 h-4" />
                </div>
                <div>
                  <h4 className="text-sm font-bold tracking-tight">{activeHotspot.details.name}</h4>
                  <div className="text-[11px] text-emerald-400 font-mono">{activeHotspot.details.status}</div>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setActiveHotspot(null)}
                className="text-slate-400 hover:text-white p-1 rounded transition-colors"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Modal Body */}
            <div className="p-5 space-y-4 text-xs">
              <div className="grid grid-cols-2 gap-3 bg-slate-950/60 p-3 rounded-lg border border-slate-800 font-mono">
                <div>
                  <span className="text-[10px] text-slate-500 uppercase font-sans">Capacity / Rate</span>
                  <div className="font-bold text-slate-200">{activeHotspot.details.teu || "24,000 TEU"}</div>
                </div>
                <div>
                  <span className="text-[10px] text-slate-500 uppercase font-sans">Speed / Velocity</span>
                  <div className="font-bold text-emerald-400">{activeHotspot.details.speed || "0.0 kts"}</div>
                </div>
                <div>
                  <span className="text-[10px] text-slate-500 uppercase font-sans">Operator</span>
                  <div className="font-bold text-slate-200">{activeHotspot.details.operator}</div>
                </div>
                <div>
                  <span className="text-[10px] text-slate-500 uppercase font-sans">Cabotage & Customs</span>
                  <div className="font-bold text-sky-400">ICEGATE Fast-Track</div>
                </div>
              </div>

              <div className="bg-slate-800/50 p-3.5 rounded-lg border border-slate-700/60 text-slate-300 leading-relaxed">
                {activeHotspot.details.notes}
              </div>

              <div className="pt-2 flex items-center justify-between gap-2">
                <button
                  type="button"
                  onClick={() => setActiveHotspot(null)}
                  className="px-4 py-2 border border-slate-700 text-slate-300 hover:text-white rounded-md text-xs font-semibold"
                >
                  Close
                </button>

                <button
                  type="button"
                  onClick={() => {
                    setActiveHotspot(null);
                    onAddToast(
                      "success",
                      activeHotspot.details.actionLabel,
                      `Action executed for ${activeHotspot.title} at ${country.terminal}.`
                    );
                    if (activeHotspot.id === "vessel-bridge" && onNavigateToScanner) {
                      onNavigateToScanner();
                    } else if (activeHotspot.id === "yard-stack" && onNavigateToQueue) {
                      onNavigateToQueue();
                    } else if (activeHotspot.id === "gantry-cranes" && onNavigateToInvoice) {
                      onNavigateToInvoice();
                    }
                  }}
                  className="px-5 py-2 bg-[#0098db] hover:bg-[#0086c2] text-white rounded-md text-xs font-bold shadow-md cursor-pointer flex items-center gap-1.5"
                >
                  <Activity className="w-3.5 h-3.5" />
                  <span>{activeHotspot.details.actionLabel}</span>
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
