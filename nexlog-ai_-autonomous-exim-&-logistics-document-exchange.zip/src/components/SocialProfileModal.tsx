import React, { useState } from "react";
import {
  X,
  Twitter,
  Facebook,
  Instagram,
  Linkedin,
  Youtube,
  ExternalLink,
  CheckCircle2,
  Heart,
  Share2,
  MessageCircle,
  Repeat2,
  ThumbsUp,
  UserPlus,
  Play,
  Pause,
  Volume2,
  VolumeX,
  Sparkles,
  Ship,
  Globe2,
  Award,
  Check,
  Radio,
  Bookmark,
} from "lucide-react";

export type SocialPlatform = "linkedin" | "twitter" | "instagram" | "facebook" | "youtube";

interface SocialProfileModalProps {
  isOpen: boolean;
  initialPlatform?: SocialPlatform;
  onClose: () => void;
  onAddToast?: (type: "success" | "info" | "warning" | "error", title: string, message: string) => void;
}

export const SocialProfileModal: React.FC<SocialProfileModalProps> = ({
  isOpen,
  initialPlatform = "linkedin",
  onClose,
  onAddToast,
}) => {
  const [activeTab, setActiveTab] = useState<SocialPlatform>(initialPlatform);
  const [isFollowing, setIsFollowing] = useState<Record<SocialPlatform, boolean>>({
    linkedin: false,
    twitter: false,
    instagram: false,
    facebook: false,
    youtube: false,
  });

  const [likedPosts, setLikedPosts] = useState<Record<string, boolean>>({
    "li-1": false,
    "li-2": true,
    "tw-1": false,
    "tw-2": false,
    "yt-1": false,
    "ig-1": false,
    "ig-2": false,
    "fb-1": false,
  });

  const [likeCounts, setLikeCounts] = useState<Record<string, number>>({
    "li-1": 428,
    "li-2": 194,
    "tw-1": 89,
    "tw-2": 142,
    "yt-1": 1820,
    "ig-1": 634,
    "ig-2": 489,
    "fb-1": 312,
  });

  const [copiedLink, setCopiedLink] = useState(false);
  const [isPlayingVideo, setIsPlayingVideo] = useState(true);
  const [isMuted, setIsMuted] = useState(true);

  // Sync initial tab when reopened
  React.useEffect(() => {
    if (initialPlatform) {
      setActiveTab(initialPlatform);
    }
  }, [initialPlatform, isOpen]);

  if (!isOpen) return null;

  const toggleFollow = (platform: SocialPlatform) => {
    const newState = !isFollowing[platform];
    setIsFollowing((prev) => ({ ...prev, [platform]: newState }));
    if (onAddToast) {
      onAddToast(
        newState ? "success" : "info",
        newState ? "Followed Successfully" : "Unfollowed",
        newState
          ? `You are now following Sudarsen Cargo Pvt Ltd on ${platform.toUpperCase()}.`
          : `Unfollowed Sudarsen Cargo on ${platform.toUpperCase()}.`
      );
    }
  };

  const toggleLike = (postId: string) => {
    const isCurrentlyLiked = !!likedPosts[postId];
    setLikedPosts((prev) => ({ ...prev, [postId]: !isCurrentlyLiked }));
    setLikeCounts((prev) => ({
      ...prev,
      [postId]: (prev[postId] || 0) + (isCurrentlyLiked ? -1 : 1),
    }));
    if (onAddToast && !isCurrentlyLiked) {
      onAddToast("success", "Liked Post", "Your feedback was registered on the live feed.");
    }
  };

  const handleShare = (title: string, url: string) => {
    if (navigator.clipboard) {
      navigator.clipboard.writeText(url).then(() => {
        setCopiedLink(true);
        setTimeout(() => setCopiedLink(false), 2500);
      });
    }
    if (onAddToast) {
      onAddToast("info", "Link Copied", `Sharable link for "${title}" copied to clipboard.`);
    }
  };

  const platforms = [
    {
      id: "linkedin" as SocialPlatform,
      name: "LinkedIn",
      icon: Linkedin,
      color: "bg-[#0077b5] text-white hover:bg-[#006097]",
      activeBg: "bg-[#0077b5] text-white",
      badge: "Verified Corporate Page",
      handle: "sudarsen-cargo-pvt-ltd",
      url: "https://www.linkedin.com/company/sudarsen-cargo",
    },
    {
      id: "twitter" as SocialPlatform,
      name: "X (Twitter)",
      icon: Twitter,
      color: "bg-[#0284c7] text-white hover:bg-[#0369a1]",
      activeBg: "bg-slate-900 text-white",
      badge: "@SudarsenCargo",
      handle: "@SudarsenCargo",
      url: "https://twitter.com/SudarsenCargo",
    },
    {
      id: "youtube" as SocialPlatform,
      name: "YouTube",
      icon: Youtube,
      color: "bg-[#ff0000] text-white hover:bg-[#d90000]",
      activeBg: "bg-[#ff0000] text-white",
      badge: "Sudarsen Cargo Maritime TV",
      handle: "@SudarsenCargoGlobal",
      url: "https://www.youtube.com/@SudarsenCargo",
    },
    {
      id: "instagram" as SocialPlatform,
      name: "Instagram",
      icon: Instagram,
      color: "bg-gradient-to-tr from-amber-500 via-rose-500 to-purple-600 text-white",
      activeBg: "bg-gradient-to-tr from-amber-500 via-rose-500 to-purple-600 text-white",
      badge: "@sudarsencargo_official",
      handle: "@sudarsencargo_official",
      url: "https://www.instagram.com/sudarsencargo_official",
    },
    {
      id: "facebook" as SocialPlatform,
      name: "Facebook",
      icon: Facebook,
      color: "bg-[#1877f2] text-white hover:bg-[#1567d3]",
      activeBg: "bg-[#1877f2] text-white",
      badge: "Official Community",
      handle: "SudarsenCargoOfficial",
      url: "https://www.facebook.com/SudarsenCargo",
    },
  ];

  const currentPlatformInfo = platforms.find((p) => p.id === activeTab) || platforms[0];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-slate-950/75 backdrop-blur-sm animate-in fade-in duration-200">
      <div className="bg-white rounded-2xl shadow-2xl border border-slate-200 w-full max-w-4xl max-h-[92vh] flex flex-col overflow-hidden text-slate-800">
        {/* Top Header Bar */}
        <div className="px-5 py-3.5 bg-slate-900 text-white flex items-center justify-between border-b border-slate-800">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-sky-500/20 text-sky-400 flex items-center justify-center border border-sky-400/30">
              <Ship className="w-4 h-4" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="text-sm font-black tracking-tight text-white">
                  Sudarsen Cargo Pvt Ltd
                </span>
                <span className="flex items-center gap-1 px-1.5 py-0.5 rounded text-[10px] font-bold bg-sky-500/20 text-sky-300 border border-sky-500/30">
                  <CheckCircle2 className="w-3 h-3 text-sky-400" />
                  Verified
                </span>
              </div>
              <p className="text-[11px] text-slate-400">
                Official Corporate Profiles & Autonomous Port Community Feed
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <a
              href={currentPlatformInfo.url}
              target="_blank"
              rel="noopener noreferrer"
              className="hidden sm:inline-flex items-center gap-1 px-3 py-1.5 rounded-lg text-xs font-semibold bg-slate-800 hover:bg-slate-700 text-slate-200 transition-colors border border-slate-700"
              title="Open external profile in new tab"
            >
              <span>Visit {currentPlatformInfo.name}</span>
              <ExternalLink className="w-3.5 h-3.5 ml-0.5" />
            </a>
            <button
              onClick={onClose}
              className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Platform Selection Tabs */}
        <div className="bg-slate-100 border-b border-slate-200 px-4 py-2 flex items-center gap-1.5 overflow-x-auto">
          {platforms.map((p) => {
            const Icon = p.icon;
            const isActive = activeTab === p.id;
            return (
              <button
                key={p.id}
                onClick={() => setActiveTab(p.id)}
                className={`flex items-center gap-2 px-3.5 py-2 rounded-xl text-xs font-bold transition-all cursor-pointer whitespace-nowrap ${
                  isActive
                    ? `${p.activeBg} shadow-sm scale-102`
                    : "bg-white text-slate-600 hover:text-slate-900 hover:bg-slate-50 border border-slate-200"
                }`}
              >
                <Icon className="w-4 h-4" />
                <span>{p.name}</span>
                {isFollowing[p.id] && (
                  <span className="w-2 h-2 rounded-full bg-emerald-400"></span>
                )}
              </button>
            );
          })}
        </div>

        {/* Modal Body / Profile Canvas */}
        <div className="flex-1 overflow-y-auto p-5 sm:p-6 space-y-6 bg-slate-50">
          {/* Corporate Profile Header Card */}
          <div className="rounded-2xl bg-white border border-slate-200 shadow-sm overflow-hidden">
            {/* Banner Backdrop */}
            <div className="h-32 sm:h-36 relative overflow-hidden bg-gradient-to-r from-blue-900 via-sky-800 to-indigo-950">
              <img
                src="/assets/images/cargo_ship.jpg"
                alt="Sudarsen Cargo Terminal"
                className="w-full h-full object-cover opacity-45 mix-blend-overlay"
              />
              <div className="absolute top-3 right-3 flex items-center gap-2">
                <span className="px-2.5 py-1 rounded-full text-[10px] font-bold font-mono tracking-wider bg-black/50 text-white backdrop-blur-md border border-white/20">
                  PRN: 100653 • ICEGATE CONNECTED
                </span>
              </div>
            </div>

            {/* Profile Bar info */}
            <div className="px-5 pb-5 pt-0 relative">
              <div className="flex flex-col sm:flex-row items-start sm:items-end justify-between gap-4 -mt-12 mb-4">
                <div className="flex items-end gap-3.5">
                  <div className="w-20 h-20 rounded-2xl bg-white p-1.5 shadow-md border border-slate-200 relative">
                    <div className="w-full h-full rounded-xl bg-gradient-to-br from-[#0098db] to-[#1e3a8a] flex flex-col items-center justify-center text-white font-black text-center shadow-inner">
                      <Ship className="w-6 h-6 mb-0.5" />
                      <span className="text-[9px] uppercase tracking-tighter">Sudarsen</span>
                    </div>
                    <span className="absolute -bottom-1 -right-1 w-5 h-5 rounded-full bg-emerald-500 border-2 border-white flex items-center justify-center text-white text-[10px]" title="Active Online">
                      ✓
                    </span>
                  </div>

                  <div>
                    <div className="flex items-center gap-1.5">
                      <h2 className="text-lg sm:text-xl font-black text-slate-900 tracking-tight">
                        Sudarsen Cargo Pvt Ltd
                      </h2>
                      <CheckCircle2 className="w-4 h-4 text-[#0098db]" />
                    </div>
                    <p className="text-xs font-medium text-slate-500">
                      {currentPlatformInfo.badge} • Authorized Multimodal Maritime Logistics
                    </p>
                  </div>
                </div>

                {/* Follow & Action Buttons */}
                <div className="flex items-center gap-2 w-full sm:w-auto">
                  <button
                    onClick={() => toggleFollow(activeTab)}
                    className={`flex-1 sm:flex-none flex items-center justify-center gap-1.5 px-4 py-2 rounded-xl text-xs font-bold transition-all shadow-sm cursor-pointer ${
                      isFollowing[activeTab]
                        ? "bg-emerald-50 text-emerald-700 border border-emerald-300"
                        : "bg-[#0098db] hover:bg-[#0086c2] text-white"
                    }`}
                  >
                    {isFollowing[activeTab] ? (
                      <>
                        <Check className="w-3.5 h-3.5 stroke-[3]" />
                        <span>Following</span>
                      </>
                    ) : (
                      <>
                        <UserPlus className="w-3.5 h-3.5" />
                        <span>Follow +</span>
                      </>
                    )}
                  </button>

                  <a
                    href={currentPlatformInfo.url}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="flex items-center justify-center gap-1.5 px-3 py-2 rounded-xl text-xs font-bold bg-slate-100 hover:bg-slate-200 text-slate-700 border border-slate-200 transition-colors"
                  >
                    <span>Open Link</span>
                    <ExternalLink className="w-3.5 h-3.5" />
                  </a>
                </div>
              </div>

              {/* Bio & Details */}
              <p className="text-xs text-slate-600 leading-relaxed max-w-3xl">
                Official profile of <strong>Sudarsen Cargo Pvt Ltd</strong> in collaboration with NexLog Autonomous EXIM Exchange.
                Providing single-window electronic Delivery Orders (eDO), automated SOLAS VGM weighbridge verification, and
                customs gate clearance across JNPT Nhava Sheva, Mundra, Tuticorin, Chennai, and overseas transshipment ports.
              </p>

              {/* Quick Stat badges */}
              <div className="flex flex-wrap items-center gap-3 mt-4 pt-3 border-t border-slate-100 text-xs text-slate-500">
                <span className="font-semibold text-slate-800">
                  <strong className="text-sky-600 font-mono">24,890</strong> Followers
                </span>
                <span>•</span>
                <span className="font-semibold text-slate-800">
                  <strong className="text-emerald-600 font-mono">100+</strong> Container Terminals
                </span>
                <span>•</span>
                <span className="font-semibold text-slate-800">
                  <strong className="text-orange-600 font-mono">75K+</strong> BL Documents Cleared
                </span>
                <span>•</span>
                <span className="inline-flex items-center gap-1 text-[11px] font-mono text-slate-500">
                  <Award className="w-3 h-3 text-amber-500" />
                  ISO 9001:2015 & ISO/IEC 27001
                </span>
              </div>
            </div>
          </div>

          {/* TAB CONTENT: LINKEDIN */}
          {activeTab === "linkedin" && (
            <div className="space-y-4">
              <div className="flex items-center justify-between text-xs text-slate-500">
                <span className="font-bold text-slate-700 uppercase tracking-wider text-[11px]">
                  Recent Corporate Announcements
                </span>
                <span>Showing 2 posts • Real-time LinkedIn Sync</span>
              </div>

              {/* Post 1 */}
              <div className="p-4 sm:p-5 rounded-2xl bg-white border border-slate-200 shadow-sm space-y-3">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2.5">
                    <div className="w-9 h-9 rounded-xl bg-blue-700 text-white flex items-center justify-center font-bold text-xs">
                      SC
                    </div>
                    <div>
                      <div className="font-bold text-xs text-slate-900 flex items-center gap-1.5">
                        <span>Sudarsen Cargo Pvt Ltd</span>
                        <span className="text-[10px] text-slate-400 font-normal">• 1d ago</span>
                      </div>
                      <div className="text-[11px] text-slate-500">
                        Multimodal EXIM Automation • Nhava Sheva & Mundra
                      </div>
                    </div>
                  </div>
                  <Linkedin className="w-4 h-4 text-[#0077b5]" />
                </div>

                <p className="text-xs text-slate-700 leading-relaxed">
                  🚢 <strong>Major Milestone:</strong> We are proud to announce our direct automated integration with DP World & APM Terminals for real-time electronic Delivery Orders (eDO) and SOLAS VGM generation.
                  Exporters and freight forwarders using Sudarsen Cargo with NexLog can now clear ocean manifests in under 4 minutes with zero manual counter queues.
                </p>

                <div className="p-3 rounded-xl bg-sky-50 border border-sky-100 flex items-center justify-between text-xs">
                  <div className="flex items-center gap-2">
                    <Sparkles className="w-4 h-4 text-sky-600" />
                    <span className="font-medium text-sky-900">
                      Powered by Google Gemini Autonomous Intake & ICEGATE EDIFACT
                    </span>
                  </div>
                  <span className="font-mono font-bold text-sky-700 text-[11px]">99.8% STP Rate</span>
                </div>

                {/* Interaction Strip */}
                <div className="pt-2 border-t border-slate-100 flex items-center justify-between text-xs text-slate-600">
                  <button
                    onClick={() => toggleLike("li-1")}
                    className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg transition-colors cursor-pointer ${
                      likedPosts["li-1"] ? "text-blue-600 font-bold bg-blue-50" : "hover:bg-slate-100"
                    }`}
                  >
                    <ThumbsUp className={`w-3.5 h-3.5 ${likedPosts["li-1"] ? "fill-blue-600 text-blue-600" : ""}`} />
                    <span>{likeCounts["li-1"]} Likes</span>
                  </button>

                  <button
                    onClick={() => handleShare("Milestone: Direct DP World Integration", "https://linkedin.com/company/sudarsen-cargo")}
                    className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg hover:bg-slate-100 transition-colors cursor-pointer"
                  >
                    <Share2 className="w-3.5 h-3.5" />
                    <span>Share</span>
                  </button>
                </div>
              </div>

              {/* Post 2 */}
              <div className="p-4 sm:p-5 rounded-2xl bg-white border border-slate-200 shadow-sm space-y-3">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2.5">
                    <div className="w-9 h-9 rounded-xl bg-blue-700 text-white flex items-center justify-center font-bold text-xs">
                      SC
                    </div>
                    <div>
                      <div className="font-bold text-xs text-slate-900 flex items-center gap-1.5">
                        <span>Sudarsen Cargo Pvt Ltd</span>
                        <span className="text-[10px] text-slate-400 font-normal">• 3d ago</span>
                      </div>
                      <div className="text-[11px] text-slate-500">Logistics & Supply Chain Operations</div>
                    </div>
                  </div>
                  <Linkedin className="w-4 h-4 text-[#0077b5]" />
                </div>

                <p className="text-xs text-slate-700 leading-relaxed">
                  📦 Over <strong>75,000 TEU container units</strong> processed autonomously in Q3 without a single paper demurrage penalty.
                  Thank you to our partners, customs house agents (CHAs), and shipping lines including Maersk, MSC, CMA CGM, and KMTC Line!
                </p>

                <div className="pt-2 border-t border-slate-100 flex items-center justify-between text-xs text-slate-600">
                  <button
                    onClick={() => toggleLike("li-2")}
                    className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg transition-colors cursor-pointer ${
                      likedPosts["li-2"] ? "text-blue-600 font-bold bg-blue-50" : "hover:bg-slate-100"
                    }`}
                  >
                    <ThumbsUp className={`w-3.5 h-3.5 ${likedPosts["li-2"] ? "fill-blue-600 text-blue-600" : ""}`} />
                    <span>{likeCounts["li-2"]} Likes</span>
                  </button>

                  <button
                    onClick={() => handleShare("75,000 TEU Processed", "https://linkedin.com/company/sudarsen-cargo")}
                    className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg hover:bg-slate-100 transition-colors cursor-pointer"
                  >
                    <Share2 className="w-3.5 h-3.5" />
                    <span>Share</span>
                  </button>
                </div>
              </div>
            </div>
          )}

          {/* TAB CONTENT: TWITTER / X */}
          {activeTab === "twitter" && (
            <div className="space-y-4">
              <div className="flex items-center justify-between text-xs text-slate-500">
                <span className="font-bold text-slate-700 uppercase tracking-wider text-[11px]">
                  Real-time Port Advisories & Alerts
                </span>
                <span className="flex items-center gap-1 text-emerald-600 font-bold">
                  <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse"></span>
                  Live Feed
                </span>
              </div>

              {/* Tweet 1 */}
              <div className="p-4 sm:p-5 rounded-2xl bg-white border border-slate-200 shadow-sm space-y-3">
                <div className="flex items-start justify-between">
                  <div className="flex items-center gap-2.5">
                    <div className="w-9 h-9 rounded-full bg-slate-900 text-white flex items-center justify-center font-black text-xs">
                      𝕏
                    </div>
                    <div>
                      <div className="font-bold text-xs text-slate-900 flex items-center gap-1">
                        <span>Sudarsen Cargo</span>
                        <CheckCircle2 className="w-3.5 h-3.5 text-sky-500" />
                        <span className="text-[11px] text-slate-400 font-normal">@SudarsenCargo • 2h</span>
                      </div>
                      <div className="text-[10px] text-slate-400">Official Port Telematics</div>
                    </div>
                  </div>
                  <Twitter className="w-4 h-4 text-sky-500" />
                </div>

                <p className="text-xs text-slate-800 leading-relaxed font-sans">
                  ⚡ <strong>PORT ADVISORY (JNPT):</strong> Nhava Sheva BMCT Gate 2 automated RFID scanner is active.
                  All Pre-gate Form 13 e-passes submitted via NexLog portal are clearing straight-through within 30 seconds.
                  #NhavaSheva #EXIM #PortLogistics #SudarsenCargo
                </p>

                <div className="flex items-center gap-6 pt-2 border-t border-slate-100 text-xs text-slate-500">
                  <button
                    onClick={() => toggleLike("tw-1")}
                    className={`flex items-center gap-1.5 transition-colors cursor-pointer ${
                      likedPosts["tw-1"] ? "text-rose-600 font-bold" : "hover:text-rose-600"
                    }`}
                  >
                    <Heart className={`w-3.5 h-3.5 ${likedPosts["tw-1"] ? "fill-rose-600 text-rose-600" : ""}`} />
                    <span>{likeCounts["tw-1"]}</span>
                  </button>

                  <button
                    onClick={() => {
                      setLikeCounts((p) => ({ ...p, "tw-1": p["tw-1"] + 1 }));
                      if (onAddToast) onAddToast("info", "Retweeted", "Retweeted to your network.");
                    }}
                    className="flex items-center gap-1.5 hover:text-emerald-600 transition-colors cursor-pointer"
                  >
                    <Repeat2 className="w-3.5 h-3.5" />
                    <span>34 Retweets</span>
                  </button>

                  <button
                    onClick={() => handleShare("JNPT Port Advisory", "https://twitter.com/SudarsenCargo/status/1")}
                    className="flex items-center gap-1.5 hover:text-sky-600 transition-colors cursor-pointer ml-auto"
                  >
                    <Share2 className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>

              {/* Tweet 2 */}
              <div className="p-4 sm:p-5 rounded-2xl bg-white border border-slate-200 shadow-sm space-y-3">
                <div className="flex items-start justify-between">
                  <div className="flex items-center gap-2.5">
                    <div className="w-9 h-9 rounded-full bg-slate-900 text-white flex items-center justify-center font-black text-xs">
                      𝕏
                    </div>
                    <div>
                      <div className="font-bold text-xs text-slate-900 flex items-center gap-1">
                        <span>Sudarsen Cargo</span>
                        <CheckCircle2 className="w-3.5 h-3.5 text-sky-500" />
                        <span className="text-[11px] text-slate-400 font-normal">@SudarsenCargo • 6h</span>
                      </div>
                      <div className="text-[10px] text-slate-400">Vessel Discharge Desk</div>
                    </div>
                  </div>
                  <Twitter className="w-4 h-4 text-sky-500" />
                </div>

                <p className="text-xs text-slate-800 leading-relaxed font-sans">
                  ⚓ <strong>VESSEL BERTHED:</strong> MSC Mediterranean container vessel berthed at Mundra terminal berth #4.
                  e-Invoicing, Delivery Order requests, and customs DPD clearance are now open for all verified consignees.
                </p>

                <div className="flex items-center gap-6 pt-2 border-t border-slate-100 text-xs text-slate-500">
                  <button
                    onClick={() => toggleLike("tw-2")}
                    className={`flex items-center gap-1.5 transition-colors cursor-pointer ${
                      likedPosts["tw-2"] ? "text-rose-600 font-bold" : "hover:text-rose-600"
                    }`}
                  >
                    <Heart className={`w-3.5 h-3.5 ${likedPosts["tw-2"] ? "fill-rose-600 text-rose-600" : ""}`} />
                    <span>{likeCounts["tw-2"]}</span>
                  </button>

                  <button
                    onClick={() => {
                      setLikeCounts((p) => ({ ...p, "tw-2": p["tw-2"] + 1 }));
                      if (onAddToast) onAddToast("info", "Retweeted", "Retweeted to your network.");
                    }}
                    className="flex items-center gap-1.5 hover:text-emerald-600 transition-colors cursor-pointer"
                  >
                    <Repeat2 className="w-3.5 h-3.5" />
                    <span>58 Retweets</span>
                  </button>

                  <button
                    onClick={() => handleShare("Vessel Berthing Alert", "https://twitter.com/SudarsenCargo/status/2")}
                    className="flex items-center gap-1.5 hover:text-sky-600 transition-colors cursor-pointer ml-auto"
                  >
                    <Share2 className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            </div>
          )}

          {/* TAB CONTENT: YOUTUBE */}
          {activeTab === "youtube" && (
            <div className="space-y-4">
              <div className="flex items-center justify-between text-xs text-slate-500">
                <span className="font-bold text-slate-700 uppercase tracking-wider text-[11px]">
                  Featured Maritime Operations Reel
                </span>
                <span className="text-red-600 font-bold flex items-center gap-1">
                  <Radio className="w-3.5 h-3.5 animate-pulse" />
                  14.2K Subscribers • 84 Videos
                </span>
              </div>

              {/* YouTube Video Player Simulation */}
              <div className="rounded-2xl bg-black border border-slate-800 overflow-hidden shadow-lg relative group">
                <div className="aspect-video relative overflow-hidden bg-slate-900 flex items-center justify-center">
                  <img
                    src="/assets/images/cargo_ship.jpg"
                    alt="Maritime Terminal Video"
                    className="w-full h-full object-cover filter brightness-95"
                  />

                  {/* Gradient overlays */}
                  <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-black/40"></div>

                  {/* Operational HUD Overlay */}
                  <div className="absolute top-4 left-4 flex items-center gap-2">
                    <span className="px-2 py-0.5 rounded bg-red-600 text-white text-[10px] font-bold uppercase tracking-wider flex items-center gap-1">
                      <span className="w-1.5 h-1.5 rounded-full bg-white animate-ping"></span>
                      4K Ultra HD
                    </span>
                    <span className="px-2 py-0.5 rounded bg-black/60 text-slate-300 text-[10px] font-mono backdrop-blur-sm">
                      Mundra Terminal Berth 04 • Live Drone View
                    </span>
                  </div>

                  {/* Center Play / Pause Button */}
                  <button
                    onClick={() => setIsPlayingVideo(!isPlayingVideo)}
                    className="w-14 h-14 rounded-full bg-red-600/90 hover:bg-red-600 text-white flex items-center justify-center shadow-xl backdrop-blur-xs transition-transform hover:scale-110 cursor-pointer"
                  >
                    {isPlayingVideo ? (
                      <Pause className="w-6 h-6" />
                    ) : (
                      <Play className="w-6 h-6 ml-0.5" />
                    )}
                  </button>

                  {/* Bottom Controls Bar */}
                  <div className="absolute bottom-0 inset-x-0 p-3 bg-gradient-to-t from-black via-black/80 to-transparent flex items-center justify-between text-white text-xs">
                    <div className="flex items-center gap-3">
                      <button
                        onClick={() => setIsPlayingVideo(!isPlayingVideo)}
                        className="hover:text-red-400 transition-colors cursor-pointer"
                      >
                        {isPlayingVideo ? <Pause className="w-4 h-4" /> : <Play className="w-4 h-4" />}
                      </button>

                      <button
                        onClick={() => setIsMuted(!isMuted)}
                        className="hover:text-red-400 transition-colors cursor-pointer"
                      >
                        {isMuted ? <VolumeX className="w-4 h-4" /> : <Volume2 className="w-4 h-4" />}
                      </button>

                      <div className="text-[11px] font-mono text-slate-300">
                        03:42 / 12:15 • Container Vessel Berthing & Gantry STS Clearance
                      </div>
                    </div>

                    <div className="flex items-center gap-2">
                      <span className="text-[10px] text-slate-400">NexLog Maritime TV</span>
                    </div>
                  </div>
                </div>

                {/* Video Info under Player */}
                <div className="p-4 bg-slate-900 text-white space-y-2">
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                    <div>
                      <h3 className="font-bold text-sm tracking-tight">
                        Inside Sudarsen Cargo: Autonomous Port Gate Operations & Vessel Turnaround
                      </h3>
                      <p className="text-xs text-slate-400">
                        24,510 views • Streamed live from Nhava Sheva & Mundra Container Terminals
                      </p>
                    </div>

                    <div className="flex items-center gap-2">
                      <button
                        onClick={() => toggleLike("yt-1")}
                        className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-bold transition-all cursor-pointer ${
                          likedPosts["yt-1"]
                            ? "bg-red-600 text-white"
                            : "bg-slate-800 text-slate-200 hover:bg-slate-700"
                        }`}
                      >
                        <ThumbsUp className="w-3.5 h-3.5" />
                        <span>{likeCounts["yt-1"]}</span>
                      </button>

                      <button
                        onClick={() => handleShare("Inside Sudarsen Cargo", "https://youtube.com/@SudarsenCargo")}
                        className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-bold bg-slate-800 text-slate-200 hover:bg-slate-700 transition-colors cursor-pointer"
                      >
                        <Share2 className="w-3.5 h-3.5" />
                        <span>Share</span>
                      </button>
                    </div>
                  </div>
                </div>
              </div>

              {/* Playlist items */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div className="p-3 rounded-xl bg-white border border-slate-200 flex gap-3 items-center">
                  <div className="w-20 h-14 rounded-lg bg-slate-200 relative overflow-hidden shrink-0">
                    <img src="/assets/images/cargo_ship.jpg" alt="Video thumb" className="w-full h-full object-cover" />
                    <span className="absolute bottom-1 right-1 px-1 rounded bg-black/70 text-[9px] font-mono text-white">04:18</span>
                  </div>
                  <div>
                    <div className="font-bold text-xs text-slate-800 line-clamp-1">
                      SOLAS VGM Weighbridge Auto Calibration
                    </div>
                    <div className="text-[11px] text-slate-500">8.9K views • 2 weeks ago</div>
                  </div>
                </div>

                <div className="p-3 rounded-xl bg-white border border-slate-200 flex gap-3 items-center">
                  <div className="w-20 h-14 rounded-lg bg-slate-200 relative overflow-hidden shrink-0">
                    <img src="/assets/images/cargo_ship.jpg" alt="Video thumb" className="w-full h-full object-cover" />
                    <span className="absolute bottom-1 right-1 px-1 rounded bg-black/70 text-[9px] font-mono text-white">06:40</span>
                  </div>
                  <div>
                    <div className="font-bold text-xs text-slate-800 line-clamp-1">
                      ICEGATE PCS 1x EDI Integration Guide
                    </div>
                    <div className="text-[11px] text-slate-500">12.1K views • 1 month ago</div>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* TAB CONTENT: INSTAGRAM */}
          {activeTab === "instagram" && (
            <div className="space-y-4">
              <div className="flex items-center justify-between text-xs text-slate-500">
                <span className="font-bold text-slate-700 uppercase tracking-wider text-[11px]">
                  Visual Harbor & Port Gallery
                </span>
                <span>@sudarsencargo_official</span>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                {/* IG Card 1 */}
                <div className="rounded-2xl bg-white border border-slate-200 overflow-hidden shadow-sm space-y-3">
                  <div className="h-48 relative overflow-hidden bg-slate-900">
                    <img
                      src="/assets/images/cargo_ship.jpg"
                      alt="Harbor vessel"
                      className="w-full h-full object-cover hover:scale-105 transition-transform duration-500"
                    />
                    <span className="absolute top-2.5 right-2.5 px-2 py-0.5 rounded-md bg-black/60 text-white text-[10px] font-mono">
                      Nhava Sheva
                    </span>
                  </div>

                  <div className="p-4 pt-1 space-y-2">
                    <div className="flex items-center justify-between text-slate-700">
                      <div className="flex items-center gap-3">
                        <button
                          onClick={() => toggleLike("ig-1")}
                          className={`cursor-pointer transition-colors ${
                            likedPosts["ig-1"] ? "text-rose-600" : "hover:text-rose-600"
                          }`}
                        >
                          <Heart className={`w-5 h-5 ${likedPosts["ig-1"] ? "fill-rose-600 text-rose-600" : ""}`} />
                        </button>
                        <MessageCircle className="w-5 h-5 hover:text-sky-600 cursor-pointer" />
                        <Share2
                          onClick={() => handleShare("Instagram Port Photo", "https://instagram.com/sudarsencargo")}
                          className="w-5 h-5 hover:text-emerald-600 cursor-pointer"
                        />
                      </div>
                      <Bookmark className="w-4 h-4 text-slate-400 hover:text-slate-700 cursor-pointer" />
                    </div>

                    <div className="text-xs font-bold text-slate-900">
                      {likeCounts["ig-1"]} likes
                    </div>
                    <p className="text-xs text-slate-600">
                      <strong>sudarsencargo_official</strong> Golden hour at the maritime terminal. Another 2,400 TEU safely secured and dispatched through our automated gate. 🌅⚓ #shipping #logistics #maritime
                    </p>
                  </div>
                </div>

                {/* IG Card 2 */}
                <div className="rounded-2xl bg-white border border-slate-200 overflow-hidden shadow-sm space-y-3">
                  <div className="h-48 relative overflow-hidden bg-slate-900">
                    <img
                      src="/assets/images/cargo_ship.jpg"
                      alt="Container loading"
                      className="w-full h-full object-cover hover:scale-105 transition-transform duration-500"
                    />
                    <span className="absolute top-2.5 right-2.5 px-2 py-0.5 rounded-md bg-black/60 text-white text-[10px] font-mono">
                      Mundra Port
                    </span>
                  </div>

                  <div className="p-4 pt-1 space-y-2">
                    <div className="flex items-center justify-between text-slate-700">
                      <div className="flex items-center gap-3">
                        <button
                          onClick={() => toggleLike("ig-2")}
                          className={`cursor-pointer transition-colors ${
                            likedPosts["ig-2"] ? "text-rose-600" : "hover:text-rose-600"
                          }`}
                        >
                          <Heart className={`w-5 h-5 ${likedPosts["ig-2"] ? "fill-rose-600 text-rose-600" : ""}`} />
                        </button>
                        <MessageCircle className="w-5 h-5 hover:text-sky-600 cursor-pointer" />
                        <Share2
                          onClick={() => handleShare("Mundra Cranes", "https://instagram.com/sudarsencargo")}
                          className="w-5 h-5 hover:text-emerald-600 cursor-pointer"
                        />
                      </div>
                      <Bookmark className="w-4 h-4 text-slate-400 hover:text-slate-700 cursor-pointer" />
                    </div>

                    <div className="text-xs font-bold text-slate-900">
                      {likeCounts["ig-2"]} likes
                    </div>
                    <p className="text-xs text-slate-600">
                      <strong>sudarsencargo_official</strong> Precision engineering and zero-paper clearances in full motion with NexLog AI. 🚢📦
                    </p>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* TAB CONTENT: FACEBOOK */}
          {activeTab === "facebook" && (
            <div className="space-y-4">
              <div className="flex items-center justify-between text-xs text-slate-500">
                <span className="font-bold text-slate-700 uppercase tracking-wider text-[11px]">
                  Community & Trade Exporters Forum
                </span>
                <span>Sudarsen Cargo Pvt Ltd Official Page</span>
              </div>

              <div className="p-5 rounded-2xl bg-white border border-slate-200 shadow-sm space-y-4">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-full bg-[#1877f2] text-white flex items-center justify-center font-bold text-sm">
                    f
                  </div>
                  <div>
                    <div className="font-bold text-xs text-slate-900">Sudarsen Cargo Pvt Ltd</div>
                    <div className="text-[11px] text-slate-400">Community • 18,200 Members</div>
                  </div>
                </div>

                <p className="text-xs text-slate-700 leading-relaxed">
                  Welcome to our global EXIM community! Have questions about container gate-in cutoffs, customs clearance, eDO releases, or SOLAS VGM certificates?
                  Our 24/7 port operational desk and automated NexLog assistants are ready to assist exporters and clearing brokers.
                </p>

                <div className="p-4 rounded-xl bg-blue-50/70 border border-blue-200/60 flex items-center justify-between text-xs">
                  <div>
                    <div className="font-bold text-blue-900">24/7 EXIM Helpdesk Hotline</div>
                    <div className="text-[11px] text-blue-700">+91 8828 822 244 • support@nexlogglobal.com</div>
                  </div>
                  <span className="px-2.5 py-1 rounded bg-blue-600 text-white font-bold text-[10px]">
                    Always Online
                  </span>
                </div>

                <div className="pt-2 border-t border-slate-100 flex items-center justify-between text-xs text-slate-600">
                  <button
                    onClick={() => toggleLike("fb-1")}
                    className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg transition-colors cursor-pointer ${
                      likedPosts["fb-1"] ? "text-[#1877f2] font-bold bg-blue-50" : "hover:bg-slate-100"
                    }`}
                  >
                    <ThumbsUp className={`w-3.5 h-3.5 ${likedPosts["fb-1"] ? "fill-[#1877f2] text-[#1877f2]" : ""}`} />
                    <span>{likeCounts["fb-1"]} Likes</span>
                  </button>

                  <button
                    onClick={() => handleShare("Sudarsen Cargo Community", "https://facebook.com/SudarsenCargo")}
                    className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg hover:bg-slate-100 transition-colors cursor-pointer"
                  >
                    <Share2 className="w-3.5 h-3.5" />
                    <span>Share to Group</span>
                  </button>
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Modal Footer */}
        <div className="px-5 py-3 bg-white border-t border-slate-200 flex flex-col sm:flex-row items-center justify-between gap-3 text-xs text-slate-500">
          <div className="flex items-center gap-2">
            <span className="font-semibold text-slate-700">Sudarsen Cargo Pvt Ltd</span>
            <span>•</span>
            <span className="text-[11px]">Authorized NexLog Marine Network</span>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={() => handleShare("Sudarsen Cargo Official Profiles", currentPlatformInfo.url)}
              className="px-3 py-1.5 rounded-lg bg-slate-100 hover:bg-slate-200 text-slate-700 font-semibold transition-colors flex items-center gap-1 cursor-pointer"
            >
              {copiedLink ? <Check className="w-3.5 h-3.5 text-emerald-600" /> : <Share2 className="w-3.5 h-3.5" />}
              <span>{copiedLink ? "Link Copied!" : "Share Profile"}</span>
            </button>

            <button
              onClick={onClose}
              className="px-4 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-900 text-white font-bold transition-colors cursor-pointer"
            >
              Done
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
