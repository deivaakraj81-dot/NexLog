import React, { useState } from "react";
import { Code2, Copy, Check, Terminal, Cpu, Database, FileJson, Sparkles } from "lucide-react";
import { ShippingAuditResult } from "../types";

interface JsonViewerProps {
  auditResult: ShippingAuditResult | null;
}

export const JsonViewer: React.FC<JsonViewerProps> = ({ auditResult }) => {
  const [copied, setCopied] = useState<boolean>(false);
  const [activeFormat, setActiveFormat] = useState<"GEMINI_JSON" | "NEXLOG_EDIFACT" | "PCS_XML">("GEMINI_JSON");

  const jsonString = auditResult
    ? JSON.stringify(auditResult, null, 2)
    : JSON.stringify(
        {
          notice: "No recent document scan selected.",
          action: "Please scan or audit a document in the Document Scanner tab to view real-time raw structured JSON output.",
          sampleFormat: {
            model: "gemini-3.8-flash",
            schema: "Type.OBJECT with strict typing",
            documentClassification: "Bill of Lading",
            confidenceScore: 98.4,
          },
        },
        null,
        2
      );

  // Generate synthetic NexLog EDIFACT CUSCAR / IFTMIN payload
  const edifactPayload = `UNA:+.? '
UNB+UNOC:3+NEXLOG_GATEWAY:ZZ+JNPT_TOS:ZZ+261102:0735+000941'
UNH+1+CUSCAR:D:00B:UN:PCS1X'
BGM+85+${auditResult?.metadata?.documentNumber || "EXIM-2026-98124"}+9'
RFF+BM:${auditResult?.metadata?.documentNumber || "MSCU-NSA-8921044"}'
NAD+CZ+${auditResult?.metadata?.consigneeName?.slice(0, 30) || "ROTTERDAM LOGISTICS"}'
NAD+CN+${auditResult?.metadata?.shipperName?.slice(0, 30) || "BHARAT AGRO EXIM"}'
TDT+20+${auditResult?.metadata?.voyageNumber || "2611W"}+1++MSC:::${auditResult?.metadata?.vesselName || "MSC OSCAR"}'
LOC+5+${auditResult?.metadata?.portOfLoading || "INNSA"}'
LOC+11+${auditResult?.metadata?.portOfDischarge || "NLRTM"}'
EQD+CN+${auditResult?.metadata?.containerId || "MSKU7291840"}+45G1:102:5++2+5'
MEA+WT+VGM+KGM:${auditResult?.metadata?.grossWeightKg || 28450}'
SEL+${auditResult?.metadata?.sealNumber || "SEAL-IN-98421"}+SH'
UNT+14+1'
UNZ+1+000941'`;

  // Generate synthetic Port Community System XML
  const pcsXmlPayload = `<?xml version="1.0" encoding="UTF-8"?>
<PCS1x_ManifestDeclaration version="4.2">
  <Header>
    <MessageId>PCS-GATE-${Date.now()}</MessageId>
    <Timestamp>${auditResult?.timestamp || new Date().toISOString()}</Timestamp>
    <Sender>NEXLOG_AI_GATEWAY</Sender>
    <Recipient>JNPT_PORT_TOS</Recipient>
    <EngineSource>Google Gemini 3.8 Flash</EngineSource>
  </Header>
  <DocumentDetails type="${auditResult?.documentClassification || "Bill of Lading"}">
    <ReferenceNumber>${auditResult?.metadata?.documentNumber || "DOC-9821"}</ReferenceNumber>
    <ContainerId>${auditResult?.metadata?.containerId || "MSKU7291840"}</ContainerId>
    <Vessel>${auditResult?.metadata?.vesselName || "MSC OSCAR"}</Vessel>
    <Voyage>${auditResult?.metadata?.voyageNumber || "2611W"}</Voyage>
    <GrossWeight unit="KG">${auditResult?.metadata?.grossWeightKg || 28450}</GrossWeight>
    <SealNumber verified="${auditResult?.riskAssessment?.riskLevel === "LOW"}">${auditResult?.metadata?.sealNumber || "SEAL-IN-98421"}</SealNumber>
  </DocumentDetails>
  <AuditVerification>
    <RiskScore>${auditResult?.riskAssessment?.riskScore ?? 12}</RiskScore>
    <RiskLevel>${auditResult?.riskAssessment?.riskLevel || "LOW"}</RiskLevel>
    <Recommendation>${auditResult?.riskAssessment?.recommendedAction || "Approve"}</Recommendation>
    <SolasComplianceStatus>PASS</SolasComplianceStatus>
  </AuditVerification>
</PCS1x_ManifestDeclaration>`;

  const activeContent =
    activeFormat === "GEMINI_JSON"
      ? jsonString
      : activeFormat === "NEXLOG_EDIFACT"
      ? edifactPayload
      : pcsXmlPayload;

  const handleCopy = () => {
    navigator.clipboard.writeText(activeContent);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="space-y-6">
      {/* Top Banner */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 p-5 rounded-2xl bg-gradient-to-r from-slate-900 via-slate-900 to-indigo-950/40 border border-slate-800">
        <div>
          <div className="flex items-center gap-2">
            <span className="px-2.5 py-0.5 rounded-full text-xs font-bold uppercase tracking-wider bg-purple-500/20 text-purple-300 border border-purple-500/30 flex items-center gap-1">
              <Sparkles className="w-3.5 h-3.5" />
              Expo Live Technical Depth
            </span>
            <h2 className="text-xl font-bold text-white tracking-tight">
              Raw Structured Output & EDI Payload Inspector
            </h2>
          </div>
          <p className="text-xs text-slate-400 mt-1">
            Real-time payload inspection for judges: inspect the schema response returned by Google Gemini (gemini-3.8-flash) and subsequent EDIFACT / PCS 1x translations.
          </p>
        </div>

        {/* Copy Button */}
        <button
          onClick={handleCopy}
          className="flex items-center gap-2 px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-white font-semibold text-xs border border-slate-700 shadow-sm transition-all"
        >
          {copied ? (
            <>
              <Check className="w-4 h-4 text-emerald-400" />
              <span className="text-emerald-400">Copied to Clipboard!</span>
            </>
          ) : (
            <>
              <Copy className="w-4 h-4 text-slate-300" />
              <span>Copy Payload</span>
            </>
          )}
        </button>
      </div>

      {/* Format Selector Tabs */}
      <div className="flex items-center gap-2 border-b border-slate-800 pb-2">
        <button
          onClick={() => setActiveFormat("GEMINI_JSON")}
          className={`flex items-center gap-2 px-3.5 py-2 rounded-xl text-xs font-semibold transition-all ${
            activeFormat === "GEMINI_JSON"
              ? "bg-blue-600 text-white shadow-md shadow-blue-600/30"
              : "text-slate-400 hover:text-slate-200 hover:bg-slate-800"
          }`}
        >
          <Cpu className="w-4 h-4" />
          <span>Raw Gemini 3.8 JSON (responseSchema)</span>
        </button>

        <button
          onClick={() => setActiveFormat("NEXLOG_EDIFACT")}
          className={`flex items-center gap-2 px-3.5 py-2 rounded-xl text-xs font-semibold transition-all ${
            activeFormat === "NEXLOG_EDIFACT"
              ? "bg-blue-600 text-white shadow-md shadow-blue-600/30"
              : "text-slate-400 hover:text-slate-200 hover:bg-slate-800"
          }`}
        >
          <Database className="w-4 h-4" />
          <span>NexLog EDIFACT (CUSCAR / IFTMIN)</span>
        </button>

        <button
          onClick={() => setActiveFormat("PCS_XML")}
          className={`flex items-center gap-2 px-3.5 py-2 rounded-xl text-xs font-semibold transition-all ${
            activeFormat === "PCS_XML"
              ? "bg-blue-600 text-white shadow-md shadow-blue-600/30"
              : "text-slate-400 hover:text-slate-200 hover:bg-slate-800"
          }`}
        >
          <FileJson className="w-4 h-4" />
          <span>PCS 1x Port Gate XML</span>
        </button>
      </div>

      {/* Code Display Card */}
      <div className="rounded-2xl bg-slate-950 border border-slate-800 shadow-2xl overflow-hidden">
        <div className="px-4 py-3 bg-slate-900/90 border-b border-slate-800 flex items-center justify-between text-xs">
          <div className="flex items-center gap-2 text-slate-300 font-mono">
            <Terminal className="w-4 h-4 text-blue-400" />
            <span>
              {activeFormat === "GEMINI_JSON"
                ? "POST /api/gemini/audit-document -> response.text"
                : activeFormat === "NEXLOG_EDIFACT"
                ? "EDIFACT UN/EDIFACT CUSCAR Manifest"
                : "PCS 1x Port Community System Gateway"}
            </span>
          </div>

          <div className="flex items-center gap-3 text-[11px] text-slate-400 font-mono">
            <span>Encoding: UTF-8</span>
            <span>•</span>
            <span className="text-emerald-400">Strict Schema Validated</span>
          </div>
        </div>

        <div className="p-4 overflow-x-auto max-h-[600px] overflow-y-auto">
          <pre className="text-xs font-mono text-emerald-300/90 leading-relaxed whitespace-pre font-normal selection:bg-blue-600 selection:text-white">
            {activeContent}
          </pre>
        </div>
      </div>
    </div>
  );
};
