import React, { useState } from "react";
import {
  X,
  User,
  Building2,
  Mail,
  Phone,
  MessageSquare,
  Bell,
  Download,
  Share2,
  ExternalLink,
  CheckCircle2,
  Clock,
  ShieldCheck,
  FileText,
  Ship,
  Sparkles,
  Layers,
  Send,
  Edit2,
  Check,
  Smartphone,
} from "lucide-react";
import { ShipmentNotification, UserNotificationPreferences } from "../types/notifications";
import {
  downloadArrivalNoticeAttachment,
  downloadShipmentManifestCSV,
  triggerWhatsAppMessage,
} from "../utils/shipmentAttachmentGenerator";

interface UserProfileNotificationDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  userName: string;
  companyName: string;
  notifications: ShipmentNotification[];
  onMarkAsRead: (id: string) => void;
  onMarkAllAsRead: () => void;
  onOpenTriggerModal: () => void;
  userPreferences: UserNotificationPreferences;
  onUpdatePreferences: (prefs: Partial<UserNotificationPreferences>) => void;
  onAddToast: (type: "success" | "warning" | "error" | "info", title: string, message: string) => void;
}

export const UserProfileNotificationDrawer: React.FC<UserProfileNotificationDrawerProps> = ({
  isOpen,
  onClose,
  userName,
  companyName,
  notifications,
  onMarkAsRead,
  onMarkAllAsRead,
  onOpenTriggerModal,
  userPreferences,
  onUpdatePreferences,
  onAddToast,
}) => {
  const [activeTab, setActiveTab] = useState<"feed" | "settings">("feed");
  const [isEditingContact, setIsEditingContact] = useState(false);
  const [emailInput, setEmailInput] = useState(userPreferences.email);
  const [phoneInput, setPhoneInput] = useState(userPreferences.whatsappPhone);

  if (!isOpen) return null;

  const unreadCount = notifications.filter((n) => !n.read).length;

  const handleSaveContact = () => {
    onUpdatePreferences({
      email: emailInput.trim(),
      whatsappPhone: phoneInput.trim(),
    });
    setIsEditingContact(false);
    onAddToast(
      "success",
      "Contact Details Updated",
      `Shipment notifications will now be dispatched to ${emailInput} and WhatsApp ${phoneInput}.`
    );
  };

  const handleDownloadAttachment = (notif: ShipmentNotification) => {
    downloadArrivalNoticeAttachment(notif);
    onAddToast(
      "success",
      "Attachment File Downloaded",
      `Official Arrival Notice & Gate Pass for container ${notif.containerNo} downloaded for physical filing.`
    );
  };

  const handleDownloadCsv = (notif: ShipmentNotification) => {
    downloadShipmentManifestCSV(notif);
    onAddToast(
      "success",
      "Manifest CSV Downloaded",
      `EXIM manifest for ${notif.containerNo} exported.`
    );
  };

  const handleShareToWhatsApp = (notif: ShipmentNotification) => {
    const waUrl = triggerWhatsAppMessage(notif, userPreferences.whatsappPhone);
    // Copy link or notify
    onAddToast(
      "success",
      "WhatsApp Dispatch Prepared",
      `Shipment arrival milestone & attachment link dispatched to ${userPreferences.whatsappPhone}.`
    );
  };

  const handleResendEmail = (notif: ShipmentNotification) => {
    onAddToast(
      "success",
      "Email Dispatched",
      `Arrival Notice & Customs OOC Dossier sent to ${userPreferences.email} for container ${notif.containerNo}.`
    );
  };

  return (
    <div className="fixed inset-0 z-50 flex justify-end bg-black/60 backdrop-blur-2xs animate-in fade-in duration-200 select-none">
      <div className="bg-white w-full max-w-xl h-full shadow-2xl flex flex-col border-l border-slate-300 animate-in slide-in-from-right duration-300">
        {/* Top Header */}
        <div className="bg-[#0f172a] text-white p-4 sm:px-6 flex items-center justify-between border-b border-slate-800">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-[#0098db]/20 border border-[#0098db]/40 flex items-center justify-center text-[#0098db]">
              <User className="w-5 h-5 text-white" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="font-bold text-sm tracking-tight text-white">{userName}</span>
                <span className="px-2 py-0.2 rounded-full bg-sky-500/20 text-sky-300 border border-sky-400/30 text-[10px] font-mono font-bold">
                  PRN 100653
                </span>
              </div>
              <div className="text-xs text-slate-400 truncate max-w-[260px]">
                {companyName} • EXIM Logistics
              </div>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800 transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Profile Identity & Notification Channels Card */}
        <div className="bg-slate-100 p-4 border-b border-slate-200 space-y-3">
          <div className="flex items-center justify-between">
            <span className="text-[11px] font-bold text-slate-600 uppercase tracking-wider flex items-center gap-1.5">
              <ShieldCheck className="w-3.5 h-3.5 text-emerald-600" />
              <span>Registered Notification Channels</span>
            </span>

            <button
              onClick={() => setIsEditingContact(!isEditingContact)}
              className="text-xs text-[#0098db] hover:text-[#0086c2] font-bold flex items-center gap-1 cursor-pointer"
            >
              <Edit2 className="w-3 h-3" />
              <span>{isEditingContact ? "Cancel" : "Edit Channels"}</span>
            </button>
          </div>

          {isEditingContact ? (
            <div className="bg-white p-3 rounded-xl border border-slate-300 space-y-2 text-xs">
              <div>
                <label className="block text-[10px] font-bold text-slate-500 uppercase">
                  Recipient Mail ID:
                </label>
                <input
                  type="email"
                  value={emailInput}
                  onChange={(e) => setEmailInput(e.target.value)}
                  className="w-full px-2.5 py-1.5 border border-slate-300 rounded font-mono text-slate-900 mt-0.5 focus:border-[#0098db] focus:outline-hidden"
                />
              </div>

              <div>
                <label className="block text-[10px] font-bold text-slate-500 uppercase">
                  Recipient WhatsApp Mobile Number:
                </label>
                <input
                  type="tel"
                  value={phoneInput}
                  onChange={(e) => setPhoneInput(e.target.value)}
                  className="w-full px-2.5 py-1.5 border border-slate-300 rounded font-mono text-slate-900 mt-0.5 focus:border-emerald-600 focus:outline-hidden"
                />
              </div>

              <div className="pt-1 flex justify-end">
                <button
                  type="button"
                  onClick={handleSaveContact}
                  className="px-3 py-1 bg-emerald-600 hover:bg-emerald-700 text-white font-bold rounded text-xs flex items-center gap-1 cursor-pointer shadow-xs"
                >
                  <Check className="w-3 h-3" />
                  <span>Save Channel Updates</span>
                </button>
              </div>
            </div>
          ) : (
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs">
              <div className="bg-white p-2.5 rounded-lg border border-slate-200 flex items-center gap-2">
                <div className="p-1.5 rounded-md bg-sky-100 text-sky-700">
                  <Mail className="w-3.5 h-3.5" />
                </div>
                <div className="min-w-0 flex-1">
                  <div className="text-[10px] text-slate-400 uppercase font-semibold">Registered Mail ID</div>
                  <div className="font-mono font-bold text-slate-800 text-[11px] truncate">
                    {userPreferences.email}
                  </div>
                </div>
              </div>

              <div className="bg-white p-2.5 rounded-lg border border-slate-200 flex items-center gap-2">
                <div className="p-1.5 rounded-md bg-emerald-100 text-emerald-700">
                  <Smartphone className="w-3.5 h-3.5" />
                </div>
                <div className="min-w-0 flex-1">
                  <div className="text-[10px] text-slate-400 uppercase font-semibold">WhatsApp Alerts</div>
                  <div className="font-mono font-bold text-slate-800 text-[11px] truncate">
                    {userPreferences.whatsappPhone}
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* Quick status indicators */}
          <div className="flex flex-wrap items-center gap-2 text-[10px] font-bold">
            <span className="px-2 py-0.5 rounded-full bg-emerald-100 text-emerald-800 border border-emerald-300">
              ● Email Dispatch Active
            </span>
            <span className="px-2 py-0.5 rounded-full bg-emerald-100 text-emerald-800 border border-emerald-300">
              ● WhatsApp Direct Active
            </span>
            <span className="px-2 py-0.5 rounded-full bg-sky-100 text-sky-800 border border-sky-300">
              ● PCS 1x Webhook Connected
            </span>
          </div>
        </div>

        {/* Tab Navigation */}
        <div className="flex items-center border-b border-slate-200 bg-white px-4 text-xs font-bold">
          <button
            onClick={() => setActiveTab("feed")}
            className={`py-3 px-3 border-b-2 transition-colors cursor-pointer flex items-center gap-2 ${
              activeTab === "feed"
                ? "border-[#0098db] text-[#0098db]"
                : "border-transparent text-slate-500 hover:text-slate-800"
            }`}
          >
            <Bell className="w-4 h-4" />
            <span>Shipment Arrival Feed</span>
            {unreadCount > 0 && (
              <span className="px-1.5 py-0.2 rounded-full bg-rose-600 text-white text-[10px] font-mono font-black">
                {unreadCount}
              </span>
            )}
          </button>

          <button
            onClick={() => setActiveTab("settings")}
            className={`py-3 px-3 border-b-2 transition-colors cursor-pointer flex items-center gap-2 ${
              activeTab === "settings"
                ? "border-[#0098db] text-[#0098db]"
                : "border-transparent text-slate-500 hover:text-slate-800"
            }`}
          >
            <Layers className="w-4 h-4" />
            <span>Alert Preferences</span>
          </button>

          <div className="ml-auto flex items-center gap-2">
            <button
              onClick={onOpenTriggerModal}
              className="px-2.5 py-1 rounded bg-[#0098db] hover:bg-[#0086c2] text-white text-[11px] font-bold shadow-xs cursor-pointer flex items-center gap-1 transition-all"
            >
              <Send className="w-3 h-3" />
              <span>Send New Alert</span>
            </button>
          </div>
        </div>

        {/* Main Content Area */}
        <div className="flex-1 overflow-y-auto p-4 sm:p-5 space-y-4">
          {activeTab === "feed" && (
            <div className="space-y-3">
              <div className="flex items-center justify-between text-xs text-slate-500 pb-1">
                <span>Recent Container Arrival Milestones ({notifications.length})</span>
                {unreadCount > 0 && (
                  <button
                    onClick={onMarkAllAsRead}
                    className="text-[#0098db] hover:underline font-bold text-[11px] cursor-pointer"
                  >
                    Mark all as read
                  </button>
                )}
              </div>

              {notifications.length === 0 ? (
                <div className="text-center py-12 text-slate-400">
                  <Bell className="w-10 h-10 mx-auto text-slate-300 mb-2" />
                  <p className="text-xs font-semibold">No shipment arrival alerts yet.</p>
                  <p className="text-[11px] text-slate-400 mt-1">
                    Track any container or click "Send New Alert" to dispatch notifications.
                  </p>
                </div>
              ) : (
                notifications.map((notif) => (
                  <div
                    key={notif.id}
                    className={`p-4 rounded-xl border transition-all ${
                      notif.read
                        ? "bg-white border-slate-200"
                        : "bg-sky-50/50 border-sky-300 ring-1 ring-sky-200"
                    }`}
                  >
                    {/* Notification Header */}
                    <div className="flex items-start justify-between gap-2">
                      <div className="space-y-0.5">
                        <div className="flex items-center gap-2">
                          <span className="font-mono font-black text-slate-900 text-sm">
                            {notif.containerNo}
                          </span>
                          <span className="px-2 py-0.2 rounded bg-slate-100 text-slate-700 font-mono text-[10px] font-bold">
                            BL: {notif.blNumber}
                          </span>
                          {!notif.read && (
                            <span className="w-2 h-2 rounded-full bg-[#0098db] animate-pulse" />
                          )}
                        </div>
                        <div className="text-xs text-slate-600 font-medium">
                          {notif.vesselName} • {notif.port}
                        </div>
                      </div>

                      <span className="px-2 py-0.5 rounded-full bg-emerald-100 text-emerald-800 text-[10px] font-bold font-mono">
                        {notif.status.replace("_", " ")}
                      </span>
                    </div>

                    {/* Milestone & Summary */}
                    <div className="mt-2.5 p-2.5 rounded-lg bg-slate-50 border border-slate-200 text-xs">
                      <div className="font-bold text-slate-800 flex items-center gap-1.5">
                        <Ship className="w-3.5 h-3.5 text-[#0098db]" />
                        <span>{notif.milestone}</span>
                      </div>
                      <p className="text-slate-600 mt-1 text-[11px] leading-relaxed">{notif.summary}</p>
                    </div>

                    {/* Dispatched Channels info */}
                    <div className="mt-2.5 flex flex-wrap items-center justify-between text-[10px] text-slate-500 gap-2 border-t border-slate-100 pt-2">
                      <div className="flex items-center gap-2 font-mono">
                        <Clock className="w-3 h-3 text-slate-400" />
                        <span>{notif.timestamp}</span>
                      </div>

                      <div className="flex items-center gap-1.5">
                        <span className="text-slate-400">Channels:</span>
                        {notif.channelsSent.includes("EMAIL") && (
                          <span className="px-1.5 py-0.2 rounded bg-sky-100 text-sky-800 font-bold">
                            Email
                          </span>
                        )}
                        {notif.channelsSent.includes("WHATSAPP") && (
                          <span className="px-1.5 py-0.2 rounded bg-emerald-100 text-emerald-800 font-bold">
                            WhatsApp
                          </span>
                        )}
                        {notif.channelsSent.includes("PROFILE") && (
                          <span className="px-1.5 py-0.2 rounded bg-amber-100 text-amber-800 font-bold">
                            Profile
                          </span>
                        )}
                      </div>
                    </div>

                    {/* Actions Toolbar: Download Attachment, WhatsApp, Email */}
                    <div className="mt-3 pt-2.5 border-t border-slate-200/80 flex flex-wrap items-center gap-2">
                      <button
                        type="button"
                        onClick={() => {
                          handleDownloadAttachment(notif);
                          if (!notif.read) onMarkAsRead(notif.id);
                        }}
                        className="px-3 py-1.5 rounded-lg bg-[#0098db] hover:bg-[#0086c2] text-white font-bold text-xs flex items-center gap-1.5 cursor-pointer shadow-xs transition-all hover:scale-102"
                        title="Download official PDF Arrival Notice and Boom Barrier Gate Pass"
                      >
                        <Download className="w-3.5 h-3.5" />
                        <span>Download Attachment (PDF)</span>
                      </button>

                      <button
                        type="button"
                        onClick={() => handleDownloadCsv(notif)}
                        className="px-2.5 py-1.5 rounded-lg bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold text-xs flex items-center gap-1 cursor-pointer transition-colors"
                        title="Download Manifest CSV data"
                      >
                        <FileText className="w-3.5 h-3.5 text-slate-500" />
                        <span>CSV Manifest</span>
                      </button>

                      <button
                        type="button"
                        onClick={() => handleShareToWhatsApp(notif)}
                        className="px-2.5 py-1.5 rounded-lg bg-emerald-50 hover:bg-emerald-100 text-emerald-800 border border-emerald-300 font-bold text-xs flex items-center gap-1 cursor-pointer transition-colors"
                        title="Send arrival notification to WhatsApp with file link"
                      >
                        <MessageSquare className="w-3.5 h-3.5 text-emerald-600" />
                        <span>WhatsApp Alert</span>
                      </button>

                      <button
                        type="button"
                        onClick={() => handleResendEmail(notif)}
                        className="px-2.5 py-1.5 rounded-lg bg-sky-50 hover:bg-sky-100 text-sky-800 border border-sky-300 font-bold text-xs flex items-center gap-1 cursor-pointer transition-colors"
                        title="Resend notice to mail ID"
                      >
                        <Mail className="w-3.5 h-3.5 text-sky-600" />
                        <span>Resend Email</span>
                      </button>
                    </div>
                  </div>
                ))
              )}
            </div>
          )}

          {activeTab === "settings" && (
            <div className="space-y-4 text-xs">
              <div className="bg-slate-50 p-4 rounded-xl border border-slate-200 space-y-3">
                <h4 className="font-bold text-slate-800 uppercase tracking-wider text-[11px]">
                  Multi-Channel Notification Rules
                </h4>

                <label className="flex items-center justify-between p-2.5 rounded-lg bg-white border border-slate-200 cursor-pointer">
                  <div>
                    <strong className="block text-slate-900">Email Notifications (Mail ID)</strong>
                    <span className="text-[11px] text-slate-500">
                      Send official Arrival Notices with PDF dossier to {userPreferences.email}
                    </span>
                  </div>
                  <input
                    type="checkbox"
                    checked={userPreferences.emailEnabled}
                    onChange={(e) => onUpdatePreferences({ emailEnabled: e.target.checked })}
                    className="w-4 h-4 text-[#0098db] rounded accent-[#0098db]"
                  />
                </label>

                <label className="flex items-center justify-between p-2.5 rounded-lg bg-white border border-slate-200 cursor-pointer">
                  <div>
                    <strong className="block text-slate-900">WhatsApp Dispatch (With File / Barcode)</strong>
                    <span className="text-[11px] text-slate-500">
                      Send instant milestone pings with direct attachment download link to {userPreferences.whatsappPhone}
                    </span>
                  </div>
                  <input
                    type="checkbox"
                    checked={userPreferences.whatsappEnabled}
                    onChange={(e) => onUpdatePreferences({ whatsappEnabled: e.target.checked })}
                    className="w-4 h-4 text-emerald-600 rounded accent-emerald-600"
                  />
                </label>

                <label className="flex items-center justify-between p-2.5 rounded-lg bg-white border border-slate-200 cursor-pointer">
                  <div>
                    <strong className="block text-slate-900">In-App Profile Feed</strong>
                    <span className="text-[11px] text-slate-500">
                      Record every arrival event in John Lanny’s corporate portal profile
                    </span>
                  </div>
                  <input
                    type="checkbox"
                    checked={userPreferences.profileFeedEnabled}
                    onChange={(e) => onUpdatePreferences({ profileFeedEnabled: e.target.checked })}
                    className="w-4 h-4 text-amber-600 rounded accent-amber-600"
                  />
                </label>
              </div>

              <div className="bg-slate-50 p-4 rounded-xl border border-slate-200 space-y-3">
                <h4 className="font-bold text-slate-800 uppercase tracking-wider text-[11px]">
                  Default Document Attachment Format
                </h4>

                <div className="space-y-2">
                  <label className="flex items-center gap-2.5 p-2 rounded-lg bg-white border border-slate-200 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={userPreferences.attachPdfDossier}
                      onChange={(e) => onUpdatePreferences({ attachPdfDossier: e.target.checked })}
                      className="rounded text-[#0098db]"
                    />
                    <div>
                      <strong className="text-slate-800">Attach Official PDF Arrival Notice Dossier</strong>
                      <div className="text-[10px] text-slate-500">
                        Includes Port Gate Pass barcode, ICEGATE OOC stamp, and carrier verification.
                      </div>
                    </div>
                  </label>

                  <label className="flex items-center gap-2.5 p-2 rounded-lg bg-white border border-slate-200 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={userPreferences.attachCsvManifest}
                      onChange={(e) => onUpdatePreferences({ attachCsvManifest: e.target.checked })}
                      className="rounded text-[#0098db]"
                    />
                    <div>
                      <strong className="text-slate-800">Attach Structured EXIM Manifest (.csv)</strong>
                      <div className="text-[10px] text-slate-500">
                        Tabular weighbridge and container telematics for corporate ERP.
                      </div>
                    </div>
                  </label>
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="p-3.5 bg-slate-100 border-t border-slate-200 flex items-center justify-between text-xs text-slate-500">
          <span>Sudarsen Cargo Pvt Ltd • PRN 100653</span>
          <button
            onClick={onClose}
            className="px-4 py-1.5 bg-white border border-slate-300 hover:bg-slate-50 text-slate-700 font-bold rounded-lg cursor-pointer transition-colors"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
};
