import React, { useState } from "react";
import {
  Search,
  Plus,
  FileText,
  Upload,
  Download,
  Copy,
  Trash2,
  CheckCircle2,
  AlertTriangle,
  ArrowLeft,
  Ship,
  Sparkles,
  Printer,
  ChevronDown,
  Layers,
  Info,
  Calendar,
  Send,
  ExternalLink,
  Truck,
  ShieldAlert,
} from "lucide-react";
import { copyTableToClipboard, downloadTableAsCSV, openPrintableTableReport } from "../utils/tableExport";

export interface HblRecord {
  id: string;
  requestedDateTime: string;
  linerName: string;
  mblNo: string;
  hblNo: string;
  vesselVoyage: string;
  consignor: string;
  consignee: string;
  totalPkgs: number;
  grossWeightKg: number;
  pod: string;
  status: "Draft" | "Submitted" | "CSN Generated" | "Verified & Dispatched";
}

const INITIAL_HBL_DATA: HblRecord[] = [
  {
    id: "hbl-1",
    requestedDateTime: "2026-11-03 14:22",
    linerName: "KMTC LINE",
    mblNo: "KMTCXGG3096868",
    hblNo: "HBL-BOM-2026-9021",
    vesselVoyage: "TIM S 043E",
    consignor: "ZHEJIANG SINOCHEM TEXTILE CO.",
    consignee: "Sudarsen Cargo Pvt Ltd",
    totalPkgs: 420,
    grossWeightKg: 24850,
    pod: "Nhava Sheva (INNSA)",
    status: "Verified & Dispatched",
  },
  {
    id: "hbl-2",
    requestedDateTime: "2026-11-03 12:15",
    linerName: "MSC MEDITERRANEAN",
    mblNo: "MEDUAFW55891",
    hblNo: "HBL-MUN-2026-4412",
    vesselVoyage: "MSC OSCAR 2611W",
    consignor: "BAVARIAN TECH TOOLS GMBH",
    consignee: "MAHARASHTRA AUTO PRECISION LTD",
    totalPkgs: 180,
    grossWeightKg: 19400,
    pod: "Mundra Port (INMUN)",
    status: "CSN Generated",
  },
  {
    id: "hbl-3",
    requestedDateTime: "2026-11-02 18:40",
    linerName: "MAERSK LINE",
    mblNo: "MAEU98214470",
    hblNo: "HBL-MAA-2026-1189",
    vesselVoyage: "MAERSK MC-KINNEY 2401",
    consignor: "ROTTERDAM CHEMICAL LOGISTICS",
    consignee: "CHENNAI PETROCHEM POLYMERS",
    totalPkgs: 64,
    grossWeightKg: 28200,
    pod: "Chennai Port (INMAA)",
    status: "Submitted",
  },
  {
    id: "hbl-4",
    requestedDateTime: "2026-11-01 09:30",
    linerName: "CMA CGM",
    mblNo: "CMAU09124881",
    hblNo: "HBL-TUT-2026-7832",
    vesselVoyage: "CMA CGM BOUGAINVILLE",
    consignor: "SINGAPORE AGRI PRODUCTS",
    consignee: "TUTICORIN SPICE EXPORTS",
    totalPkgs: 850,
    grossWeightKg: 21600,
    pod: "Tuticorin (INTUT)",
    status: "Draft",
  },
];

const LINER_OPTIONS = [
  "KMTC LINE",
  "MSC MEDITERRANEAN",
  "MAERSK LINE",
  "CMA CGM",
  "HAPAG-LLOYD",
  "COSCO SHIPPING",
  "ONE (OCEAN NETWORK EXPRESS)",
  "EVERGREEN MARINE",
  "YANG MING",
  "ZIM INTEGRATED",
  "WAN HAI LINES",
  "HYUNDAI MERCHANT MARINE",
  "OOCL",
  "SAMUDERA SHIPPING",
  "PACIFIC INTERNATIONAL LINES (PIL)",
];

interface ContainerRow {
  id: string;
  containerNo: string;
  isoType: string;
  sealNo: string;
  tareWeight: number;
  grossWeight: number;
  packages: number;
  packageType: string;
}

interface HblModuleProps {
  initialView?: "search" | "create";
  onAddToast: (type: "success" | "warning" | "error" | "info", title: string, message: string) => void;
  onOpenScannerWithData?: (data: any) => void;
  onOpenTracking?: (query: string) => void;
  isLoggedIn?: boolean;
  userName?: string;
  companyName?: string;
  onRequireLogin?: () => void;
}

export const HblModule: React.FC<HblModuleProps> = ({
  initialView = "search",
  onAddToast,
  onOpenScannerWithData,
  onOpenTracking,
  isLoggedIn = true,
  userName = "John Lanny",
  companyName = "Sudarsen Cargo Pvt Ltd",
  onRequireLogin,
}) => {
  const [view, setView] = useState<"search" | "create">(initialView);
  const [hblRecords, setHblRecords] = useState<HblRecord[]>(INITIAL_HBL_DATA);
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedRecord, setSelectedRecord] = useState<HblRecord | null>(null);

  // Form State for Create HBL
  const [activeStep, setActiveStep] = useState<"house" | "csn-gen" | "csn-sub">("house");
  const [linerName, setLinerName] = useState("KMTC LINE");
  const [mblNo, setMblNo] = useState("KMTCXGG3096868");
  const [hblNo, setHblNo] = useState(`HBL-BOM-${Date.now().toString().slice(-4)}`);
  const [vesselName, setVesselName] = useState("TIM S");
  const [voyageNo, setVoyageNo] = useState("043E");
  const [pol, setPol] = useState("SHANGHAI (CNSHA)");
  const [pod, setPod] = useState("NHAVA SHEVA (INNSA)");
  const [fd, setFd] = useState("ICD TUGLAKABAD (INTKD)");

  // Consignor / Consignee
  const [consignor, setConsignor] = useState("ZHEJIANG SINOCHEM TEXTILE CO., NO. 44 INDUSTRY RD, NINGBO");
  const [consignee, setConsignee] = useState("Sudarsen Cargo Pvt Ltd, Plot 14, Sector 19, Vashi, Navi Mumbai");
  const [notifyParty, setNotifyParty] = useState("SAME AS CONSIGNEE");

  // Dynamic Container details table
  const [containers, setContainers] = useState<ContainerRow[]>([
    {
      id: "c-1",
      containerNo: "KMTU8821940",
      isoType: "40HC",
      sealNo: "SL-994102",
      tareWeight: 3800,
      grossWeight: 24850,
      packages: 420,
      packageType: "Cartons",
    },
  ]);

  // Cargo details
  const [cargoDesc, setCargoDesc] = useState("SYNTHETIC POLYESTER KNITTED FABRICS FOR INDUSTRIAL APPAREL");
  const [hsCode, setHsCode] = useState("5407.52.00");

  // Handlers
  const handleCopyToNotify = () => {
    setNotifyParty(consignee);
    onAddToast("info", "Copied to Notify Party", "Consignee information mirrored to notify party.");
  };

  const handleAddContainerRow = () => {
    const newRow: ContainerRow = {
      id: `c-${Date.now()}`,
      containerNo: `MSKU${Math.floor(1000000 + Math.random() * 9000000)}`,
      isoType: "40HC",
      sealNo: `SL-${Math.floor(100000 + Math.random() * 900000)}`,
      tareWeight: 3820,
      grossWeight: 22000,
      packages: 350,
      packageType: "Cartons",
    };
    setContainers([...containers, newRow]);
  };

  const handleDeleteContainerRow = (id: string) => {
    if (containers.length <= 1) {
      onAddToast("warning", "Container Required", "At least one container row must be retained.");
      return;
    }
    setContainers(containers.filter((c) => c.id !== id));
  };

  const handleUpdateContainer = (id: string, field: keyof ContainerRow, value: any) => {
    setContainers(
      containers.map((c) => (c.id === id ? { ...c, [field]: value } : c))
    );
  };

  const handleSubmitHbl = () => {
    if (!isLoggedIn) {
      onAddToast(
        "warning",
        "Authentication Required",
        "Only logged-in users (e.g., John Lanny for Sudarsen Cargo Pvt Ltd) can submit official HBL manifests and port transactions."
      );
      onRequireLogin?.();
      return;
    }

    if (!mblNo || !hblNo) {
      onAddToast("error", "Missing Details", "Please provide MBL and HBL numbers.");
      return;
    }

    const totalWeight = containers.reduce((sum, c) => sum + Number(c.grossWeight || 0), 0);
    const totalPkgs = containers.reduce((sum, c) => sum + Number(c.packages || 0), 0);

    const newRecord: HblRecord = {
      id: `hbl-${Date.now()}`,
      requestedDateTime: new Date().toISOString().replace("T", " ").slice(0, 16),
      linerName,
      mblNo,
      hblNo,
      vesselVoyage: `${vesselName} ${voyageNo}`,
      consignor,
      consignee,
      totalPkgs,
      grossWeightKg: totalWeight,
      pod,
      status: "Submitted",
    };

    setHblRecords([newRecord, ...hblRecords]);
    onAddToast(
      "success",
      "HBL Request Dispatched",
      `House Bill ${hblNo} successfully submitted to ${linerName} and Port Community System.`
    );
    setView("search");
  };

  const filteredHbl = hblRecords.filter((h) => {
    const q = searchQuery.toLowerCase();
    return (
      h.hblNo.toLowerCase().includes(q) ||
      h.mblNo.toLowerCase().includes(q) ||
      h.linerName.toLowerCase().includes(q) ||
      h.consignee.toLowerCase().includes(q)
    );
  });

  return (
    <div className="w-full max-w-7xl mx-auto px-3 sm:px-6 py-6 select-none space-y-4">
      {/* Guest Mode Banner when logged out */}
      {!isLoggedIn && (
        <div className="bg-amber-50 border border-amber-200 rounded-xl p-3 text-xs text-amber-900 flex flex-col sm:flex-row sm:items-center justify-between gap-2 shadow-xs">
          <div className="flex items-center gap-2">
            <ShieldAlert className="w-4 h-4 text-amber-600 shrink-0" />
            <span>
              <strong>Read-Only Mode:</strong> Only authenticated logistics managers ({companyName}) can file HBL manifests or submit container documents.
            </span>
          </div>
          <button
            onClick={onRequireLogin}
            className="px-3 py-1 bg-amber-600 hover:bg-amber-700 text-white rounded font-bold cursor-pointer transition-colors text-xs shrink-0"
          >
            Log In to Transact
          </button>
        </div>
      )}

      {/* 1. Header Bar with Tabs and "NEW HBL" button */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between pb-4 border-b border-slate-300 gap-3">
        <div>
          <h1 className="text-xl sm:text-2xl font-bold text-[#0098db] tracking-tight flex items-center gap-2">
            <FileText className="w-6 h-6 text-[#0098db]" />
            <span>{view === "search" ? "HBL Request (Request)" : "Create House Bill of Lading (HBL)"}</span>
          </h1>
          <p className="text-xs text-slate-500 mt-0.5">
            Results For: Date: 19-10-2026 To 03-11-2026 • Port Community System 1x Certified
          </p>
        </div>

        <div className="flex items-center gap-2">
          {view === "search" ? (
            <button
              onClick={() => {
                if (!isLoggedIn) {
                  onAddToast(
                    "warning",
                    "Authentication Required",
                    "Please log in to create and file new House Bills of Lading (HBL)."
                  );
                  onRequireLogin?.();
                  return;
                }
                setView("create");
              }}
              className="px-4 py-2 bg-[#10b981] hover:bg-[#059669] text-white text-xs font-bold rounded-md shadow-sm flex items-center gap-1.5 transition-all cursor-pointer"
            >
              <Plus className="w-4 h-4 font-bold" />
              <span>NEW HBL</span>
            </button>
          ) : (
            <button
              onClick={() => setView("search")}
              className="px-4 py-2 bg-slate-200 hover:bg-slate-300 text-slate-800 text-xs font-bold rounded-md flex items-center gap-1.5 transition-all cursor-pointer"
            >
              <ArrowLeft className="w-4 h-4" />
              <span>BACK TO HBL SEARCH</span>
            </button>
          )}
        </div>
      </div>

      {/* 2. SEARCH VIEW (Matching Screenshots 5, 6, 7) */}
      {view === "search" && (
        <div className="mt-6 space-y-4">
          {/* Action Toolbar & Search */}
          <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3 bg-white p-3 rounded-lg border border-slate-200 shadow-xs">
            <div className="flex items-center gap-1.5 flex-wrap">
              <button
                disabled={!selectedRecord}
                onClick={() => {
                  if (selectedRecord) {
                    onAddToast("info", "Edit HBL", `Opening ${selectedRecord.hblNo} in edit mode.`);
                    setView("create");
                  }
                }}
                className={`px-3 py-1.5 text-xs font-semibold rounded border transition-colors cursor-pointer ${
                  selectedRecord
                    ? "bg-slate-100 hover:bg-slate-200 text-slate-800 border-slate-300"
                    : "bg-slate-50 text-slate-400 border-slate-200 cursor-not-allowed"
                }`}
              >
                ✎ Edit
              </button>
              <button
                disabled={!selectedRecord}
                onClick={() => {
                  if (selectedRecord) {
                    onAddToast(
                      "info",
                      `View HBL: ${selectedRecord.hblNo}`,
                      `MBL: ${selectedRecord.mblNo} | Vessel: ${selectedRecord.vesselVoyage} | Gross Wt: ${selectedRecord.grossWeightKg} KG`
                    );
                  }
                }}
                className={`px-3 py-1.5 text-xs font-semibold rounded border transition-colors cursor-pointer ${
                  selectedRecord
                    ? "bg-slate-100 hover:bg-slate-200 text-slate-800 border-slate-300"
                    : "bg-slate-50 text-slate-400 border-slate-200 cursor-not-allowed"
                }`}
              >
                🔍 View
              </button>
              <button
                disabled={!selectedRecord}
                onClick={() => {
                  if (selectedRecord) {
                    onAddToast(
                      "success",
                      "CSN Dispatched",
                      `Cargo Submission Notification for ${selectedRecord.hblNo} sent to Customs ICEGATE.`
                    );
                  }
                }}
                className={`px-3 py-1.5 text-xs font-semibold rounded border transition-colors cursor-pointer ${
                  selectedRecord
                    ? "bg-sky-50 text-sky-700 hover:bg-sky-100 border-sky-300"
                    : "bg-slate-50 text-slate-400 border-slate-200 cursor-not-allowed"
                }`}
              >
                ✈ Send To Liner
              </button>
              <button
                type="button"
                onClick={() => {
                  const target = selectedRecord?.mblNo || (searchQuery.trim() || "KMTCXGG3096868");
                  if (onOpenTracking) onOpenTracking(target);
                }}
                className="px-3 py-1.5 text-xs font-bold rounded border bg-emerald-50 text-emerald-700 hover:bg-emerald-100 border-emerald-300 transition-colors cursor-pointer flex items-center gap-1 shadow-2xs"
                title="Live Container & Vessel Tracking"
              >
                <Truck className="w-3.5 h-3.5" />
                <span>Live Tracking</span>
              </button>
            </div>

            <div className="flex items-center gap-2">
              <div className="relative flex-1 sm:w-72">
                <input
                  type="text"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  onKeyDown={(e) => {
                    if (e.key === "Enter" && searchQuery.trim() && onOpenTracking) {
                      onOpenTracking(searchQuery.trim());
                    }
                  }}
                  placeholder="SEARCH HBL / MBL (PRESS ENTER TO TRACK)"
                  className="w-full pl-8 pr-3 py-1.5 text-xs border border-slate-300 rounded-md focus:outline-hidden focus:border-[#0098db]"
                />
                <Search className="w-3.5 h-3.5 text-slate-400 absolute left-2.5 top-2.5" />
              </div>
            </div>
          </div>

          {/* Data Table */}
          <div className="bg-white rounded-lg border border-slate-200 shadow-sm overflow-x-auto">
            <table className="w-full text-left border-collapse text-xs">
              <thead>
                <tr className="bg-slate-100 text-slate-700 font-bold border-b border-slate-200 uppercase tracking-tight text-[11px]">
                  <th className="p-3 w-8">#</th>
                  <th className="p-3">Requested Date & Time</th>
                  <th className="p-3">Liner Name</th>
                  <th className="p-3">MBL No.</th>
                  <th className="p-3">HBL No.</th>
                  <th className="p-3">Vessel-Voyage</th>
                  <th className="p-3">Consignee</th>
                  <th className="p-3 text-right">Packages</th>
                  <th className="p-3 text-right">Gross Wt (KG)</th>
                  <th className="p-3">POD</th>
                  <th className="p-3 text-center">Status</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {filteredHbl.map((row, idx) => {
                  const isSelected = selectedRecord?.id === row.id;
                  return (
                    <tr
                      key={row.id}
                      onClick={() => setSelectedRecord(row)}
                      className={`hover:bg-sky-50/60 cursor-pointer transition-colors ${
                        isSelected ? "bg-sky-100/70 font-semibold" : ""
                      }`}
                    >
                      <td className="p-3 text-slate-400 text-[10px]">{idx + 1}</td>
                      <td className="p-3 font-mono text-slate-600">{row.requestedDateTime}</td>
                      <td className="p-3 font-bold text-slate-800">{row.linerName}</td>
                      <td className="p-3 font-mono text-[#0098db] font-bold">{row.mblNo}</td>
                      <td className="p-3 font-mono text-slate-800">{row.hblNo}</td>
                      <td className="p-3 font-mono text-slate-700">{row.vesselVoyage}</td>
                      <td className="p-3 text-slate-600 truncate max-w-[160px]">{row.consignee}</td>
                      <td className="p-3 text-right font-mono">{row.totalPkgs}</td>
                      <td className="p-3 text-right font-mono font-bold">{row.grossWeightKg.toLocaleString()}</td>
                      <td className="p-3 text-slate-600">{row.pod}</td>
                      <td className="p-3 text-center">
                        <span
                          className={`px-2 py-0.5 rounded text-[10px] font-bold uppercase ${
                            row.status === "Verified & Dispatched"
                              ? "bg-emerald-100 text-emerald-800"
                              : row.status === "CSN Generated"
                              ? "bg-sky-100 text-sky-800"
                              : row.status === "Submitted"
                              ? "bg-blue-100 text-blue-800"
                              : "bg-slate-200 text-slate-700"
                          }`}
                        >
                          {row.status}
                        </span>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>

          {/* Table Bottom Pagination & Export Controls */}
          <div className="flex flex-col sm:flex-row items-center justify-between gap-3 text-xs text-slate-500 pt-2">
            <div>
              Showing 1 to {filteredHbl.length} of {filteredHbl.length} entries
            </div>
            <div className="flex items-center gap-1.5">
              <button
                type="button"
                onClick={async () => {
                  const exportData = {
                    title: "House Bill of Lading (HBL) Electronic Manifest",
                    filenamePrefix: "HBL_Manifest_Export",
                    headers: ["#", "REQUESTED DATE", "LINER NAME", "MBL NUMBER", "HBL NUMBER", "VESSEL / VOYAGE", "CONSIGNEE", "PKGS", "GROSS WT (KG)", "PORT OF DISCHARGE", "STATUS"],
                    rows: filteredHbl.map((h, i) => [
                      i + 1,
                      h.requestedDateTime,
                      h.linerName,
                      h.mblNo,
                      h.hblNo,
                      h.vesselVoyage,
                      h.consignee,
                      h.totalPkgs,
                      h.grossWeightKg.toLocaleString(),
                      h.pod,
                      h.status,
                    ]),
                    metadata: {
                      Company: companyName || "Sudarsen Cargo Pvt Ltd",
                      Officer: userName || "John Lanny",
                      Terminal: "JNPT Nhava Sheva / Mundra",
                      TotalRecords: `${filteredHbl.length} Bills of Lading`,
                    },
                  };
                  const ok = await copyTableToClipboard(exportData);
                  if (ok) {
                    onAddToast("success", "Table Copied", `Copied ${filteredHbl.length} HBL records to clipboard as tab-delimited text.`);
                  } else {
                    onAddToast("error", "Copy Failed", "Unable to copy to clipboard.");
                  }
                }}
                className="px-2.5 py-1 bg-white border border-slate-300 rounded hover:bg-slate-100 text-slate-700 font-semibold cursor-pointer active:scale-95 transition-all shadow-2xs"
                title="Copy table data to clipboard"
              >
                Copy
              </button>
              <button
                type="button"
                onClick={() => {
                  const exportData = {
                    title: "House Bill of Lading (HBL) Electronic Manifest",
                    filenamePrefix: "HBL_Manifest_Export",
                    headers: ["#", "REQUESTED DATE", "LINER NAME", "MBL NUMBER", "HBL NUMBER", "VESSEL / VOYAGE", "CONSIGNEE", "PKGS", "GROSS WT (KG)", "PORT OF DISCHARGE", "STATUS"],
                    rows: filteredHbl.map((h, i) => [
                      i + 1,
                      h.requestedDateTime,
                      h.linerName,
                      h.mblNo,
                      h.hblNo,
                      h.vesselVoyage,
                      h.consignee,
                      h.totalPkgs,
                      h.grossWeightKg,
                      h.pod,
                      h.status,
                    ]),
                  };
                  downloadTableAsCSV(exportData);
                  onAddToast("success", "CSV Exported", `Downloaded ${filteredHbl.length} HBL records as CSV file.`);
                }}
                className="px-2.5 py-1 bg-white border border-slate-300 rounded hover:bg-slate-100 text-slate-700 font-semibold cursor-pointer active:scale-95 transition-all shadow-2xs"
                title="Download table data as CSV"
              >
                CSV
              </button>
              <button
                type="button"
                onClick={() => {
                  const exportData = {
                    title: "House Bill of Lading (HBL) Electronic Manifest",
                    filenamePrefix: "HBL_Manifest_Export",
                    headers: ["#", "REQUESTED DATE", "LINER NAME", "MBL NUMBER", "HBL NUMBER", "VESSEL / VOYAGE", "CONSIGNEE", "PKGS", "GROSS WT (KG)", "PORT OF DISCHARGE", "STATUS"],
                    rows: filteredHbl.map((h, i) => [
                      i + 1,
                      h.requestedDateTime,
                      h.linerName,
                      h.mblNo,
                      h.hblNo,
                      h.vesselVoyage,
                      h.consignee,
                      h.totalPkgs,
                      h.grossWeightKg.toLocaleString(),
                      h.pod,
                      h.status,
                    ]),
                    metadata: {
                      Company: companyName || "Sudarsen Cargo Pvt Ltd",
                      Officer: userName || "John Lanny",
                      Terminal: "JNPT Nhava Sheva / Mundra",
                      TotalRecords: `${filteredHbl.length} Bills of Lading`,
                    },
                  };
                  openPrintableTableReport(exportData, false);
                  onAddToast("info", "PDF Generated", `Opened printable PDF report for ${filteredHbl.length} HBL records.`);
                }}
                className="px-2.5 py-1 bg-white border border-slate-300 rounded hover:bg-slate-100 text-slate-700 font-semibold cursor-pointer active:scale-95 transition-all shadow-2xs"
                title="View printable PDF manifest report"
              >
                PDF
              </button>
              <button
                type="button"
                onClick={() => {
                  const exportData = {
                    title: "House Bill of Lading (HBL) Electronic Manifest",
                    filenamePrefix: "HBL_Manifest_Export",
                    headers: ["#", "REQUESTED DATE", "LINER NAME", "MBL NUMBER", "HBL NUMBER", "VESSEL / VOYAGE", "CONSIGNEE", "PKGS", "GROSS WT (KG)", "PORT OF DISCHARGE", "STATUS"],
                    rows: filteredHbl.map((h, i) => [
                      i + 1,
                      h.requestedDateTime,
                      h.linerName,
                      h.mblNo,
                      h.hblNo,
                      h.vesselVoyage,
                      h.consignee,
                      h.totalPkgs,
                      h.grossWeightKg.toLocaleString(),
                      h.pod,
                      h.status,
                    ]),
                    metadata: {
                      Company: companyName || "Sudarsen Cargo Pvt Ltd",
                      Officer: userName || "John Lanny",
                      Terminal: "JNPT Nhava Sheva / Mundra",
                    },
                  };
                  openPrintableTableReport(exportData, true);
                  onAddToast("info", "Print Ready", "Opened print dialog for HBL manifest report.");
                }}
                className="px-2.5 py-1 bg-white border border-slate-300 rounded hover:bg-slate-100 text-slate-700 font-semibold cursor-pointer active:scale-95 transition-all shadow-2xs"
                title="Print table data"
              >
                Print
              </button>
            </div>
          </div>
        </div>
      )}

      {/* 3. CREATE HBL FORM VIEW (Matching Screenshots 8, 9, 10) */}
      {view === "create" && (
        <div className="mt-6 space-y-6">
          {/* Step tabs: House Submission | CSN Generation | CSN Submission */}
          <div className="flex items-center border-b border-slate-200 bg-white rounded-t-lg px-4 pt-3 gap-2">
            <button
              onClick={() => setActiveStep("house")}
              className={`pb-3 px-4 text-xs font-bold border-b-2 transition-colors cursor-pointer ${
                activeStep === "house"
                  ? "border-[#0098db] text-[#0098db]"
                  : "border-transparent text-slate-500 hover:text-slate-800"
              }`}
            >
              1. House Submission
            </button>
            <button
              onClick={() => setActiveStep("csn-gen")}
              className={`pb-3 px-4 text-xs font-bold border-b-2 transition-colors cursor-pointer ${
                activeStep === "csn-gen"
                  ? "border-[#0098db] text-[#0098db]"
                  : "border-transparent text-slate-500 hover:text-slate-800"
              }`}
            >
              2. CSN Generation
            </button>
            <button
              onClick={() => setActiveStep("csn-sub")}
              className={`pb-3 px-4 text-xs font-bold border-b-2 transition-colors cursor-pointer ${
                activeStep === "csn-sub"
                  ? "border-[#0098db] text-[#0098db]"
                  : "border-transparent text-slate-500 hover:text-slate-800"
              }`}
            >
              3. CSN Submission
            </button>
          </div>

          {/* Vessel Warning Notification (Matching TIM S 043E alert from Screenshot) */}
          <div className="bg-amber-50 border-l-4 border-amber-500 p-3 rounded-r-md flex items-center justify-between text-xs text-amber-900 shadow-2xs">
            <div className="flex items-center gap-2">
              <AlertTriangle className="w-4 h-4 text-amber-600 shrink-0" />
              <span>
                <strong>Vessel Alert:</strong> {vesselName} ({voyageNo}) gate cut-off is in <strong>4 hours 12 mins</strong>. Ensure gross weight within SOLAS tolerance.
              </span>
            </div>
            <span className="font-mono text-[11px] bg-amber-200/80 px-2 py-0.5 rounded text-amber-900 font-bold">
              BERTH 04 - JNPT
            </span>
          </div>

          {/* Section 1: MBL & Voyage Details */}
          <div className="bg-white p-5 rounded-lg border border-slate-200 shadow-xs space-y-4">
            <h3 className="text-xs font-bold uppercase tracking-wider text-slate-700 pb-2 border-b border-slate-100 flex items-center gap-2">
              <Ship className="w-4 h-4 text-[#0098db]" />
              <span>Master Bill of Lading (MBL) & Carrier Specifics</span>
            </h3>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 text-xs">
              <div>
                <label className="block text-slate-600 font-semibold mb-1">
                  Shipping Line / Carrier *
                </label>
                <select
                  value={linerName}
                  onChange={(e) => setLinerName(e.target.value)}
                  className="w-full p-2 border border-slate-300 rounded-md bg-white font-semibold text-slate-800 focus:border-[#0098db]"
                >
                  {LINER_OPTIONS.map((l) => (
                    <option key={l} value={l}>
                      {l}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-slate-600 font-semibold mb-1">
                  Master BL (MBL) No. *
                </label>
                <input
                  type="text"
                  value={mblNo}
                  onChange={(e) => setMblNo(e.target.value)}
                  placeholder="e.g. KMTCXGG3096868"
                  className="w-full p-2 border border-slate-300 rounded-md font-mono font-bold text-slate-800"
                />
              </div>

              <div>
                <label className="block text-slate-600 font-semibold mb-1">
                  House BL (HBL) No. *
                </label>
                <input
                  type="text"
                  value={hblNo}
                  onChange={(e) => setHblNo(e.target.value)}
                  placeholder="e.g. HBL-BOM-2026-9021"
                  className="w-full p-2 border border-slate-300 rounded-md font-mono font-bold text-slate-800"
                />
              </div>

              <div>
                <label className="block text-slate-600 font-semibold mb-1">
                  Vessel Name & Voyage *
                </label>
                <div className="flex gap-2">
                  <input
                    type="text"
                    value={vesselName}
                    onChange={(e) => setVesselName(e.target.value)}
                    className="w-2/3 p-2 border border-slate-300 rounded-md text-slate-800"
                  />
                  <input
                    type="text"
                    value={voyageNo}
                    onChange={(e) => setVoyageNo(e.target.value)}
                    className="w-1/3 p-2 border border-slate-300 rounded-md font-mono text-slate-800"
                  />
                </div>
              </div>

              <div>
                <label className="block text-slate-600 font-semibold mb-1">
                  Port of Loading (POL)
                </label>
                <input
                  type="text"
                  value={pol}
                  onChange={(e) => setPol(e.target.value)}
                  className="w-full p-2 border border-slate-300 rounded-md text-slate-800"
                />
              </div>

              <div>
                <label className="block text-slate-600 font-semibold mb-1">
                  Port of Discharge (POD)
                </label>
                <input
                  type="text"
                  value={pod}
                  onChange={(e) => setPod(e.target.value)}
                  className="w-full p-2 border border-slate-300 rounded-md text-slate-800"
                />
              </div>
            </div>
          </div>

          {/* Section 2: Consignor, Consignee & Notify Party with "Copy to Notify" */}
          <div className="bg-white p-5 rounded-lg border border-slate-200 shadow-xs space-y-4">
            <div className="flex items-center justify-between pb-2 border-b border-slate-100">
              <h3 className="text-xs font-bold uppercase tracking-wider text-slate-700">
                Shipper, Consignee & Notify Party
              </h3>
              <button
                type="button"
                onClick={handleCopyToNotify}
                className="px-2.5 py-1 bg-sky-50 text-[#0098db] hover:bg-sky-100 border border-sky-300 rounded text-xs font-semibold flex items-center gap-1 cursor-pointer transition-colors"
              >
                <Copy className="w-3.5 h-3.5" />
                <span>Copy Consignee to Notify Party</span>
              </button>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 text-xs">
              <div>
                <label className="block text-slate-600 font-semibold mb-1">
                  Consignor (Shipper) Name & Address *
                </label>
                <textarea
                  rows={3}
                  value={consignor}
                  onChange={(e) => setConsignor(e.target.value)}
                  className="w-full p-2 border border-slate-300 rounded-md text-slate-800"
                />
              </div>

              <div>
                <label className="block text-slate-600 font-semibold mb-1">
                  Consignee Name & Address *
                </label>
                <textarea
                  rows={3}
                  value={consignee}
                  onChange={(e) => setConsignee(e.target.value)}
                  className="w-full p-2 border border-slate-300 rounded-md text-slate-800"
                />
              </div>

              <div>
                <label className="block text-slate-600 font-semibold mb-1">
                  Notify Party Details
                </label>
                <textarea
                  rows={3}
                  value={notifyParty}
                  onChange={(e) => setNotifyParty(e.target.value)}
                  className="w-full p-2 border border-slate-300 rounded-md text-slate-800"
                />
              </div>
            </div>
          </div>

          {/* Section 3: Dynamic Container Details Table */}
          <div className="bg-white p-5 rounded-lg border border-slate-200 shadow-xs space-y-4">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between pb-2 border-b border-slate-100 gap-2">
              <div>
                <h3 className="text-xs font-bold uppercase tracking-wider text-slate-700">
                  Container Specification & Packing Manifest
                </h3>
                <p className="text-[11px] text-slate-400">
                  ISO 6346 compliant container number format & Tare/Gross verification
                </p>
              </div>

              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={handleAddContainerRow}
                  className="px-3 py-1.5 bg-[#0098db] hover:bg-[#0086c2] text-white rounded text-xs font-bold flex items-center gap-1 cursor-pointer transition-colors shadow-2xs"
                >
                  <Plus className="w-3.5 h-3.5 font-bold" />
                  <span>+ Add Row</span>
                </button>
              </div>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs border border-slate-200">
                <thead>
                  <tr className="bg-slate-50 text-slate-700 font-bold border-b border-slate-200">
                    <th className="p-2.5">Container No.</th>
                    <th className="p-2.5">ISO Type</th>
                    <th className="p-2.5">Seal No.</th>
                    <th className="p-2.5 text-right">Tare Wt (KG)</th>
                    <th className="p-2.5 text-right">Gross Wt (KG)</th>
                    <th className="p-2.5 text-right">Packages</th>
                    <th className="p-2.5">Type</th>
                    <th className="p-2.5 text-center w-12">Action</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 font-mono">
                  {containers.map((row) => (
                    <tr key={row.id} className="hover:bg-slate-50">
                      <td className="p-2">
                        <input
                          type="text"
                          value={row.containerNo}
                          onChange={(e) => handleUpdateContainer(row.id, "containerNo", e.target.value)}
                          className="w-full p-1 border border-slate-300 rounded font-bold text-slate-800"
                        />
                      </td>
                      <td className="p-2">
                        <select
                          value={row.isoType}
                          onChange={(e) => handleUpdateContainer(row.id, "isoType", e.target.value)}
                          className="w-full p-1 border border-slate-300 rounded"
                        >
                          <option value="20GP">20GP Standard</option>
                          <option value="40GP">40GP Standard</option>
                          <option value="40HC">40HC High Cube</option>
                          <option value="20RF">20RF Reefer</option>
                          <option value="40RF">40RF Reefer</option>
                        </select>
                      </td>
                      <td className="p-2">
                        <input
                          type="text"
                          value={row.sealNo}
                          onChange={(e) => handleUpdateContainer(row.id, "sealNo", e.target.value)}
                          className="w-full p-1 border border-slate-300 rounded"
                        />
                      </td>
                      <td className="p-2 text-right">
                        <input
                          type="number"
                          value={row.tareWeight}
                          onChange={(e) => handleUpdateContainer(row.id, "tareWeight", Number(e.target.value))}
                          className="w-24 p-1 border border-slate-300 rounded text-right"
                        />
                      </td>
                      <td className="p-2 text-right">
                        <input
                          type="number"
                          value={row.grossWeight}
                          onChange={(e) => handleUpdateContainer(row.id, "grossWeight", Number(e.target.value))}
                          className="w-28 p-1 border border-slate-300 rounded text-right font-bold text-slate-900"
                        />
                      </td>
                      <td className="p-2 text-right">
                        <input
                          type="number"
                          value={row.packages}
                          onChange={(e) => handleUpdateContainer(row.id, "packages", Number(e.target.value))}
                          className="w-20 p-1 border border-slate-300 rounded text-right"
                        />
                      </td>
                      <td className="p-2">
                        <input
                          type="text"
                          value={row.packageType}
                          onChange={(e) => handleUpdateContainer(row.id, "packageType", e.target.value)}
                          className="w-24 p-1 border border-slate-300 rounded"
                        />
                      </td>
                      <td className="p-2 text-center">
                        <button
                          type="button"
                          onClick={() => handleDeleteContainerRow(row.id)}
                          className="p-1 text-rose-500 hover:text-rose-700 hover:bg-rose-50 rounded cursor-pointer"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>

            {/* Total Row */}
            <div className="flex justify-end gap-6 text-xs font-mono font-bold text-slate-700 bg-slate-50 p-2.5 rounded border border-slate-200">
              <div>Total Containers: {containers.length}</div>
              <div>
                Total Packages: {containers.reduce((s, c) => s + (Number(c.packages) || 0), 0)}
              </div>
              <div className="text-[#0098db]">
                Total Gross Weight: {containers.reduce((s, c) => s + (Number(c.grossWeight) || 0), 0).toLocaleString()} KG
              </div>
            </div>
          </div>

          {/* Section 4: Cargo Details */}
          <div className="bg-white p-5 rounded-lg border border-slate-200 shadow-xs space-y-4">
            <h3 className="text-xs font-bold uppercase tracking-wider text-slate-700 pb-2 border-b border-slate-100">
              Cargo Description & Classification
            </h3>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
              <div>
                <label className="block text-slate-600 font-semibold mb-1">
                  General Cargo Description *
                </label>
                <textarea
                  rows={2}
                  value={cargoDesc}
                  onChange={(e) => setCargoDesc(e.target.value)}
                  className="w-full p-2 border border-slate-300 rounded-md text-slate-800"
                />
              </div>
              <div>
                <label className="block text-slate-600 font-semibold mb-1">
                  HS Code (Customs Tariff)
                </label>
                <input
                  type="text"
                  value={hsCode}
                  onChange={(e) => setHsCode(e.target.value)}
                  className="w-full p-2 border border-slate-300 rounded-md font-mono"
                />
              </div>
            </div>
          </div>

          {/* Bottom Action Buttons */}
          <div className="flex items-center justify-between pt-4 border-t border-slate-300">
            <button
              type="button"
              onClick={() => setView("search")}
              className="px-4 py-2 border border-slate-300 text-slate-700 text-xs font-semibold rounded-md hover:bg-slate-100 transition-colors cursor-pointer"
            >
              Cancel
            </button>

            <div className="flex items-center gap-3">
              <button
                type="button"
                onClick={() => {
                  onAddToast(
                    "info",
                    "AI Pre-Scan",
                    "Gemini AI verified zero SOLAS weight discrepancies and ISO container formats."
                  );
                }}
                className="px-4 py-2 bg-emerald-50 text-emerald-700 border border-emerald-300 rounded-md text-xs font-bold flex items-center gap-1.5 hover:bg-emerald-100 transition-colors cursor-pointer"
              >
                <Sparkles className="w-4 h-4 text-emerald-600" />
                <span>AI Pre-Validate</span>
              </button>

              <button
                type="button"
                onClick={handleSubmitHbl}
                className="px-5 py-2.5 bg-[#0098db] hover:bg-[#0086c2] text-white rounded-md text-xs font-bold flex items-center gap-2 shadow-sm transition-all cursor-pointer"
              >
                <Send className="w-4 h-4" />
                <span>Submit HBL to Liner & PCS 1x</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Corporate support footer matching screenshot 6 */}
      <div className="mt-8 pt-4 border-t border-slate-200 text-center text-xs text-slate-500 space-y-1">
        <p>
          For immediate assistance and quick query resolution, please email{" "}
          <span className="text-[#0098db] font-semibold">platinunmsupport@nexlogglobal.com</span> or call{" "}
          <span className="text-slate-700 font-bold">+91 8828 822 244</span>.
        </p>
        <p className="text-[11px] text-slate-400">
          © Copyright 2018-2026 EA Technologies. All rights reserved. NexLog Autonomous EXIM Exchange.
        </p>
      </div>
    </div>
  );
};
