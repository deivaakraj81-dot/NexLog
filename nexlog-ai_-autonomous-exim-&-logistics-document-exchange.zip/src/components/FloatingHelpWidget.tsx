import React, { useState } from "react";
import {
  HelpCircle,
  X,
  Phone,
  Mail,
  Send,
  MessageSquare,
  ChevronLeft,
  ChevronRight,
  ShieldCheck,
  CheckCircle2,
  Bell,
} from "lucide-react";

interface FloatingHelpWidgetProps {
  onAddToast: (type: "success" | "warning" | "error" | "info", title: string, message: string) => void;
  onOpenNotifications?: () => void;
}

export const FloatingHelpWidget: React.FC<FloatingHelpWidgetProps> = ({
  onAddToast,
  onOpenNotifications,
}) => {
  const [isOpen, setIsOpen] = useState(false);
  const [ticketSubject, setTicketSubject] = useState("");
  const [ticketMessage, setTicketMessage] = useState("");
  const [submittedTicketId, setSubmittedTicketId] = useState<string | null>(null);

  const handleSubmitTicket = (e: React.FormEvent) => {
    e.preventDefault();
    if (!ticketSubject.trim()) return;

    const id = `TKT-${Math.floor(10000 + Math.random() * 90000)}`;
    setSubmittedTicketId(id);
    onAddToast(
      "success",
      `Support Ticket Generated: ${id}`,
      "Our 24/7 Port Gate Operations Desk will respond within 15 minutes."
    );
    setTicketSubject("");
    setTicketMessage("");
  };

  return (
    <>
      {/* 1. Floating Cyan HELP Tab on Right Edge (Matching Screenshots 1, 3, 5, 6) */}
      <div className="fixed right-0 top-1/2 -translate-y-1/2 z-40 select-none">
        <button
          onClick={() => setIsOpen(!isOpen)}
          className="bg-[#0098db] hover:bg-[#0086c2] text-white px-2 py-3 rounded-l-md shadow-2xl flex flex-col items-center gap-1 cursor-pointer transition-all border-l border-y border-sky-400 group"
          title="Click to open NexLog Port Help & Support"
        >
          <div className="w-4 h-4 rounded-full bg-white text-[#0098db] flex items-center justify-center font-bold text-[10px] shadow-2xs">
            {isOpen ? <X className="w-3 h-3" /> : "?"}
          </div>
          <span className="[writing-mode:vertical-rl] rotate-180 font-black tracking-widest text-xs uppercase my-1 text-white">
            H E L P
          </span>
          <ChevronLeft
            className={`w-3.5 h-3.5 transition-transform duration-200 ${
              isOpen ? "rotate-180" : ""
            }`}
          />
        </button>
      </div>

      {/* 2. Slide-out Support Drawer */}
      {isOpen && (
        <div className="fixed right-10 top-1/2 -translate-y-1/2 w-80 sm:w-96 bg-white rounded-l-xl shadow-2xl border border-slate-300 z-50 p-5 space-y-4 animate-in slide-in-from-right duration-200 text-xs text-slate-700">
          <div className="flex items-center justify-between pb-3 border-b border-slate-200">
            <div className="flex items-center gap-2">
              <div className="p-1.5 rounded-md bg-sky-100 text-[#0098db]">
                <HelpCircle className="w-5 h-5" />
              </div>
              <div>
                <h3 className="font-bold text-sm text-slate-800">
                  NexLog Gate Support
                </h3>
                <p className="text-[10px] text-slate-500">
                  24/7 Port Community System Assistance
                </p>
              </div>
            </div>
            <button
              onClick={() => setIsOpen(false)}
              className="p-1 text-slate-400 hover:text-slate-600 rounded cursor-pointer"
            >
              <X className="w-4 h-4" />
            </button>
          </div>

          {/* Direct Hotlines */}
          <div className="space-y-2 bg-slate-50 p-3 rounded-lg border border-slate-200">
            <div className="flex items-center gap-2 text-slate-700">
              <Phone className="w-3.5 h-3.5 text-[#0098db]" />
              <span className="font-semibold">Gate Emergency:</span>
              <span className="font-mono text-slate-900 font-bold">+91 8828 822 244</span>
            </div>
            <div className="flex items-center gap-2 text-slate-700">
              <Phone className="w-3.5 h-3.5 text-[#0098db]" />
              <span className="font-semibold">General Desk:</span>
              <span className="font-mono text-slate-900 font-bold">+91 9863 122 122</span>
            </div>
            <div className="flex items-center gap-2 text-slate-700">
              <Mail className="w-3.5 h-3.5 text-[#0098db]" />
              <span className="font-semibold">Support Email:</span>
              <span className="font-mono text-[#0098db] text-[11px] truncate">
                platinunmsupport@nexlogglobal.com
              </span>
            </div>
          </div>

          {onOpenNotifications && (
            <button
              type="button"
              onClick={() => {
                setIsOpen(false);
                onOpenNotifications();
              }}
              className="w-full py-2 px-3 rounded-lg bg-sky-50 hover:bg-sky-100 border border-sky-300 text-[#0098db] font-bold text-xs flex items-center justify-center gap-2 cursor-pointer transition-colors shadow-2xs"
            >
              <Bell className="w-4 h-4 text-amber-500" />
              <span>Shipment Arrival Alerts & Attachments</span>
            </button>
          )}

          {/* Quick Ticket Form */}
          <form onSubmit={handleSubmitTicket} className="space-y-3">
            <div className="font-bold text-slate-800">Submit Priority Ticket</div>
            <div>
              <input
                type="text"
                required
                value={ticketSubject}
                onChange={(e) => setTicketSubject(e.target.value)}
                placeholder="Subject (e.g. BL Hold / Container Discrepancy)"
                className="w-full p-2 border border-slate-300 rounded text-xs focus:outline-hidden focus:border-[#0098db]"
              />
            </div>
            <div>
              <textarea
                rows={2}
                value={ticketMessage}
                onChange={(e) => setTicketMessage(e.target.value)}
                placeholder="Brief description or container number..."
                className="w-full p-2 border border-slate-300 rounded text-xs focus:outline-hidden focus:border-[#0098db]"
              />
            </div>
            <button
              type="submit"
              className="w-full py-2 bg-[#0098db] hover:bg-[#0086c2] text-white font-bold rounded flex items-center justify-center gap-1.5 cursor-pointer transition-colors shadow-2xs"
            >
              <Send className="w-3.5 h-3.5" />
              <span>Submit Gate Ticket</span>
            </button>
          </form>

          {/* Last Submitted Ticket Confirmation */}
          {submittedTicketId && (
            <div className="p-2.5 bg-emerald-50 border border-emerald-200 rounded text-[11px] text-emerald-800 flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
              <span>
                Ticket <strong>{submittedTicketId}</strong> active. Engineer assigned.
              </span>
            </div>
          )}

          {/* ISO Compliance notice */}
          <div className="pt-2 border-t border-slate-200 text-[10px] text-slate-400 text-center">
            ISO 9001:2015 & ISO/IEC 27001 Certified Security Desk
          </div>
        </div>
      )}
    </>
  );
};
