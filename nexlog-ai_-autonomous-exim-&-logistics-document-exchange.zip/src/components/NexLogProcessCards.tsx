import React, { useState } from "react";
import {
  Users,
  CreditCard,
  Share2,
  FileCheck2,
  FileText,
  Boxes,
  ArrowRight,
  ChevronDown,
  Search,
  CheckCircle2,
  Sparkles,
  Loader2,
} from "lucide-react";

export interface ProcessCardConfig {
  id: string;
  title: string;
  sublabels?: { left: string; right: string };
  headerBg: string;
  circleBg: string;
  arrowBg: string;
  icon: "counter" | "payment" | "esb" | "form13" | "hbl" | "vgm";
  defaultPort: string;
  actionTarget: string;
  description: string;
}

const INDIAN_PORTS = [
  "Ahmedabad",
  "NCR",
  "Mundra",
  "ICD Bangalore",
  "Mangalore",
  "Mumbai",
  "ICD Hyderabad",
  "Tuticorin",
  "Chennai",
  "Nhava Sheva",
  "Pipavav",
  "Cochin",
  "Kolkata",
  "Visakhapatnam",
];

const CARDS_DATA: ProcessCardConfig[] = [
  {
    id: "counter",
    title: "Counter Process",
    headerBg: "bg-[#f59e0b]", // Amber / Orange
    circleBg: "bg-[#d97706]/20 text-[#b45309]",
    arrowBg: "bg-[#f59e0b] hover:bg-[#d97706]",
    icon: "counter",
    defaultPort: "Mundra",
    actionTarget: "cfs-search",
    description: "Physical counter queue token, physical document validation & gate handover.",
  },
  {
    id: "epayment",
    title: "ePayment",
    sublabels: { left: "eInvoice", right: "eDO" },
    headerBg: "bg-[#ef4444]", // Red
    circleBg: "bg-[#dc2626]/20 text-[#b91c1c]",
    arrowBg: "bg-[#ef4444] hover:bg-[#dc2626]",
    icon: "payment",
    defaultPort: "Nhava Sheva",
    actionTarget: "invoice-search",
    description: "Real-time liner tariff reconciliation, GST invoice lookup and instant eDO issuance.",
  },
  {
    id: "esb",
    title: "eSB",
    headerBg: "bg-[#a855f7]", // Purple
    circleBg: "bg-[#9333ea]/20 text-[#7e22ce]",
    arrowBg: "bg-[#a855f7] hover:bg-[#9333ea]",
    icon: "esb",
    defaultPort: "Nhava Sheva",
    actionTarget: "scanner",
    description: "Electronic Shipping Bill transmission directly to ICEGATE & Terminal Gate.",
  },
  {
    id: "eform13",
    title: "eForm13",
    sublabels: { left: "eForm11", right: "eCart in" },
    headerBg: "bg-[#10b981]", // Emerald Green
    circleBg: "bg-[#059669]/20 text-[#047857]",
    arrowBg: "bg-[#10b981] hover:bg-[#059669]",
    icon: "form13",
    defaultPort: "Nhava Sheva",
    actionTarget: "scanner",
    description: "Terminal Gate Entry pass, boom barrier clearance & RFID pre-check.",
  },
  {
    id: "ehbl",
    title: "eHBL",
    sublabels: { left: "eIGM", right: "eCFS" },
    headerBg: "bg-[#0098db]", // Cyan / Blue from screenshot
    circleBg: "bg-[#0284c7]/20 text-[#0369a1]",
    arrowBg: "bg-[#0098db] hover:bg-[#0284c7]",
    icon: "hbl",
    defaultPort: "Tuticorin",
    actionTarget: "hbl-search",
    description: "House Bill of Lading filing, Cargo manifest integration & CFS nomination.",
  },
  {
    id: "evgm",
    title: "eVGM",
    headerBg: "bg-[#a89988]", // Taupe / warm gray from screenshot
    circleBg: "bg-[#8c7b6b]/20 text-[#6e5d4f]",
    arrowBg: "bg-[#a89988] hover:bg-[#8c7b6b]",
    icon: "vgm",
    defaultPort: "Nhava Sheva",
    actionTarget: "scanner",
    description: "SOLAS Verified Gross Mass compliance certificate with weighbridge telemetry.",
  },
];

interface NexLogProcessCardsProps {
  onExecuteProcess: (target: string, port: string, cardTitle: string) => void;
  currencySymbol?: string;
}

export const NexLogProcessCards: React.FC<NexLogProcessCardsProps> = ({
  onExecuteProcess,
  currencySymbol = "₹",
}) => {
  const [selectedPorts, setSelectedPorts] = useState<Record<string, string>>({
    counter: "Mundra",
    epayment: "Nhava Sheva",
    esb: "Nhava Sheva",
    eform13: "Nhava Sheva",
    ehbl: "Tuticorin",
    evgm: "Nhava Sheva",
  });

  const [activePortDropdown, setActivePortDropdown] = useState<string | null>(null);
  const [portFilterQuery, setPortFilterQuery] = useState("");
  const [isProcessing, setIsProcessing] = useState<boolean>(false);
  const [processingCardName, setProcessingCardName] = useState<string>("");

  const handlePortSelect = (cardId: string, port: string) => {
    setSelectedPorts((prev) => ({ ...prev, [cardId]: port }));
    setActivePortDropdown(null);
    setPortFilterQuery("");
  };

  const handleArrowClick = (card: ProcessCardConfig) => {
    const port = selectedPorts[card.id] || card.defaultPort;
    setProcessingCardName(card.title);
    setIsProcessing(true);

    // Realistic processing pause matching Screenshot 4: "Processing your request. Please wait..."
    setTimeout(() => {
      setIsProcessing(false);
      onExecuteProcess(card.actionTarget, port, card.title);
    }, 900);
  };

  const renderIcon = (type: string) => {
    switch (type) {
      case "counter":
        return <Users className="w-7 h-7 text-amber-700" />;
      case "payment":
        return (
          <div className="flex items-center justify-center font-bold text-base text-rose-700 font-mono tracking-tighter">
            {currencySymbol.trim() || "₹"}
          </div>
        );
      case "esb":
        return <Share2 className="w-6 h-6 text-purple-700" />;
      case "form13":
        return <FileCheck2 className="w-6 h-6 text-emerald-700" />;
      case "hbl":
        return <FileText className="w-6 h-6 text-sky-700" />;
      case "vgm":
        return <Boxes className="w-6 h-6 text-[#6e5d4f]" />;
      default:
        return <FileText className="w-6 h-6" />;
    }
  };

  return (
    <div className="w-full max-w-7xl mx-auto px-4 sm:px-6 py-6 select-none relative">
      {/* Breadcrumb matching Screenshot 1 */}
      <div className="flex items-center gap-2 mb-6 text-xs font-semibold text-slate-500">
        <span className="text-amber-500 font-bold uppercase tracking-wider">Service</span>
        <span>/</span>
        <span className="text-slate-700 font-medium">Port Clearance Operations</span>
      </div>

      {/* 6 Grid Cards Matching Screenshot 1, 2, 4 */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
        {CARDS_DATA.map((card) => {
          const currentPort = selectedPorts[card.id] || card.defaultPort;
          const isDropdownOpen = activePortDropdown === card.id;

          const filteredPorts = INDIAN_PORTS.filter((p) =>
            p.toLowerCase().includes(portFilterQuery.toLowerCase())
          );

          return (
            <div
              key={card.id}
              className="bg-white rounded-xl shadow-md hover:shadow-xl transition-all duration-200 border border-slate-200 overflow-visible flex flex-col justify-between"
            >
              {/* Header with Title and Optional Sublabels */}
              <div
                className={`${card.headerBg} text-white p-3.5 rounded-t-xl flex flex-col items-center justify-center min-h-[58px] relative`}
              >
                <h3 className="font-bold text-sm tracking-wide text-white drop-shadow-xs">
                  {card.title}
                </h3>

                {card.sublabels && (
                  <div className="flex items-center justify-between w-full px-2 mt-1 text-[11px] font-semibold text-white/90">
                    <span>{card.sublabels.left}</span>
                    <span>{card.sublabels.right}</span>
                  </div>
                )}
              </div>

              {/* Card Body */}
              <div className="p-4 flex flex-col items-center flex-1 justify-center space-y-4">
                {/* Round Circular Icon in Center */}
                <div
                  className={`w-14 h-14 rounded-full ${card.circleBg} border-2 border-white shadow-xs flex items-center justify-center`}
                >
                  {renderIcon(card.icon)}
                </div>

                {/* Port Selector and Arrow Action Button Row */}
                <div className="w-full flex items-center gap-2 relative">
                  {/* Port Selector Input Box */}
                  <div className="relative flex-1">
                    <button
                      type="button"
                      onClick={() => {
                        setActivePortDropdown(isDropdownOpen ? null : card.id);
                        setPortFilterQuery("");
                      }}
                      className="w-full px-3 py-2 text-xs font-semibold text-slate-800 bg-slate-50 border border-slate-300 rounded-md flex items-center justify-between hover:bg-slate-100 transition-colors cursor-pointer text-left shadow-2xs"
                    >
                      <span className="truncate">{currentPort}</span>
                      <ChevronDown className="w-3.5 h-3.5 text-slate-500 shrink-0 ml-1" />
                    </button>

                    {/* Port Dropdown Menu Matching Screenshot 3 */}
                    {isDropdownOpen && (
                      <div className="absolute top-full left-0 mt-1 w-56 bg-white rounded-md shadow-2xl border border-slate-300 z-50 py-1 max-h-60 overflow-hidden flex flex-col animate-in fade-in duration-150">
                        {/* Search input in port selector */}
                        <div className="p-1.5 border-b border-slate-200 sticky top-0 bg-white">
                          <div className="flex items-center px-2 py-1 bg-slate-100 rounded border border-slate-300">
                            <Search className="w-3.5 h-3.5 text-slate-400 mr-1.5" />
                            <input
                              type="text"
                              autoFocus
                              value={portFilterQuery}
                              onChange={(e) => setPortFilterQuery(e.target.value)}
                              placeholder="Filter port..."
                              className="w-full text-xs bg-transparent focus:outline-hidden text-slate-700"
                            />
                          </div>
                        </div>

                        {/* Port Options List with scrollbar */}
                        <div className="overflow-y-auto max-h-48 py-0.5">
                          {filteredPorts.length === 0 ? (
                            <div className="px-3 py-2 text-xs text-slate-400 text-center">
                              No matching port
                            </div>
                          ) : (
                            filteredPorts.map((port) => (
                              <button
                                key={port}
                                type="button"
                                onClick={() => handlePortSelect(card.id, port)}
                                className={`w-full text-left px-3 py-1.5 text-xs font-medium transition-colors cursor-pointer flex items-center justify-between ${
                                  port === currentPort
                                    ? "bg-[#0098db] text-white font-bold"
                                    : "text-slate-700 hover:bg-sky-50 hover:text-[#0098db]"
                                }`}
                              >
                                <span>{port}</span>
                                {port === currentPort && (
                                  <CheckCircle2 className="w-3.5 h-3.5 text-white" />
                                )}
                              </button>
                            ))
                          )}
                        </div>
                      </div>
                    )}
                  </div>

                  {/* Circular Arrow Button from Screenshot 1 & 2 */}
                  <button
                    type="button"
                    onClick={() => handleArrowClick(card)}
                    title={`Process ${card.title} for ${currentPort}`}
                    className={`w-9 h-9 rounded-full ${card.arrowBg} text-white flex items-center justify-center shrink-0 shadow-md transition-all duration-200 hover:scale-105 active:scale-95 cursor-pointer`}
                  >
                    <ArrowRight className="w-4 h-4 font-bold" />
                  </button>
                </div>
              </div>

              {/* Subtle card bottom tag */}
              <div className="px-3 py-1.5 bg-slate-50 border-t border-slate-100 rounded-b-xl text-[10px] text-slate-500 text-center font-mono">
                Port Clearance Gate Ready
              </div>
            </div>
          );
        })}
      </div>

      {/* 3. Authentic Circular Green Loading Overlay (Matching Screenshot 4) */}
      {isProcessing && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-xs z-50 flex items-center justify-center animate-in fade-in duration-150">
          <div className="bg-white px-8 py-6 rounded-2xl shadow-2xl flex flex-col items-center space-y-4 max-w-sm border border-slate-200">
            {/* Spinning Green Daisy Wheel / Circle Loader */}
            <div className="relative w-16 h-16 flex items-center justify-center">
              <div className="absolute inset-0 rounded-full border-4 border-slate-200 border-t-emerald-500 border-r-emerald-500 animate-spin"></div>
              <Sparkles className="w-6 h-6 text-emerald-500" />
            </div>

            <div className="text-center">
              <h4 className="text-sm font-bold text-slate-800">
                Processing your request. Please wait...
              </h4>
              <p className="text-xs text-slate-500 mt-1 font-mono">
                Routing {processingCardName} to Port Gate Gateway
              </p>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
