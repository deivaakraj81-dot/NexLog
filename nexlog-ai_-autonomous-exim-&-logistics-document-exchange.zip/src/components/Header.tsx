import React from "react";
import { Ship, Radio, Cpu, ShieldCheck, Clock, Terminal } from "lucide-react";

interface HeaderProps {
  onOpenQuickScan: () => void;
  pendingCount: number;
}

export const Header: React.FC<HeaderProps> = ({ onOpenQuickScan, pendingCount }) => {
  return (
    <header className="sticky top-0 z-30 bg-slate-900/90 backdrop-blur-md border-b border-slate-800 px-6 py-3.5 flex flex-wrap items-center justify-between gap-4">
      {/* Brand & Terminal Identifier */}
      <div className="flex items-center gap-3">
        <div className="relative flex items-center justify-center w-10 h-10 rounded-xl bg-gradient-to-tr from-blue-600 via-blue-500 to-emerald-400 p-0.5 shadow-lg shadow-blue-500/20">
          <div className="w-full h-full bg-slate-950 rounded-[10px] flex items-center justify-center">
            <Ship className="w-5 h-5 text-blue-400" />
          </div>
          <span className="absolute -bottom-1 -right-1 flex h-3 w-3">
            <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
            <span className="relative inline-flex rounded-full h-3 w-3 bg-emerald-500 border-2 border-slate-900"></span>
          </span>
        </div>

        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-lg font-bold tracking-tight text-white flex items-center gap-1.5">
              <span>NexLog</span>
              <span className="text-transparent bg-clip-text bg-gradient-to-r from-blue-400 to-emerald-400 font-extrabold">
                AI
              </span>
            </h1>
            <span className="px-2 py-0.5 rounded-full text-[10px] font-semibold tracking-wider uppercase bg-blue-950/80 text-blue-300 border border-blue-800/60">
              Enterprise EXIM
            </span>
            <span className="hidden sm:inline-flex px-2 py-0.5 rounded-full text-[10px] font-semibold tracking-wider uppercase bg-emerald-950/80 text-emerald-300 border border-emerald-800/60">
              NexLog PCS 1x Ready
            </span>
          </div>
          <p className="text-xs text-slate-400 font-medium">
            Autonomous EXIM & Logistics Document Exchange • Port of Nhava Sheva (INNSA)
          </p>
        </div>
      </div>

      {/* Integration Status Badges & Quick Action */}
      <div className="flex items-center gap-3">
        {/* Gemini Engine Badge */}
        <div className="hidden lg:flex items-center gap-2 px-3 py-1.5 rounded-lg bg-slate-950/70 border border-slate-800 text-xs">
          <Cpu className="w-3.5 h-3.5 text-blue-400 animate-pulse" />
          <span className="text-slate-400">Model:</span>
          <span className="font-mono font-medium text-blue-300">gemini-3.8-flash</span>
          <span className="w-1.5 h-1.5 rounded-full bg-emerald-400"></span>
        </div>

        {/* PCS 1x Feed Status */}
        <div className="hidden md:flex items-center gap-2 px-3 py-1.5 rounded-lg bg-slate-950/70 border border-slate-800 text-xs">
          <Radio className="w-3.5 h-3.5 text-emerald-400" />
          <span className="text-slate-400">EDIFACT TOS:</span>
          <span className="font-medium text-emerald-300">Live 99.98%</span>
        </div>

        {/* Quick Launch Scanner Button */}
        <button
          onClick={onOpenQuickScan}
          className="flex items-center gap-2 px-3.5 py-1.5 rounded-lg bg-gradient-to-r from-blue-600 to-blue-500 hover:from-blue-500 hover:to-blue-400 text-white font-medium text-xs shadow-md shadow-blue-600/30 transition-all hover:scale-[1.02] active:scale-[0.98]"
        >
          <Terminal className="w-3.5 h-3.5" />
          <span>New AI Intake</span>
        </button>

        {/* User Pill */}
        <div className="flex items-center gap-2.5 pl-2 border-l border-slate-800">
          <div className="w-8 h-8 rounded-lg bg-slate-800 border border-slate-700 flex items-center justify-center font-bold text-xs text-blue-300">
            DK
          </div>
          <div className="hidden sm:block text-left text-xs leading-tight">
            <div className="font-semibold text-slate-200">Devraj K.</div>
            <div className="text-[10px] text-slate-400">Lead Gate Officer</div>
          </div>
        </div>
      </div>
    </header>
  );
};
