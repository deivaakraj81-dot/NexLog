import React, { useState, useRef } from "react";
import {
  UploadCloud,
  FileText,
  AlertTriangle,
  CheckCircle2,
  XCircle,
  Sparkles,
  ArrowRight,
  ShieldAlert,
  ShieldCheck,
  Scale,
  Anchor,
  Box,
  Hash,
  Send,
  RefreshCw,
  Code2,
  Layers,
  FileCheck,
  Info,
} from "lucide-react";
import { SAMPLE_DOCUMENTS, SampleDoc } from "../data/sampleDocuments";
import { ShippingAuditResult, QueueItem } from "../types";

interface DocumentScannerProps {
  onAuditComplete: (result: ShippingAuditResult, rawText: string) => void;
  onSendToQueue: (item: QueueItem) => void;
  onViewJson: (result: ShippingAuditResult) => void;
}

export const DocumentScanner: React.FC<DocumentScannerProps> = ({
  onAuditComplete,
  onSendToQueue,
  onViewJson,
}) => {
  const [documentText, setDocumentText] = useState<string>(SAMPLE_DOCUMENTS[0].content);
  const [selectedSampleId, setSelectedSampleId] = useState<string>(SAMPLE_DOCUMENTS[0].id);
  const [isScanning, setIsScanning] = useState<boolean>(false);
  const [scanStep, setScanStep] = useState<number>(0);
  const [auditResult, setAuditResult] = useState<ShippingAuditResult | null>(null);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [isDragging, setIsDragging] = useState<boolean>(false);
  const [uploadedFileName, setUploadedFileName] = useState<string>("Sample_Bill_of_Lading.txt");
  const [hasSentToQueue, setHasSentToQueue] = useState<boolean>(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  // Load preset sample document
  const handleLoadSample = (sample: SampleDoc) => {
    setSelectedSampleId(sample.id);
    setDocumentText(sample.content);
    setUploadedFileName(`${sample.name.replace(/\s+/g, "_")}.txt`);
    setAuditResult(null);
    setErrorMessage(null);
    setHasSentToQueue(false);
  };

  // Handle Drag and Drop
  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(true);
  };

  const handleDragLeave = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
  };

  const handleDrop = async (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
    if (e.dataTransfer.files && e.dataTransfer.files.length > 0) {
      handleFileSelected(e.dataTransfer.files[0]);
    }
  };

  const handleFileSelected = (file: File) => {
    setUploadedFileName(file.name);
    setSelectedSampleId("custom-upload");
    setAuditResult(null);
    setErrorMessage(null);
    setHasSentToQueue(false);

    const reader = new FileReader();
    reader.onload = (event) => {
      const text = event.target?.result as string;
      if (text) {
        setDocumentText(text);
      }
    };
    reader.readAsText(file);
  };

  // Execute Gemini AI Document Audit
  const handleRunAudit = async () => {
    if (!documentText.trim()) {
      setErrorMessage("Please input or load shipping document text before auditing.");
      return;
    }

    setIsScanning(true);
    setScanStep(1);
    setErrorMessage(null);
    setHasSentToQueue(false);

    const stepInterval = setInterval(() => {
      setScanStep((prev) => (prev < 4 ? prev + 1 : prev));
    }, 450);

    try {
      const response = await fetch("/api/gemini/audit-document", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          text: documentText,
          documentTypeHint: SAMPLE_DOCUMENTS.find((d) => d.id === selectedSampleId)?.typeHint,
          fileName: uploadedFileName,
        }),
      });

      if (!response.ok) {
        const errorData = await response.json().catch(() => ({}));
        throw new Error(errorData.error || `Server responded with status ${response.status}`);
      }

      const data: ShippingAuditResult = await response.json();
      data.rawText = documentText;

      setAuditResult(data);
      onAuditComplete(data, documentText);
    } catch (err: any) {
      console.error("Audit error:", err);
      setErrorMessage(err.message || "Failed to audit document with Gemini API.");
    } finally {
      clearInterval(stepInterval);
      setIsScanning(false);
    }
  };

  // Push audited document directly to manager approval queue
  const handlePushToQueue = () => {
    if (!auditResult) return;

    const newQueueItem: QueueItem = {
      id: `queue-${Date.now()}`,
      docId: auditResult.metadata.documentNumber || `DOC-${Math.floor(1000 + Math.random() * 9000)}`,
      documentType: auditResult.documentClassification,
      shipper: auditResult.metadata.shipperName || "Unknown Shipper",
      consignee: auditResult.metadata.consigneeName || "Unknown Consignee",
      vessel: `${auditResult.metadata.vesselName} / ${auditResult.metadata.voyageNumber}`,
      containerId: auditResult.metadata.containerId || "CONTAINER-PENDING",
      riskScore: auditResult.riskAssessment.riskScore,
      riskLevel: auditResult.riskAssessment.riskLevel,
      aiRecommendation: auditResult.riskAssessment.recommendedAction,
      status: "PENDING_APPROVAL",
      submittedAt: "Just now",
      auditResult: auditResult,
      rawText: documentText,
    };

    onSendToQueue(newQueueItem);
    setHasSentToQueue(true);
  };

  return (
    <div className="space-y-6">
      {/* Top Banner & Context */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 p-5 rounded-2xl bg-gradient-to-r from-slate-900 via-slate-900 to-blue-950/60 border border-slate-800">
        <div>
          <div className="flex items-center gap-2">
            <span className="px-2.5 py-0.5 rounded-full text-xs font-bold uppercase tracking-wider bg-blue-500/20 text-blue-300 border border-blue-500/30">
              Core Feature 1
            </span>
            <h2 className="text-xl font-bold text-white tracking-tight">
              Interactive Document Scanner & AI Intake
            </h2>
          </div>
          <p className="text-xs text-slate-400 mt-1">
            Multimodal document parser powered by Google Gemini (gemini-3.8-flash). Detects container weights, SOLAS compliance, seal tampering, and manifest discrepancies in milliseconds.
          </p>
        </div>

        <button
          onClick={handleRunAudit}
          disabled={isScanning}
          className={`flex items-center justify-center gap-2.5 px-6 py-3 rounded-xl font-bold text-sm text-white shadow-lg shadow-blue-600/30 transition-all ${
            isScanning
              ? "bg-slate-700 cursor-not-allowed text-slate-300"
              : "bg-gradient-to-r from-blue-600 via-blue-500 to-emerald-500 hover:from-blue-500 hover:to-emerald-400 hover:scale-[1.02] active:scale-[0.98]"
          }`}
        >
          {isScanning ? (
            <>
              <RefreshCw className="w-4 h-4 animate-spin text-blue-300" />
              <span>Auditing with Gemini 3.8...</span>
            </>
          ) : (
            <>
              <Sparkles className="w-4 h-4 text-emerald-300" />
              <span>Run Gemini AI Compliance Audit</span>
            </>
          )}
        </button>
      </div>

      {/* Preset Sample Document Buttons */}
      <div className="space-y-2">
        <div className="flex items-center justify-between">
          <span className="text-xs font-semibold uppercase tracking-wider text-slate-400">
            Preset Real-World EXIM Test Manifests (Click to Load)
          </span>
          <span className="text-xs text-blue-400 font-mono">NexLog PCS 1x Standard Feeds</span>
        </div>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
          {SAMPLE_DOCUMENTS.map((sample) => {
            const isSelected = selectedSampleId === sample.id;
            return (
              <button
                key={sample.id}
                onClick={() => handleLoadSample(sample)}
                className={`p-3.5 rounded-xl border text-left transition-all ${
                  isSelected
                    ? "bg-slate-800/90 border-blue-500 shadow-md shadow-blue-500/10 ring-1 ring-blue-500/50"
                    : "bg-slate-900/70 border-slate-800 hover:border-slate-700 hover:bg-slate-800/40"
                }`}
              >
                <div className="flex items-center justify-between mb-1.5">
                  <span className="text-xs font-bold text-slate-200">{sample.name}</span>
                  <span className={`text-[10px] px-2 py-0.5 rounded-md font-semibold border ${sample.badgeColor}`}>
                    {sample.badge}
                  </span>
                </div>
                <p className="text-[11px] text-slate-400 line-clamp-2 leading-relaxed">
                  {sample.description}
                </p>
              </button>
            );
          })}
        </div>
      </div>

      {/* Intake Grid: Drag-and-drop & Raw Document View */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left Column: Drag & Drop Zone + Raw Manifest Editor (5 cols) */}
        <div className="lg:col-span-5 space-y-4">
          {/* Dropzone */}
          <div
            onDragOver={handleDragOver}
            onDragLeave={handleDragLeave}
            onDrop={handleDrop}
            onClick={() => fileInputRef.current?.click()}
            className={`p-6 rounded-2xl border-2 border-dashed transition-all cursor-pointer flex flex-col items-center justify-center text-center ${
              isDragging
                ? "border-blue-400 bg-blue-950/30 scale-[1.01]"
                : "border-slate-700/80 bg-slate-900/60 hover:border-blue-500/60 hover:bg-slate-900/90"
            }`}
          >
            <input
              type="file"
              ref={fileInputRef}
              onChange={(e) => e.target.files && handleFileSelected(e.target.files[0])}
              className="hidden"
              accept=".txt,.pdf,.csv,.json,.edi,.xml,image/*"
            />
            <div className="w-12 h-12 rounded-xl bg-blue-950/80 border border-blue-800/60 flex items-center justify-center text-blue-400 mb-3 shadow-inner">
              <UploadCloud className="w-6 h-6" />
            </div>
            <div className="text-sm font-semibold text-slate-200">
              Drag & drop document or <span className="text-blue-400 underline">browse files</span>
            </div>
            <p className="text-xs text-slate-400 mt-1">
              Supports Bill of Lading, VGM Slips, Form 13 Gate Passes (.pdf, .txt, .edi, .xml)
            </p>
            <div className="mt-3 flex items-center gap-2 text-[11px] font-mono text-emerald-400 bg-emerald-950/50 px-2.5 py-1 rounded-md border border-emerald-800/40">
              <FileCheck className="w-3.5 h-3.5" />
              <span>Loaded: {uploadedFileName}</span>
            </div>
          </div>

          {/* Raw Text Inspector & Editor */}
          <div className="rounded-2xl bg-slate-900/90 border border-slate-800 overflow-hidden shadow-lg">
            <div className="px-4 py-3 bg-slate-950/60 border-b border-slate-800 flex items-center justify-between">
              <div className="flex items-center gap-2 text-xs font-semibold text-slate-300">
                <FileText className="w-4 h-4 text-blue-400" />
                <span>Raw Document Content (Live Editable)</span>
              </div>
              <span className="text-[10px] text-slate-400 font-mono">
                {documentText.length} chars
              </span>
            </div>
            <div className="p-3">
              <textarea
                value={documentText}
                onChange={(e) => {
                  setDocumentText(e.target.value);
                  setAuditResult(null);
                  setHasSentToQueue(false);
                }}
                rows={13}
                placeholder="Paste ocean bill of lading, weighbridge ticket, or port customs declaration text here..."
                className="w-full bg-slate-950 border border-slate-800 rounded-xl p-3 text-xs font-mono text-slate-300 focus:outline-none focus:border-blue-500 focus:ring-1 focus:ring-blue-500 transition-all leading-relaxed resize-none"
              />
              <div className="mt-2 flex items-center justify-between text-[11px] text-slate-400">
                <span className="flex items-center gap-1 text-slate-400">
                  <Info className="w-3.5 h-3.5 text-blue-400 shrink-0" />
                  Tip: You can edit numbers to test weight discrepancies or missing seal flags.
                </span>
              </div>
            </div>
          </div>
        </div>

        {/* Right Column: AI Audit Results & Risk Engine (7 cols) */}
        <div className="lg:col-span-7 space-y-4">
          {/* Scanning Animation State */}
          {isScanning && (
            <div className="p-8 rounded-2xl bg-slate-900/90 border border-blue-500/40 shadow-xl space-y-6 animate-pulse">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-blue-600/20 border border-blue-500/40 flex items-center justify-center text-blue-400">
                  <RefreshCw className="w-5 h-5 animate-spin" />
                </div>
                <div>
                  <h3 className="text-base font-bold text-white">
                    Google Gemini 3.8 Flash Autonomous Document Audit in Progress
                  </h3>
                  <p className="text-xs text-slate-400">
                    Executing structured schema parsing, SOLAS weight verification, and customs rules...
                  </p>
                </div>
              </div>

              {/* Progress Stepper */}
              <div className="space-y-3 pt-2">
                {[
                  { step: 1, label: "Ingesting OCR / Manifest Stream & Normalizing Container IDs" },
                  { step: 2, label: "Prompting Gemini 3.8 Flash with Strict Enterprise EXIM Schema" },
                  { step: 3, label: "Cross-auditing IMO SOLAS Chapter VI & ISO 17712 Bolt Seal Rules" },
                  { step: 4, label: "Synthesizing Risk Score & Generating Terminal Pre-Advice Payload" },
                ].map((s) => (
                  <div key={s.step} className="flex items-center gap-3 text-xs">
                    <div
                      className={`w-6 h-6 rounded-full flex items-center justify-center font-bold font-mono text-[11px] ${
                        scanStep >= s.step
                          ? "bg-emerald-500 text-slate-950"
                          : "bg-slate-800 text-slate-400 border border-slate-700"
                      }`}
                    >
                      {scanStep > s.step ? "✓" : s.step}
                    </div>
                    <span
                      className={
                        scanStep >= s.step ? "text-slate-200 font-medium" : "text-slate-400"
                      }
                    >
                      {s.label}
                    </span>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Error Message */}
          {errorMessage && (
            <div className="p-4 rounded-xl bg-rose-950/60 border border-rose-800/80 text-rose-200 text-xs flex items-center gap-3">
              <AlertTriangle className="w-5 h-5 text-rose-400 shrink-0" />
              <div>
                <div className="font-semibold">Audit Execution Notice</div>
                <div>{errorMessage}</div>
              </div>
            </div>
          )}

          {/* Audit Result Display */}
          {auditResult && !isScanning && (
            <div className="space-y-4 animate-in fade-in-50 duration-300">
              {/* Classification & Decision Header Banner */}
              <div
                className={`p-5 rounded-2xl border shadow-xl flex flex-wrap items-center justify-between gap-4 ${
                  auditResult.riskAssessment.riskLevel === "LOW"
                    ? "bg-emerald-950/40 border-emerald-800/60 text-emerald-100"
                    : auditResult.riskAssessment.riskLevel === "MEDIUM"
                    ? "bg-amber-950/40 border-amber-800/60 text-amber-100"
                    : "bg-rose-950/40 border-rose-800/60 text-rose-100"
                }`}
              >
                <div>
                  <div className="flex items-center gap-2 mb-1">
                    <span className="text-xs font-semibold uppercase tracking-wider text-slate-300">
                      Document Classification:
                    </span>
                    <span className="font-bold text-white text-base">
                      {auditResult.documentClassification}
                    </span>
                    <span className="text-[10px] px-2 py-0.5 rounded-full bg-slate-900 border border-slate-700 font-mono text-blue-300">
                      {auditResult.confidenceScore}% confidence
                    </span>
                  </div>
                  <div className="text-xs text-slate-300 flex items-center gap-3">
                    <span>Doc Ref: <strong className="text-white font-mono">{auditResult.metadata.documentNumber}</strong></span>
                    <span>•</span>
                    <span>Audited By: <strong className="text-blue-300">{auditResult.analyzedBy}</strong></span>
                  </div>
                </div>

                {/* Risk Gauge Badge */}
                <div className="flex items-center gap-4">
                  <div className="text-right">
                    <div className="text-[10px] uppercase font-bold text-slate-400">Gemini Risk Score</div>
                    <div className="text-2xl font-black font-mono">
                      {auditResult.riskAssessment.riskScore}
                      <span className="text-xs font-normal text-slate-400">/100</span>
                    </div>
                  </div>

                  <div
                    className={`px-4 py-2 rounded-xl font-extrabold text-xs uppercase tracking-wider border shadow-md flex items-center gap-1.5 ${
                      auditResult.riskAssessment.recommendedAction === "Approve"
                        ? "bg-emerald-600 text-white border-emerald-400 shadow-emerald-900/40"
                        : auditResult.riskAssessment.recommendedAction === "Needs Manual Review"
                        ? "bg-amber-600 text-white border-amber-400 shadow-amber-900/40"
                        : "bg-rose-600 text-white border-rose-400 shadow-rose-900/40"
                    }`}
                  >
                    {auditResult.riskAssessment.recommendedAction === "Approve" && (
                      <CheckCircle2 className="w-4 h-4" />
                    )}
                    {auditResult.riskAssessment.recommendedAction === "Needs Manual Review" && (
                      <AlertTriangle className="w-4 h-4" />
                    )}
                    {auditResult.riskAssessment.recommendedAction === "Reject" && (
                      <XCircle className="w-4 h-4" />
                    )}
                    <span>{auditResult.riskAssessment.recommendedAction}</span>
                  </div>
                </div>
              </div>

              {/* Extracted Metadata Grid */}
              <div className="p-4 rounded-2xl bg-slate-900/90 border border-slate-800 space-y-3">
                <div className="flex items-center justify-between pb-2 border-b border-slate-800">
                  <span className="text-xs font-bold text-slate-200 uppercase tracking-wider flex items-center gap-1.5">
                    <Box className="w-4 h-4 text-blue-400" />
                    Autonomous Metadata Extraction (ISO / PCS 1x Standard)
                  </span>
                  <span className="text-[10px] font-mono text-emerald-400 bg-emerald-950/60 px-2 py-0.5 rounded border border-emerald-800/40">
                    Valid ISO 6346 Format
                  </span>
                </div>

                <div className="grid grid-cols-2 sm:grid-cols-3 gap-3 text-xs">
                  <div className="p-2.5 rounded-xl bg-slate-950/70 border border-slate-800">
                    <span className="text-[10px] text-slate-400 uppercase block">Container ID</span>
                    <span className="font-bold font-mono text-blue-300 text-sm">
                      {auditResult.metadata.containerId}
                    </span>
                  </div>

                  <div className="p-2.5 rounded-xl bg-slate-950/70 border border-slate-800">
                    <span className="text-[10px] text-slate-400 uppercase block">Gross Weight</span>
                    <span className="font-bold font-mono text-slate-100 text-sm">
                      {auditResult.metadata.grossWeightKg.toLocaleString()} KG
                    </span>
                  </div>

                  <div className="p-2.5 rounded-xl bg-slate-950/70 border border-slate-800">
                    <span className="text-[10px] text-slate-400 uppercase block">Customs Bolt Seal</span>
                    <span
                      className={`font-bold font-mono text-xs ${
                        auditResult.metadata.sealNumber.includes("MISSING") ||
                        auditResult.metadata.sealNumber.includes("DAMAGED")
                          ? "text-rose-400"
                          : "text-emerald-300"
                      }`}
                    >
                      {auditResult.metadata.sealNumber}
                    </span>
                  </div>

                  <div className="p-2.5 rounded-xl bg-slate-950/70 border border-slate-800">
                    <span className="text-[10px] text-slate-400 uppercase block">Vessel & Voyage</span>
                    <span className="font-semibold text-slate-200 truncate block">
                      {auditResult.metadata.vesselName} / {auditResult.metadata.voyageNumber}
                    </span>
                  </div>

                  <div className="p-2.5 rounded-xl bg-slate-950/70 border border-slate-800">
                    <span className="text-[10px] text-slate-400 uppercase block">Port of Loading (POL)</span>
                    <span className="font-semibold text-slate-200 truncate block">
                      {auditResult.metadata.portOfLoading}
                    </span>
                  </div>

                  <div className="p-2.5 rounded-xl bg-slate-950/70 border border-slate-800">
                    <span className="text-[10px] text-slate-400 uppercase block">Port of Discharge (POD)</span>
                    <span className="font-semibold text-slate-200 truncate block">
                      {auditResult.metadata.portOfDischarge}
                    </span>
                  </div>

                  <div className="p-2.5 rounded-xl bg-slate-950/70 border border-slate-800 col-span-2 sm:col-span-2">
                    <span className="text-[10px] text-slate-400 uppercase block">Shipper / Exporter</span>
                    <span className="font-semibold text-slate-200 truncate block">
                      {auditResult.metadata.shipperName}
                    </span>
                  </div>

                  <div className="p-2.5 rounded-xl bg-slate-950/70 border border-slate-800">
                    <span className="text-[10px] text-slate-400 uppercase block">HS Tariff Code</span>
                    <span className="font-mono text-slate-200 font-semibold">
                      {auditResult.metadata.hsCode || "8471.30.00"}
                    </span>
                  </div>
                </div>
              </div>

              {/* Risk & Compliance Assessment Section */}
              <div className="p-4 rounded-2xl bg-slate-900/90 border border-slate-800 space-y-3">
                <div className="flex items-center justify-between pb-2 border-b border-slate-800">
                  <span className="text-xs font-bold text-slate-200 uppercase tracking-wider flex items-center gap-1.5">
                    <ShieldAlert className="w-4 h-4 text-amber-400" />
                    Regulatory Compliance & Weight Verification
                  </span>
                  <span className="text-[10px] text-slate-400">IMO MSC.1/Circ.1475 Standards</span>
                </div>

                {/* Executive Summary */}
                <div className="p-3 rounded-xl bg-slate-950/80 border border-slate-800 text-xs text-slate-300 leading-relaxed">
                  <strong className="text-slate-100 block mb-1">AI Audit Synthesis:</strong>
                  {auditResult.riskAssessment.summary}
                </div>

                {/* Discrepancies if any */}
                {auditResult.riskAssessment.discrepancies.length > 0 && (
                  <div className="p-3 rounded-xl bg-rose-950/30 border border-rose-800/60 space-y-1.5">
                    <div className="text-xs font-bold text-rose-300 flex items-center gap-1.5">
                      <AlertTriangle className="w-3.5 h-3.5" />
                      Detected Non-Compliance & Field Discrepancies:
                    </div>
                    <ul className="list-disc list-inside text-xs text-rose-200 space-y-1">
                      {auditResult.riskAssessment.discrepancies.map((disc, idx) => (
                        <li key={idx}>{disc}</li>
                      ))}
                    </ul>
                  </div>
                )}

                {/* Compliance Checks Checklist */}
                <div className="space-y-1.5">
                  <div className="text-[11px] font-semibold uppercase tracking-wider text-slate-400">
                    Compliance Verification Matrix
                  </div>
                  <div className="space-y-1">
                    {auditResult.riskAssessment.complianceChecks.map((check, idx) => {
                      const isPass = check.status === "PASS";
                      const isWarn = check.status === "WARN";
                      return (
                        <div
                          key={idx}
                          className="flex items-start justify-between p-2 rounded-lg bg-slate-950/60 border border-slate-800/80 text-xs"
                        >
                          <div className="space-y-0.5">
                            <div className="font-semibold text-slate-200 flex items-center gap-1.5">
                              <span>{check.category}</span>
                              <span className="text-[10px] text-slate-400 font-mono">({check.regulation})</span>
                            </div>
                            <div className="text-slate-400 text-[11px]">{check.finding}</div>
                          </div>
                          <span
                            className={`px-2 py-0.5 rounded text-[10px] font-bold font-mono uppercase ${
                              isPass
                                ? "bg-emerald-950 text-emerald-300 border border-emerald-800/60"
                                : isWarn
                                ? "bg-amber-950 text-amber-300 border border-amber-800/60"
                                : "bg-rose-950 text-rose-300 border border-rose-800/60"
                            }`}
                          >
                            {check.status}
                          </span>
                        </div>
                      );
                    })}
                  </div>
                </div>

                {/* Manager Decision Recommendation Notes */}
                <div className="p-3 rounded-xl bg-blue-950/30 border border-blue-800/50 text-xs text-blue-200 flex items-start gap-2.5">
                  <Info className="w-4 h-4 text-blue-400 shrink-0 mt-0.5" />
                  <div>
                    <span className="font-bold text-blue-300 block">Terminal Gate Superintendent Recommendation:</span>
                    <span>{auditResult.managerNotes}</span>
                  </div>
                </div>
              </div>

              {/* Action Bar */}
              <div className="p-4 rounded-2xl bg-slate-900/90 border border-slate-800 flex flex-wrap items-center justify-between gap-3">
                <button
                  onClick={() => onViewJson(auditResult)}
                  className="flex items-center gap-2 px-3.5 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white text-xs font-semibold border border-slate-700 transition-colors"
                >
                  <Code2 className="w-4 h-4 text-blue-400" />
                  <span>Inspect Raw Gemini JSON</span>
                </button>

                <div className="flex items-center gap-3">
                  <button
                    onClick={handlePushToQueue}
                    disabled={hasSentToQueue}
                    className={`flex items-center gap-2 px-5 py-2.5 rounded-xl font-bold text-xs shadow-md transition-all ${
                      hasSentToQueue
                        ? "bg-slate-800 text-slate-400 cursor-not-allowed border border-slate-700"
                        : "bg-blue-600 hover:bg-blue-500 text-white shadow-blue-600/30 hover:scale-[1.02]"
                    }`}
                  >
                    <Send className="w-3.5 h-3.5" />
                    <span>{hasSentToQueue ? "Added to Approval Queue ✓" : "Send to Human Approval Queue"}</span>
                  </button>
                </div>
              </div>
            </div>
          )}

          {/* Placeholder state before scanning */}
          {!auditResult && !isScanning && (
            <div className="p-12 rounded-2xl bg-slate-900/50 border border-slate-800/80 text-center space-y-4">
              <div className="w-16 h-16 rounded-2xl bg-slate-800/60 border border-slate-700/80 flex items-center justify-center text-blue-400 mx-auto">
                <Scale className="w-8 h-8" />
              </div>
              <div className="max-w-md mx-auto">
                <h3 className="text-base font-bold text-slate-200">
                  Autonomous Compliance Intake Ready
                </h3>
                <p className="text-xs text-slate-400 mt-1 leading-relaxed">
                  Select a test manifest above or paste custom shipping text, then click{" "}
                  <strong className="text-blue-400">"Run Gemini AI Compliance Audit"</strong> to execute real-time IMO SOLAS and Port Gate validation.
                </p>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
