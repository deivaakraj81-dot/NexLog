import React, { useState } from "react";
import {
  CreditCard,
  Plus,
  Search,
  Download,
  CheckCircle2,
  AlertCircle,
  FileText,
  DollarSign,
  ArrowLeft,
  Building,
  Building2,
  Receipt,
  Check,
  Landmark,
  ShieldCheck,
  Lock,
  ArrowRight,
  Printer,
  Copy,
  QrCode,
  Smartphone,
  ExternalLink,
  RefreshCw,
  X,
  FileCheck,
  ShieldAlert,
} from "lucide-react";
import confetti from "canvas-confetti";
import { CountryNode } from "./OdexTopBar";
import { copyTableToClipboard, downloadTableAsCSV, openPrintableTableReport } from "../utils/tableExport";

export interface InvoiceRecord {
  id: string;
  invoiceRef: string;
  invoiceDate: string;
  linerName: string;
  blNo: string;
  category: "Terminal Handling (THC)" | "Ocean Freight" | "Demurrage & Detention" | "DO Issuance Fee";
  location: string;
  currency: string;
  baseAmount: number;
  gstAmount: number;
  totalAmount: number;
  paymentStatus: "Paid" | "Pending Payment" | "Under Reconciliation";
  utrNumber?: string;
  paidAt?: string;
  containerNo?: string;
}

const INITIAL_INVOICES: InvoiceRecord[] = [
  {
    id: "inv-1",
    invoiceRef: "INV-KMTC-2026-9921",
    invoiceDate: "2026-11-03",
    linerName: "KMTC LINE",
    blNo: "KMTCXGG3096868",
    category: "Terminal Handling (THC)",
    location: "Nhava Sheva",
    currency: "INR",
    baseAmount: 38500,
    gstAmount: 6930,
    totalAmount: 45430,
    paymentStatus: "Paid",
    utrNumber: "UTR-SBIN2630718921",
    paidAt: "2026-11-03 09:42:15 IST",
    containerNo: "KMTC8829104 / 40HC",
  },
  {
    id: "inv-2",
    invoiceRef: "INV-MSC-2026-3841",
    invoiceDate: "2026-11-02",
    linerName: "MSC MEDITERRANEAN",
    blNo: "MEDUAFW55891",
    category: "DO Issuance Fee",
    location: "Mundra",
    currency: "INR",
    baseAmount: 18000,
    gstAmount: 3240,
    totalAmount: 21240,
    paymentStatus: "Pending Payment",
    containerNo: "MEDU4928172 / 20GP",
  },
  {
    id: "inv-3",
    invoiceRef: "INV-MAE-2026-7712",
    invoiceDate: "2026-11-01",
    linerName: "MAERSK LINE",
    blNo: "MAEU98214470",
    category: "Ocean Freight",
    location: "Chennai",
    currency: "INR",
    baseAmount: 125000,
    gstAmount: 22500,
    totalAmount: 147500,
    paymentStatus: "Under Reconciliation",
    containerNo: "MSKU7719203 / 40HC",
  },
];

interface IndianBank {
  id: string;
  name: string;
  shortName: string;
  popular: boolean;
  type: "Corporate" | "Retail & Corporate";
  color: string;
  tagline: string;
}

const INDIAN_BANKS: IndianBank[] = [
  { id: "sbi", name: "State Bank of India (SBI)", shortName: "SBI", popular: true, type: "Corporate", color: "bg-[#0b5c96] text-white", tagline: "CINB & YONO Business" },
  { id: "hdfc", name: "HDFC Bank Corporate NetBanking", shortName: "HDFC", popular: true, type: "Corporate", color: "bg-[#004c8f] text-white", tagline: "eNet & Trade OnLine" },
  { id: "icici", name: "ICICI Bank Corporate Internet Banking", shortName: "ICICI", popular: true, type: "Corporate", color: "bg-[#9c2415] text-white", tagline: "Corporate CIB Gateway" },
  { id: "axis", name: "Axis Bank Corporate Banking", shortName: "AXIS", popular: true, type: "Corporate", color: "bg-[#97144d] text-white", tagline: "Corporate Connect Portal" },
  { id: "kotak", name: "Kotak Mahindra Bank", shortName: "KOTAK", popular: true, type: "Corporate", color: "bg-[#ed1c24] text-white", tagline: "Kotak Corporate Banking" },
  { id: "pnb", name: "Punjab National Bank (PNB)", shortName: "PNB", popular: true, type: "Corporate", color: "bg-[#a20037] text-white", tagline: "PNB Corporate NetBanking" },
  { id: "bob", name: "Bank of Baroda (BoB)", shortName: "BOB", popular: true, type: "Corporate", color: "bg-[#f26522] text-white", tagline: "Baroda Connect Corporate" },
  { id: "canara", name: "Canara Bank", shortName: "CANARA", popular: true, type: "Corporate", color: "bg-[#0089cf] text-white", tagline: "Canara Corporate Gateway" },
  { id: "union", name: "Union Bank of India", shortName: "UNION", popular: false, type: "Corporate", color: "bg-[#d01e25] text-white", tagline: "Union Corporate NetBanking" },
  { id: "idbi", name: "IDBI Bank Corporate", shortName: "IDBI", popular: false, type: "Corporate", color: "bg-[#00605a] text-white", tagline: "IDBI e-Banking" },
  { id: "indusind", name: "IndusInd Bank", shortName: "INDUS", popular: false, type: "Corporate", color: "bg-[#861f41] text-white", tagline: "IndusDirect Corporate" },
  { id: "stanchart", name: "Standard Chartered Bank India", shortName: "SCB", popular: false, type: "Corporate", color: "bg-[#007a3d] text-white", tagline: "Straight2Bank EXIM" },
  { id: "dbs", name: "DBS Bank India", shortName: "DBS", popular: false, type: "Corporate", color: "bg-[#d41420] text-white", tagline: "IDEAL Corporate Banking" },
];

interface InvoiceModuleProps {
  initialView?: "search" | "create";
  onAddToast: (type: "success" | "warning" | "error" | "info", title: string, message: string) => void;
  country?: CountryNode;
  isLoggedIn?: boolean;
  userName?: string;
  companyName?: string;
  onRequireLogin?: () => void;
}

export const InvoiceModule: React.FC<InvoiceModuleProps> = ({
  initialView = "search",
  onAddToast,
  country = { code: "IN", name: "INDIA", flag: "🇮🇳", port: "INNSA", terminal: "Nhava Sheva (JNPT)", currencyCode: "INR", currencySymbol: "₹", rateToInr: 1.0 },
  isLoggedIn = true,
  userName = "John Lanny",
  companyName = "Sudarsen Cargo Pvt Ltd",
  onRequireLogin,
}) => {
  const [view, setView] = useState<"search" | "create">(initialView);
  const [invoices, setInvoices] = useState<InvoiceRecord[]>(INITIAL_INVOICES);
  const [searchQuery, setSearchQuery] = useState("");
  
  // Default selection to invoice 2 (MSC - Pending Payment) so buttons are immediately functional
  const [selectedInvoice, setSelectedInvoice] = useState<InvoiceRecord | null>(INITIAL_INVOICES[1]);

  // Payment Gateway Modal State
  const [showPaymentModal, setShowPaymentModal] = useState(false);
  const [payingInvoice, setPayingInvoice] = useState<InvoiceRecord | null>(null);
  const [paymentTab, setPaymentTab] = useState<"netbanking" | "van" | "upi" | "card">("netbanking");
  const [selectedBank, setSelectedBank] = useState<IndianBank>(INDIAN_BANKS[0]);
  const [bankSearchTerm, setBankSearchTerm] = useState("");
  const [corpUserId, setCorpUserId] = useState("SUDARSEN_CRG_992");
  const [corpPassword, setCorpPassword] = useState("••••••••••••");
  const [paymentStep, setPaymentStep] = useState<"select_bank" | "otp_verify" | "success">("select_bank");
  const [otpValue, setOtpValue] = useState("849201");
  const [isProcessing, setIsProcessing] = useState(false);
  const [lastPaymentResult, setLastPaymentResult] = useState<{ utr: string; timestamp: string } | null>(null);

  // PDF Preview & Download Modal State
  const [showPdfModal, setShowPdfModal] = useState(false);
  const [pdfInvoice, setPdfInvoice] = useState<InvoiceRecord | null>(null);

  // Currency & Tax settings based on active country
  const sym = country.currencySymbol;
  const currCode = country.currencyCode;
  const isIndia = country.code === "IN";
  const taxRate = isIndia ? 0.18 : country.code === "AE" ? 0.05 : country.code === "SG" ? 0.09 : country.code === "US" ? 0.03 : 0.08;
  const taxName = isIndia ? "GST (18% IGST)" : country.code === "AE" ? "VAT (5%)" : country.code === "SG" ? "GST (9%)" : "Port Duty & Surcharge";

  // Form Fields for New Invoice
  const [blNo, setBlNo] = useState("KMTCXGG3096868");
  const [linerName, setLinerName] = useState("KMTC LINE");
  const [location, setLocation] = useState(country.terminal || "Nhava Sheva");
  const [category, setCategory] = useState<InvoiceRecord["category"]>("Terminal Handling (THC)");
  
  const defaultBaseInr = 38500;
  const initialBase = Math.round(defaultBaseInr * country.rateToInr);
  const [baseAmount, setBaseAmount] = useState<number>(initialBase);

  const gst = +(baseAmount * taxRate).toFixed(2);
  const total = +(baseAmount + gst).toFixed(2);

  // Filtered Banks
  const filteredBanks = INDIAN_BANKS.filter(
    (b) =>
      b.name.toLowerCase().includes(bankSearchTerm.toLowerCase()) ||
      b.shortName.toLowerCase().includes(bankSearchTerm.toLowerCase())
  );

  // Open Payment Modal for an invoice
  const handleOpenPayment = (inv?: InvoiceRecord | null) => {
    if (!isLoggedIn) {
      onAddToast(
        "warning",
        "Authentication Required",
        `Only logged-in users (${userName} for ${companyName}) can execute payment transactions. Please log in.`
      );
      onRequireLogin?.();
      return;
    }

    const target = inv || selectedInvoice || invoices.find((i) => i.paymentStatus !== "Paid") || invoices[0];
    if (!target) return;
    
    if (target.paymentStatus === "Paid") {
      onAddToast("info", "Invoice Already Paid", `Invoice ${target.invoiceRef} is already settled via UTR: ${target.utrNumber || "Verified"}.`);
      handleOpenPdf(target);
      return;
    }

    setPayingInvoice(target);
    setSelectedInvoice(target);
    setPaymentStep("select_bank");
    setShowPaymentModal(true);
  };

  // Open PDF Download / Preview
  const handleOpenPdf = (inv?: InvoiceRecord | null) => {
    const target = inv || selectedInvoice || invoices[0];
    if (!target) return;
    setPdfInvoice(target);
    setSelectedInvoice(target);
    setShowPdfModal(true);
  };

  // Directly download HTML/PDF file
  const handleDirectDownloadPdf = (inv: InvoiceRecord) => {
    const displayTotal = (inv.totalAmount * (isIndia ? 1 : country.rateToInr)).toLocaleString(undefined, { maximumFractionDigits: 2 });
    const displayBase = (inv.baseAmount * (isIndia ? 1 : country.rateToInr)).toLocaleString(undefined, { maximumFractionDigits: 2 });
    const displayTax = (inv.gstAmount * (isIndia ? 1 : country.rateToInr)).toLocaleString(undefined, { maximumFractionDigits: 2 });
    
    const htmlContent = `<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <title>Tax Invoice - ${inv.invoiceRef} - Sudarsen Cargo Pvt Ltd</title>
  <style>
    body { font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif; margin: 40px; color: #1e293b; }
    .header { border-bottom: 3px solid #0098db; padding-bottom: 20px; display: flex; justify-content: space-between; align-items: flex-start; }
    .company-title { font-size: 24px; font-weight: bold; color: #0f172a; }
    .company-sub { font-size: 13px; color: #64748b; margin-top: 4px; }
    .tax-badge { background: #0098db; color: #fff; padding: 4px 12px; font-size: 12px; font-weight: bold; border-radius: 4px; }
    .meta-box { margin-top: 24px; display: grid; grid-template-columns: 1fr 1fr; gap: 24px; background: #f8fafc; padding: 16px; border: 1px solid #e2e8f0; border-radius: 8px; }
    .label { font-size: 11px; text-transform: uppercase; color: #64748b; font-weight: 600; }
    .val { font-size: 14px; font-weight: 700; color: #0f172a; margin-top: 2px; }
    table { width: 100%; border-collapse: collapse; margin-top: 28px; }
    th { background: #0f172a; color: #fff; text-align: left; padding: 10px 14px; font-size: 12px; text-transform: uppercase; }
    td { padding: 12px 14px; border-bottom: 1px solid #e2e8f0; font-size: 13px; }
    .total-row { font-weight: bold; background: #f1f5f9; }
    .stamp-box { margin-top: 40px; border: 2px dashed #10b981; background: #ecfdf5; padding: 16px; border-radius: 8px; display: flex; justify-content: space-between; align-items: center; }
    .stamp-text { font-size: 12px; color: #065f46; font-weight: 600; }
  </style>
</head>
<body>
  <div class="header">
    <div>
      <div class="company-title">SUDARSEN CARGO PVT LTD</div>
      <div class="company-sub">Authorized Customs Broker & Multi-modal Logistics Provider</div>
      <div class="company-sub">CIN: U63090MH2018PTC318291 • GSTIN: 27AABCS8891P1Z4 • IEC: 0312098441</div>
      <div class="company-sub">Plot 14, Sector 19, Vashi, Navi Mumbai, Maharashtra 400703, India</div>
    </div>
    <div style="text-align: right;">
      <span class="tax-badge">OFFICIAL GST TAX INVOICE</span>
      <div style="font-size: 18px; font-weight: 800; color: #0098db; margin-top: 8px;">${inv.invoiceRef}</div>
      <div style="font-size: 12px; color: #64748b;">Date: ${inv.invoiceDate}</div>
    </div>
  </div>

  <div class="meta-box">
    <div>
      <div class="label">Shipping Line / Carrier</div>
      <div class="val">${inv.linerName}</div>
      <div class="label" style="margin-top: 10px;">Master Bill of Lading (BL)</div>
      <div class="val" style="color: #0098db;">${inv.blNo}</div>
      <div class="label" style="margin-top: 10px;">Port Location / Terminal</div>
      <div class="val">${inv.location} (${country.name})</div>
    </div>
    <div>
      <div class="label">Billed To Consignee / Agent</div>
      <div class="val">Sudarsen Cargo Pvt Ltd (Ops Account)</div>
      <div class="label" style="margin-top: 10px;">Authorized Officer</div>
      <div class="val">John Lanny (Logistics Manager)</div>
      <div class="label" style="margin-top: 10px;">Payment Status</div>
      <div class="val" style="color: ${inv.paymentStatus === 'Paid' ? '#10b981' : '#e11d48'};">
        ${inv.paymentStatus.toUpperCase()} ${inv.utrNumber ? `• Ref: ${inv.utrNumber}` : ""}
      </div>
    </div>
  </div>

  <table>
    <thead>
      <tr>
        <th>Item Description</th>
        <th>HSN / SAC</th>
        <th>Location</th>
        <th style="text-align: right;">Base (${sym.trim()})</th>
        <th style="text-align: right;">${taxName}</th>
        <th style="text-align: right;">Total (${sym.trim()})</th>
      </tr>
    </thead>
    <tbody>
      <tr>
        <td><strong>${inv.category}</strong><br><small style="color: #64748b;">Liner Tariff Billing for Container ${inv.containerNo || "40HC"}</small></td>
        <td>996719</td>
        <td>${inv.location}</td>
        <td style="text-align: right; font-family: monospace;">${sym}${displayBase}</td>
        <td style="text-align: right; font-family: monospace;">${sym}${displayTax}</td>
        <td style="text-align: right; font-family: monospace; font-weight: bold;">${sym}${displayTotal}</td>
      </tr>
      <tr class="total-row">
        <td colspan="5" style="text-align: right; font-size: 14px;">Total Invoice Amount Due:</td>
        <td style="text-align: right; font-size: 15px; color: #0098db; font-family: monospace;">${sym}${displayTotal}</td>
      </tr>
    </tbody>
  </table>

  <div class="stamp-box">
    <div>
      <div class="stamp-text">✓ ELECTRONICALLY VERIFIED & AUDITED BY NEXLOG AI</div>
      <div style="font-size: 11px; color: #047857; margin-top: 2px;">
        Cryptographic Signatory Hash: SHA256-${Math.random().toString(16).substring(2, 14).toUpperCase()}
      </div>
      <div style="font-size: 11px; color: #64748b; margin-top: 2px;">
        Authorized by John Lanny, Logistics Manager • Sudarsen Cargo Pvt Ltd
      </div>
    </div>
    <div style="text-align: right; font-size: 11px; color: #64748b;">
      <div>Generated at ${new Date().toISOString()}</div>
      <div>Valid for Port Delivery Order (eDO) Issuance</div>
    </div>
  </div>
</body>
</html>`;

    const blob = new Blob([htmlContent], { type: "text/html;charset=utf-8" });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.href = url;
    link.download = `SudarsenCargo_TaxInvoice_${inv.invoiceRef}.html`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);

    onAddToast(
      "success",
      "PDF / Tax Invoice Downloaded",
      `Official GST Tax Invoice for ${inv.invoiceRef} downloaded successfully for Sudarsen Cargo Pvt Ltd.`
    );
  };

  // Complete Netbanking Payment Simulation
  const handleProceedToOtp = () => {
    if (!payingInvoice) return;
    setIsProcessing(true);
    setTimeout(() => {
      setIsProcessing(false);
      setPaymentStep("otp_verify");
    }, 800);
  };

  const handleAuthorizePayment = () => {
    if (!isLoggedIn) {
      onAddToast("error", "Transaction Blocked", "Please log in to authorize bank netbanking payment.");
      onRequireLogin?.();
      return;
    }

    if (!payingInvoice) return;
    setIsProcessing(true);

    setTimeout(() => {
      setIsProcessing(false);
      const generatedUtr = `UTR-${selectedBank.shortName.toUpperCase()}${Date.now().toString().slice(-8)}`;
      const timestamp = new Date().toLocaleString("en-IN", { timeZone: "Asia/Kolkata" }) + " IST";

      setLastPaymentResult({ utr: generatedUtr, timestamp });

      // Update in state
      setInvoices((prev) =>
        prev.map((i) =>
          i.id === payingInvoice.id
            ? {
                ...i,
                paymentStatus: "Paid",
                utrNumber: generatedUtr,
                paidAt: timestamp,
              }
            : i
        )
      );

      // Also update selectedInvoice
      setSelectedInvoice((prev) =>
        prev && prev.id === payingInvoice.id
          ? {
              ...prev,
              paymentStatus: "Paid",
              utrNumber: generatedUtr,
              paidAt: timestamp,
            }
          : prev
      );

      setPaymentStep("success");

      // Celebrate
      confetti({
        particleCount: 80,
        spread: 70,
        origin: { y: 0.6 },
      });

      const displayAmount = (payingInvoice.totalAmount * (isIndia ? 1 : country.rateToInr)).toLocaleString(undefined, { maximumFractionDigits: 2 });
      onAddToast(
        "success",
        "Netbanking Payment Authorized",
        `Payment of ${sym}${displayAmount} via ${selectedBank.name} completed! UTR: ${generatedUtr}.`
      );
    }, 1200);
  };

  const handleCreateInvoice = (e: React.FormEvent) => {
    e.preventDefault();

    if (!isLoggedIn) {
      onAddToast("warning", "Authentication Required", "Please log in to submit new invoice tariff requests.");
      onRequireLogin?.();
      return;
    }

    const newRef = `INV-${linerName.split(" ")[0]}-2026-${Math.floor(1000 + Math.random() * 9000)}`;
    const newInv: InvoiceRecord = {
      id: `inv-${Date.now()}`,
      invoiceRef: newRef,
      invoiceDate: new Date().toISOString().slice(0, 10),
      linerName,
      blNo,
      category,
      location,
      currency: "INR",
      baseAmount,
      gstAmount: gst,
      totalAmount: total,
      paymentStatus: "Pending Payment",
      containerNo: "SUDU" + Math.floor(1000000 + Math.random() * 9000000) + " / 40HC",
    };

    setInvoices([newInv, ...invoices]);
    setSelectedInvoice(newInv);
    onAddToast(
      "success",
      "Invoice Request Registered",
      `Invoice request ${newRef} submitted to ${linerName} for Sudarsen Cargo Pvt Ltd.`
    );
    setView("search");
  };

  const filteredInvoices = invoices.filter((i) => {
    const q = searchQuery.toLowerCase();
    return (
      i.invoiceRef.toLowerCase().includes(q) ||
      i.blNo.toLowerCase().includes(q) ||
      i.linerName.toLowerCase().includes(q) ||
      i.category.toLowerCase().includes(q)
    );
  });

  return (
    <div className="w-full max-w-7xl mx-auto px-3 sm:px-6 py-6 select-none space-y-4">
      {/* Guest Mode Banner when logged out */}
      {!isLoggedIn && (
        <div className="bg-amber-50 border border-amber-200 rounded-xl p-3 text-xs text-amber-900 flex flex-col sm:flex-row sm:items-center justify-between gap-2 shadow-xs">
          <div className="flex items-center gap-2">
            <ShieldAlert className="w-4 h-4 text-amber-600 shrink-0" />
            <span>
              <strong>Read-Only Mode:</strong> Only authenticated logistics managers ({companyName}) can execute netbanking payments, eDO settlements, and invoice requests.
            </span>
          </div>
          <button
            onClick={onRequireLogin}
            className="px-3 py-1 bg-amber-600 hover:bg-amber-700 text-white rounded font-bold cursor-pointer transition-colors text-xs shrink-0"
          >
            Log In to Transact
          </button>
        </div>
      )}

      {/* 1. Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between pb-4 border-b border-slate-300 gap-3">
        <div>
          <h1 className="text-xl sm:text-2xl font-bold text-[#0098db] tracking-tight flex items-center gap-2">
            <CreditCard className="w-6 h-6 text-[#0098db]" />
            <span>{view === "search" ? "Search Invoice & ePayment" : "New Invoice Request"}</span>
          </h1>
          <p className="text-xs text-slate-500 mt-0.5">
            Real-time Liner Tariff Billing, Multi-Bank Netbanking, GST Invoicing & Instant Delivery Order (eDO)
          </p>
        </div>

        <div className="flex items-center gap-2">
          {view === "search" ? (
            <button
              onClick={() => {
                if (!isLoggedIn) {
                  onAddToast(
                    "warning",
                    "Authentication Required",
                    "Please log in to raise new liner invoice tariff requests."
                  );
                  onRequireLogin?.();
                  return;
                }
                setView("create");
              }}
              className="px-4 py-2 bg-[#10b981] hover:bg-[#059669] text-white text-xs font-bold rounded-md shadow-sm flex items-center gap-1.5 transition-all cursor-pointer"
            >
              <Plus className="w-4 h-4 font-bold" />
              <span>NEW INVOICE REQUEST</span>
            </button>
          ) : (
            <button
              onClick={() => setView("search")}
              className="px-4 py-2 bg-slate-200 hover:bg-slate-300 text-slate-800 text-xs font-bold rounded-md flex items-center gap-1.5 transition-all cursor-pointer"
            >
              <ArrowLeft className="w-4 h-4" />
              <span>BACK TO INVOICE SEARCH</span>
            </button>
          )}
        </div>
      </div>

      {/* 2. SEARCH VIEW */}
      {view === "search" && (
        <div className="mt-6 space-y-4">
          {/* Active Invoice Bar with Enabled Action Buttons */}
          <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3 bg-white p-3 rounded-lg border border-slate-200 shadow-xs">
            <div className="flex flex-wrap items-center gap-2">
              {/* Pay Online Button - Fully Enabled */}
              <button
                type="button"
                onClick={() => handleOpenPayment(selectedInvoice)}
                className="px-3.5 py-1.5 text-xs font-bold rounded-md bg-[#10b981] hover:bg-[#059669] active:scale-95 text-white shadow-xs border border-emerald-600 transition-all cursor-pointer flex items-center gap-1.5"
                title="Pay online via Indian Netbanking, RTGS/NEFT VAN, or Corporate UPI"
              >
                <Landmark className="w-3.5 h-3.5" />
                <span>Pay Online (ePayment)</span>
              </button>

              {/* Download PDF Button - Fully Enabled */}
              <button
                type="button"
                onClick={() => handleOpenPdf(selectedInvoice)}
                className="px-3.5 py-1.5 text-xs font-semibold rounded-md bg-white hover:bg-slate-50 active:scale-95 text-slate-700 border border-slate-300 shadow-2xs transition-all cursor-pointer flex items-center gap-1.5"
                title="View & Download Official GST Tax Invoice PDF"
              >
                <Download className="w-3.5 h-3.5 text-slate-500" />
                <span>Download PDF</span>
              </button>

              {/* Current Selection Indicator */}
              {selectedInvoice && (
                <div className="hidden md:flex items-center gap-1.5 ml-2 px-2.5 py-1 bg-sky-50 border border-sky-200 rounded text-[11px] text-sky-800">
                  <span className="font-semibold text-slate-500">Selected:</span>
                  <span className="font-mono font-bold text-[#0098db]">{selectedInvoice.invoiceRef}</span>
                  <span className="text-slate-400">•</span>
                  <span className="font-semibold">{selectedInvoice.linerName}</span>
                  <span className="text-slate-400">•</span>
                  <span className="font-mono font-bold text-emerald-700">
                    {sym}{(selectedInvoice.totalAmount * (isIndia ? 1 : country.rateToInr)).toLocaleString()}
                  </span>
                  <span
                    className={`ml-1 px-1.5 py-0.2 rounded text-[10px] font-bold uppercase ${
                      selectedInvoice.paymentStatus === "Paid"
                        ? "bg-emerald-100 text-emerald-800"
                        : "bg-rose-100 text-rose-800"
                    }`}
                  >
                    {selectedInvoice.paymentStatus}
                  </span>
                </div>
              )}
            </div>

            {/* Search Bar */}
            <div className="flex items-center gap-2">
              <div className="relative flex-1 sm:w-64">
                <input
                  type="text"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  placeholder="SEARCH INVOICE / BL NUMBER"
                  className="w-full pl-8 pr-3 py-1.5 text-xs border border-slate-300 rounded-md focus:outline-hidden focus:border-[#0098db]"
                />
                <Search className="w-3.5 h-3.5 text-slate-400 absolute left-2.5 top-2.5" />
              </div>
            </div>
          </div>

          {/* Table */}
          <div className="bg-white rounded-lg border border-slate-200 shadow-sm overflow-x-auto">
            <table className="w-full text-left border-collapse text-xs">
              <thead>
                <tr className="bg-slate-100 text-slate-700 font-bold border-b border-slate-200 uppercase tracking-tight text-[11px]">
                  <th className="p-3 w-8">#</th>
                  <th className="p-3">Invoice Ref</th>
                  <th className="p-3">Date</th>
                  <th className="p-3">Liner Name</th>
                  <th className="p-3">BL Number</th>
                  <th className="p-3">Category</th>
                  <th className="p-3">Location</th>
                  <th className="p-3 text-right">Base ({sym.trim()})</th>
                  <th className="p-3 text-right">{taxName}</th>
                  <th className="p-3 text-right">Total ({sym.trim()})</th>
                  <th className="p-3 text-center">Status</th>
                  <th className="p-3 text-center">Action</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {filteredInvoices.map((inv, idx) => {
                  const isSelected = selectedInvoice?.id === inv.id;
                  const displayBase = (inv.baseAmount * (isIndia ? 1 : country.rateToInr)).toLocaleString(undefined, { maximumFractionDigits: 2 });
                  const displayTax = (inv.gstAmount * (isIndia ? 1 : country.rateToInr)).toLocaleString(undefined, { maximumFractionDigits: 2 });
                  const displayTotal = (inv.totalAmount * (isIndia ? 1 : country.rateToInr)).toLocaleString(undefined, { maximumFractionDigits: 2 });
                  return (
                    <tr
                      key={inv.id}
                      onClick={() => setSelectedInvoice(inv)}
                      className={`hover:bg-sky-50/70 cursor-pointer transition-colors ${
                        isSelected ? "bg-sky-50/90 ring-1 ring-inset ring-sky-300" : ""
                      }`}
                    >
                      <td className="p-3 text-slate-400 text-[10px]">
                        <div className="flex items-center gap-1.5">
                          <input
                            type="radio"
                            name="selectedInvoiceRadio"
                            checked={isSelected}
                            onChange={() => setSelectedInvoice(inv)}
                            className="text-[#0098db] focus:ring-0 cursor-pointer"
                          />
                          <span>{idx + 1}</span>
                        </div>
                      </td>
                      <td className="p-3 font-mono font-bold text-slate-900">
                        {inv.invoiceRef}
                        {inv.utrNumber && (
                          <div className="text-[10px] text-slate-400 font-mono font-normal">
                            UTR: {inv.utrNumber}
                          </div>
                        )}
                      </td>
                      <td className="p-3 font-mono text-slate-600">{inv.invoiceDate}</td>
                      <td className="p-3 font-bold text-slate-800">{inv.linerName}</td>
                      <td className="p-3 font-mono text-[#0098db] font-bold">{inv.blNo}</td>
                      <td className="p-3 text-slate-700">{inv.category}</td>
                      <td className="p-3 text-slate-600">{inv.location}</td>
                      <td className="p-3 text-right font-mono">{sym}{displayBase}</td>
                      <td className="p-3 text-right font-mono text-slate-500">{sym}{displayTax}</td>
                      <td className="p-3 text-right font-mono font-bold text-slate-900">{sym}{displayTotal}</td>
                      <td className="p-3 text-center">
                        <span
                          className={`px-2 py-0.5 rounded text-[10px] font-bold uppercase ${
                            inv.paymentStatus === "Paid"
                              ? "bg-emerald-100 text-emerald-800"
                              : inv.paymentStatus === "Pending Payment"
                              ? "bg-rose-100 text-rose-800"
                              : "bg-amber-100 text-amber-800"
                          }`}
                        >
                          {inv.paymentStatus}
                        </span>
                      </td>
                      <td className="p-3 text-center">
                        <div className="flex items-center justify-center gap-1.5">
                          {inv.paymentStatus !== "Paid" ? (
                            <button
                              type="button"
                              onClick={(e) => {
                                e.stopPropagation();
                                handleOpenPayment(inv);
                              }}
                              className="px-2.5 py-1 bg-[#10b981] hover:bg-[#059669] text-white rounded text-[11px] font-bold transition-all cursor-pointer shadow-2xs flex items-center gap-1"
                            >
                              <CreditCard className="w-3 h-3" />
                              Pay Now
                            </button>
                          ) : (
                            <button
                              type="button"
                              onClick={(e) => {
                                e.stopPropagation();
                                handleOpenPdf(inv);
                              }}
                              className="px-2 py-1 bg-emerald-50 hover:bg-emerald-100 text-emerald-700 border border-emerald-300 rounded text-[11px] font-semibold transition-all cursor-pointer flex items-center gap-1"
                            >
                              <Check className="w-3 h-3 text-emerald-600" />
                              Cleared (PDF)
                            </button>
                          )}

                          <button
                            type="button"
                            onClick={(e) => {
                              e.stopPropagation();
                              handleOpenPdf(inv);
                            }}
                            className="p-1 text-slate-400 hover:text-slate-700 hover:bg-slate-100 rounded transition-colors"
                            title="Preview / Download Tax Invoice"
                          >
                            <Download className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>

          {/* Table Bottom Pagination & Export Controls (Matching Attachment) */}
          <div className="flex flex-col sm:flex-row items-center justify-between gap-3 text-xs text-slate-500 pt-1">
            <div>
              Showing 1 to {filteredInvoices.length} of {filteredInvoices.length} entries
            </div>
            <div className="flex items-center gap-1.5">
              <button
                type="button"
                onClick={async () => {
                  const exportData = {
                    title: "Liner Tariff Invoices & ePayment Statements",
                    filenamePrefix: "Invoice_Statement_Export",
                    headers: ["#", "INVOICE REF", "DATE", "LINER NAME", "BL NUMBER", "CATEGORY", "LOCATION", "BASE AMOUNT", "GST (18%)", "TOTAL AMOUNT", "STATUS"],
                    rows: filteredInvoices.map((inv, idx) => [
                      idx + 1,
                      inv.invoiceRef,
                      inv.invoiceDate,
                      inv.linerName,
                      inv.blNo,
                      inv.category,
                      inv.location,
                      `${sym}${(inv.baseAmount * (isIndia ? 1 : country.rateToInr)).toLocaleString()}`,
                      `${sym}${(inv.gstAmount * (isIndia ? 1 : country.rateToInr)).toLocaleString()}`,
                      `${sym}${(inv.totalAmount * (isIndia ? 1 : country.rateToInr)).toLocaleString()}`,
                      inv.paymentStatus,
                    ]),
                    metadata: {
                      Company: companyName,
                      Officer: userName,
                      Terminal: country.terminal,
                      Currency: country.currencyCode,
                    },
                  };
                  const ok = await copyTableToClipboard(exportData);
                  if (ok) {
                    onAddToast("success", "Invoices Copied", `Copied ${filteredInvoices.length} invoice records to clipboard.`);
                  } else {
                    onAddToast("error", "Copy Failed", "Unable to copy to clipboard.");
                  }
                }}
                className="px-2.5 py-1 bg-white border border-slate-300 rounded hover:bg-slate-100 text-slate-700 font-semibold cursor-pointer active:scale-95 transition-all shadow-2xs"
                title="Copy table data to clipboard"
              >
                Copy
              </button>
              <button
                type="button"
                onClick={() => {
                  const exportData = {
                    title: "Liner Tariff Invoices & ePayment Statements",
                    filenamePrefix: "Invoice_Statement_Export",
                    headers: ["#", "INVOICE REF", "DATE", "LINER NAME", "BL NUMBER", "CATEGORY", "LOCATION", "BASE AMOUNT", "GST (18%)", "TOTAL AMOUNT", "STATUS"],
                    rows: filteredInvoices.map((inv, idx) => [
                      idx + 1,
                      inv.invoiceRef,
                      inv.invoiceDate,
                      inv.linerName,
                      inv.blNo,
                      inv.category,
                      inv.location,
                      (inv.baseAmount * (isIndia ? 1 : country.rateToInr)).toFixed(2),
                      (inv.gstAmount * (isIndia ? 1 : country.rateToInr)).toFixed(2),
                      (inv.totalAmount * (isIndia ? 1 : country.rateToInr)).toFixed(2),
                      inv.paymentStatus,
                    ]),
                  };
                  downloadTableAsCSV(exportData);
                  onAddToast("success", "CSV Exported", `Downloaded ${filteredInvoices.length} invoice records as CSV.`);
                }}
                className="px-2.5 py-1 bg-white border border-slate-300 rounded hover:bg-slate-100 text-slate-700 font-semibold cursor-pointer active:scale-95 transition-all shadow-2xs"
                title="Download table data as CSV"
              >
                CSV
              </button>
              <button
                type="button"
                onClick={() => {
                  const exportData = {
                    title: "Liner Tariff Invoices & ePayment Statements",
                    filenamePrefix: "Invoice_Statement_Export",
                    headers: ["#", "INVOICE REF", "DATE", "LINER NAME", "BL NUMBER", "CATEGORY", "LOCATION", "BASE AMOUNT", "GST (18%)", "TOTAL AMOUNT", "STATUS"],
                    rows: filteredInvoices.map((inv, idx) => [
                      idx + 1,
                      inv.invoiceRef,
                      inv.invoiceDate,
                      inv.linerName,
                      inv.blNo,
                      inv.category,
                      inv.location,
                      `${sym}${(inv.baseAmount * (isIndia ? 1 : country.rateToInr)).toLocaleString()}`,
                      `${sym}${(inv.gstAmount * (isIndia ? 1 : country.rateToInr)).toLocaleString()}`,
                      `${sym}${(inv.totalAmount * (isIndia ? 1 : country.rateToInr)).toLocaleString()}`,
                      inv.paymentStatus,
                    ]),
                    metadata: {
                      Company: companyName,
                      Officer: userName,
                      Terminal: country.terminal,
                      Currency: country.currencyCode,
                      TotalAmount: `${sym}${filteredInvoices.reduce((s, i) => s + (i.totalAmount * (isIndia ? 1 : country.rateToInr)), 0).toLocaleString()}`,
                    },
                  };
                  openPrintableTableReport(exportData, false);
                  onAddToast("info", "PDF Generated", `Opened printable PDF statement for ${filteredInvoices.length} invoices.`);
                }}
                className="px-2.5 py-1 bg-white border border-slate-300 rounded hover:bg-slate-100 text-slate-700 font-semibold cursor-pointer active:scale-95 transition-all shadow-2xs"
                title="View printable PDF statement"
              >
                PDF
              </button>
              <button
                type="button"
                onClick={() => {
                  const exportData = {
                    title: "Liner Tariff Invoices & ePayment Statements",
                    filenamePrefix: "Invoice_Statement_Export",
                    headers: ["#", "INVOICE REF", "DATE", "LINER NAME", "BL NUMBER", "CATEGORY", "LOCATION", "BASE AMOUNT", "GST (18%)", "TOTAL AMOUNT", "STATUS"],
                    rows: filteredInvoices.map((inv, idx) => [
                      idx + 1,
                      inv.invoiceRef,
                      inv.invoiceDate,
                      inv.linerName,
                      inv.blNo,
                      inv.category,
                      inv.location,
                      `${sym}${(inv.baseAmount * (isIndia ? 1 : country.rateToInr)).toLocaleString()}`,
                      `${sym}${(inv.gstAmount * (isIndia ? 1 : country.rateToInr)).toLocaleString()}`,
                      `${sym}${(inv.totalAmount * (isIndia ? 1 : country.rateToInr)).toLocaleString()}`,
                      inv.paymentStatus,
                    ]),
                    metadata: {
                      Company: companyName,
                      Officer: userName,
                      Terminal: country.terminal,
                    },
                  };
                  openPrintableTableReport(exportData, true);
                  onAddToast("info", "Print Ready", "Opened print dialog for invoice statements.");
                }}
                className="px-2.5 py-1 bg-white border border-slate-300 rounded hover:bg-slate-100 text-slate-700 font-semibold cursor-pointer active:scale-95 transition-all shadow-2xs"
                title="Print invoices statement"
              >
                Print
              </button>
            </div>
          </div>

          {/* User Company Context Card */}
          <div className="bg-slate-50 border border-slate-200 rounded-lg p-3 text-xs text-slate-600 flex flex-col md:flex-row items-start md:items-center justify-between gap-2">
            <div className="flex items-center gap-2">
              <Building2 className="w-4 h-4 text-[#0098db]" />
              <span>
                Billing Account: <strong className="text-slate-800">Sudarsen Cargo Pvt Ltd</strong> • Registered User: <strong className="text-slate-800">John Lanny</strong> (Logistics & Customs Manager)
              </span>
            </div>
            <div className="flex items-center gap-3 text-[11px] text-slate-500 font-mono">
              <span>GSTIN: 27AABCS8891P1Z4</span>
              <span>IEC: 0312098441</span>
              <span>RBI Netbanking Approved</span>
            </div>
          </div>
        </div>
      )}

      {/* 3. CREATE INVOICE FORM */}
      {view === "create" && (
        <form onSubmit={handleCreateInvoice} className="mt-6 space-y-6">
          <div className="bg-white p-5 rounded-lg border border-slate-200 shadow-xs space-y-4">
            <div className="flex items-center justify-between pb-2 border-b border-slate-100">
              <h3 className="text-xs font-bold uppercase tracking-wider text-slate-700">
                Invoice Request Parameters
              </h3>
              <span className="text-[11px] text-slate-500 font-medium">
                Applicant: <strong>Sudarsen Cargo Pvt Ltd</strong> (John Lanny)
              </span>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
              <div>
                <label className="block text-slate-600 font-semibold mb-1">
                  Bill of Lading (BL) Number *
                </label>
                <input
                  type="text"
                  required
                  value={blNo}
                  onChange={(e) => setBlNo(e.target.value)}
                  className="w-full p-2 border border-slate-300 rounded-md font-mono font-bold text-slate-800 focus:border-[#0098db] focus:outline-hidden"
                />
              </div>

              <div>
                <label className="block text-slate-600 font-semibold mb-1">
                  Shipping Line *
                </label>
                <select
                  value={linerName}
                  onChange={(e) => setLinerName(e.target.value)}
                  className="w-full p-2 border border-slate-300 rounded-md bg-white font-semibold text-slate-800 focus:border-[#0098db] focus:outline-hidden"
                >
                  <option value="KMTC LINE">KMTC LINE</option>
                  <option value="MSC MEDITERRANEAN">MSC MEDITERRANEAN</option>
                  <option value="MAERSK LINE">MAERSK LINE</option>
                  <option value="CMA CGM">CMA CGM</option>
                  <option value="HAPAG-LLOYD">HAPAG-LLOYD</option>
                  <option value="OCEAN NETWORK EXPRESS (ONE)">OCEAN NETWORK EXPRESS (ONE)</option>
                </select>
              </div>

              <div>
                <label className="block text-slate-600 font-semibold mb-1">
                  Port Location *
                </label>
                <select
                  value={location}
                  onChange={(e) => setLocation(e.target.value)}
                  className="w-full p-2 border border-slate-300 rounded-md bg-white font-semibold text-slate-800 focus:border-[#0098db] focus:outline-hidden"
                >
                  <option value="Nhava Sheva">Nhava Sheva (JNPT)</option>
                  <option value="Mundra">Mundra Port</option>
                  <option value="Chennai">Chennai Port</option>
                  <option value="Tuticorin">Tuticorin Port</option>
                  <option value="ICD Bangalore">ICD Bangalore</option>
                  <option value="Pipavav">Pipavav Port</option>
                  <option value="Hazira">Hazira Port</option>
                </select>
              </div>

              <div>
                <label className="block text-slate-600 font-semibold mb-1">
                  Invoice Tariff Category *
                </label>
                <select
                  value={category}
                  onChange={(e) => setCategory(e.target.value as any)}
                  className="w-full p-2 border border-slate-300 rounded-md bg-white font-semibold text-slate-800 focus:border-[#0098db] focus:outline-hidden"
                >
                  <option value="Terminal Handling (THC)">Terminal Handling (THC)</option>
                  <option value="Ocean Freight">Ocean Freight</option>
                  <option value="Demurrage & Detention">Demurrage & Detention</option>
                  <option value="DO Issuance Fee">DO Issuance Fee</option>
                </select>
              </div>

              <div>
                <label className="block text-slate-600 font-semibold mb-1">
                  Base Amount ({currCode}) *
                </label>
                <input
                  type="number"
                  required
                  value={baseAmount}
                  onChange={(e) => setBaseAmount(Number(e.target.value))}
                  className="w-full p-2 border border-slate-300 rounded-md font-mono font-bold text-slate-900 focus:border-[#0098db] focus:outline-hidden"
                />
              </div>

              {/* Live Tax Summary */}
              <div className="bg-slate-50 p-3 rounded-lg border border-slate-200 flex flex-col justify-center space-y-1">
                <div className="flex justify-between text-slate-500">
                  <span>Base Amount:</span>
                  <span className="font-mono font-semibold">{sym}{baseAmount.toLocaleString()}</span>
                </div>
                <div className="flex justify-between text-slate-500">
                  <span>{taxName}:</span>
                  <span className="font-mono font-semibold">{sym}{gst.toLocaleString()}</span>
                </div>
                <div className="flex justify-between text-slate-900 font-bold border-t border-slate-200 pt-1">
                  <span>Payable Total:</span>
                  <span className="font-mono text-emerald-600">{sym}{total.toLocaleString()}</span>
                </div>
              </div>
            </div>
          </div>

          <div className="flex items-center justify-between pt-4 border-t border-slate-300">
            <button
              type="button"
              onClick={() => setView("search")}
              className="px-4 py-2 border border-slate-300 text-slate-700 text-xs font-semibold rounded-md hover:bg-slate-100 transition-colors cursor-pointer"
            >
              Cancel
            </button>

            <button
              type="submit"
              className="px-6 py-2.5 bg-[#0098db] hover:bg-[#0086c2] text-white text-xs font-bold rounded-md shadow-md transition-all cursor-pointer"
            >
              Submit Invoice Request
            </button>
          </div>
        </form>
      )}

      {/* 4. NETBANKING & EPAYMENT GATEWAY MODAL */}
      {showPaymentModal && payingInvoice && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-xs p-3 overflow-y-auto animate-in fade-in duration-200">
          <div className="bg-white rounded-xl shadow-2xl border border-slate-300 w-full max-w-2xl overflow-hidden my-6">
            {/* Modal Header */}
            <div className="bg-gradient-to-r from-[#0f172a] via-[#1e293b] to-[#0f172a] text-white px-5 py-4 flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-lg bg-emerald-500/20 border border-emerald-400/30 flex items-center justify-center text-emerald-400">
                  <Landmark className="w-5 h-5" />
                </div>
                <div>
                  <div className="flex items-center gap-2">
                    <span className="text-sm font-bold tracking-tight">NexLog ePayment Gateway</span>
                    <span className="px-2 py-0.5 bg-emerald-500/20 text-emerald-300 border border-emerald-400/30 text-[10px] font-semibold rounded-full">
                      RBI Approved / 256-bit SSL
                    </span>
                  </div>
                  <div className="text-xs text-slate-300">
                    Direct Corporate Netbanking & Liner Tariff Settlement
                  </div>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setShowPaymentModal(false)}
                className="text-slate-400 hover:text-white p-1 rounded-md transition-colors"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Invoice Breakdown Banner */}
            <div className="bg-slate-50 border-b border-slate-200 px-5 py-3 flex flex-wrap items-center justify-between gap-3 text-xs">
              <div>
                <span className="text-slate-500">Invoice:</span>{" "}
                <strong className="font-mono text-slate-900">{payingInvoice.invoiceRef}</strong>{" "}
                <span className="text-slate-400">•</span>{" "}
                <span className="text-slate-500">BL:</span>{" "}
                <strong className="font-mono text-[#0098db]">{payingInvoice.blNo}</strong>
                <div className="text-[11px] text-slate-500 mt-0.5">
                  Liner: <strong>{payingInvoice.linerName}</strong> | Account: <strong>Sudarsen Cargo Pvt Ltd</strong>
                </div>
              </div>
              <div className="text-right">
                <div className="text-[11px] text-slate-500 uppercase font-semibold">Total Payable</div>
                <div className="text-lg font-bold font-mono text-emerald-700">
                  {sym}{(payingInvoice.totalAmount * (isIndia ? 1 : country.rateToInr)).toLocaleString(undefined, { minimumFractionDigits: 2 })}
                </div>
              </div>
            </div>

            {/* Payment Method Tabs */}
            <div className="border-b border-slate-200 bg-white px-5 pt-3 flex gap-4 text-xs font-semibold overflow-x-auto">
              <button
                type="button"
                onClick={() => {
                  setPaymentTab("netbanking");
                  setPaymentStep("select_bank");
                }}
                className={`pb-2.5 border-b-2 flex items-center gap-1.5 transition-colors cursor-pointer ${
                  paymentTab === "netbanking"
                    ? "border-[#0098db] text-[#0098db] font-bold"
                    : "border-transparent text-slate-500 hover:text-slate-800"
                }`}
              >
                <Landmark className="w-4 h-4" />
                <span>Net Banking (All Indian Banks)</span>
              </button>

              <button
                type="button"
                onClick={() => setPaymentTab("van")}
                className={`pb-2.5 border-b-2 flex items-center gap-1.5 transition-colors cursor-pointer ${
                  paymentTab === "van"
                    ? "border-[#0098db] text-[#0098db] font-bold"
                    : "border-transparent text-slate-500 hover:text-slate-800"
                }`}
              >
                <Building className="w-4 h-4" />
                <span>NEFT / RTGS (Virtual Account)</span>
              </button>

              <button
                type="button"
                onClick={() => setPaymentTab("upi")}
                className={`pb-2.5 border-b-2 flex items-center gap-1.5 transition-colors cursor-pointer ${
                  paymentTab === "upi"
                    ? "border-[#0098db] text-[#0098db] font-bold"
                    : "border-transparent text-slate-500 hover:text-slate-800"
                }`}
              >
                <QrCode className="w-4 h-4" />
                <span>UPI / Bharat QR</span>
              </button>

              <button
                type="button"
                onClick={() => setPaymentTab("card")}
                className={`pb-2.5 border-b-2 flex items-center gap-1.5 transition-colors cursor-pointer ${
                  paymentTab === "card"
                    ? "border-[#0098db] text-[#0098db] font-bold"
                    : "border-transparent text-slate-500 hover:text-slate-800"
                }`}
              >
                <CreditCard className="w-4 h-4" />
                <span>Corporate Card</span>
              </button>
            </div>

            {/* TAB CONTENT */}
            <div className="p-5">
              {/* TAB 1: NET BANKING */}
              {paymentTab === "netbanking" && (
                <div>
                  {/* Step 1: Bank Selection */}
                  {paymentStep === "select_bank" && (
                    <div className="space-y-4">
                      <div className="flex items-center justify-between">
                        <label className="text-xs font-bold text-slate-700 uppercase tracking-tight">
                          Select Your Corporate / Retail Bank
                        </label>
                        <span className="text-[11px] text-slate-400">
                          Instant Real-Time Reconciliation
                        </span>
                      </div>

                      {/* Popular Banks Grid */}
                      <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
                        {INDIAN_BANKS.filter((b) => b.popular).map((b) => {
                          const isBankSelected = selectedBank.id === b.id;
                          return (
                            <button
                              key={b.id}
                              type="button"
                              onClick={() => setSelectedBank(b)}
                              className={`p-3 rounded-lg border text-left transition-all cursor-pointer relative flex flex-col justify-between h-20 ${
                                isBankSelected
                                  ? "border-[#0098db] bg-sky-50/70 ring-2 ring-[#0098db]"
                                  : "border-slate-200 hover:border-slate-300 hover:bg-slate-50 bg-white"
                              }`}
                            >
                              <div className="flex items-center justify-between">
                                <span className={`text-[10px] font-black px-1.5 py-0.5 rounded ${b.color}`}>
                                  {b.shortName}
                                </span>
                                {isBankSelected && (
                                  <CheckCircle2 className="w-4 h-4 text-[#0098db]" />
                                )}
                              </div>
                              <div>
                                <div className="text-[11px] font-bold text-slate-800 line-clamp-1">
                                  {b.shortName} Bank
                                </div>
                                <div className="text-[9px] text-slate-500 line-clamp-1">{b.tagline}</div>
                              </div>
                            </button>
                          );
                        })}
                      </div>

                      {/* All Other Banks Dropdown / Search */}
                      <div className="pt-2">
                        <label className="block text-xs font-semibold text-slate-600 mb-1">
                          Or search all other Indian scheduled commercial banks
                        </label>
                        <div className="relative">
                          <input
                            type="text"
                            placeholder="Type bank name (e.g., Union Bank, Canara, Standard Chartered...)"
                            value={bankSearchTerm}
                            onChange={(e) => setBankSearchTerm(e.target.value)}
                            className="w-full pl-8 pr-3 py-2 text-xs border border-slate-300 rounded-md focus:border-[#0098db] focus:outline-hidden"
                          />
                          <Search className="w-3.5 h-3.5 text-slate-400 absolute left-2.5 top-3" />
                        </div>

                        {bankSearchTerm && (
                          <div className="mt-1 max-h-36 overflow-y-auto border border-slate-200 rounded-md bg-white shadow-sm divide-y divide-slate-100">
                            {filteredBanks.map((b) => (
                              <button
                                key={b.id}
                                type="button"
                                onClick={() => {
                                  setSelectedBank(b);
                                  setBankSearchTerm("");
                                }}
                                className="w-full px-3 py-2 text-left text-xs flex items-center justify-between hover:bg-slate-50 cursor-pointer"
                              >
                                <span className="font-semibold text-slate-800">{b.name}</span>
                                <span className="text-[10px] text-slate-400">{b.tagline}</span>
                              </button>
                            ))}
                          </div>
                        )}
                      </div>

                      {/* Bank Details & Credentials Form */}
                      <div className="bg-slate-50 rounded-lg p-3.5 border border-slate-200 space-y-3">
                        <div className="flex items-center gap-2 text-xs font-semibold text-slate-700">
                          <Lock className="w-3.5 h-3.5 text-emerald-600" />
                          <span>
                            Selected: <strong className="text-slate-900">{selectedBank.name}</strong> ({selectedBank.tagline})
                          </span>
                        </div>

                        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
                          <div>
                            <label className="block text-slate-500 font-semibold mb-1">
                              Corporate ID / Customer ID
                            </label>
                            <input
                              type="text"
                              value={corpUserId}
                              onChange={(e) => setCorpUserId(e.target.value)}
                              className="w-full p-2 border border-slate-300 rounded-md font-mono text-slate-800 bg-white"
                            />
                          </div>
                          <div>
                            <label className="block text-slate-500 font-semibold mb-1">
                              User ID / Initiator
                            </label>
                            <input
                              type="text"
                              defaultValue="john.lanny@sudarsencargo.com"
                              className="w-full p-2 border border-slate-300 rounded-md font-mono text-slate-800 bg-white"
                            />
                          </div>
                        </div>

                        <div className="flex items-center justify-between text-[11px] text-slate-500 pt-1">
                          <span>Remitting Entity: <strong>Sudarsen Cargo Pvt Ltd</strong></span>
                          <span>Account: <strong>**** 4819 (Current EXIM A/C)</strong></span>
                        </div>
                      </div>

                      {/* CTA */}
                      <div className="pt-2 flex items-center justify-between">
                        <button
                          type="button"
                          onClick={() => setShowPaymentModal(false)}
                          className="px-4 py-2 border border-slate-300 text-slate-700 text-xs font-semibold rounded-md hover:bg-slate-50"
                        >
                          Cancel
                        </button>

                        <button
                          type="button"
                          disabled={isProcessing}
                          onClick={handleProceedToOtp}
                          className="px-6 py-2.5 bg-[#0098db] hover:bg-[#0086c2] text-white text-xs font-bold rounded-md shadow-md transition-all cursor-pointer flex items-center gap-1.5"
                        >
                          {isProcessing ? (
                            <>
                              <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                              <span>Connecting to Bank Gateway...</span>
                            </>
                          ) : (
                            <>
                              <span>Proceed to {selectedBank.shortName} Portal</span>
                              <ArrowRight className="w-3.5 h-3.5" />
                            </>
                          )}
                        </button>
                      </div>
                    </div>
                  )}

                  {/* Step 2: 3D Secure / Bank OTP Verification */}
                  {paymentStep === "otp_verify" && (
                    <div className="space-y-4">
                      {/* Bank Gateway Emulation Header */}
                      <div className="p-3 rounded-lg border border-slate-200 bg-slate-50 flex items-center justify-between">
                        <div className="flex items-center gap-2">
                          <span className={`text-[10px] font-black px-2 py-0.5 rounded ${selectedBank.color}`}>
                            {selectedBank.shortName}
                          </span>
                          <div>
                            <div className="text-xs font-bold text-slate-900">
                              {selectedBank.name} - Corporate NetBanking 2FA
                            </div>
                            <div className="text-[10px] text-slate-500">
                              Transaction Reference: TXN-{Date.now().toString().slice(-6)}
                            </div>
                          </div>
                        </div>
                        <ShieldCheck className="w-6 h-6 text-emerald-600" />
                      </div>

                      <div className="bg-amber-50 border border-amber-200 rounded-lg p-3 text-xs text-amber-900 space-y-1">
                        <div className="font-bold flex items-center gap-1.5">
                          <AlertCircle className="w-4 h-4 text-amber-600" />
                          <span>Corporate Authorization Required</span>
                        </div>
                        <p className="text-[11px] text-amber-800">
                          A 6-digit High Security Password (OTP) has been dispatched to registered authorizer mobile <strong>+91 98**** 2244</strong> (John Lanny).
                        </p>
                      </div>

                      <div className="space-y-3">
                        <div className="flex justify-between items-center text-xs">
                          <label className="font-semibold text-slate-700">Enter One-Time Password (OTP)</label>
                          <button
                            type="button"
                            onClick={() => setOtpValue("849201")}
                            className="text-[11px] text-[#0098db] hover:underline font-semibold cursor-pointer"
                          >
                            Auto-fill Demo OTP: 849201
                          </button>
                        </div>

                        <div className="flex items-center gap-2">
                          <input
                            type="text"
                            maxLength={6}
                            value={otpValue}
                            onChange={(e) => setOtpValue(e.target.value)}
                            placeholder="6-digit OTP"
                            className="w-48 text-center tracking-widest text-lg font-mono font-bold p-2 border border-slate-300 rounded-md focus:border-[#0098db] focus:outline-hidden"
                          />
                          <span className="text-xs text-slate-400">Expires in 04:58 mins</span>
                        </div>
                      </div>

                      <div className="pt-4 flex items-center justify-between border-t border-slate-200">
                        <button
                          type="button"
                          onClick={() => setPaymentStep("select_bank")}
                          className="px-4 py-2 border border-slate-300 text-slate-700 text-xs font-semibold rounded-md hover:bg-slate-50"
                        >
                          Back to Bank Select
                        </button>

                        <button
                          type="button"
                          disabled={isProcessing}
                          onClick={handleAuthorizePayment}
                          className="px-6 py-2.5 bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold rounded-md shadow-md transition-all cursor-pointer flex items-center gap-1.5"
                        >
                          {isProcessing ? (
                            <>
                              <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                              <span>Authorizing Corporate Payment...</span>
                            </>
                          ) : (
                            <>
                              <Check className="w-4 h-4 font-bold" />
                              <span>Confirm & Authorize {sym}{(payingInvoice.totalAmount * (isIndia ? 1 : country.rateToInr)).toLocaleString()}</span>
                            </>
                          )}
                        </button>
                      </div>
                    </div>
                  )}

                  {/* Step 3: Success Confirmation */}
                  {paymentStep === "success" && lastPaymentResult && (
                    <div className="space-y-4 py-2 text-center">
                      <div className="w-14 h-14 bg-emerald-100 text-emerald-600 rounded-full flex items-center justify-center mx-auto ring-8 ring-emerald-50">
                        <CheckCircle2 className="w-8 h-8" />
                      </div>

                      <div>
                        <h4 className="text-base font-bold text-slate-900">
                          Payment Cleared & Reconciled!
                        </h4>
                        <p className="text-xs text-slate-500 mt-1">
                          Remittance of {sym}{(payingInvoice.totalAmount * (isIndia ? 1 : country.rateToInr)).toLocaleString()} successfully debited via {selectedBank.name}.
                        </p>
                      </div>

                      <div className="bg-slate-50 border border-slate-200 rounded-lg p-4 text-left space-y-2 text-xs">
                        <div className="flex justify-between border-b border-slate-200 pb-2">
                          <span className="text-slate-500">Bank UTR / Transaction No:</span>
                          <span className="font-mono font-bold text-slate-900">{lastPaymentResult.utr}</span>
                        </div>
                        <div className="flex justify-between border-b border-slate-200 pb-2">
                          <span className="text-slate-500">Invoice Reference:</span>
                          <span className="font-mono font-bold text-[#0098db]">{payingInvoice.invoiceRef}</span>
                        </div>
                        <div className="flex justify-between border-b border-slate-200 pb-2">
                          <span className="text-slate-500">Delivery Order (eDO) Token:</span>
                          <span className="font-mono font-bold text-emerald-700">EDO-REL-{Date.now().toString().slice(-6)}</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-slate-500">Timestamp:</span>
                          <span className="font-mono text-slate-600">{lastPaymentResult.timestamp}</span>
                        </div>
                      </div>

                      <div className="flex flex-col sm:flex-row items-center justify-center gap-3 pt-3">
                        <button
                          type="button"
                          onClick={() => {
                            handleDirectDownloadPdf(payingInvoice);
                          }}
                          className="w-full sm:w-auto px-5 py-2.5 bg-[#0098db] hover:bg-[#0086c2] text-white text-xs font-bold rounded-md shadow-md transition-all cursor-pointer flex items-center justify-center gap-1.5"
                        >
                          <Download className="w-4 h-4" />
                          <span>Download Tax Invoice PDF</span>
                        </button>

                        <button
                          type="button"
                          onClick={() => setShowPaymentModal(false)}
                          className="w-full sm:w-auto px-5 py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-800 text-xs font-semibold rounded-md transition-colors"
                        >
                          Done & Return to Invoices
                        </button>
                      </div>
                    </div>
                  )}
                </div>
              )}

              {/* TAB 2: VIRTUAL ACCOUNT / RTGS */}
              {paymentTab === "van" && (
                <div className="space-y-4 text-xs">
                  <div className="p-3 bg-sky-50 border border-sky-200 rounded-lg text-sky-900">
                    <strong className="block font-bold">Liner Dedicated Virtual Account (VAN)</strong>
                    <p className="text-[11px] text-sky-700 mt-0.5">
                      Remit funds directly from your treasury management system via NEFT / RTGS. Auto-matched within 60 seconds.
                    </p>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 bg-slate-50 p-3.5 border border-slate-200 rounded-lg font-mono">
                    <div>
                      <span className="text-[10px] text-slate-500 uppercase font-sans">Beneficiary Name</span>
                      <div className="font-bold text-slate-900">{payingInvoice.linerName} (INDIA) PVT LTD</div>
                    </div>
                    <div>
                      <span className="text-[10px] text-slate-500 uppercase font-sans">Virtual Account Number (VAN)</span>
                      <div className="font-bold text-[#0098db]">ODEXMSC{payingInvoice.blNo.slice(-6)}</div>
                    </div>
                    <div>
                      <span className="text-[10px] text-slate-500 uppercase font-sans">IFSC Code</span>
                      <div className="font-bold text-slate-900">HDFC0000060 (Corporate Banking)</div>
                    </div>
                    <div>
                      <span className="text-[10px] text-slate-500 uppercase font-sans">Exact Amount</span>
                      <div className="font-bold text-emerald-700">
                        {sym}{(payingInvoice.totalAmount * (isIndia ? 1 : country.rateToInr)).toLocaleString()}
                      </div>
                    </div>
                  </div>

                  <div className="pt-3 flex justify-between items-center">
                    <button
                      type="button"
                      onClick={() => setShowPaymentModal(false)}
                      className="px-4 py-2 border border-slate-300 text-slate-700 rounded-md"
                    >
                      Close
                    </button>
                    <button
                      type="button"
                      onClick={() => {
                        handleAuthorizePayment();
                      }}
                      className="px-5 py-2.5 bg-emerald-600 hover:bg-emerald-500 text-white font-bold rounded-md"
                    >
                      Simulate UTR Verification & Clear
                    </button>
                  </div>
                </div>
              )}

              {/* TAB 3: UPI & BHARAT QR */}
              {paymentTab === "upi" && (
                <div className="space-y-4 text-xs text-center py-2">
                  <div className="w-36 h-36 mx-auto bg-white p-2 border-2 border-slate-300 rounded-lg shadow-inner flex items-center justify-center">
                    <div className="w-full h-full bg-slate-900 rounded p-1 flex flex-col items-center justify-center text-white">
                      <QrCode className="w-24 h-24 text-white" />
                      <span className="text-[8px] font-mono tracking-widest mt-1">SCAN VIA ANY UPI APP</span>
                    </div>
                  </div>

                  <div>
                    <div className="text-sm font-bold text-slate-900">
                      Amount: {sym}{(payingInvoice.totalAmount * (isIndia ? 1 : country.rateToInr)).toLocaleString()}
                    </div>
                    <div className="text-[11px] text-slate-500 mt-0.5">
                      VPA: <strong className="font-mono text-slate-800">sudarsencargo.liner@icici</strong>
                    </div>
                  </div>

                  <div className="flex justify-center gap-2 pt-2">
                    <button
                      type="button"
                      onClick={() => {
                        navigator.clipboard?.writeText("sudarsencargo.liner@icici");
                        onAddToast("info", "VPA Copied", "VPA copied to clipboard.");
                      }}
                      className="px-3 py-1.5 border border-slate-300 rounded text-slate-700 text-xs font-semibold flex items-center gap-1 hover:bg-slate-50"
                    >
                      <Copy className="w-3.5 h-3.5" />
                      Copy VPA
                    </button>

                    <button
                      type="button"
                      onClick={() => handleAuthorizePayment()}
                      className="px-4 py-1.5 bg-emerald-600 hover:bg-emerald-500 text-white rounded text-xs font-bold flex items-center gap-1"
                    >
                      <Check className="w-3.5 h-3.5" />
                      Simulate UPI Confirmation
                    </button>
                  </div>
                </div>
              )}

              {/* TAB 4: CORPORATE CARDS */}
              {paymentTab === "card" && (
                <div className="space-y-3 text-xs">
                  <div>
                    <label className="block text-slate-600 font-semibold mb-1">Corporate Card Number</label>
                    <input
                      type="text"
                      defaultValue="4532 •••• •••• 9921"
                      className="w-full p-2 border border-slate-300 rounded font-mono font-bold"
                    />
                  </div>
                  <div className="grid grid-cols-2 gap-3">
                    <div>
                      <label className="block text-slate-600 font-semibold mb-1">Expiry</label>
                      <input type="text" defaultValue="09/29" className="w-full p-2 border border-slate-300 rounded font-mono" />
                    </div>
                    <div>
                      <label className="block text-slate-600 font-semibold mb-1">CVV</label>
                      <input type="password" defaultValue="•••" className="w-full p-2 border border-slate-300 rounded font-mono" />
                    </div>
                  </div>
                  <div>
                    <label className="block text-slate-600 font-semibold mb-1">Cardholder Name</label>
                    <input type="text" defaultValue="JOHN LANNY / SUDARSEN CARGO" className="w-full p-2 border border-slate-300 rounded font-semibold uppercase" />
                  </div>

                  <div className="pt-3 flex justify-between">
                    <button type="button" onClick={() => setShowPaymentModal(false)} className="px-4 py-2 border rounded">Cancel</button>
                    <button
                      type="button"
                      onClick={() => handleAuthorizePayment()}
                      className="px-5 py-2 bg-emerald-600 hover:bg-emerald-500 text-white font-bold rounded"
                    >
                      Pay {sym}{(payingInvoice.totalAmount * (isIndia ? 1 : country.rateToInr)).toLocaleString()}
                    </button>
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
      )}

      {/* 5. PDF TAX INVOICE PREVIEW & DOWNLOAD MODAL */}
      {showPdfModal && pdfInvoice && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-xs p-3 overflow-y-auto animate-in fade-in duration-200">
          <div className="bg-white rounded-xl shadow-2xl border border-slate-300 w-full max-w-3xl overflow-hidden my-6">
            {/* Modal Controls Bar */}
            <div className="bg-[#0f172a] text-white px-5 py-3.5 flex items-center justify-between">
              <div className="flex items-center gap-2">
                <FileText className="w-5 h-5 text-[#0098db]" />
                <span className="font-bold text-sm">Tax Invoice & Delivery Order Receipt Preview</span>
                <span className="text-xs text-slate-400 font-mono">({pdfInvoice.invoiceRef})</span>
              </div>

              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => window.print()}
                  className="px-3 py-1 bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold rounded border border-slate-700 flex items-center gap-1 cursor-pointer"
                  title="Print this invoice"
                >
                  <Printer className="w-3.5 h-3.5" />
                  <span>Print</span>
                </button>

                <button
                  type="button"
                  onClick={() => handleDirectDownloadPdf(pdfInvoice)}
                  className="px-3 py-1 bg-[#0098db] hover:bg-[#0086c2] text-white text-xs font-bold rounded flex items-center gap-1 cursor-pointer shadow-xs"
                >
                  <Download className="w-3.5 h-3.5" />
                  <span>Download HTML/PDF</span>
                </button>

                <button
                  type="button"
                  onClick={() => setShowPdfModal(false)}
                  className="text-slate-400 hover:text-white p-1 rounded transition-colors"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>
            </div>

            {/* Printable Document Sheet */}
            <div className="p-6 bg-slate-50/50 max-h-[75vh] overflow-y-auto">
              <div className="bg-white p-6 rounded-lg border border-slate-200 shadow-sm text-slate-800 text-xs space-y-5">
                {/* Invoice Head */}
                <div className="flex flex-col sm:flex-row justify-between items-start pb-4 border-b-2 border-[#0098db] gap-4">
                  <div>
                    <div className="text-lg font-black text-slate-900 tracking-tight">
                      SUDARSEN CARGO PVT LTD
                    </div>
                    <div className="text-xs text-slate-500 font-medium mt-0.5">
                      Authorized Customs Broker & Multi-modal Logistics Provider
                    </div>
                    <div className="text-[11px] text-slate-500 space-y-0.5 mt-1 font-mono">
                      <div>CIN: U63090MH2018PTC318291 • GSTIN: 27AABCS8891P1Z4</div>
                      <div>IEC No: 0312098441 • PAN: AABCS8891P</div>
                      <div>Plot 14, Sector 19, Vashi, Navi Mumbai, Maharashtra 400703, India</div>
                    </div>
                  </div>

                  <div className="text-left sm:text-right">
                    <span className="px-2.5 py-1 bg-[#0098db] text-white font-bold rounded text-[10px] uppercase tracking-wider">
                      GST TAX INVOICE
                    </span>
                    <div className="text-base font-extrabold text-[#0098db] font-mono mt-1.5">
                      {pdfInvoice.invoiceRef}
                    </div>
                    <div className="text-slate-500 text-[11px]">Date: {pdfInvoice.invoiceDate}</div>
                    <div className="text-[11px] font-semibold text-emerald-600 mt-1 flex items-center justify-start sm:justify-end gap-1">
                      <CheckCircle2 className="w-3.5 h-3.5" />
                      Status: {pdfInvoice.paymentStatus.toUpperCase()}
                    </div>
                  </div>
                </div>

                {/* Billing Info Grid */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 bg-slate-50 p-3.5 rounded-lg border border-slate-200">
                  <div className="space-y-1">
                    <div className="text-[10px] font-bold text-slate-400 uppercase tracking-tight">Billing Party / Carrier</div>
                    <div className="font-bold text-slate-900 text-sm">{pdfInvoice.linerName}</div>
                    <div className="text-slate-600">Port Terminal: <strong>{pdfInvoice.location}</strong></div>
                    <div className="text-slate-600">Master BL: <strong className="font-mono text-[#0098db]">{pdfInvoice.blNo}</strong></div>
                    <div className="text-slate-600">Container: <strong className="font-mono">{pdfInvoice.containerNo || "40HC / DRY"}</strong></div>
                  </div>

                  <div className="space-y-1 sm:text-right">
                    <div className="text-[10px] font-bold text-slate-400 uppercase tracking-tight">Consignee & Customs Broker</div>
                    <div className="font-bold text-slate-900 text-sm">Sudarsen Cargo Pvt Ltd</div>
                    <div className="text-slate-600">Authorized Officer: <strong>John Lanny (Logistics Manager)</strong></div>
                    <div className="text-slate-600">Branch Office: Mumbai Sea Port / JNPT CFS Cell</div>
                    {pdfInvoice.utrNumber && (
                      <div className="text-emerald-700 font-mono font-bold text-[11px] pt-1">
                        Bank UTR: {pdfInvoice.utrNumber}
                      </div>
                    )}
                  </div>
                </div>

                {/* Table of Charges */}
                <div className="border border-slate-200 rounded-md overflow-hidden">
                  <table className="w-full text-left text-xs">
                    <thead className="bg-slate-100 text-slate-700 font-bold border-b border-slate-200">
                      <tr>
                        <th className="p-2.5">Item Description</th>
                        <th className="p-2.5">HSN/SAC</th>
                        <th className="p-2.5 text-right">Base ({sym.trim()})</th>
                        <th className="p-2.5 text-right">{taxName}</th>
                        <th className="p-2.5 text-right">Total ({sym.trim()})</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100">
                      <tr>
                        <td className="p-2.5">
                          <strong className="text-slate-900">{pdfInvoice.category}</strong>
                          <div className="text-[10px] text-slate-500">
                            Terminal handling, EDI messaging & statutory port delivery documentation
                          </div>
                        </td>
                        <td className="p-2.5 font-mono text-slate-600">996719</td>
                        <td className="p-2.5 text-right font-mono">
                          {sym}{(pdfInvoice.baseAmount * (isIndia ? 1 : country.rateToInr)).toLocaleString()}
                        </td>
                        <td className="p-2.5 text-right font-mono text-slate-500">
                          {sym}{(pdfInvoice.gstAmount * (isIndia ? 1 : country.rateToInr)).toLocaleString()}
                        </td>
                        <td className="p-2.5 text-right font-mono font-bold text-slate-900">
                          {sym}{(pdfInvoice.totalAmount * (isIndia ? 1 : country.rateToInr)).toLocaleString()}
                        </td>
                      </tr>
                    </tbody>
                    <tfoot className="bg-slate-50 font-bold border-t border-slate-200">
                      <tr>
                        <td colSpan={4} className="p-2.5 text-right text-slate-700">Total Invoice Amount:</td>
                        <td className="p-2.5 text-right font-mono text-emerald-700 text-sm">
                          {sym}{(pdfInvoice.totalAmount * (isIndia ? 1 : country.rateToInr)).toLocaleString()}
                        </td>
                      </tr>
                    </tfoot>
                  </table>
                </div>

                {/* Signature & Digital Verification */}
                <div className="flex flex-col sm:flex-row items-center justify-between p-3.5 bg-emerald-50/60 border border-emerald-200 rounded-lg gap-3">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-full bg-emerald-100 flex items-center justify-center text-emerald-700 font-bold">
                      <FileCheck className="w-5 h-5" />
                    </div>
                    <div>
                      <div className="font-bold text-emerald-900 text-xs">
                        DIGITALLY VERIFIED TAX DOCUMENT
                      </div>
                      <div className="text-[10px] text-emerald-800">
                        Authorized Signatory: <strong>John Lanny</strong>, Logistics & Customs Manager
                      </div>
                      <div className="text-[9px] text-slate-500 font-mono mt-0.5">
                        SHA-256: 0x99a8f27...38e129 • ISO 9001:2015 EXIM Compliance
                      </div>
                    </div>
                  </div>

                  <div className="text-right">
                    <button
                      type="button"
                      onClick={() => handleDirectDownloadPdf(pdfInvoice)}
                      className="px-4 py-1.5 bg-[#10b981] hover:bg-[#059669] text-white text-xs font-bold rounded shadow-xs flex items-center gap-1.5 cursor-pointer"
                    >
                      <Download className="w-3.5 h-3.5" />
                      <span>Download Receipt</span>
                    </button>
                  </div>
                </div>
              </div>
            </div>

            {/* Modal Footer */}
            <div className="bg-slate-100 px-5 py-3 flex items-center justify-between text-xs border-t border-slate-200">
              <span className="text-slate-500 text-[11px]">
                Valid for Port Boom Barrier & Delivery Order (eDO) Clearances.
              </span>
              <button
                type="button"
                onClick={() => setShowPdfModal(false)}
                className="px-4 py-1.5 bg-white border border-slate-300 text-slate-700 rounded hover:bg-slate-50 font-semibold"
              >
                Close Preview
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Support footer */}
      <div className="mt-8 pt-4 border-t border-slate-200 text-center text-xs text-slate-500 space-y-1">
        <p>
          For immediate assistance and quick query resolution, please email{" "}
          <span className="text-[#0098db] font-semibold">platinunmsupport@nexlogglobal.com</span> or call{" "}
          <span className="text-slate-700 font-bold">+91 8828 822 244</span>.
        </p>
        <p className="text-[11px] text-slate-400">
          © Copyright 2018-2026 EA Technologies. All rights reserved. Sudarsen Cargo Pvt Ltd • NexLog Autonomous EXIM Exchange.
        </p>
      </div>
    </div>
  );
};
