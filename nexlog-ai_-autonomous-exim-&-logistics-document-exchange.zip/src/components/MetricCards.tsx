import React from "react";
import {
  FileText,
  CheckCircle2,
  Clock,
  Zap,
  TrendingUp,
  ShieldCheck,
  ArrowUpRight,
  Sparkles,
} from "lucide-react";

interface MetricCardsProps {
  totalUploaded: number;
  accuracy: number;
  pendingApprovals: number;
  timeSavedHours: number;
  onNavigateToQueue: () => void;
  onNavigateToScanner: () => void;
}

export const MetricCards: React.FC<MetricCardsProps> = ({
  totalUploaded,
  accuracy,
  pendingApprovals,
  timeSavedHours,
  onNavigateToQueue,
  onNavigateToScanner,
}) => {
  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
      {/* Metric 1: Total Documents Uploaded */}
      <div
        onClick={onNavigateToScanner}
        className="group relative p-5 rounded-2xl bg-slate-900/90 border border-slate-800 hover:border-blue-600/50 shadow-lg shadow-black/20 transition-all cursor-pointer overflow-hidden"
      >
        <div className="absolute top-0 right-0 w-24 h-24 bg-blue-500/5 rounded-full blur-2xl group-hover:bg-blue-500/10 transition-all"></div>
        <div className="flex items-center justify-between">
          <span className="text-xs font-semibold text-slate-400 tracking-wider uppercase">
            Total Documents Uploaded
          </span>
          <div className="p-2 rounded-xl bg-blue-950/70 border border-blue-800/60 text-blue-400 group-hover:scale-110 transition-transform">
            <FileText className="w-4 h-4" />
          </div>
        </div>
        <div className="mt-3 flex items-baseline gap-2">
          <span className="text-3xl font-extrabold text-white tracking-tight font-mono">
            {totalUploaded}
          </span>
          <span className="inline-flex items-center text-[11px] font-semibold text-emerald-400 gap-0.5">
            <TrendingUp className="w-3 h-3" />
            +18% today
          </span>
        </div>
        <div className="mt-2 text-xs text-slate-400 flex items-center justify-between">
          <span>B/L, VGM & Form 13 Intakes</span>
          <span className="text-blue-400 flex items-center text-[11px] group-hover:translate-x-0.5 transition-transform">
            Scan new <ArrowUpRight className="w-3 h-3" />
          </span>
        </div>
      </div>

      {/* Metric 2: AI Processing Accuracy */}
      <div className="group relative p-5 rounded-2xl bg-slate-900/90 border border-slate-800 hover:border-emerald-500/50 shadow-lg shadow-black/20 transition-all overflow-hidden">
        <div className="absolute top-0 right-0 w-24 h-24 bg-emerald-500/5 rounded-full blur-2xl group-hover:bg-emerald-500/10 transition-all"></div>
        <div className="flex items-center justify-between">
          <span className="text-xs font-semibold text-slate-400 tracking-wider uppercase">
            AI Processing Accuracy
          </span>
          <div className="p-2 rounded-xl bg-emerald-950/70 border border-emerald-800/60 text-emerald-400 group-hover:scale-110 transition-transform">
            <ShieldCheck className="w-4 h-4" />
          </div>
        </div>
        <div className="mt-3 flex items-baseline gap-2">
          <span className="text-3xl font-extrabold text-white tracking-tight font-mono">
            {accuracy.toFixed(1)}%
          </span>
          <span className="inline-flex items-center text-[11px] font-semibold text-emerald-400 gap-0.5">
            <Sparkles className="w-3 h-3" />
            Gemini 3.8
          </span>
        </div>
        <div className="mt-2 text-xs text-slate-400 flex items-center justify-between">
          <span>Zero hallucinations in manifest</span>
          <span className="text-emerald-400 text-[11px] font-medium">99.8% precision</span>
        </div>
      </div>

      {/* Metric 3: Pending Manager Approvals */}
      <div
        onClick={onNavigateToQueue}
        className={`group relative p-5 rounded-2xl bg-slate-900/90 border transition-all cursor-pointer overflow-hidden ${
          pendingApprovals > 0
            ? "border-amber-600/50 hover:border-amber-500 shadow-amber-950/20"
            : "border-slate-800 hover:border-slate-700"
        }`}
      >
        <div className="absolute top-0 right-0 w-24 h-24 bg-amber-500/5 rounded-full blur-2xl group-hover:bg-amber-500/10 transition-all"></div>
        <div className="flex items-center justify-between">
          <span className="text-xs font-semibold text-slate-400 tracking-wider uppercase">
            Pending Manager Approvals
          </span>
          <div
            className={`p-2 rounded-xl border group-hover:scale-110 transition-transform ${
              pendingApprovals > 0
                ? "bg-amber-950/80 border-amber-800/80 text-amber-400"
                : "bg-slate-800 border-slate-700 text-slate-400"
            }`}
          >
            <Clock className="w-4 h-4" />
          </div>
        </div>
        <div className="mt-3 flex items-baseline gap-2">
          <span className="text-3xl font-extrabold text-white tracking-tight font-mono">
            {pendingApprovals}
          </span>
          {pendingApprovals > 0 && (
            <span className="inline-flex items-center px-1.5 py-0.5 rounded text-[10px] font-bold bg-amber-500/20 text-amber-300 border border-amber-500/40 animate-pulse">
              Needs Gate Sign-Off
            </span>
          )}
        </div>
        <div className="mt-2 text-xs text-slate-400 flex items-center justify-between">
          <span>Human-In-The-Loop gate</span>
          <span className="text-amber-400 flex items-center text-[11px] group-hover:translate-x-0.5 transition-transform">
            Review queue <ArrowUpRight className="w-3 h-3" />
          </span>
        </div>
      </div>

      {/* Metric 4: Estimated Time Saved */}
      <div className="group relative p-5 rounded-2xl bg-slate-900/90 border border-slate-800 hover:border-blue-500/50 shadow-lg shadow-black/20 transition-all overflow-hidden">
        <div className="absolute top-0 right-0 w-24 h-24 bg-blue-500/5 rounded-full blur-2xl group-hover:bg-blue-500/10 transition-all"></div>
        <div className="flex items-center justify-between">
          <span className="text-xs font-semibold text-slate-400 tracking-wider uppercase">
            Estimated Time Saved
          </span>
          <div className="p-2 rounded-xl bg-blue-950/70 border border-blue-800/60 text-blue-400 group-hover:scale-110 transition-transform">
            <Zap className="w-4 h-4" />
          </div>
        </div>
        <div className="mt-3 flex items-baseline gap-2">
          <span className="text-3xl font-extrabold text-white tracking-tight font-mono">
            {timeSavedHours} <span className="text-lg font-medium text-slate-400">Hours</span>
          </span>
          <span className="inline-flex items-center text-[11px] font-semibold text-emerald-400 gap-0.5">
            ~35m / doc
          </span>
        </div>
        <div className="mt-2 text-xs text-slate-400 flex items-center justify-between">
          <span>vs traditional manual desk audit</span>
          <span className="text-blue-400 text-[11px] font-medium">92% faster</span>
        </div>
      </div>
    </div>
  );
};
