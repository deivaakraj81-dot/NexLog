import React, { useState } from "react";
import {
  Search,
  Plus,
  Filter,
  CheckCircle2,
  Ship,
  Truck,
  Building,
  Upload,
  Calendar,
  X,
  FileText,
  AlertCircle,
  Clock,
  Sparkles,
  ShieldAlert,
} from "lucide-react";
import { copyTableToClipboard, downloadTableAsCSV, openPrintableTableReport } from "../utils/tableExport";

export interface CfsRequestRecord {
  id: string;
  requestedDateTime: string;
  linerName: string;
  bookingLine: string;
  mblNo: string;
  mblDate: string;
  vesselVoyage: string;
  manifestVesselVoyage: string;
  pod: string;
  deliveryType: "CFS" | "DPD" | "ICD";
  cfsName: string;
  icdSezName: string;
  status: "Not Submitted" | "Submitted" | "DO Issued" | "Gate Cleared";
}

const INITIAL_CFS_REQUESTS: CfsRequestRecord[] = [
  {
    id: "cfs-1",
    requestedDateTime: "2026-11-03 14:10",
    linerName: "KMTC LINE",
    bookingLine: "KMTC (INDIA) PVT LTD",
    mblNo: "KMTCXGG3096868",
    mblDate: "2026-10-28",
    vesselVoyage: "TIM S 043E",
    manifestVesselVoyage: "TIM S - 043E / JNPT",
    pod: "Nhava Sheva",
    deliveryType: "CFS",
    cfsName: "ALLCARGO LOGISTICS PARK",
    icdSezName: "NA",
    status: "Submitted",
  },
  {
    id: "cfs-2",
    requestedDateTime: "2026-11-03 11:20",
    linerName: "MSC MEDITERRANEAN",
    bookingLine: "MSC AGENCY INDIA",
    mblNo: "MEDUAFW55891",
    mblDate: "2026-10-25",
    vesselVoyage: "MSC OSCAR 2611W",
    manifestVesselVoyage: "MSC OSCAR - 2611W",
    pod: "Mundra",
    deliveryType: "DPD",
    cfsName: "DIRECT PORT DELIVERY (DPD GATE 2)",
    icdSezName: "SEZ MUNDRA ZONE B",
    status: "Gate Cleared",
  },
  {
    id: "cfs-3",
    requestedDateTime: "2026-11-02 16:45",
    linerName: "MAERSK LINE",
    bookingLine: "MAERSK INDIA A/S",
    mblNo: "MAEU98214470",
    mblDate: "2026-10-24",
    vesselVoyage: "MAERSK MC-KINNEY",
    manifestVesselVoyage: "MAERSK MC-KINNEY 2401",
    pod: "Chennai",
    deliveryType: "ICD",
    cfsName: "CONCOR CFS TONDIARPET",
    icdSezName: "ICD BANGALORE WHITEFIELD",
    status: "DO Issued",
  },
  {
    id: "cfs-4",
    requestedDateTime: "2026-11-01 10:05",
    linerName: "ONE LINE",
    bookingLine: "OCEAN NETWORK EXPRESS",
    mblNo: "ONEY7712903",
    mblDate: "2026-10-22",
    vesselVoyage: "ONE OLYMPUS 002W",
    manifestVesselVoyage: "ONE OLYMPUS 002W",
    pod: "Nhava Sheva",
    deliveryType: "CFS",
    cfsName: "GATEWAY DISTRIPARKS CFS",
    icdSezName: "NA",
    status: "Not Submitted",
  },
];

const PRESET_MBLS = [
  { mbl: "KMTCXGG3096868", liner: "KMTC LINE", vessel: "TIM S 043E", pod: "Nhava Sheva", cfs: "ALLCARGO LOGISTICS PARK" },
  { mbl: "MEDUAFW55891", liner: "MSC MEDITERRANEAN", vessel: "MSC OSCAR 2611W", pod: "Mundra", cfs: "DIRECT PORT DELIVERY (DPD)" },
  { mbl: "MAEU98214470", liner: "MAERSK LINE", vessel: "MAERSK MC-KINNEY", pod: "Chennai", cfs: "CONCOR CFS WHITEFIELD" },
];

const CFS_NOMINATIONS = [
  "ALLCARGO LOGISTICS PARK (JNPT)",
  "GATEWAY DISTRIPARKS CFS (DRONAGIRI)",
  "SEABIRD MARINE SERVICES CFS",
  "CONTINENTAL WAREHOUSING (NAVA)",
  "APM TERMINALS CFS (DADRI / JNPT)",
  "CONCOR CONTAINER DEPOT",
  "DIRECT PORT DELIVERY (DPD FACILITY)",
];

interface CfsDpdModuleProps {
  initialView?: "search" | "create";
  onAddToast: (type: "success" | "warning" | "error" | "info", title: string, message: string) => void;
  isLoggedIn?: boolean;
  userName?: string;
  companyName?: string;
  onRequireLogin?: () => void;
}

export const CfsDpdModule: React.FC<CfsDpdModuleProps> = ({
  initialView = "search",
  onAddToast,
  isLoggedIn = true,
  userName = "John Lanny",
  companyName = "Sudarsen Cargo Pvt Ltd",
  onRequireLogin,
}) => {
  const [view, setView] = useState<"search" | "create">(initialView);
  const [requests, setRequests] = useState<CfsRequestRecord[]>(INITIAL_CFS_REQUESTS);
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedRow, setSelectedRow] = useState<CfsRequestRecord | null>(null);

  // Form Fields
  const [mblNo, setMblNo] = useState("KMTCXGG3096868");
  const [linerName, setLinerName] = useState("KMTC LINE");
  const [bookingLine, setBookingLine] = useState("KMTC (INDIA) PVT LTD");
  const [deliveryType, setDeliveryType] = useState<"CFS" | "DPD" | "ICD">("CFS");
  const [cfsName, setCfsName] = useState("ALLCARGO LOGISTICS PARK (JNPT)");
  const [vesselVoyage, setVesselVoyage] = useState("TIM S 043E");
  const [pod, setPod] = useState("Nhava Sheva");
  const [iecCode, setIecCode] = useState("0312098441");
  const [consignee, setConsignee] = useState("Sudarsen Cargo Pvt Ltd");
  const [attachedFileName, setAttachedFileName] = useState("MBL_Copy_KMTCXGG3096868.pdf");

  // Success Confirmation Modal
  const [showSuccessModal, setShowSuccessModal] = useState(false);
  const [submittedRef, setSubmittedRef] = useState("");

  const handleSelectPreset = (p: typeof PRESET_MBLS[0]) => {
    setMblNo(p.mbl);
    setLinerName(p.liner);
    setVesselVoyage(p.vessel);
    setPod(p.pod);
    setCfsName(p.cfs);
    onAddToast("info", "Preset Loaded", `Populated details for MBL ${p.mbl}`);
  };

  const handleSubmitRequest = (e: React.FormEvent) => {
    e.preventDefault();

    if (!isLoggedIn) {
      onAddToast(
        "warning",
        "Authentication Required",
        "Only logged-in users (e.g., John Lanny for Sudarsen Cargo Pvt Ltd) can submit official CFS / DPD nomination requests."
      );
      onRequireLogin?.();
      return;
    }

    if (!mblNo) {
      onAddToast("error", "Validation Error", "MBL Number is mandatory.");
      return;
    }

    const refNo = `CFS-2026-${Math.floor(1000 + Math.random() * 9000)}`;
    const newRecord: CfsRequestRecord = {
      id: `cfs-${Date.now()}`,
      requestedDateTime: new Date().toISOString().replace("T", " ").slice(0, 16),
      linerName,
      bookingLine: bookingLine || `${linerName} AGENCY`,
      mblNo,
      mblDate: new Date().toISOString().slice(0, 10),
      vesselVoyage,
      manifestVesselVoyage: `${vesselVoyage} / ${pod}`,
      pod,
      deliveryType,
      cfsName,
      icdSezName: deliveryType === "ICD" ? "ICD WHITEFIELD" : "NA",
      status: "Submitted",
    };

    setRequests([newRecord, ...requests]);
    setSubmittedRef(refNo);
    setShowSuccessModal(true);
  };

  const filteredRequests = requests.filter((r) => {
    const q = searchQuery.toLowerCase();
    return (
      r.mblNo.toLowerCase().includes(q) ||
      r.linerName.toLowerCase().includes(q) ||
      r.cfsName.toLowerCase().includes(q) ||
      r.vesselVoyage.toLowerCase().includes(q)
    );
  });

  return (
    <div className="w-full max-w-7xl mx-auto px-3 sm:px-6 py-6 select-none space-y-4">
      {/* Guest Mode Banner when logged out */}
      {!isLoggedIn && (
        <div className="bg-amber-50 border border-amber-200 rounded-xl p-3 text-xs text-amber-900 flex flex-col sm:flex-row sm:items-center justify-between gap-2 shadow-xs">
          <div className="flex items-center gap-2">
            <ShieldAlert className="w-4 h-4 text-amber-600 shrink-0" />
            <span>
              <strong>Read-Only Mode:</strong> Only authenticated logistics managers ({companyName}) can submit CFS nominations or direct port delivery passes.
            </span>
          </div>
          <button
            onClick={onRequireLogin}
            className="px-3 py-1 bg-amber-600 hover:bg-amber-700 text-white rounded font-bold cursor-pointer transition-colors text-xs shrink-0"
          >
            Log In to Transact
          </button>
        </div>
      )}

      {/* 1. Module Header Bar (Matching Screenshot 6) */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between pb-4 border-b border-slate-300 gap-3">
        <div>
          <h1 className="text-xl sm:text-2xl font-bold text-[#0098db] tracking-tight flex items-center gap-2">
            <Truck className="w-6 h-6 text-[#0098db]" />
            <span>Search Request for CFS/DPD/ICD</span>
          </h1>
          <p className="text-xs text-amber-700 font-medium mt-0.5">
            Results For: Date: 19-10-2026 To 03-11-2026 • Status: All Direct Port Operations
          </p>
        </div>

        <div className="flex items-center gap-2">
          {view === "search" ? (
            <button
              onClick={() => {
                if (!isLoggedIn) {
                  onAddToast(
                    "warning",
                    "Authentication Required",
                    "Please log in to submit new CFS nomination requests."
                  );
                  onRequireLogin?.();
                  return;
                }
                setView("create");
              }}
              className="px-4 py-2 bg-[#10b981] hover:bg-[#059669] text-white text-xs font-bold rounded-md shadow-sm flex items-center gap-1.5 transition-all cursor-pointer"
            >
              <Plus className="w-4 h-4 font-bold" />
              <span>NEW MBL REQUEST</span>
            </button>
          ) : (
            <button
              onClick={() => setView("search")}
              className="px-4 py-2 bg-slate-200 hover:bg-slate-300 text-slate-800 text-xs font-bold rounded-md flex items-center gap-1.5 transition-all cursor-pointer"
            >
              <span>BACK TO REQUESTS</span>
            </button>
          )}
        </div>
      </div>

      {/* 2. SEARCH / LIST VIEW */}
      {view === "search" && (
        <div className="mt-6 space-y-4">
          {/* Action Toolbar from Screenshot 6 */}
          <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3 bg-white p-3 rounded-lg border border-slate-200 shadow-xs">
            <div className="flex items-center gap-1.5 flex-wrap">
              <button
                disabled={!selectedRow}
                onClick={() => {
                  if (selectedRow) {
                    onAddToast("info", "Edit Request", `Editing CFS allocation for ${selectedRow.mblNo}`);
                    setView("create");
                  }
                }}
                className={`px-3 py-1.5 text-xs font-semibold rounded border transition-colors cursor-pointer ${
                  selectedRow
                    ? "bg-slate-100 hover:bg-slate-200 text-slate-800 border-slate-300"
                    : "bg-slate-50 text-slate-400 border-slate-200 cursor-not-allowed"
                }`}
              >
                ✎ Edit
              </button>
              <button
                disabled={!selectedRow}
                onClick={() => {
                  if (selectedRow) {
                    onAddToast(
                      "info",
                      `Request Details: ${selectedRow.mblNo}`,
                      `Nominated CFS: ${selectedRow.cfsName} | Delivery: ${selectedRow.deliveryType} | Status: ${selectedRow.status}`
                    );
                  }
                }}
                className={`px-3 py-1.5 text-xs font-semibold rounded border transition-colors cursor-pointer ${
                  selectedRow
                    ? "bg-slate-100 hover:bg-slate-200 text-slate-800 border-slate-300"
                    : "bg-slate-50 text-slate-400 border-slate-200 cursor-not-allowed"
                }`}
              >
                🔍 View
              </button>
              <button
                disabled={!selectedRow}
                onClick={() => {
                  if (selectedRow) {
                    onAddToast(
                      "success",
                      "Sent to Shipping Line",
                      `CFS Request for ${selectedRow.mblNo} dispatched to ${selectedRow.linerName}.`
                    );
                  }
                }}
                className={`px-3 py-1.5 text-xs font-semibold rounded border transition-colors cursor-pointer ${
                  selectedRow
                    ? "bg-sky-50 text-sky-700 hover:bg-sky-100 border-sky-300"
                    : "bg-slate-50 text-slate-400 border-slate-200 cursor-not-allowed"
                }`}
              >
                ✈ Send To Liner
              </button>
            </div>

            {/* Search Input matching Screenshot 6 */}
            <div className="flex items-center gap-2">
              <div className="flex items-stretch border border-slate-300 rounded-md overflow-hidden bg-white">
                <input
                  type="text"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  placeholder="SEARCH MBL NUMBER"
                  className="px-3 py-1.5 text-xs focus:outline-hidden w-48 sm:w-64"
                />
                <button
                  type="button"
                  className="bg-[#0098db] text-white px-3 flex items-center justify-center hover:bg-[#0086c2] transition-colors cursor-pointer"
                >
                  <Search className="w-3.5 h-3.5" />
                </button>
              </div>

              <button
                type="button"
                onClick={() => onAddToast("info", "Filters", "Filtered by current financial year & Nhava Sheva / Mundra")}
                className="px-3 py-1.5 border border-slate-300 rounded-md text-xs font-semibold text-slate-700 hover:bg-slate-100 flex items-center gap-1 cursor-pointer"
              >
                <Filter className="w-3.5 h-3.5 text-[#0098db]" />
                <span>More Filters</span>
              </button>
            </div>
          </div>

          {/* Data Table Matching Screenshot 6 */}
          <div className="bg-white rounded-lg border border-slate-200 shadow-sm overflow-x-auto">
            <table className="w-full text-left border-collapse text-xs">
              <thead>
                <tr className="bg-slate-100 text-slate-700 font-bold border-b border-slate-200 uppercase tracking-tight text-[11px]">
                  <th className="p-3 w-8">#</th>
                  <th className="p-3">Requested Date & Time</th>
                  <th className="p-3">Liner Name</th>
                  <th className="p-3">Booking Line</th>
                  <th className="p-3">MBL No.</th>
                  <th className="p-3">MBL Date</th>
                  <th className="p-3">Vessel-Voyage No.</th>
                  <th className="p-3">Manifest Vessel-Voyage</th>
                  <th className="p-3">POD</th>
                  <th className="p-3 text-center">Delivery Type</th>
                  <th className="p-3">CFS Name</th>
                  <th className="p-3">ICD/SEZ Name</th>
                  <th className="p-3 text-center">Status</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {filteredRequests.map((row, idx) => {
                  const isSelected = selectedRow?.id === row.id;
                  return (
                    <tr
                      key={row.id}
                      onClick={() => setSelectedRow(row)}
                      className={`hover:bg-sky-50/60 cursor-pointer transition-colors ${
                        isSelected ? "bg-sky-100/70 font-semibold" : ""
                      }`}
                    >
                      <td className="p-3 text-slate-400 text-[10px]">{idx + 1}</td>
                      <td className="p-3 font-mono text-slate-600">{row.requestedDateTime}</td>
                      <td className="p-3 font-bold text-slate-800">{row.linerName}</td>
                      <td className="p-3 text-slate-600">{row.bookingLine}</td>
                      <td className="p-3 font-mono text-[#0098db] font-bold">{row.mblNo}</td>
                      <td className="p-3 font-mono text-slate-500">{row.mblDate}</td>
                      <td className="p-3 font-mono text-slate-700">{row.vesselVoyage}</td>
                      <td className="p-3 font-mono text-slate-600">{row.manifestVesselVoyage}</td>
                      <td className="p-3 text-slate-700">{row.pod}</td>
                      <td className="p-3 text-center">
                        <span className="px-2 py-0.5 rounded font-bold font-mono text-[10px] bg-slate-200 text-slate-800">
                          {row.deliveryType}
                        </span>
                      </td>
                      <td className="p-3 font-medium text-slate-800 max-w-[180px] truncate">{row.cfsName}</td>
                      <td className="p-3 text-slate-500">{row.icdSezName}</td>
                      <td className="p-3 text-center">
                        <span
                          className={`px-2 py-0.5 rounded text-[10px] font-bold uppercase ${
                            row.status === "Gate Cleared"
                              ? "bg-emerald-100 text-emerald-800"
                              : row.status === "DO Issued"
                              ? "bg-sky-100 text-sky-800"
                              : row.status === "Submitted"
                              ? "bg-blue-100 text-blue-800"
                              : "bg-amber-100 text-amber-800"
                          }`}
                        >
                          {row.status}
                        </span>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>

          {/* Table Footer Controls */}
          <div className="flex flex-col sm:flex-row items-center justify-between gap-3 text-xs text-slate-500 pt-2">
            <div>
              Showing 1 to {filteredRequests.length} of {filteredRequests.length} entries
            </div>
            <div className="flex items-center gap-1.5">
              <button
                type="button"
                onClick={async () => {
                  const exportData = {
                    title: "CFS / DPD / ICD Port Nomination Requests",
                    filenamePrefix: "CFS_Nomination_Export",
                    headers: ["#", "REQUEST DATE", "LINER NAME", "BOOKING LINE", "MBL NO", "VESSEL / VOYAGE", "POD", "DELIVERY TYPE", "NOMINATED CFS", "STATUS"],
                    rows: filteredRequests.map((r, i) => [
                      i + 1,
                      r.requestedDateTime,
                      r.linerName,
                      r.bookingLine,
                      r.mblNo,
                      r.vesselVoyage,
                      r.pod,
                      r.deliveryType,
                      r.cfsName,
                      r.status,
                    ]),
                    metadata: {
                      Company: companyName || "Sudarsen Cargo Pvt Ltd",
                      Officer: userName || "John Lanny",
                      Terminal: "JNPT / Mundra / Tuticorin",
                      TotalRecords: `${filteredRequests.length} Nominations`,
                    },
                  };
                  const ok = await copyTableToClipboard(exportData);
                  if (ok) {
                    onAddToast("success", "Table Copied", `Copied ${filteredRequests.length} CFS requests to clipboard as tab-delimited text.`);
                  } else {
                    onAddToast("error", "Copy Failed", "Unable to copy to clipboard.");
                  }
                }}
                className="px-2.5 py-1 bg-white border border-slate-300 rounded hover:bg-slate-100 text-slate-700 font-semibold cursor-pointer active:scale-95 transition-all shadow-2xs"
                title="Copy table data to clipboard"
              >
                Copy
              </button>
              <button
                type="button"
                onClick={() => {
                  const exportData = {
                    title: "CFS / DPD / ICD Port Nomination Requests",
                    filenamePrefix: "CFS_Nomination_Export",
                    headers: ["#", "REQUEST DATE", "LINER NAME", "BOOKING LINE", "MBL NO", "VESSEL / VOYAGE", "POD", "DELIVERY TYPE", "NOMINATED CFS", "STATUS"],
                    rows: filteredRequests.map((r, i) => [
                      i + 1,
                      r.requestedDateTime,
                      r.linerName,
                      r.bookingLine,
                      r.mblNo,
                      r.vesselVoyage,
                      r.pod,
                      r.deliveryType,
                      r.cfsName,
                      r.status,
                    ]),
                  };
                  downloadTableAsCSV(exportData);
                  onAddToast("success", "CSV Exported", `Downloaded ${filteredRequests.length} CFS requests as CSV file.`);
                }}
                className="px-2.5 py-1 bg-white border border-slate-300 rounded hover:bg-slate-100 text-slate-700 font-semibold cursor-pointer active:scale-95 transition-all shadow-2xs"
                title="Download table data as CSV"
              >
                CSV
              </button>
              <button
                type="button"
                onClick={() => {
                  const exportData = {
                    title: "CFS / DPD / ICD Port Nomination Requests",
                    filenamePrefix: "CFS_Nomination_Export",
                    headers: ["#", "REQUEST DATE", "LINER NAME", "BOOKING LINE", "MBL NO", "VESSEL / VOYAGE", "POD", "DELIVERY TYPE", "NOMINATED CFS", "STATUS"],
                    rows: filteredRequests.map((r, i) => [
                      i + 1,
                      r.requestedDateTime,
                      r.linerName,
                      r.bookingLine,
                      r.mblNo,
                      r.vesselVoyage,
                      r.pod,
                      r.deliveryType,
                      r.cfsName,
                      r.status,
                    ]),
                    metadata: {
                      Company: companyName || "Sudarsen Cargo Pvt Ltd",
                      Officer: userName || "John Lanny",
                      Terminal: "JNPT / Mundra / Tuticorin",
                      TotalRecords: `${filteredRequests.length} Nominations`,
                    },
                  };
                  openPrintableTableReport(exportData, false);
                  onAddToast("info", "PDF Generated", `Opened printable PDF report for ${filteredRequests.length} CFS requests.`);
                }}
                className="px-2.5 py-1 bg-white border border-slate-300 rounded hover:bg-slate-100 text-slate-700 font-semibold cursor-pointer active:scale-95 transition-all shadow-2xs"
                title="View printable PDF report"
              >
                PDF
              </button>
              <button
                type="button"
                onClick={() => {
                  const exportData = {
                    title: "CFS / DPD / ICD Port Nomination Requests",
                    filenamePrefix: "CFS_Nomination_Export",
                    headers: ["#", "REQUEST DATE", "LINER NAME", "BOOKING LINE", "MBL NO", "VESSEL / VOYAGE", "POD", "DELIVERY TYPE", "NOMINATED CFS", "STATUS"],
                    rows: filteredRequests.map((r, i) => [
                      i + 1,
                      r.requestedDateTime,
                      r.linerName,
                      r.bookingLine,
                      r.mblNo,
                      r.vesselVoyage,
                      r.pod,
                      r.deliveryType,
                      r.cfsName,
                      r.status,
                    ]),
                    metadata: {
                      Company: companyName || "Sudarsen Cargo Pvt Ltd",
                      Officer: userName || "John Lanny",
                    },
                  };
                  openPrintableTableReport(exportData, true);
                  onAddToast("info", "Print Ready", "Opened print dialog for CFS nomination report.");
                }}
                className="px-2.5 py-1 bg-white border border-slate-300 rounded hover:bg-slate-100 text-slate-700 font-semibold cursor-pointer active:scale-95 transition-all shadow-2xs"
                title="Print table data"
              >
                Print
              </button>
            </div>
          </div>
        </div>
      )}

      {/* 3. CREATE CFS / DPD / ICD REQUEST FORM */}
      {view === "create" && (
        <form onSubmit={handleSubmitRequest} className="mt-6 space-y-6">
          {/* Autocomplete Quick Preset Banner */}
          <div className="bg-sky-50 border border-sky-200 rounded-lg p-3.5 flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs">
            <div className="flex items-center gap-2">
              <Sparkles className="w-4 h-4 text-[#0098db]" />
              <span className="font-bold text-sky-900">
                Quick Autocomplete Presets (From Manifest):
              </span>
            </div>
            <div className="flex items-center gap-2 flex-wrap">
              {PRESET_MBLS.map((p) => (
                <button
                  key={p.mbl}
                  type="button"
                  onClick={() => handleSelectPreset(p)}
                  className="px-2.5 py-1 bg-white hover:bg-sky-100 text-sky-800 font-mono font-semibold rounded border border-sky-300 shadow-2xs transition-all cursor-pointer"
                >
                  {p.mbl} ({p.liner.split(" ")[0]})
                </button>
              ))}
            </div>
          </div>

          {/* Form Fields */}
          <div className="bg-white p-5 rounded-lg border border-slate-200 shadow-xs space-y-4">
            <h3 className="text-xs font-bold uppercase tracking-wider text-slate-700 pb-2 border-b border-slate-100 flex items-center gap-2">
              <Ship className="w-4 h-4 text-[#0098db]" />
              <span>Bill of Lading & Carrier Details</span>
            </h3>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 text-xs">
              <div>
                <label className="block text-slate-600 font-semibold mb-1">
                  Master BL (MBL) Number *
                </label>
                <input
                  type="text"
                  required
                  value={mblNo}
                  onChange={(e) => setMblNo(e.target.value)}
                  className="w-full p-2 border border-slate-300 rounded-md font-mono font-bold text-slate-800"
                />
              </div>

              <div>
                <label className="block text-slate-600 font-semibold mb-1">
                  Shipping Line *
                </label>
                <input
                  type="text"
                  required
                  value={linerName}
                  onChange={(e) => setLinerName(e.target.value)}
                  className="w-full p-2 border border-slate-300 rounded-md font-semibold text-slate-800"
                />
              </div>

              <div>
                <label className="block text-slate-600 font-semibold mb-1">
                  Booking Line / Agent
                </label>
                <input
                  type="text"
                  value={bookingLine}
                  onChange={(e) => setBookingLine(e.target.value)}
                  className="w-full p-2 border border-slate-300 rounded-md text-slate-800"
                />
              </div>

              <div>
                <label className="block text-slate-600 font-semibold mb-1">
                  Vessel & Voyage
                </label>
                <input
                  type="text"
                  value={vesselVoyage}
                  onChange={(e) => setVesselVoyage(e.target.value)}
                  className="w-full p-2 border border-slate-300 rounded-md font-mono text-slate-800"
                />
              </div>

              <div>
                <label className="block text-slate-600 font-semibold mb-1">
                  Port of Discharge (POD)
                </label>
                <input
                  type="text"
                  value={pod}
                  onChange={(e) => setPod(e.target.value)}
                  className="w-full p-2 border border-slate-300 rounded-md text-slate-800"
                />
              </div>

              <div>
                <label className="block text-slate-600 font-semibold mb-1">
                  Delivery Type *
                </label>
                <div className="flex gap-2">
                  {(["CFS", "DPD", "ICD"] as const).map((t) => (
                    <button
                      key={t}
                      type="button"
                      onClick={() => setDeliveryType(t)}
                      className={`flex-1 py-2 text-xs font-bold rounded border transition-all cursor-pointer ${
                        deliveryType === t
                          ? "bg-[#0098db] text-white border-[#0098db]"
                          : "bg-slate-50 text-slate-700 border-slate-300 hover:bg-slate-100"
                      }`}
                    >
                      {t}
                    </button>
                  ))}
                </div>
              </div>
            </div>
          </div>

          {/* Section 2: Nominated Facility & Consignee */}
          <div className="bg-white p-5 rounded-lg border border-slate-200 shadow-xs space-y-4">
            <h3 className="text-xs font-bold uppercase tracking-wider text-slate-700 pb-2 border-b border-slate-100 flex items-center gap-2">
              <Building className="w-4 h-4 text-[#0098db]" />
              <span>Nominated Delivery Destination & Consignee Entity</span>
            </h3>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
              <div>
                <label className="block text-slate-600 font-semibold mb-1">
                  Nominated CFS / Delivery Facility *
                </label>
                <select
                  value={cfsName}
                  onChange={(e) => setCfsName(e.target.value)}
                  className="w-full p-2 border border-slate-300 rounded-md font-semibold text-slate-800 bg-white"
                >
                  {CFS_NOMINATIONS.map((c) => (
                    <option key={c} value={c}>
                      {c}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-slate-600 font-semibold mb-1">
                  Consignee Import-Export Code (IEC)
                </label>
                <input
                  type="text"
                  value={iecCode}
                  onChange={(e) => setIecCode(e.target.value)}
                  className="w-full p-2 border border-slate-300 rounded-md font-mono text-slate-800"
                />
              </div>

              <div className="sm:col-span-2">
                <label className="block text-slate-600 font-semibold mb-1">
                  Consignee Registered Name
                </label>
                <input
                  type="text"
                  value={consignee}
                  onChange={(e) => setConsignee(e.target.value)}
                  className="w-full p-2 border border-slate-300 rounded-md text-slate-800"
                />
              </div>
            </div>
          </div>

          {/* Section 3: Attachment */}
          <div className="bg-white p-5 rounded-lg border border-slate-200 shadow-xs space-y-3">
            <h3 className="text-xs font-bold uppercase tracking-wider text-slate-700">
              Supporting Documentation
            </h3>
            <div className="p-4 border-2 border-dashed border-slate-300 rounded-lg text-center bg-slate-50">
              <FileText className="w-8 h-8 text-[#0098db] mx-auto mb-2" />
              <div className="text-xs font-semibold text-slate-700">
                Attached Document: <span className="font-mono text-[#0098db]">{attachedFileName}</span>
              </div>
              <p className="text-[11px] text-slate-500 mt-1">
                Scanned via Gemini 3.8 Autonomous OCR Engine • PCS 1x Compliant
              </p>
            </div>
          </div>

          {/* Submit Action */}
          <div className="flex items-center justify-between pt-4 border-t border-slate-300">
            <button
              type="button"
              onClick={() => setView("search")}
              className="px-4 py-2 border border-slate-300 text-slate-700 text-xs font-semibold rounded-md hover:bg-slate-100 transition-colors cursor-pointer"
            >
              Cancel
            </button>

            <button
              type="submit"
              className="px-6 py-2.5 bg-[#10b981] hover:bg-[#059669] text-white text-xs font-bold rounded-md shadow-md flex items-center gap-2 transition-all cursor-pointer"
            >
              <CheckCircle2 className="w-4 h-4 font-bold" />
              <span>Submit CFS/DPD/ICD Request</span>
            </button>
          </div>
        </form>
      )}

      {/* 4. SUCCESS CONFIRMATION MODAL (Matching Screenshot 13) */}
      {showSuccessModal && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-xs z-50 flex items-center justify-center p-4 animate-in fade-in duration-150">
          <div className="bg-white rounded-xl shadow-2xl max-w-md w-full border border-slate-200 overflow-hidden">
            <div className="bg-[#0098db] text-white p-4 flex items-center justify-between">
              <div className="flex items-center gap-2">
                <CheckCircle2 className="w-5 h-5 text-white" />
                <h3 className="text-sm font-bold">CFS Request Registered Successfully</h3>
              </div>
              <button
                onClick={() => {
                  setShowSuccessModal(false);
                  setView("search");
                }}
                className="text-white/80 hover:text-white cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="p-6 space-y-4 text-xs text-slate-700">
              <div className="p-3 bg-emerald-50 border border-emerald-200 rounded-lg">
                <div className="text-[11px] text-emerald-800 font-medium">Reference Authorization Number</div>
                <div className="text-lg font-bold font-mono text-emerald-900">{submittedRef}</div>
              </div>

              <div className="space-y-2">
                <div className="flex justify-between border-b border-slate-100 pb-1.5">
                  <span className="text-slate-500">MBL Number:</span>
                  <span className="font-mono font-bold text-slate-900">{mblNo}</span>
                </div>
                <div className="flex justify-between border-b border-slate-100 pb-1.5">
                  <span className="text-slate-500">Shipping Line:</span>
                  <span className="font-bold text-slate-900">{linerName}</span>
                </div>
                <div className="flex justify-between border-b border-slate-100 pb-1.5">
                  <span className="text-slate-500">Delivery Type:</span>
                  <span className="font-bold text-[#0098db]">{deliveryType}</span>
                </div>
                <div className="flex justify-between border-b border-slate-100 pb-1.5">
                  <span className="text-slate-500">Nominated CFS:</span>
                  <span className="font-semibold text-slate-900 truncate max-w-[220px]">{cfsName}</span>
                </div>
              </div>

              <p className="text-[11px] text-slate-500 leading-relaxed">
                Notification dispatched to shipping line operations and JNPT gate community servers.
              </p>

              <button
                type="button"
                onClick={() => {
                  setShowSuccessModal(false);
                  setView("search");
                  onAddToast("success", "Request Queued", `CFS nomination ${submittedRef} is active.`);
                }}
                className="w-full py-2.5 bg-[#0098db] hover:bg-[#0086c2] text-white font-bold rounded-md shadow-xs cursor-pointer transition-colors text-center"
              >
                OK
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Support footer */}
      <div className="mt-8 pt-4 border-t border-slate-200 text-center text-xs text-slate-500 space-y-1">
        <p>
          For immediate assistance and quick query resolution, please email{" "}
          <span className="text-[#0098db] font-semibold">platinunmsupport@nexlogglobal.com</span> or call{" "}
          <span className="text-slate-700 font-bold">+91 8828 822 244</span>.
        </p>
        <p className="text-[11px] text-slate-400">
          © Copyright 2018-2026 EA Technologies. All rights reserved. NexLog Autonomous EXIM Exchange.
        </p>
      </div>
    </div>
  );
};
