import React, { useState } from "react";
import {
  Search,
  ChevronDown,
  Layers,
  FileText,
  DollarSign,
  Send,
  FileCheck,
  BarChart3,
  CreditCard,
  Settings,
  Sparkles,
  ShieldCheck,
  Ship,
  Truck,
  Anchor,
  X,
  CheckCircle2,
  AlertTriangle,
} from "lucide-react";

export type PortalNavTab =
  | "portal-home"
  | "hbl-search"
  | "hbl-create"
  | "cfs-search"
  | "cfs-create"
  | "invoice-search"
  | "invoice-create"
  | "scanner"
  | "queue"
  | "logs"
  | "architecture"
  | "json-viewer"
  | "public-home";

interface NexLogPortalNavProps {
  currentTab: PortalNavTab;
  onSelectTab: (tab: PortalNavTab) => void;
  onSearchMbl: (query: string) => void;
  onOpenTracking?: (query: string) => void;
  pendingQueueCount: number;
}

export const NexLogPortalNav: React.FC<NexLogPortalNavProps> = ({
  currentTab,
  onSelectTab,
  onSearchMbl,
  onOpenTracking,
  pendingQueueCount,
}) => {
  const [activeDropdown, setActiveDropdown] = useState<string | null>(null);
  const [searchQuery, setSearchQuery] = useState("");
  const [searchType, setSearchType] = useState<string>("EDO DETAILS");
  const [isSearchDropdownOpen, setIsSearchDropdownOpen] = useState(false);
  const [quickSearchResult, setQuickSearchResult] = useState<any | null>(null);

  const sampleSearchIds = [
    { label: "MBL: KMTCXGG3096868", type: "MBL", val: "KMTCXGG3096868", vessel: "TIM S 043E", status: "DO Issued" },
    { label: "MBL: MEDUAFW55891", type: "MBL", val: "MEDUAFW55891", vessel: "MSC OSCAR 2611W", status: "Customs Clear" },
    { label: "CTR: MSKU9182341", type: "Container", val: "MSKU9182341", vessel: "MAERSK MC-KINNEY", status: "Gate-In Granted" },
    { label: "CTR: HLXU7721903", type: "Container", val: "HLXU7721903", vessel: "AL ZUBARA 2644E", status: "VGM Validated" },
  ];

  const handleExecuteSearch = (valToSearch?: string) => {
    const term = (valToSearch !== undefined ? valToSearch : searchQuery).trim();
    if (!term) return;

    // Look for matching sample
    const found = sampleSearchIds.find(
      (s) => s.val.toLowerCase() === term.toLowerCase()
    );

    if (found) {
      setQuickSearchResult(found);
    } else {
      setQuickSearchResult({
        label: `Query: ${term}`,
        type: searchType,
        val: term,
        vessel: "M/V SUDARSEN TITAN",
        status: "Active in Port Gate Queue",
      });
    }

    if (onOpenTracking) {
      onOpenTracking(term);
    }
    onSearchMbl(term);
  };

  return (
    <div className="w-full flex flex-col select-none relative z-20">
      {/* 1. Main Navigation Bar with Menus from Screenshot 1 & 5 */}
      <nav className="w-full bg-[#1e3a5f] text-white px-3 sm:px-6 py-0 flex flex-wrap items-center justify-between shadow-md border-b border-sky-900/60">
        <div className="flex items-center flex-wrap gap-1 sm:gap-2">
          {/* Dashboard (Home) */}
          <button
            onClick={() => {
              setActiveDropdown(null);
              onSelectTab("portal-home");
            }}
            className={`px-3 py-2.5 text-xs font-bold tracking-wide transition-all border-b-2 flex items-center gap-1.5 cursor-pointer ${
              currentTab === "portal-home"
                ? "border-sky-400 text-white bg-white/10"
                : "border-transparent text-slate-200 hover:text-white hover:bg-white/5"
            }`}
          >
            <Ship className="w-3.5 h-3.5 text-sky-400" />
            <span>Dashboard</span>
          </button>

          {/* Requests Dropdown */}
          <div className="relative">
            <button
              onClick={() => setActiveDropdown(activeDropdown === "requests" ? null : "requests")}
              className={`px-3 py-2.5 text-xs font-bold tracking-wide transition-all border-b-2 flex items-center gap-1 cursor-pointer ${
                activeDropdown === "requests"
                  ? "border-sky-400 text-white bg-white/10"
                  : "border-transparent text-slate-200 hover:text-white hover:bg-white/5"
              }`}
            >
              <span>Requests</span>
              <ChevronDown className="w-3.5 h-3.5 opacity-80" />
            </button>

            {activeDropdown === "requests" && (
              <div className="absolute top-full left-0 mt-0.5 w-56 bg-white text-slate-800 rounded-b-md shadow-2xl border border-slate-200 py-1 z-50 animate-in fade-in duration-150">
                <button
                  onClick={() => {
                    setActiveDropdown(null);
                    onSelectTab("cfs-search");
                  }}
                  className="w-full text-left px-4 py-2 text-xs font-semibold hover:bg-sky-50 hover:text-[#0098db] transition-colors flex items-center justify-between cursor-pointer"
                >
                  <span>Request for CFS/DPD/ICD</span>
                  <span className="text-[10px] bg-sky-100 text-[#0098db] px-1.5 py-0.5 rounded font-mono font-bold">New</span>
                </button>
                <button
                  onClick={() => {
                    setActiveDropdown(null);
                    onSelectTab("hbl-search");
                  }}
                  className="w-full text-left px-4 py-2 text-xs font-semibold hover:bg-sky-50 hover:text-[#0098db] transition-colors cursor-pointer"
                >
                  <span>Liner Requests</span>
                </button>
                <button
                  onClick={() => {
                    setActiveDropdown(null);
                    onSelectTab("scanner");
                  }}
                  className="w-full text-left px-4 py-2 text-xs font-semibold hover:bg-sky-50 hover:text-[#0098db] transition-colors flex items-center justify-between cursor-pointer"
                >
                  <span>Terminal AI Gate Request</span>
                  <Sparkles className="w-3 h-3 text-emerald-500" />
                </button>
              </div>
            )}
          </div>

          {/* Invoices Dropdown */}
          <div className="relative">
            <button
              onClick={() => setActiveDropdown(activeDropdown === "invoices" ? null : "invoices")}
              className={`px-3 py-2.5 text-xs font-bold tracking-wide transition-all border-b-2 flex items-center gap-1 cursor-pointer ${
                currentTab === "invoice-search" || currentTab === "invoice-create"
                  ? "border-sky-400 text-white bg-white/10"
                  : "border-transparent text-slate-200 hover:text-white hover:bg-white/5"
              }`}
            >
              <span>Invoices</span>
              <ChevronDown className="w-3.5 h-3.5 opacity-80" />
            </button>

            {activeDropdown === "invoices" && (
              <div className="absolute top-full left-0 mt-0.5 w-52 bg-white text-slate-800 rounded-b-md shadow-2xl border border-slate-200 py-1 z-50 animate-in fade-in duration-150">
                <button
                  onClick={() => {
                    setActiveDropdown(null);
                    onSelectTab("invoice-search");
                  }}
                  className="w-full text-left px-4 py-2 text-xs font-semibold hover:bg-sky-50 hover:text-[#0098db] transition-colors cursor-pointer"
                >
                  <span>Invoice Search</span>
                </button>
                <button
                  onClick={() => {
                    setActiveDropdown(null);
                    onSelectTab("invoice-create");
                  }}
                  className="w-full text-left px-4 py-2 text-xs font-semibold hover:bg-sky-50 hover:text-[#0098db] transition-colors cursor-pointer"
                >
                  <span>New Invoice Request</span>
                </button>
              </div>
            )}
          </div>

          {/* Payments Dropdown */}
          <div className="relative">
            <button
              onClick={() => setActiveDropdown(activeDropdown === "payments" ? null : "payments")}
              className="px-3 py-2.5 text-xs font-bold tracking-wide transition-all border-b-2 border-transparent text-slate-200 hover:text-white hover:bg-white/5 flex items-center gap-1 cursor-pointer"
            >
              <span>Payments</span>
              <ChevronDown className="w-3.5 h-3.5 opacity-80" />
            </button>
            {activeDropdown === "payments" && (
              <div className="absolute top-full left-0 mt-0.5 w-52 bg-white text-slate-800 rounded-b-md shadow-2xl border border-slate-200 py-1 z-50">
                <button
                  onClick={() => {
                    setActiveDropdown(null);
                    onSelectTab("invoice-search");
                  }}
                  className="w-full text-left px-4 py-2 text-xs font-semibold hover:bg-sky-50 hover:text-[#0098db] cursor-pointer"
                >
                  <span>ePayment Dashboard</span>
                </button>
                <button
                  onClick={() => {
                    setActiveDropdown(null);
                    onSelectTab("invoice-search");
                  }}
                  className="w-full text-left px-4 py-2 text-xs font-semibold hover:bg-sky-50 hover:text-[#0098db] cursor-pointer"
                >
                  <span>Payment Receipts & VAN</span>
                </button>
              </div>
            )}
          </div>

          {/* Documents Dropdown */}
          <div className="relative">
            <button
              onClick={() => setActiveDropdown(activeDropdown === "documents" ? null : "documents")}
              className="px-3 py-2.5 text-xs font-bold tracking-wide transition-all border-b-2 border-transparent text-slate-200 hover:text-white hover:bg-white/5 flex items-center gap-1 cursor-pointer"
            >
              <span>Documents</span>
              <ChevronDown className="w-3.5 h-3.5 opacity-80" />
            </button>
            {activeDropdown === "documents" && (
              <div className="absolute top-full left-0 mt-0.5 w-56 bg-white text-slate-800 rounded-b-md shadow-2xl border border-slate-200 py-1 z-50">
                <button
                  onClick={() => {
                    setActiveDropdown(null);
                    onSelectTab("scanner");
                  }}
                  className="w-full text-left px-4 py-2 text-xs font-semibold hover:bg-sky-50 hover:text-[#0098db] flex items-center justify-between cursor-pointer"
                >
                  <span>eDO (Delivery Order)</span>
                  <span className="text-[10px] text-emerald-600 font-bold">Paperless</span>
                </button>
                <button
                  onClick={() => {
                    setActiveDropdown(null);
                    onSelectTab("scanner");
                  }}
                  className="w-full text-left px-4 py-2 text-xs font-semibold hover:bg-sky-50 hover:text-[#0098db] cursor-pointer"
                >
                  <span>eForm 13 / eCart In</span>
                </button>
                <button
                  onClick={() => {
                    setActiveDropdown(null);
                    onSelectTab("scanner");
                  }}
                  className="w-full text-left px-4 py-2 text-xs font-semibold hover:bg-sky-50 hover:text-[#0098db] cursor-pointer"
                >
                  <span>eVGM Certificates</span>
                </button>
              </div>
            )}
          </div>

          {/* HBL Dropdown (Highlighted exactly like Screenshot 5) */}
          <div className="relative">
            <button
              onClick={() => setActiveDropdown(activeDropdown === "hbl" ? null : "hbl")}
              className={`px-3 py-2.5 text-xs font-bold tracking-wide transition-all border-b-2 flex items-center gap-1 cursor-pointer ${
                currentTab === "hbl-search" || currentTab === "hbl-create" || activeDropdown === "hbl"
                  ? "border-sky-400 text-white bg-sky-700/60"
                  : "border-transparent text-slate-200 hover:text-white hover:bg-white/5"
              }`}
            >
              <span>HBL</span>
              <ChevronDown className="w-3.5 h-3.5 opacity-80" />
            </button>

            {activeDropdown === "hbl" && (
              <div className="absolute top-full left-0 mt-0.5 w-64 bg-white text-slate-800 rounded-b-md shadow-2xl border border-slate-200 py-1 z-50 animate-in fade-in duration-150">
                {/* 1. HBL Request (Request) */}
                <button
                  onClick={() => {
                    setActiveDropdown(null);
                    onSelectTab("hbl-search");
                  }}
                  className="w-full text-left px-4 py-2.5 text-xs font-bold text-white bg-[#0098db] hover:bg-[#0086c2] transition-colors cursor-pointer"
                >
                  HBL Request (Request)
                </button>

                {/* 2. Request for CFS/DPD/ICD */}
                <button
                  onClick={() => {
                    setActiveDropdown(null);
                    onSelectTab("cfs-search");
                  }}
                  className="w-full text-left px-4 py-2.5 text-xs font-medium text-slate-700 hover:bg-sky-50 hover:text-[#0098db] transition-colors cursor-pointer"
                >
                  Request for CFS/DPD/ICD
                </button>

                {/* 3. HBL Excel Upload */}
                <button
                  onClick={() => {
                    setActiveDropdown(null);
                    onSelectTab("hbl-create");
                  }}
                  className="w-full text-left px-4 py-2.5 text-xs font-medium text-slate-700 hover:bg-sky-50 hover:text-[#0098db] transition-colors cursor-pointer"
                >
                  HBL Excel Upload
                </button>
              </div>
            )}
          </div>

          {/* AI Autonomous Auditor Dropdown */}
          <div className="relative">
            <button
              onClick={() => setActiveDropdown(activeDropdown === "ai-auditor" ? null : "ai-auditor")}
              className={`px-3 py-2.5 text-xs font-bold tracking-wide transition-all border-b-2 flex items-center gap-1.5 cursor-pointer ${
                currentTab === "scanner" || currentTab === "queue" || currentTab === "logs"
                  ? "border-emerald-400 text-emerald-300 bg-emerald-950/40"
                  : "border-transparent text-emerald-300/90 hover:text-white hover:bg-emerald-950/20"
              }`}
            >
              <Sparkles className="w-3.5 h-3.5 text-emerald-400" />
              <span>AI Auditor</span>
              {pendingQueueCount > 0 && (
                <span className="px-1.5 py-0.2 rounded-full bg-amber-500 text-slate-950 text-[10px] font-black">
                  {pendingQueueCount}
                </span>
              )}
              <ChevronDown className="w-3.5 h-3.5 opacity-80" />
            </button>

            {activeDropdown === "ai-auditor" && (
              <div className="absolute top-full left-0 mt-0.5 w-64 bg-slate-900 text-slate-100 rounded-b-md shadow-2xl border border-slate-700 py-1 z-50">
                <button
                  onClick={() => {
                    setActiveDropdown(null);
                    onSelectTab("scanner");
                  }}
                  className="w-full text-left px-4 py-2.5 text-xs font-medium hover:bg-slate-800 flex items-center justify-between cursor-pointer"
                >
                  <span className="flex items-center gap-2">
                    <Sparkles className="w-3.5 h-3.5 text-emerald-400" />
                    <span>Gemini Intake Scanner</span>
                  </span>
                  <span className="text-[10px] bg-emerald-900 text-emerald-300 px-1.5 py-0.5 rounded font-mono">v3.8</span>
                </button>

                <button
                  onClick={() => {
                    setActiveDropdown(null);
                    onSelectTab("queue");
                  }}
                  className="w-full text-left px-4 py-2.5 text-xs font-medium hover:bg-slate-800 flex items-center justify-between cursor-pointer"
                >
                  <span className="flex items-center gap-2">
                    <ShieldCheck className="w-3.5 h-3.5 text-amber-400" />
                    <span>Manager Approval Queue</span>
                  </span>
                  <span className="text-[10px] bg-amber-500 text-slate-900 px-1.5 py-0.5 rounded font-bold">
                    {pendingQueueCount}
                  </span>
                </button>

                <button
                  onClick={() => {
                    setActiveDropdown(null);
                    onSelectTab("logs");
                  }}
                  className="w-full text-left px-4 py-2.5 text-xs font-medium hover:bg-slate-800 flex items-center gap-2 cursor-pointer"
                >
                  <FileText className="w-3.5 h-3.5 text-blue-400" />
                  <span>Audit & Analytics Log</span>
                </button>

                <button
                  onClick={() => {
                    setActiveDropdown(null);
                    onSelectTab("architecture");
                  }}
                  className="w-full text-left px-4 py-2.5 text-xs font-medium hover:bg-slate-800 flex items-center gap-2 border-t border-slate-800 cursor-pointer"
                >
                  <Layers className="w-3.5 h-3.5 text-sky-400" />
                  <span>System Architecture (Expo)</span>
                </button>
              </div>
            )}
          </div>

          {/* Reports */}
          <button
            onClick={() => {
              setActiveDropdown(null);
              onSelectTab("logs");
            }}
            className="px-3 py-2.5 text-xs font-bold tracking-wide transition-all border-b-2 border-transparent text-slate-200 hover:text-white hover:bg-white/5 cursor-pointer"
          >
            Reports
          </button>

          {/* Public Portal Switch */}
          <button
            onClick={() => {
              setActiveDropdown(null);
              onSelectTab("public-home");
            }}
            className="px-3 py-2.5 text-xs font-bold tracking-wide transition-all border-b-2 border-transparent text-sky-300 hover:text-white hover:bg-white/5 ml-auto flex items-center gap-1 cursor-pointer"
          >
            <span>Public Expo Landing</span>
          </button>
        </div>
      </nav>

      {/* 2. Harbor Backdrop Search Banner (Matching Screenshot 1 & 5) */}
      <div className="relative w-full overflow-hidden bg-slate-900 min-h-[160px] sm:min-h-[190px] flex items-center justify-center border-b border-slate-700/60 shadow-inner">
        {/* Real Container Yard & Gantry Cranes Background Image */}
        <img
          src="/assets/images/harbor_cranes_ship.jpg"
          alt="NexLog Container Harbor with Green Gantry Cranes"
          className="absolute inset-0 w-full h-full object-cover opacity-45 filter brightness-90 contrast-115 scale-102 transition-all duration-700"
        />
        <div className="absolute inset-0 bg-gradient-to-r from-slate-950/90 via-slate-900/65 to-slate-950/90" />

        {/* Search Bar Container */}
        <div className="relative z-10 w-full max-w-4xl px-4 py-4 space-y-2">
          <div className="flex flex-col sm:flex-row items-stretch sm:items-center bg-white rounded-lg shadow-2xl p-1.5 gap-1.5 border-2 border-sky-600/50">
            {/* Input Field */}
            <div className="relative flex-1 flex items-center">
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                onKeyDown={(e) => e.key === "Enter" && handleExecuteSearch()}
                placeholder="ENTER BL NO. / CONTAINER NO. / JOB NO. / VIA NO-CUST CODE"
                className="w-full px-4 py-2.5 text-xs sm:text-sm font-semibold tracking-wide text-slate-800 placeholder-slate-400 bg-transparent focus:outline-hidden"
              />
              {searchQuery && (
                <button
                  onClick={() => setSearchQuery("")}
                  className="p-1 text-slate-400 hover:text-slate-600 mr-2 cursor-pointer"
                >
                  <X className="w-4 h-4" />
                </button>
              )}
            </div>

            {/* Dropdown Selector: Q EDO DETAILS ▾ from Screenshot */}
            <div className="relative">
              <button
                type="button"
                onClick={() => setIsSearchDropdownOpen(!isSearchDropdownOpen)}
                className="w-full sm:w-auto px-4 py-2.5 bg-[#0098db] hover:bg-[#0086c2] text-white text-xs sm:text-sm font-bold flex items-center justify-between sm:justify-center gap-2 rounded-md transition-all shadow-xs cursor-pointer"
              >
                <Search className="w-4 h-4" />
                <span>{searchType}</span>
                <ChevronDown className="w-3.5 h-3.5" />
              </button>

              {isSearchDropdownOpen && (
                <div className="absolute top-full right-0 mt-1 w-56 bg-white rounded-md shadow-xl border border-slate-200 py-1 z-50 text-xs font-semibold text-slate-700">
                  {["EDO DETAILS", "CONTAINER TRACKING", "CFS ALLOCATION", "CUSTOMS PASS"].map((t) => (
                    <button
                      key={t}
                      onClick={() => {
                        setSearchType(t);
                        setIsSearchDropdownOpen(false);
                      }}
                      className="w-full text-left px-4 py-2 hover:bg-sky-50 hover:text-[#0098db] transition-colors cursor-pointer"
                    >
                      {t}
                    </button>
                  ))}
                </div>
              )}
            </div>
          </div>

          {/* Quick preset links under search bar for expo demonstration */}
          <div className="flex flex-wrap items-center justify-between text-[11px] text-slate-300 font-medium px-1 gap-2">
            <div className="flex items-center gap-1.5 flex-wrap">
              <span className="text-sky-400 font-bold">Quick Lookup Samples:</span>
              {sampleSearchIds.map((s) => (
                <button
                  key={s.val}
                  onClick={() => {
                    setSearchQuery(s.val);
                    handleExecuteSearch(s.val);
                  }}
                  className="px-2 py-0.5 rounded bg-slate-900/80 border border-slate-700 hover:border-sky-400 text-slate-200 hover:text-white transition-all font-mono text-[10px] cursor-pointer"
                >
                  {s.label}
                </button>
              ))}
            </div>
            <div className="text-[10px] text-slate-400 hidden md:block">
              Connected to JNPT / Mundra Port Community System (PCS 1x)
            </div>
          </div>

          {/* Quick Search Result Banner if found */}
          {quickSearchResult && (
            <div className="mt-2 p-3 bg-slate-900/95 border border-sky-500 rounded-lg text-xs text-white shadow-xl flex items-center justify-between flex-wrap gap-2 animate-in fade-in duration-200">
              <div className="flex items-center gap-3">
                <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                <div>
                  <span className="font-bold text-sky-400">{quickSearchResult.val}</span>
                  <span className="text-slate-400 mx-2">•</span>
                  <span className="font-mono text-slate-200">{quickSearchResult.vessel}</span>
                  <span className="text-slate-400 mx-2">•</span>
                  <span className="text-emerald-300 font-semibold">{quickSearchResult.status}</span>
                </div>
              </div>
              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => onOpenTracking && onOpenTracking(quickSearchResult.val)}
                  className="px-2.5 py-1 bg-emerald-600 hover:bg-emerald-500 text-white rounded text-[11px] font-bold cursor-pointer flex items-center gap-1 shadow-xs"
                >
                  <Truck className="w-3.5 h-3.5" />
                  <span>Live Tracking</span>
                </button>
                <button
                  onClick={() => onSelectTab("cfs-search")}
                  className="px-2.5 py-1 bg-sky-600 hover:bg-sky-500 text-white rounded text-[11px] font-bold cursor-pointer"
                >
                  CFS Queue
                </button>
                <button
                  onClick={() => setQuickSearchResult(null)}
                  className="p-1 text-slate-400 hover:text-white cursor-pointer"
                >
                  <X className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
